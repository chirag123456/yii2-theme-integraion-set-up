<?php
use yii\helpers\Html;
use common\models\submittal\Submittal;
use common\models\submittal\SubmittalItem;

?> 

<div class="pdf-dealer container">
    <?php 

        foreach ($data as $model) { 
    ?>
            <h4>Submittal Log</h4>
                <table class="table table-bordered" style="font-family: sans-serif;
                border: 1px solid #CECECE;
                border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Project</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">To User</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Regarding</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Phone</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Email</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Date</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Attention</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Review Date Of Resubmittal</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->project->project_name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->user->email ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->re ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->phone ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->email ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->date ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->attention ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->review_date_of_resubmittal ?></td>
                    </tr> 



                </tbody>
            </table>

            <h4>Submittal Log Item</h4>

            <table class="table table-bordered" style="font-family: sans-serif;
            border: 1px solid #CECECE;
            border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">SR.</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Copies</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Date</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Number</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Description</th>
                </tr>
            </thead>
            <tbody>

                <?php 

                $model1 = SubmittalItem::find()->where(['submittal_id' => $model->id ])->all();
                //echo "<pre>"; print_r($model1); exit();
                if(isset($model1) && !empty($model1))
                {
                    foreach ($model1 as $value) {
                        $i = 1;
                        ?>
                        <tr>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $i; ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->copies ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->item_date ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->number ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->description ?></td>
                        </tr> 
                        <?php
                        $i++;
                    }
                }                
                ?>
            </tbody>
        </table>
<?php
}
?>
</div>