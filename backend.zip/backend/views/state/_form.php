<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>

<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update State' : 'Add State'; ?></h4>
      </div>
      <div class="card-body project-management-form">
        <?php
            $form = ActiveForm::begin([
                        'id' => 'state-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
            ]);
            ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-flag" aria-hidden="true"></i> State </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?php
                    echo $form->field($model, 'country_id')->widget(
                            Select2::classname(), [
                        'data' => ArrayHelper::map(\common\models\country\Country::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'country_name'),
                        'options' => ['placeholder' => 'Select Country'],
                    ])->label();
                    ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'state_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter State']) ?>
                </div>
              </div>
              <!--/span-->
            </div>
            
          </div>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['state/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>