<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\components\CommonFunctions;

$this->title = 'Admin'; 
?>
<section class="content-header">
    <h1> Team </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("team/index") ?>" >Team</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Team' : 'Add Team'; ?></li>
    </ol>
</section> 
<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Team' : 'Add Team'; ?></h4>
      </div>
      <div class="card-body project-management-form">
         <?php
            $form = ActiveForm::begin([
                        'id' => 'team-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
            ]);
            ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-group" aria-hidden="true"></i> Team </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();
                ?>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <?php  
                    $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                  ?>
                  <?=
                $form->field($model, 'role_id')->widget(Select2::classname(), [
                    'data' => \yii\helpers\ArrayHelper::map(\common\models\userrole\UserAccess::find()->all(), 'id', 'name'),
                    'options' => ['placeholder' => 'Select Role', 'onchange' => '
                    var role = "'.$role.'";
                                    if($(this).val() == role)
                                    {
                                      $(".custom-item").show();
                                      $(".custom-address").removeClass("col-md-6").addClass("col-md-4");
                                      $(".custom-fax").removeClass("col-md-6").addClass("col-md-4");
                                      $("#teamform-item_id").text(" ");
                                    }
                                    else
                                    {
                                      $(".custom-item").hide();
                                      $(".custom-address").removeClass("col-md-4").addClass("col-md-6");
                                      $(".custom-fax").removeClass("col-md-4").addClass("col-md-6");
                                      $("#teamform-item_id").text(" ");
                            

                                    }
                                    $.post( "' . Yii::$app->urlManager->createUrl('team/set-action?id=') . '"+$(this).val(), function( data ) {
                                      $("#title").html( data );
                                    });
                                '],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ])->label();
                ?>
                </div>
              </div> 
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">

                  <?=
                    $form->field($model, 'user_id')->widget(Select2::classname(), [
                        'data' => \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'email'),
                        'options' => ['placeholder' => 'Please select Role', 
                        'id' => 'title', 'prompt' => 'Please select Role',
                        'onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('team/get-user?id=') . '"+$(this).val(), function( data ) {
                                      var result = $.parseJSON(data);
                                      $("#teamform-email").val(result.model.email);
                                      $("#teamform-phone").val(result.model.contact_number);
                                      $("#teamform-address").val(result.model.address + " " +result.city + " " + result.state + " " + result.model.zipcode);
                                    });
                                    $.post( "' . Yii::$app->urlManager->createUrl('team/set-item?id=') . '"+$(this).val(), function( data ) {
                                      $("#teamform-item_id").html( data );
                                    });
                                '],
                        'pluginOptions' => [
                            'allowClear' => true
                        ],
                    ])->label();
                    ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'business_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Business Name']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'contact_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Contact Name']) ?>
                </div>
              </div>
            </div>

            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'email')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Email','readonly' => true]) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'phone')->textInput(['maxlength' => 12, 'placeholder' => 'Enter Phone Number']) ?>
                </div>
              </div>
            </div>

            <div class="row p-t-20">
              <div class="col-md-6 custom-fax">
                <div class="form-group">
                  <?= $form->field($model, 'fax')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Fax']) ?>
                </div>
              </div>
              <div class="col-md-6 custom-address">
                <div class="form-group">
                  <?= $form->field($model, 'address')->textArea(['maxlength' => 200, 'placeholder' => 'Enter Address']) ?>
                </div>
              </div>
              <div class="col-md-4 custom-item">
                <div class="form-group">
                  <?=
                        $form->field($model, 'item_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model){
                              return $model['cost_code'] .' - '.$model['name'];
                            }),
                            'options' => ['placeholder' => 'Select Item Work'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();?>
                </div>
              </div>
            </div>

          </div>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['team/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php
$this->registerJs("
    $('.custom-item').hide();
");
if(isset($_GET['id']) && !empty($_GET['id']))
{
    if($role == $model->role_id)
    {
      $this->registerJs('
          $(".custom-item").show();
          $(".custom-address").removeClass("col-md-6").addClass("col-md-4");
          $(".custom-fax").removeClass("col-md-6").addClass("col-md-4");
      ');   
    }
}