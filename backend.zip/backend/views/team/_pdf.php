<?php
use yii\helpers\Html;

?>

<div class="pdf-dealer container">
    <h4>Team</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
    border: 1px solid #CECECE;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Project</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Role</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">User</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Business Name</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Contact Name</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Email</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Phone Number</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">FAX</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Address</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item</th>
                
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($data) && !empty($data))
                { 
                    foreach ($data as $model) {
                        //echo "<pre>"; print_r($model); exit();
            ?>
                    <tr>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->project->project_name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->role->name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->user->email ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->business_name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->contact_name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->email ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->phone ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= isset($model->fax) ?  $model->fax : '' ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->address ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= isset($model->item) ?  $model->item->cost_code.' - '.$model->item->name : '' ?></td>
                    </tr> 
            <?php
            }
                }
                else
                {
            ?>
                    <tr>
                        <p> No Data Available</p>     
                    </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>
