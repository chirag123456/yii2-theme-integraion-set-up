<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Client </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("client/index") ?>" >Client</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Client' : 'Add Client'; ?></li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo isset($_GET['id']) ? 'Update Client' : 'Add Client'; ?></h3> 

                    <a href="<?php echo yii\helpers\Url::to(['client/index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>

                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">

                <div class="client-form">
                    <?php
                        $form = ActiveForm::begin([
                                    'id' => 'client-form',
                                    'enableAjaxValidation' => false,
                                    'enableClientValidation' => true,
                                    'options' => ['enctype' => 'multipart/form-data']
                        ]);
                    ?>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class=" col-md-6">
                                <?= $form->field($model, 'client_name')->textInput(['maxlength' => 30]) ?>
                            </div>
                            <div class=" col-md-6">
                                <?= $form->field($model, 'client_phone')->textInput(['maxlength' => 12]) ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            
                            <div class=" col-md-6">
                                <?= $form->field($model, 'client_address')->textArea(['maxlength' => 200]) ?>
                            </div>
                            <?php 
                                if(isset($model->client_email) && !empty($model->client_email))
                                {
                            ?>
                                <div class=" col-md-4">
                                     <?= $form->field($model, 'client_email')->textInput(['maxlength' => 50,'readonly' =>true]) ?>
                                </div>
                            <?php
                                }
                                else
                                {
                            ?>
                                <div class=" col-md-6">
                                     <?= $form->field($model, 'client_email')->textInput(['maxlength' => 50]) ?>
                                </div>
                            <?php
                                }
                            ?>
                        </div>
                        
                        <div class=" col-md-12">
                            <div class="col-md-6 col-md-offset-6">
                                <?php
                                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                                        echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                                } else {
                                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                                }
                                ?>
                                <a href="<?php echo yii\helpers\Url::to(['client/index']) ?>" style = "margin-right: 5px;" class="btn btn-default pull-right"> Cancel</a>
                            </div>
                        </div>
                    </div>
                    <?php ActiveForm::end(); ?>

                </div>
                </div>
         </div>
    </div>
</div>
</section>
<?php 
    if (isset($_GET['id']) && empty($_GET['id'])) {
    $this->registerJs("
    
    $(window).load(function() {
       $('#clientform-client_email').prop('disabled', true); 
    
    });
");
}
?>