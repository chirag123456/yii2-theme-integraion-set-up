<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Client </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("client/index") ?>" >Client</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Client' : 'Add Client'; ?></li>
    </ol>
</section>

<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Client' : 'Add Client'; ?></h4>
      </div>
      <div class="card-body project-management-form">
        <?php
            $form = ActiveForm::begin([
                        'id' => 'client-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data']
            ]);
        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Client </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'client_name')->textInput(['maxlength' => 30, 'placeholder' => 'Enter Client Name']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'client_phone')->textInput(['maxlength' => 12, 'placeholder' => 'Enter Client Phone Number']) ?>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'client_address')->textArea(['maxlength' => 300,'placeholder' => 'Enter Client Address']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                    <?php 
                        if(isset($_GET['id']) && !empty($_GET['id']))
                        {
                            echo $form->field($model, 'client_email')->textInput(['maxlength' => 50,'disabled'=>true ,'placeholder' => 'Enter Client Email']) ;
                        }
                        else
                        {
                            echo $form->field($model, 'client_email')->textInput(['maxlength' => 50,'placeholder' => 'Enter Client Email']) ;
                        }
                    ?>
                  
                </div>
              </div>
              <!--/span-->
            </div>
            
          </div>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['client/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php 
    if (isset($_GET['id']) && empty($_GET['id'])) {
    $this->registerJs("
    
    $(window).load(function() {
       $('#clientform-client_email').prop('disabled', true); 
    
    });
");
}
?>