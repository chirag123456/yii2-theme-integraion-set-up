<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use dosamigos\ckeditor\CKEditor; 
use common\models\projectbudget\ProjectBudgetItemForm;
use common\models\projectbudget\ProjectBudgetItem;
use backend\components\CommonFunctions;

$this->title = 'Project Budget | ' . isset($_GET['id']) ? 'Update' : 'Add';
?>
<section class="content">  
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Project Budget' : 'Add Project Budget'; ?></h4>
      </div> 
      <div class="card-body project-budget-management-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'projectbudget-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
            ]);
                        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Project Budget Information</h3>
            <hr>
            <div class="row p-t-20">
             
              <!--/span-->
              <div class="col-md-12">
                <div class="form-group">
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();
                ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <!--/row-->
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Item Work</h3>
            <hr>
            
              <?php 
                
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  $details = ProjectBudgetItem::find()->where(['project_budget_id'=> $_GET['id']] )->all();  
                }
                
                if(isset($details) && !empty($details))
                {
                    $i = 0 ;
                    foreach ($details as $value) {

                      $projectBudgetItemForm = new ProjectBudgetItemForm();
                      $model1 = $projectBudgetItemForm->getUpdateModel($value);
                      if($i == 0)
                      {
                        $class =  "row add";
                      }
                      else
                      {
                        $class =  "row add".$i;  
                      }
                      
                      ?>
                      <div class="<?= $class?>">
                      <div class="col-md-2">                   
                        <?php
                          $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'name');
                          echo $form->field($model1, 'item_id')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Work','required'=>true,'class' => 'form-control name-change-item']);
                        ?> 
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'cost')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Item Work Cost','class' => 'form-control custom-val name-change-cost','onKeyUp'=>'return calculateSum(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','required'=>true]) ?>
                      </div>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'comment')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Comment','required'=>true,'class' => 'form-control name-change-comment']) ?>
                      </div>
                      <div class=" col-md-2">
                        <?php 
                            $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                            $dataPost = \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            });                          
                            echo $form->field($model1, 'sub_contractor_id')
                            ->dropDownList(
                            $dataPost ,['id' => 'title111', 'prompt' => 'Select Sub Contractor','required'=>true,'class' => 'form-control name-change-subcontractor'])->label('Sub Contractor');
                        ?>                       
                    </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'sub_contractor_estimate_cost')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Sub Contractor Estimate Cost','class' => 'form-control custom-val-contractor name-change-contractor-cost','onKeyUp'=>'return calculateSumOfContractor(this.id);','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div>  
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                    </div>
                <?php $i++;    } 
                }
                else
                {
                  $model1 = new ProjectBudgetItemForm();
                ?>
                <div class="row add">  
                  <div class="col-md-2">                   
                    <?php
                      $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'name');
                        echo $form->field($model1, 'item_id[]')
                        ->dropDownList(
                        $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Work','required'=>true]);
                      ?> 
                  </div>
                  <div class="col-md-2"> 
                      <?php echo $form->field($model1, 'cost[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Item Work Cost','class' => 'form-control custom-val','onKeyUp'=>'return calculateSum(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','required'=>true]) ?>
                  </div>
                  <div class="col-md-3"> 
                      <?php echo $form->field($model1, 'comment[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Comment','required'=>true]) ?>
                  </div>
                  <div class=" col-md-2">
                    <?php 
                        $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                        $dataPost = \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                            return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                        });
                        echo $form->field($model1, 'sub_contractor_id[]')
                        ->dropDownList(
                        $dataPost ,['id' => 'title111', 'prompt' => 'Select Sub Contractor','required'=>true])->label('Sub Contractor');;
                    ?>
                                               
                  </div>
                  <div class="col-md-2"> 
                      <?php echo $form->field($model1, 'sub_contractor_estimate_cost[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Sub Contractor Estimate Cost','class' => 'form-control custom-val-contractor','onKeyUp'=>'return calculateSumOfContractor(this.id);','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                  </div>  
                  <div class="col-md-1" style="    margin-top: 26px;">                
                    <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 
                  </div>
                <?php  
                }
              ?>    
            </div>
            <div class="a" id="l"></div>
            <a style="cursor: pointer; margin-right: 36px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>

            <h3 class="box-title m-t-40"><i class="fa fa-usd" aria-hidden="true"></i> Costing </h3>
            <hr>
            <div class="row"> 
              <div class="col-md-6">
               <?php echo $form->field($model, 'sub_contractor_total_cost')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Sub Contractor Total Cost','readonly'=>true]) ?>
              </div>
              <div class="col-md-6">
                <?php echo $form->field($model, 'pb_total_cost')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Project Budget Total Cost','readonly'=>true]) ?>
              </div>              
            </div>
            
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Project Budget Description</h3>
            <hr>
            <div class="row">
              <div class=" col-md-12"> 
                  <?= $form->field($model, 'pb_desc')->widget(CKEditor::className(), [
                          'options' => ['rows' => 6],
                          'preset' => 'basic'
                  ]) ?>
              </div>
              
            </div>
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Conditions and Exclusions </h3>
            <hr style="border-top: 2px solid #ccc !important;">
                  <ul class="conditions-and-exclusions"> 
                    <li>Excludes "Service or Warranty" on existing fixtures and equipment.</li>
                    <li>Excludes cost of building permit, tap and utility fees.</li>
                    <li>NIC means not in contract.</li>
                    <li>Scope of work is based upon.</li>
                  </ul>             
          
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['project-budget/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php
$this->registerJs("
  $('.name-change-cost').attr('name', 'ProjectBudgetItemForm[cost][]');
  $('.name-change-item').attr('name', 'ProjectBudgetItemForm[item_id][]');
  $('.name-change-comment').attr('name', 'ProjectBudgetItemForm[comment][]');
  $('.name-change-subcontractor').attr('name', 'ProjectBudgetItemForm[sub_contractor_id][]');
  $('.name-change-contractor-cost').attr('name', 'ProjectBudgetItemForm[sub_contractor_estimate_cost][]');
        $('.addd').click(function(){
          $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
          //$('.xcas').find(':input').val('');
          calculateSum();
          calculateSumOfContractor();
        });   
        $('.remove_daterow').click(function(){      
          $(this).closest('.xcas').remove();
          calculateSum();
          calculateSumOfContractor();
        });   
           
  ");
?>
<script type="text/javascript">
  function calculateSum() {
          var calculated_total_sum = 0;
      
          $('.custom-val').each(function () {
             var get_textbox_value = $(this).val();
             if ($.isNumeric(get_textbox_value)) {
                calculated_total_sum += parseFloat(get_textbox_value);
              }                  
            });
          $('#projectbudgetform-pb_total_cost').val(calculated_total_sum);       
        }
  function calculateSumOfContractor() {
          var calculated_total_sum = 0;
      
          $('.custom-val-contractor').each(function () {
             var get_textbox_value = $(this).val();
             if ($.isNumeric(get_textbox_value)) {
                calculated_total_sum += parseFloat(get_textbox_value);
              }                  
            });
          $('#projectbudgetform-sub_contractor_total_cost').val(calculated_total_sum);       
        }
</script> 
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>