<?php
use yii\helpers\Html;

?>

<div class="pdf-dealer container">
    <h4>Project Budget</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
    border: 1px solid #CECECE;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CDCDCD;
                    vertical-align: middle;
                    font-size: 12px ">Project Name</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Sub Contractor Total Cost</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Project Budget Total Cost</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model) && !empty($model))
                {
                    foreach ($model as $value) {
            ?>
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['project_name'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['sub_contractor_total_cost'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['pb_total_cost'] ?></td>
                    </tr> 
            <?php
                    }
                }
                else
                {
            ?>
                    <tr>
                        <p> No Data Available</p>     
                    </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>

<div class="pdf-dealer container">
    <h4>Project Budget Item</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Work Name</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Work Cost</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Comment</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Sub Contractor</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Sub Contractor Cost</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model1) && !empty($model1))
                {
                    foreach ($model1 as $value) {
            ?>
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['name'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['cost'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['comment'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['first_name'].' '.$value['last_name'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['sub_contractor_estimate_cost'] ?></td>
                    </tr> 
            <?php
                    }
                }
                else
                {
            ?>
                <tr>
                    <p> No Data Available</p>     
                </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>