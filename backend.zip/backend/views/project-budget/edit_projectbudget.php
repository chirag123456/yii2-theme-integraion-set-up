<?php

use yii\helpers\Html;
?>

<section class="content-header">
      <h1>
        Project Budget
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
       <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("project-budget/index") ?>" >Project Budget</a></li>
        <li class="active">Edit Project Budget</li>
      </ol>
  </section>
 <?= $this->render('_form', [
                            'model' => $model,
                        ]) ?>
