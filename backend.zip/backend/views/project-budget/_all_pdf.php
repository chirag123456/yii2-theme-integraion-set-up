<?php
use yii\helpers\Html;
use common\models\projectbudget\ProjectBudget;
use common\models\projectbudget\ProjectBudgetItem;

?> 

<div class="pdf-dealer container">
    <?php 
        foreach ($data as $val) {
    ?>
    <?php 
                $porojectbudget = new ProjectBudget();
                $model = $porojectbudget->getProjectBudgetData($val->id);
                if(isset($model) && !empty($model))
                {
                    foreach ($model as $value) {
            ?>
    <h4>Project Budget</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CDCDCD;
                    vertical-align: middle;
                    font-size: 12px ">Project #ID</th>
                <th style="padding: 5px;
                    border: 1px solid #CDCDCD;
                    vertical-align: middle;
                    font-size: 12px ">Project Name</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Sub Contractor Total Cost</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Project Budget Total Cost</th>
            </tr>
        </thead>
        <tbody>
            
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['pb_id'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['project_name'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['sub_contractor_total_cost'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['pb_total_cost'] ?></td>
                    </tr> 
            
                   
            
        </tbody>
    </table>

    <h4>Project Budget Item</h4>

    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Work Name</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Work Cost</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Comment</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Sub Contractor</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Sub Contractor Cost</th>
            </tr>
        </thead>
        <tbody>

            <?php 
                $model1 = ProjectBudgetItem::find()->where(['project_budget_id' =>$val->id ])->all();
                //$model1 = $porojectbudget->getProjectBudgetItemData($value['pb_id']);
                if(isset($model1) && !empty($model1))
                {
                    foreach ($model1 as $value) {
            ?>
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value->item->name ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value->cost ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value->comment ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value->subcontractor->first_name.' '.$value->subcontractor->last_name ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value->sub_contractor_estimate_cost ?></td>
                    </tr> 
            <?php
                    }
                }
                
            ?>               
           
        </tbody>
    </table>
     <?php
                    }
                }
                
            ?>
    <?php
            
        }
    ?>
</div>