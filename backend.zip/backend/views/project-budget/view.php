<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Project Budget </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project-budget/index") ?>" >Project Budget</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Project Budget Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [

                                
                                
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by last name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'sub_contractor_total_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'pb_total_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'pb_desc',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function($model)
                                    {
                                        return strip_tags(trim($model->pb_desc));
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                    ],
                                ],
                                    
                            ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Item Work Details</h3> 
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                   <div class="order-form">
                    <table class="table">
                        <thead>
                          <tr>
                            <th>Sr.</th>
                            <th>Item Work Name</th>
                            <th>Sub Contractor</th>
                            <th>Sub Contractor Estimate Cost</th>
                            <th>Comment</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 

                            if(isset($model1) && $model1 != '')
                            {
                                $i = 1;
                                foreach ($model1 as  $value) {                                   
                                ?>
                                    <tr>
                                        <td><?= $i?></td>
                                        <td><?php echo $value->item->name; ?></td>
                                        <td><?php echo $value->subcontractor->first_name .' '.$value->subcontractor->last_name.'-'.$value->subcontractor->email ; ?></td>
                                        <td><?= $value->cost; ?></td>
                                        <td><?= $value->comment; ?></td>
                                    </tr>
                                <?php  
                                $i++;   
                                }
                            }
                        ?>
                        </tbody>
                    </table>   
                    </div>     
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>