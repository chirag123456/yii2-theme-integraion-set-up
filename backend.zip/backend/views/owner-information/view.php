<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Owner Information </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("owner-information/index") ?>" >Owner Information</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Owner Information Details</h3> 
                    <a href="<?php echo ($_SERVER['HTTP_REFERER']); ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [                                
                                [
                                    'attribute' => 'owners_legal_name',
                                ],
                                [
                                    'attribute' => 'permissible_working_hours',
                                ],
                                [
                                    'attribute' => 'latest_owner_signed_construction_proposal_date',
                                ],
                                [
                                    'attribute' => 'owners_mailing_address',
                                ],
                                [
                                    'attribute' => 'owner_state_id',
                                    'value' => $model->ownerState->state_name,
                                    
                                ],
                                [
                                    'attribute' => 'owner_city_id',
                                    'value' => $model->ownerCity->name,
                                    
                                ],
                                [
                                    'attribute' => 'owner_zipcode',
                                ],
                                [
                                    'attribute' => 'owners_primary_contact_person',
                                ],
                                [
                                    'attribute' => 'owner_email',
                                ],
                                [
                                    'attribute' => 'owner_phone',
                                ],
                            ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
    
</section> 
</div>