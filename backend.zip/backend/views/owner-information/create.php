<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\OwnerInformation */

$this->title = 'Create Owner Information';
$this->params['breadcrumbs'][] = ['label' => 'Owner Informations', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="owner-information-create">

   

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
