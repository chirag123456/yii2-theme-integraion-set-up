<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm; 

$this->params['breadcrumbs'][] = $this->title;
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
        Owner Information
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Owner Information</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="contractor-management-index">
                        <div class="table-responsive">
                        <?php
                            $form = \yii\widgets\ActiveForm::begin([
                                        'method' => 'get', 'id' => 'super'
                            ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();?>
                        <?php
                            $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>

                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel5 = '';
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '5') {
                                        $sel5 = 'selected="selected"';
                                    } else if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="5" <?php echo $sel5; ?>>5</option>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            <?= Html::a('Add Owner Information', ['add'], ['class' => 'btn btn-primary']) ?>
                            <?= Html::a('Reset', ['index'], ['class' => 'btn btn-primary']) ?>
                        </p>

                        <?php Pjax::begin(['id' => 'owner-information']) ?> 
                        
                        <?= GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'columns' => [
                                [   'attribute' => 'id',
                                        'label' => '#ID',
                                        'contentOptions' => ['style' => 'width:30px;'],
                                ],
                                [
                                    'attribute' => 'owners_legal_name',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Owners legal Name'
                                        ],
                                ],
                                [
                                    'attribute' => 'permissible_working_hours',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Pemissible Working Hours'
                                        ],
                                ],
                                [
                                    'attribute' => 'owners_primary_contact_person',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Owners primary Contact Person'
                                        ],
                                ],
                                [
                                    'attribute' => 'owner_email',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Owners Email'
                                        ],
                                ],
                                [
                                    'attribute' => 'owner_phone',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Owners Phone'
                                        ],
                                ],
                               
                                [
                                    'attribute' => 'is_active',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'prompt' => 'Select Status'
                                        ],
                                    'filter' => [ACTIVE => "Active", INACTIVE => "Inactive"],
                                    'value' => function ($model) {
                                        if ($model->is_active == ACTIVE) {
                                            return Html::tag('span', 'Active', ['class' => ['label', 'label-success'], '']);
                                        } elseif ($model->is_active == INACTIVE) {
                                            return Html::tag('span', 'Inactive', ['class' => ['label', 'label-danger']]);
                                        }
                                    },
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{update}  {status} {delete}  {view}',
                                    'buttons' => [
                                        'status' => function ($url, $model) {
                                            if ($model->is_active == ACTIVE) {
                                                return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                            'class' => '',
                                                            'title' => Yii::t('app', 'View'),
                                                            'data-confirm' => INACTIVESTATUS, 
                                                            // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Inactive',
                                                ]);
                                            } else {
                                                return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                            'data-confirm' => ACTIVESTATUS, 
                                                            // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'title' => 'inactive',
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Active',
                                                ]);
                                            }
                                        },
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'title' => Yii::t('app', 'lead-delete'),
                                                        'data-confirm' => DELETESTATUS , 
                                                        // <-- confirmation works...
                                                        'data-method' => 'post',
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Delete',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Edit',
                                            ]);
                                        },

                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                            ]);
                                        },
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'update') {
                                            return \yii\helpers\Url::to(['owner-information/update/' . $key]);
                                        }
                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['owner-information/status/' . $key]);
                                        }
                                        if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['owner-information/delete/' . $key]);
                                        }
                                        if ($action === 'view') {
                                            return \yii\helpers\Url::toRoute(['owner-information/view/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                    
                        <?php Pjax::end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");