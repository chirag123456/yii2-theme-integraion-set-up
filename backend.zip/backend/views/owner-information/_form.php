<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;
?> 

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<style type="text/css">
    

.card .card-body [type="radio"]:not(:checked), .card .card-body [type="radio"]:checked {
    position: static; 
    left: -9999px; 
    opacity: 1; 
}
.hidden{
    display: none;
}
</style>
<section class="content-header">
    <h1> Owner Information </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("owner-information/index") ?>" >Owner Information</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Owner Information' : 'Add Owner Information'; ?></li>
    </ol>
</section>

<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Owner Information' : 'Add Owner Information'; ?></h4>
      </div>
      <div class="card-body project-management-form">
        <?php
            $form = ActiveForm::begin([
                        'id' => 'owner-information-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data']
            ]);
        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Owner Information </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                      <?= $form->field($model, 'owners_legal_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Owners Legal Name']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'permissible_working_hours')->textInput(['maxlength' => 12, 'placeholder' => 'Enter Permissible Working Hour']) ?>
                </div>
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'owners_mailing_address')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Owners Mailing Address']) ?>
                </div>
              </div> 
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
              
                    <?php 
                        echo $form->field($model, 'latest_owner_signed_construction_proposal_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                        ]);
                    ?>
                </div>
              </div> 
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'owners_primary_contact_person')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Owners Primary Contact Person']) ?>
                </div>
              </div>  
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'owner_email')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Oners Email Address']) ?>
                </div>
              </div> 
              <!--/span-->

              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'owner_phone')->textInput(['maxlength' => 12, 'placeholder' => 'Enter Owners Phone Number']) ?>
                </div>
              </div> 
              <!--/span-->
            </div>

            <h3 class="card-title"><i class="fa fa-map-marker" aria-hidden="true"></i>  Address </h3>
            <hr>
            <div class="row p-t-20">
              
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                    <?php 
                                    
                      echo $form->field($model, 'owner_state_id')->widget(
                       Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\state\State::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'state_name'),
                      'options' => ['placeholder' => 'Select State','onchange' => '
                          $.post( "' . Yii::$app->urlManager->createUrl('city/set-city?id=') . '"+$(this).val(), function( data ) {
                          $("#title").html( data );
                          });
                      '],
                      'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                       ])->label(); 
                  ?>
                  
                </div>
              </div>
               <div class="col-md-4">
                <div class="form-group">
                  <?php 
                    echo $form->field($model, 'owner_city_id')->widget(
                          Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\city\City::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED,'state_id' => $model->owner_state_id])->asArray()->all(), 'id', 'name'),
                     'options' => ['placeholder' => 'Please Select state','id' => 'title'],
                     'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                      ])->label();
                  ?>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                    <?= $form->field($model, 'owner_zipcode')->textInput(['maxlength' => 8, 'placeholder' => 'Enter Landlord Zipcode']) ?>
                </div>
              </div>
              <!--/span-->
            </div>
          </div>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php 
$this->registerJs("
    
    $('input[type=radio]').change(function() {
        if (this.value == 'Y') {
            $('.custom-radio-hide').removeClass('hidden');
        }
        else{
            $('.custom-radio-hide').addClass('hidden');
        }
    });
");

if(isset($_GET['id']) && !empty($_GET['id']))
{
  $this->registerJs("   
     var val = $('input[type=radio]').val(); 
      if (val == 'Y') {
          $('.custom-radio-hide').removeClass('hidden');
      }
      else{
          $('.custom-radio-hide').addClass('hidden');
      }
  ");
}

?>