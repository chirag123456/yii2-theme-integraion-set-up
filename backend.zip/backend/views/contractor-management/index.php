<?php
/* @var $this yii\web\View */

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel common\models\search\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'Supplier';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<?php $head_arr = []; $head = 'Supplier';
    $url = \Yii::$app->urlManager->createUrl("dashboard/index");
    $head_arr = [0=> $head, 1=>$url, 2=> $head];
?>
<?= $this->render('@common/views/heading.php',['head_arr' => $head_arr]) ?>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="table-responsive">
                    <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php $page_arr = []; $id = 'Super'; $perpage = '5';
                            $label = 'Add Supplier';
                            $reset_url = Yii::$app->urlManager->createAbsoluteUrl(['/contractor-management/index']);
                            $action = yii\helpers\Url::base() . '/contractor-management/index';
                            $page_arr = [0=> $id, 1=>$perpage, 2=> $label, 3=>$reset_url, 4=>$action];
                        ?>
                        <?= $this->render('@common/views/paging.php',['page_arr' => $page_arr]) ?>

                        <?php Pjax::begin(['id' => 'users']) ?>
                        <?php
                        echo
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'showOnEmpty' => true,
                            'columns' => [
                                [
                                    'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                                
                                [
                                    'attribute' => 'first_name',
                                    'headerOptions' => ['title' => 'sort by first name'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by First Name'
                                    ],
                                ],
                                [
                                    'attribute' => 'last_name',
                                    'headerOptions' => ['title' => 'sort by last name'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Last Name'
                                    ],
                                ],
                                [
                                    'attribute' => 'email',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Email'
                                    ],
                                ],
                                [
                                    'attribute' => 'contact_number',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'is_active',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:150px;'],
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select status'
                                    ],
                                    'filter' => [ACTIVE => "Active", INACTIVE => "InActive"],
                                    'value' => function ($model) {
                                        if ($model->is_active == ACTIVE) {
                                            return Html::tag('span', 'Active', ['class' => ['label', 'label-success']]);
                                        } elseif ($model->is_active == INACTIVE) {
                                            return Html::tag('span', 'InActive', ['class' => ['label', 'label-danger']]);
                                        }
                                    },
                                ],
                                
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:130px;'],
                                    'template' => '{update} {status} {delete} {view}',
                                    'buttons' => [
                                        'status' => function ($url, $model) {
                                            if ($model->is_active == ACTIVE) {
                                                return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                            'class' => '',
                                                            'data-confirm' => INACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'InActive'
                                                ]);
                                            } else {
                                                return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                            'data-confirm' => ACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Active'
                                                ]);
                                            }
                                        },
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'data-confirm' => DELETESTATUS, // <-- confirmation works...
                                                        'data-method' => 'post',
                                                        'class' => 'delete',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Delete',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                        //'title' => Yii::t('app', 'lead-delete'),
                                                        // 'data-confirm' => DELETESTATUS . " state?", // <-- confirmation works...
                                                        // 'data-method' => 'post',
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Edit',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['contractor-management/status/' . $key]);
                                        } else if ($action === 'update') {

                                            return \yii\helpers\Url::toRoute(['contractor-management/update/' . $key]);
                                        } else if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['contractor-management/delete/' . $key]);
                                        } 
                                        else if ($action === 'view') {
                                            return \yii\helpers\Url::toRoute(['contractor-management/view/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");