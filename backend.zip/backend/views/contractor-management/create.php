<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\User */


?>

<div class="supplier-create">

    <?php echo
    $this->render('_form', [
        'model' => $model,
        'subcontractor' => $subcontractor, 
    ])
    ?>

</div>
<?php
if (isset($_GET['image-not-found']) && !empty($_GET['image-not-found'])) {

    $this->registerJs("
        $('#user_image').css('border', '1px solid red');
    ");
}
?>