<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;
use common\models\submittal\SubmittalItem;
use common\models\submittal\SubmittalItemForm;
?>  

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Submittal </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("submittal/index") ?>" >Submittal</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Submittal' : 'Add Submittal'; ?></li>
    </ol>
</section> 

<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Submittal' : 'Add Submittal'; ?></h4>
      </div>
      <div class="card-body project-submittal-form">
        <?php
            $form = ActiveForm::begin([
                        'id' => 'submittal-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data']
            ]);
        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Submittal Information </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?php 
                    echo $form->field($model, 'date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date ','autocomplete'=> 'off'],

                          'pluginOptions' => [    
                          'language' => 'en',                
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                  ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?php
                    echo $form->field($model, 'to_user_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'is_admin' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' '.$model['email'];
                            }), 
                              'options' => ['placeholder' => 'Select User','onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('submittal/get-user?id=') . '"+$(this).val(), function( data ) {
                                      var result = $.parseJSON(data);
                                      $("#submittalform-email").val(result.model.email);
                                      $("#submittalform-phone").val(result.model.contact_number);
                                    });
                                '],
                      ])->label();  
                   ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                        ])->label();
                    ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 're')->textInput(['maxlength' => 50,'placeholder' => 'Enter Regarding']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'phone')->textInput(['maxlength' => 12,'placeholder' => 'Enter Phone Number']) ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                    <?= $form->field($model, 'email')->textInput(['maxlength' => 50,'placeholder' => 'Enter Email']) ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'attention')->textInput(['maxlength' => 100,'placeholder' => 'Enter Attention']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?php 
                    echo $form->field($model, 'review_date_of_resubmittal')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Review Date of Resubmittal ','autocomplete'=> 'off'],

                          'pluginOptions' => [    
                          'language' => 'en',                
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                  ?>
                </div> 
              </div> 
            </div>
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> We are sending you following Items</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                    <?= $form->field($model, 'under_separate_cover')->textInput(['maxlength' => 100,'placeholder' => 'Enter Under Seprate Cover']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'under_separate_cover_via')->textInput(['maxlength' => 100,'placeholder' => 'Enter Under Seprate Cover Via']) ?>
                </div>
              </div>
              
            </div>
            <div class="row p-t-20">
              
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <?= 
                  /*$form->field($model, 'shop_drawings')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding']) */
                  $form->field($model, 'shop_drawings')->checkbox()

                  ?>
                </div> 
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                    <?=                     
                    /*$form->field($model, 'prints')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding']) */
                    $form->field($model, 'prints')->checkbox()

                    ?>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <?= 
                  /*$form->field($model, 'plans')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                  $form->field($model, 'plans')->checkbox() 

                  ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <?= 
                    /*$form->field($model, 'samples')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding']) */
                    $form->field($model, 'samples')->checkbox()
                  ?>
                </div> 
              </div>
              <!--/span-->
            </div>
            
             <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group">
                    <?= 
                      /*$form->field($model, 'specifications')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding']) */
                      $form->field($model, 'specifications')->checkbox()
                    ?>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <?= 
                    /*$form->field($model, 'copy_of_letter')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                    $form->field($model, 'copy_of_letter')->checkbox()
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <?= 
                     /*$form->field($model, 'change_order')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                     $form->field($model, 'change_order')->checkbox()
                   ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-3">
                <div class="form-group">
                    <?= 
                      /*$form->field($model, 'other')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                      $form->field($model, 'other')->checkbox()
                     ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Item Work</h3>
            <hr>
            
              <?php 
                
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  $details = SubmittalItem::find()->where(['submittal_id'=> $_GET['id']] )->all();  
                }
                
                if(isset($details) && !empty($details))
                {
                    $i = 0 ;
                    foreach ($details as $value) {

                      $projectBudgetItemForm = new SubmittalItemForm();
                      $model1 = $projectBudgetItemForm->getUpdateModel($value);
                      if($i == 0)
                      {
                        $class =  "row add";
                      }
                      else
                      {
                        $class =  "row add".$i;  
                      }
                      
                      ?>
                      <div class="<?= $class?>">
                      <div class="col-md-2">                   
                        <?php echo $form->field($model1, 'copies')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Copies','class' => 'form-control custom-val name-change-copies','required'=>true]) ?> 
                      </div>
                      <div class="col-md-3"> 
                          <?php 
                          echo $form->field($model1, 'item_date')->input('date',['required'=>true,'class' => 'form-control custom-val name-change-item_date'])
                          ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'number')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Number','class' => 'form-control custom-val name-change-number','required'=>true]) ?> 
                      </div>
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'description')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Description','required'=>true,'class' => 'form-control name-change-description']) ?>
                      </div>
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                    </div>
                <?php $i++;    } 
                }
                else
                {
                  $model1 = new SubmittalItemForm();
                ?>
                <div class="row add">  
                  <div class="col-md-2">                   
                      <?php echo $form->field($model1, 'copies[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Copies','class' => 'form-control custom-val name-change-copies','required'=>true]) ?>
                  </div>
                  <div class="col-md-3">  
                        <?php 
                          echo $form->field($model1, 'item_date[]')->input('date',['required'=>true,'class' => 'form-control custom-val name-change-item_date'])
                        ?>
                  </div>
                  <div class="col-md-2"> 
                      <?php echo $form->field($model1, 'number[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Number','class' => 'form-control custom-val name-change-number','required'=>true]) ?> 
                  </div>
                  <div class=" col-md-4">
                    <?php echo $form->field($model1, 'description[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Description','required'=>true,'class' => 'form-control name-change-description']) ?>
                                               
                  </div>
                    
                  <div class="col-md-1" style="    margin-top: 26px;">                
                    <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 
                  </div>
                <?php  
                }
              ?>    
            </div>
            <div class="a" id="l"></div>
                          <a style="cursor: pointer; margin-right: 35px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>

             <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> There are transmitted as below:</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?= /*$form->field($model, 'for_approval')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                  $form->field($model, 'for_approval')->checkbox()
                   ?>

                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= /*$form->field($model, 'approved_as_submitted')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                  $form->field($model, 'approved_as_submitted')->checkbox()
                   ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                    <?= /*$form->field($model, 'resubmit')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                      $form->field($model, 'resubmit')->checkbox()
                     ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?= /*$form->field($model, 'copies_for_approval')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                    $form->field($model, 'copies_for_approval')->checkbox()
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= /*$form->field($model, 'for_your_use')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                    $form->field($model, 'for_your_use')->checkbox()
                   ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                    <?= /*$form->field($model, 'approved_as_noted')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                      $form->field($model, 'approved_as_noted')->checkbox()
                     ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?= /*$form->field($model, 'submit')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                    $form->field($model, 'submit')->checkbox()
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= /*$form->field($model, 'copies_for_distribution')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                    $form->field($model, 'copies_for_distribution')->checkbox()
                   ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                    <?= /*$form->field($model, 'as_requested')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                      $form->field($model, 'as_requested')->checkbox()
                     ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group">
                  <?= /*$form->field($model, 'returned_for_corrections')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                    $form->field($model, 'returned_for_corrections')->checkbox()
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <?= /*$form->field($model, 'return')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/ 
                    $form->field($model, 'return')->checkbox()
                  ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-3">
                <div class="form-group">
                    <?= /*$form->field($model, 'corrected_prints')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding'])*/
                      $form->field($model, 'corrected_prints')->checkbox()
                     ?>
                </div>
              </div> 
              <div class="col-md-3">
                <div class="form-group">
                  <?= /*$form->field($model, 'review_comment')->textInput(['maxlength' => 100,'placeholder' => 'Enter regarding']) */
                    $form->field($model, 'review_comment')->checkbox()
                  ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'for_bids_due')->textInput(['maxlength' => 100,'placeholder' => 'Enter For Bids Due']) ?>
                </div> 
              </div> 
              <!--/span-->

              <div class="col-md-6">
                <div class="form-group">
                    <?= $form->field($model, 'remarks')->textInput(['maxlength' => 100,'placeholder' => 'Enter Remarks']) ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            
            
          </div>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>

</section>
<?php
  $this->registerJs("
    $('.name-change-copies').attr('name', 'SubmittalItemForm[copies][]');
    $('.name-change-item_date').attr('name', 'SubmittalItemForm[item_date][]');
    $('.name-change-number').attr('name', 'SubmittalItemForm[number][]');
    $('.name-change-description').attr('name', 'SubmittalItemForm[description][]');

    var n = 1;
    $('.addd').click(function(){
        $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
        $('.xcas').find(':input').val('');
       
    });   
    $('.remove_daterow').click(function(){      
        $(this).closest('.xcas').remove();
    });   
 ");
?> 