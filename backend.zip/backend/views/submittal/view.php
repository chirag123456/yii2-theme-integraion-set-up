<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Submittal </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("submittal/index") ?>" >Submittal</a></li>
        <li class="active">View</li> 
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Submittal Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                ],
                                [
                                    'attribute' => 'date',
                                    'headerOptions' => ['title' => 'sort by'],

                                    
                                ],
                                [
                                    'attribute' => 'to_user_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->user->email;
                                    },
                                ],
                                [
                                    'attribute' => 're',
                                    'headerOptions' => ['title' => 'sort by'],
                                    
                                ],
                                [
                                    'attribute' => 'phone',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'email',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'attention',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'review_date_of_resubmittal',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'under_separate_cover',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'under_separate_cover_via',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'shop_drawings',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->shop_drawings) && $model->shop_drawings == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'prints',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->prints) && $model->prints == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'plans',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->plans) && $model->plans == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'samples',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->samples) && $model->samples == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'specifications',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->specifications) && $model->specifications == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'copy_of_letter',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->copy_of_letter) && $model->copy_of_letter == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'change_order',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->change_order) && $model->change_order == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'other',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->other) && $model->other == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'for_approval',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->for_approval) && $model->for_approval == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'approved_as_submitted',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->approved_as_submitted) && $model->approved_as_submitted == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'resubmit',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->resubmit) && $model->resubmit == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'for_your_use',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->for_your_use) && $model->for_your_use == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                   'attribute' => 'approved_as_noted',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->approved_as_noted) && $model->approved_as_noted == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'submit',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->submit) && $model->submit == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'copies_for_distribution',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->copies_for_distribution) && $model->copies_for_distribution == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'as_requested',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->as_requested) && $model->as_requested == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'returned_for_corrections',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->returned_for_corrections) && $model->returned_for_corrections == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'return',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->return) && $model->return == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'corrected_prints',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->corrected_prints) && $model->corrected_prints == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'review_comment',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->review_comment) && $model->review_comment == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'for_bids_due',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->for_bids_due) && $model->for_bids_due == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                                [
                                    'attribute' => 'remarks',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            $val = isset($model->remarks) && $model->remarks == "1" ? "Yes" : "No";
                                            return $val;
                                    },
                                ],
                            ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Submittal Item Information</h3> 
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                   <div class="order-form">
                    <table class="table">
                        <thead>
                          <tr>
                            <th>SR.</th>
                            <th>Copies</th>
                            <th>Date</th>
                            <th>No.</th>
                            <th>Description</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 

                            if(isset($model1) && $model1 != '')
                            {
                                $i = 1;
                                foreach ($model1 as  $value) {                                   
                                ?>
                                    <tr>
                                        <td><?= $i; ?></td>
                                        <td><?= $value->copies; ?></td>
                                        <td><?= $value->item_date ; ?></td>
                                        <td><?= $value->number; ?></td>
                                        <td><?= $value->description; ?></td>
                                    </tr>
                                <?php    $i++;
                                }
                            }
                        ?>
                        </tbody>
                    </table>   
                    </div>     
                </div>        
            </div> 
        </div>
    </div> 
</section> 
</div>