<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\TaskAllocation */

$this->title = 'Update Task Allocation: {nameAttribute}';
$this->params['breadcrumbs'][] = ['label' => 'Task Allocations', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="task-allocation-update">


    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
