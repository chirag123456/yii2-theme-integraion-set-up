<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\TaskAllocation */

$this->title = 'Create Task Allocation';
$this->params['breadcrumbs'][] = ['label' => 'Task Allocations', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="task-allocation-create">

    	

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
