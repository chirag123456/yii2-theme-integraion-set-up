
<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use common\models\userrole\UserAccess;
use yii\helpers\ArrayHelper;
use common\models\contractor\ContractorManagement;
use backend\components\CommonFunctions;
 
use kartik\date\DatePicker;
use dosamigos\ckeditor\CKEditor;  
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Task Management </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("task-allocation/index") ?>" >Task management</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Task management' : 'Add Task management'; ?></li>
    </ol>
</section>

<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">

                    <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Task management' : 'Add Task management'; ?></h4> 

                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="card-body task-allocation-form">    
                    <?php
                    $form = ActiveForm::begin([
                        'id' => 'subcontractor-management-form',
                        'enableAjaxValidation' => false,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data']
                    ]);
                    ?>
                    
                    <div class="form-body">
                        <h3 class="card-title"><i class="fa fa-tasks" aria-hidden="true"></i> Task Information</h3>
                        <hr>
                        <div class="row p-t-20"> 
                            <div class=" col-md-4">
                                <div class="form-group">
                                    <?php 
                                        $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                                    ?>
                                    <?=

                                    $form->field($model, 'project_id')->widget(Select2::classname(), [
                                        'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                                        'options' => ['prompt' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                                    ])->label();
                                    ?>
                                </div>
                            </div>
                            
                                <div class=" col-md-4">
                                    <div class="form-group">
                                        <?= $form->field($model, 'task_name')->textInput(['maxlength' => 50]) ?>
                                    </div> 
                                </div> 
                                <div class=" col-md-4">
                                <div class="form-group">
                                    <?php
                                    echo $form->field($model, 'priority')->widget(
                                        Select2::classname(), [
                                            'data' => ['LOW' => 'Low', 'MEDIUM' => 'Medium', 'HIGH' => 'High','URGENT' =>'Urgent'],
                                            'options' => ['placeholder' => 'Select Priority'],
                                        ])->label();
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row p-t-20">
                                <div class=" col-md-4">
                                    <div class="form-group">
                                        <?php
                                        echo $form->field($model, 'task_status')->widget(
                                            Select2::classname(), [
                                                'data' => ['INITIALISED' => 'Initialised', 'START' => 'Start', 'ONGOING' => 'Ongoing','PENDING' =>'Pending' , 'COMPLETED' => 'Completed'],
                                                'options' => ['placeholder' => 'Select Task Status'],
                                            ])->label();
                                            ?>
                                    </div>
                                </div>
                                <div class=" col-md-4">
                                    <div class="form-group">
                                    <?php 

                                        echo $form->field($model, 'role_id')->widget(
                                              Select2::classname(), [
                                        'data' => ArrayHelper::map(\common\models\userrole\UserAccess::find()
                                        ->asArray()->all(), 'id', 'name'),
                                        'options' => ['placeholder' => 'Select User Type','onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('task-allocation/set-user?id=') . '"+$(this).val(), function( data ) {
                                        $("#taskallocationform-user_id").attr("disabled", false);

                                      $("#taskallocationform-user_id").html( data );
                                    });
                                '],
                                        ])->label();
                                    ?>
                                    
                                    </div>
                                </div>
                                
                                <div class=" col-md-4">
                                    <div class="form-group">
                                    <?php
                                    if(isset($_GET['id']) && !empty($_GET['id']))
                                    {
                                        echo $form->field($model, 'user_id')->widget(Select2::classname(), [
                                            'data' => \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $model->role_id])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'email'),
                                            'options' => ['prompt' => 'Plese Select User Type'],
                                            'pluginOptions' => [
                                                'allowClear' => true
                                            ],
                                        ])->label();
                                    }
                                    else
                                    {
                                        echo $form->field($model, 'user_id')->widget(Select2::classname(), [
                                            'data' => \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $model->role_id])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'email'),
                                            'options' => ['prompt' => 'Plese Select User Type','disabled' => true],
                                            'pluginOptions' => [
                                                'allowClear' => true
                                            ],
                                        ])->label();
                                    }
                                    ?>
                                    </div>
                                </div>
                                
                    </div>
                    

                    <h3 class="box-title m-t-40"><i class="fa fa-calendar" aria-hidden="true"></i> Task Date</h3>
                    <hr>
                    <div class="row">
                      <div class="col-md-6">
                        <?php 
                          echo $form->field($model, 'start_date')->widget(DatePicker::classname(), [
                                  'options' => ['placeholder' => 'Select Start Date','autocomplete'=> 'off',],

                                  'pluginOptions' => [  
                                  'language' => 'en',                  
                                  'autoclose' => true,
                                  'format' => 'yyyy-mm-dd',                                  
                                  'startDate' => date("yyyy-MM-dd H:i:s"),
                                  ]
                          ]);
                        ?>
                      </div>
                      <div class="col-md-6">
                        <?php 
                            echo $form->field($model, 'due_date')->widget(DatePicker::classname(), [
                                    'options' => ['placeholder' => 'Select Due Date','autocomplete'=> 'off',],

                                    'pluginOptions' => [  
                                    'language' => 'en',                  
                                    'autoclose' => true,
                                    'format' => 'yyyy-mm-dd',                                    
                                    'startDate' => date("yyyy-MM-dd H:i:s"),
                                    ]
                            ]);
                        ?>
                      </div>
                      
                    </div>
                    <h3 class="box-title m-t-40"><i class="fa fa-paragraph" aria-hidden="true"></i> Task Description</h3>
                    <hr>
                    <div class="row">
                      <div class=" col-md-12"> 
                          <?= $form->field($model, 'description')->widget(CKEditor::className(), [
                                  'options' => ['rows' => 6],
                                  'preset' => 'basic'
                          ]) ?>
                      </div>
                      
                    </div>
                </div>
                <div class="form-actions">

                    <a href="<?php echo yii\helpers\Url::to(['task-allocation/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"> <i class="fa fa-close"></i> Cancel</a>

                    <?php
                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                        echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                    } else {
                        echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img']);
                    }
                    ?>


                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </section>

