<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\ContractorManagement */
?>
<div class="client-update">

    <?= $this->render('edit_form', [
        'model' => $model,
    ]) ?>

</div>
