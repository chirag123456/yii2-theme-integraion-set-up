<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Module </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("module/index") ?>" >Module</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Module' : 'Add Module'; ?></li>
    </ol>
</section>

<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Module' : 'Add Module'; ?></h4>
      </div>
      <div class="card-body project-management-form">
        <?php
            $form = ActiveForm::begin([
                        'id' => 'module-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data']
            ]);
        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Module </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'module_name')->textInput(['maxlength' => 30, 'id' => 'module_name', 'placeholder' => 'Enter Module Name']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'icon')->textInput(['maxlength' => 30, 'id' => 'icon', 'placeholder' => 'Enter Icon code']) ?>
                </div>
              </div>
            </div>
            <div class="row p-t-20">
              <div class="col-md-12">
                  <?php
                  $selectArray = [
                      'index' => 'List',
                      'add' => 'Add',
                      'update' => 'Update',
                      'delete' => 'Delete',
                      'view' => 'View',
                      'status' => 'Status',
                      'export-excel' => 'Export Excel',
                      'export-pdf' => 'Export PDF',
                      'export-one-pdf' => 'Export Single PDF'
                  ];
                  echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                    echo Html::label('Actions List'); ?>
                    
                    <p><label><input type="checkbox" id="check-all-act"/> All Actions</label></p>
                  <?php   echo Html::Tag('div' ,
                              Html::checkboxList(
                                              'action_name' , [] , $selectArray ,
                                              [ 'class' => 'icheck-inline icheck-inline-custom lbl_modules custom-add-role-check ' , 'itemOptions' => [ 'class' => 'icheck' ] ], ['separator'=>'br']
                              ) //. Html::tag( 'div' , 'Note : Above all are list of Menu(Left Side). Select from list to access it.' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                      );
                      echo Html::endTag('div');
                  ?>
              </div>
            </div>
          </div>
          <div class="form-actions">
               <a href="<?php echo yii\helpers\Url::to(['module/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
              <?php
                  if (isset($_GET['id']) && !empty($_GET['id'])) {
                      echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                  } else {
                      echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                  }
              ?>
          </div>
          <?php ActiveForm::end(); ?>
          </div>
      </div>
    </div>
  </div>
</section>
<?php 
  $this->registerJs("
      $('#check-all-act').change(function () {
          $('.icheck').prop('checked', $(this).prop('checked'));
      });
      
  ");
?>