<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use common\models\userrole\UserAccess;
use yii\helpers\ArrayHelper;
use common\models\contractor\ContractorManagement;
use backend\components\CommonFunctions;
use kartik\date\DatePicker;

$start_date = isset($_GET['ProjectScheduleReportForm']['start_date']) && ($_GET['ProjectScheduleReportForm']['start_date']) != '' ? $_GET['ProjectScheduleReportForm']['start_date']  : '';

$end_date = isset($_GET['ProjectScheduleReportForm']['end_date']) && ($_GET['ProjectScheduleReportForm']['end_date']) != '' ? $_GET['ProjectScheduleReportForm']['end_date']  : '';

$project_id = isset($_GET['ProjectScheduleReportForm']['project_id']) && ($_GET['ProjectScheduleReportForm']['project_id']) != '' ? $_GET['ProjectScheduleReportForm']['project_id']  : '';

$this->title = 'Admin';
$this->params['breadcrumbs'][] = $this->title;

?> 
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
        Project Report
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Project Report</li>
    </ol>
</section>
<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">

                    <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Filter Project' : 'Filter Project'; ?></h4> 

                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="card-body task-allocation-form">    
                    <?php
                    $form = ActiveForm::begin([
                        'id' => 'project-schedule-report-form',
                        'enableAjaxValidation' => false,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data'],
                        'method' => 'GET'
                    ]);
                    ?>
                    
                    <div class="form-body">
                        <?php 
                            $model->start_date = $start_date;
                            $model->end_date = $end_date;
                            $model->project_id = $project_id;
                        ?>
                    <div class="row p-t-20">
                      <div class="col-md-6">
                        <?php 
                          echo $form->field($model, 'start_date')->widget(DatePicker::classname(), [
                                  'options' => ['placeholder' => 'Select Start Date','autocomplete'=> 'off',],

                                  'pluginOptions' => [  
                                  'language' => 'en',                  
                                  'autoclose' => true,
                                  'format' => 'yyyy-mm-dd',                                  
                                  ]
                          ]);
                        ?>
                      </div>
                      <div class="col-md-6">
                        <?php 
                            echo $form->field($model, 'end_date')->widget(DatePicker::classname(), [
                                    'options' => ['placeholder' => 'Select Start Date','autocomplete'=> 'off',],

                                    'pluginOptions' => [  
                                    'language' => 'en',                  
                                    'autoclose' => true,
                                    'format' => 'yyyy-mm-dd',                                    
                                    ]
                            ]);
                        ?>
                      </div>
                      
                    </div>
                    
                    
                </div>
                <div class="form-actions">

                    <a href="<?php echo yii\helpers\Url::to(['project-report/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"> <i class="fa fa-close"></i> Cancel</a>

                    <?php
                    echo Html::submitButton('<i class="fa fa-check"></i> Filter', ['class' => 'btn btn-primary', 'id' => 'img']);
                    ?>


                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </section>
<section class="content">
    <div class="row">
        
        <div class="col-xs-12">
            <div class="box box-primary">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="state-index">
                        <div class="table-responsive">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                            $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>

                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel5 = '';
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '5') {
                                        $sel5 = 'selected="selected"';
                                    } else if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="5" <?php echo $sel5; ?>>5</option>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                           
                            <?php echo Html::a('Export Excel', ['export-excel?date_of_commencement='.$date_of_commencement.'&date_of_completion='.$date_of_completion], ['class' => 'btn btn-primary filter-reset']) ?>
                            <?php echo Html::a('Reset', ['index'], ['class' => 'btn btn-primary filter-reset']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'task-allocation']) ?>  

                        <?=
                            GridView::widget([
                                'dataProvider' => $dataProvider,
                                'filterModel' => $searchModel,
                                'columns' => [
                                    [   'attribute' => 'id',
                                        'label' => '#ID',
                                        'contentOptions' => ['style' => 'width:40px;',],
                                        'filterInputOptions' => [
                                                'class'=>'form-control',
                                                'placeholder' => 'Search By ID'
                                            ],
                                    ],
                                    
                                    [
                                        'attribute' => 'project_id',
                                        'format' => 'raw',
                                        'value' => 'project.project_name',
                                        'filterInputOptions' => [
                                                'class'=>'form-control',
                                                'placeholder' => 'Search By Project Name'
                                            ],
                                    ],
                                    [
                                        'attribute' => 'schedule_title',
                                        'format' => 'raw',
                                        'filterInputOptions' => [
                                                'class'=>'form-control',
                                                'placeholder' => 'Search By Schedule Title'
                                            ],
                                    ],
                                    [
                                        'attribute' => 'item_name',
                                        'format' => 'raw',
                                        'value' => 'item.name',
                                        'filterInputOptions' => [
                                                'class'=>'form-control',
                                                'placeholder' => 'Search By Item Name'
                                            ],
                                    ],
                                    [
                                        'attribute' => 'is_active',
                                        'format' => 'raw',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'prompt' => 'Select Status'
                                        ],
                                        'filter' => [ACTIVE => "Active", INACTIVE => "Inactive"],
                                        'value' => function ($model) {
                                           
                                            if ($model->is_active == ACTIVE) {
                                                return Html::tag('span', 'Active', ['class' => ['label', 'label-success']]);
                                            } elseif ($model->is_active == INACTIVE) {
                                                return Html::tag('span', 'Inactive', ['class' => ['label', 'label-danger']]);
                                            }
                                        },
                                    ],
                                    [
                                        'class' => 'yii\grid\ActionColumn',
                                        'header' => 'Actions',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'template' => '{update}  {status} {delete} {view}',  //{delete} {excel}
                                        'buttons' => [
                                            'status' => function ($url, $model) {
                                                if ($model->is_active == ACTIVE) {
                                                    return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                                'class' => '',
                                                                'data-confirm' => INACTIVESTATUS , // <-- confirmation works...
                                                                'data-method' => 'post',
                                                                'data-toggle' => 'tooltip',
                                                                'title' => 'Inactive'
                                                    ]);
                                                } else {
                                                    return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                                'data-confirm' => ACTIVESTATUS , // <-- confirmation works...
                                                                'data-method' => 'post',
                                                                'class' => '',
                                                                'data-toggle' => 'tooltip',
                                                                'title' => 'Active'
                                                    ]);
                                                }
                                            }, 
                                            'delete' => function ($url, $model) {
                                                return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                            'data-confirm' => DELETESTATUS , // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Delete',
                                                ]);
                                            },
                                            'update' => function ($url, $model) {
                                                return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                            //'title' => Yii::t('app', 'lead-delete'),
                                                            // 'data-confirm' => DELETESTATUS . " state?", // <-- confirmation works...
                                                            // 'data-method' => 'post',
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Edit',
                                                ]);
                                            },
                                            'view' => function ($url, $model) {
                                                return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', $url, [
                                                           // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'View',
                                                ]);
                                            },
                                        ],
                                        'urlCreator' => function ($action, $model, $key, $index) {
                                            if ($action === 'view') {
                                                 return \yii\helpers\Url::toRoute(['project-schedule-management/view/' . $key]);
                                            }
                                        } 
                                    ],
                                ],
                            ]);
                            ?>
                            <?php Pjax::end() ?> 
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
