<?php
use yii\helpers\Url;

$baseUrl = Url::base(true);
?>
<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><img src="<?php echo $baseUrl; ?>/web/images/logo/uclogo.png.png" alt="logo-lg"/></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg">
            <img src="<?php echo $baseUrl; ?>/web/images/logo/uclogo.png" alt="logo-lg"/>
            <span>Admin</span>
        </span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <?php if( isset( Yii::$app->user->identity->id ) ){?>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- Messages: style can be found in dropdown.less-->

                <!-- Notifications: style can be found in dropdown.less -->

                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?php if (isset(Yii::$app->user->identity->image_path) && !empty(Yii::$app->user->identity->image_path)) { ?>
                            <?php 
                            $file = dirname( \Yii::$app->basePath ).DIRECTORY_SEPARATOR.'backend'.DIRECTORY_SEPARATOR.'web'.DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR.'users' .DIRECTORY_SEPARATOR. Yii::$app->user->identity->image_path;
                            if(file_exists($file) ){?>
                              <img src="<?php echo Yii::$app->request->BaseUrl . 'uploads/users/' . Yii::$app->user->identity->image_path ?>" class="user-image" alt="User Image">  
                            <?php }else{ ?>
                              <img src="<?php echo Yii::$app->request->BaseUrl . 'uploads/default_image.png' ?>" class="user-image" alt="User Image">
                            <?php } ?>                                    
                        <?php } else { ?>
                            <img src="<?php echo Yii::$app->request->BaseUrl . 'uploads/default_image.png' ?>" class="user-image" alt="User Image">                                      
                        <?php } ?>
                        <?php if( isset( Yii::$app->user->identity->name ) ){?>
                            <span class="hidden-xs"><?php echo Yii::$app->user->identity->name; /*. ' ' . Yii::$app->user->identity->name*/ ?></span>
                        <?php } ?>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <?php if (isset(Yii::$app->user->identity->image_path) && !empty(Yii::$app->user->identity->image_path)) { ?>  
                                <?php 
                                $file = dirname( \Yii::$app->basePath ).DIRECTORY_SEPARATOR.'backend'.DIRECTORY_SEPARATOR.'web'.DIRECTORY_SEPARATOR.'uploads'.DIRECTORY_SEPARATOR.'users' .DIRECTORY_SEPARATOR. Yii::$app->user->identity->image_path;
                                if(file_exists($file) ){?>
                                  <img src="<?php echo \Yii::$app->request->BaseUrl . 'uploads/users/' . Yii::$app->user->identity->image_path ?>" class="img-circle" alt="User Image"> 
                                <?php }else{ ?>
                                  <img src="<?php echo Yii::$app->request->BaseUrl . 'uploads/default_image.png' ?>" class="img-circle" alt="User Image">
                                <?php } ?>
                            <?php } else { ?> 
                                <img src="<?php echo \Yii::$app->request->BaseUrl . 'uploads/default_image.png'?>" class="img-circle" alt="User Image">
                            
                                <?php }?>
                                <?php if( isset( Yii::$app->user->identity->name ) ){?>
                                <p>
                                    <?php echo Yii::$app->user->identity->name; /*. ' ' . Yii::$app->user->identity->name*/ ?> <small></small>
                                </p>
                                <?php } ?>
                            </li>
                            <!-- Menu Body -->
                            <!-- Menu Footer-->
                            <?php if( isset( Yii::$app->user->identity->id ) ){?>
                            <li class="user-footer">
                                <div class="pull-left">
                                    <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['user/update/'.Yii::$app->user->identity->id]) ?>" class="btn btn-default">Profile</a>
                                    <a style="padding: 5px 5px;" href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['user/change-password/'.Yii::$app->user->identity->id]) ?>" class="btn btn-default">Change Password</a>
                                </div>
                                <div class="pull-right">
                                    <?php
                                    echo \yii\helpers\Html::a(
                                            'Sign out', \yii\helpers\Url::to(['site/logout']), [
                                            'data-confirm' => "Do you want to signout?", // <-- confirmation works...
                                            'data-method' => 'post',
                                            'class' => "btn btn-default"
                                            ]
                                    );
                                    ?>
                                </div>
                        </li>
                            <?php }?>
                    </ul>
                </li>
            </ul>
        </div>
        <?php }?>
    </nav>
</header>