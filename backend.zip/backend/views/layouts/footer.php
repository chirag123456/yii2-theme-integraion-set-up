<?php
/*
 * Footer 
 */
?>
<footer class="main-footer">
    
    <strong>Copyright &copy; <?php echo date('Y') ?> <a href="#"> "Couch Construction Services"</a>.</strong> All rights
    reserved.
</footer>                        
<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php
$this->registerJsFile('//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit', ['depends' => 'yii\web\JqueryAsset']);
?>