<?php 
use yii\helpers\Html;
//use yii\widgets\Menu;
use common\models\userrole\AuthAssignment;
use common\models\userrole\UserAccess;
use common\models\module\Module;
use common\models\module\Action;

?>
<aside class="main-sidebar">    
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->

        <!-- sidebar menu: : style can be found in sidebar.less -->
		<?php
		$active = isset( $this->params[ 'left_menu_active' ] ) ? $this->params[ 'left_menu_active' ] : '';
		$itemsArray = array();
		
		$moduleArr = Module::find()->where(['is_delete'=>INACTIVE])->all();
	
		// menu dashboard array
		$itemsArray['dashboard'] = [
				'class'=>'',
				'label' => '<i class="fa fa-tachometer"></i> <span>Dashboard</span>', 
				'url' => 'dashboard/index',
		];
		
		foreach($moduleArr as $kmod =>$vmod){
			$mod_name = $vmod->module_name;
			$lbl_mod_name = implode(' ', array_map('ucfirst', explode('-', $mod_name)));
			if($lbl_mod_name == 'Construction Contract Management')
			{
				$lbl_mod_name = 'Construction Contract';
			}
			$mod_icon = $vmod->icon;
			$itemsArray[$mod_name] = [
				'class'=>'',
				'label' => '<i class="'.$mod_icon.'"></i> <span>'.$lbl_mod_name.'</span>',
				'url' => $mod_name.'/index',
			];
		}

		$authAssig = AuthAssignment::find()->select('item_name')->where(['user_id' => Yii::$app->user->id ])->one();
		
		if( $authAssig != null && ( $authAssig->item_name != 'superadmin' ) ){
		
			$userAccess = UserAccess::find()->select('access')->where(['name' => $authAssig->item_name , 'is_admin' => '0' ])->one();
			
			if( $userAccess != null ){
				
				$_itemsArray = [ $itemsArray['dashboard'] ];
				
				if( $userAccess->access != '' ){
					
					$accessArr = json_decode( $userAccess->access , 16 );								
					
					if( is_array( $accessArr ) ){
						foreach( $accessArr as $val ){
							if(isset($itemsArray[ $val['module'] ])){
							$_itemsArray[] = $itemsArray[ $val['module'] ];
							}
						}
					}
				}
				
				$itemsArray = $_itemsArray;
			
			}
		}
		function chkmodule($url){
			$authAssig = AuthAssignment::find()->select('item_name')->where(['user_id' => Yii::$app->user->id ])->one();
			
			$itemsArray=array();
			if( $authAssig != null && ( $authAssig->item_name != 'superadmin' ) ){
		
				$userAccess = UserAccess::find()->select('access')->where(['name' => $authAssig->item_name , 'is_admin' => '0' ])->one();
		
			
				if( $userAccess != null ){
				
					//$_itemsArray = [ $itemsArray['dashboard'] ];
					
					if( $userAccess->access != '' ){
						
						$accessArr = json_decode( $userAccess->access , 16 );								
					
					if( is_array( $accessArr ) ){
						foreach( $accessArr as $val ){
							$_itemsArray[] = $val['module'];
						}
					}
				}
				
				$itemsArray = $_itemsArray;
			
			}
		}	
		return in_array($url, $itemsArray);

		}
		?>
        <ul class="sidebar-menu">
            
            <?php
			
			foreach( $itemsArray as $k=>$v ){
				echo Html::beginTag('li',['class'=> $v['class'] ]);
					echo Html::a( $v['label'],[$v['url']],[] );
					if( isset( $v['items'] ) ){
						echo Html::beginTag('ul',['class'=>'treeview-menu main-module']);
							foreach( $v['items'] as $val ){
								/*Sub->subMenu Start*/
								 /*if(isset($val['class']) && $val['class']=='treeview'){
								 	echo Html::beginTag('li',['class'=> $v['class'] ]);
								 	echo Html::a( $v['label'],[$v['url']],[] );

								 }
								 if(isset( $val['items']))	{
								 	echo Html::beginTag('ul',['class'=>'treeview-menu main-module']);
								 	foreach( $val['items'] as $val1 ){
								 		echo Html::beginTag('li',['class'=> ($val1['class']??'') ]);
								 		echo Html::a( $val1['label'],[$val1['url']],[] );
								 		echo Html::endTag('li');	
								 	}
								 }*/
								
								/*sub ->submenu End*/
									if(chkmodule($val['class']??'')){
										echo Html::beginTag('li',['class'=> ($val['class']??'') ]);
										echo Html::a( $val['label'],[$val['url']],[] );
										echo Html::endTag('li');
									}else if(isset($val['class']) && $val['class']=='treeview') {

										echo Html::beginTag('li',['class'=> ($val['class']??'') ]);
										echo Html::a( $val['label'],[$val['url']],[] );
										//echo Html::endTag('li');
										/*Submenu*/
										if(isset($val['items'])){
											echo Html::beginTag('ul',['class'=>'treeview-menu main-module']);
											foreach ($val['items'] as $val1) {
												echo Html::beginTag('li',['class'=> ($val1['class']??'') ]);
												echo Html::a( $val1['label'],[$val1['url']],[] );
												echo Html::endTag('li');
											}
											echo Html::endTag('ul');
											
										}
										echo Html::endTag('li');
										/*Submenu*/

									}else if(!isset($val['class'])){
										echo Html::beginTag('li',['class'=> ($val['class']??'') ]);
										echo Html::a( $val['label'],[$val['url']],[] );
										echo Html::endTag('li');
									}
							}
						echo Html::endTag('ul');
					}
				echo Html::endTag('li');
			}
			?>
			
        </ul>
    </section>
    
    <!-- /.sidebar -->
</aside>

<?php
/*$this->registerJs("
    $('.multi-menu').click(function(){
      // $(this).addClass('active');
    });
");*/
?>
