<?php

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\helpers\Url;

AppAsset::register($this);

$this->title = 'Couch Construction Services | Admin Panel';

$baseUrl = Url::base(true);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>

<html lang="<?php echo Yii::$app->language ?>">
    <head>
        <meta charset="<?php echo Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- <link rel="icon" type="image/png" href="<?php// echo $baseUrl; ?>/web/favicon.ico" /> -->
        
        <?php echo Html::csrfMetaTags() ?>
        <title><?php echo Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>

    <body class="hold-transition skin-blue sidebar-mini">
        <?php $this->beginBody() ?>

        <div class="wrapper">
            <?php echo $this->render('header'); ?>

            <?php if(Yii::$app->user->identity->id==1){ ?>
                <?php echo $this->render('side-bar'); ?>     
            <?php } else { ?>
               <?php echo $this->render('side-bar-new'); ?>     
            <?php } ?>

            <div class="content-wrapper">
                <?php echo $content ?>
            </div>
            <?php echo $this->render('footer'); ?>
        </div>
    <?php $this->endBody() ?>
    </body>
</html>

<?php $this->endPage() ?>
