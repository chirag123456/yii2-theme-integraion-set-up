<?php if (isset(Yii::$app->user->identity->id)) { ?>
    <aside class="main-sidebar">    
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                  <?php 
                        if (isset(Yii::$app->user->identity->user_image) && !empty(Yii::$app->user->identity->user_image)) 
                            
                        {  
                            $file = Yii::$app->request->hostInfo . USER_PROFILE_PATH . Yii::$app->user->identity->user_image; ?>

                        <img src="<?php echo $file; ?>" class="img-circle" alt="User Image">  
                                                                  
                        <?php } else { ?>
                            <img src="<?php echo Yii::$app->request->BaseUrl . 'uploads/default_image.png' ?>" class="img-circle" alt="User Image">                                      
                            <?php } ?>
                            <!-- <?php if (isset(Yii::$app->user->identity->username)) { ?>
                                <span class="hidden-xs"><?php echo Yii::$app->user->identity->username; /* . ' ' . Yii::$app->user->identity->name */ ?></span>
                            <?php } ?>   -->         
                </div>  

                <div class="pull-left info">
                    <p><?php echo Yii::$app->user->identity->username; ' ' . Yii::$app->user->identity->username  ?></p>
                    <small>Last Login <?php echo Yii::$app->user->identity->last_login ?></small><br>
                    
                </div>
            </div>
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
                <li class="header" style="margin-bottom: 5px;">MAIN NAVIGATION</li>
                <li class="<?php echo (\Yii::$app->controller->id === "dashboard") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>
                <li class="<?php echo (\Yii::$app->controller->id === "user") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>">
                        <i class="fa fa-users"></i> <span>User Management</span>
                    </a>
                </li>

                <li class="<?php echo (\Yii::$app->controller->id === "pwa-user") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("pwa-user/index") ?>">
                        <i class="fa fa-users"></i> <span>Pwa User Management</span>
                    </a>
                </li>

                <li class="<?php echo (\Yii::$app->controller->id === "user-role") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user-role/index") ?>"> 
                            <i class="fa fa-user"></i> <span>User Roles & Permission</span>
                    </a>
                </li>
                <li class="<?php echo (\Yii::$app->controller->id === "client") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("client/index") ?>">
                        <i class="fa fa-users"></i> <span>Client Management</span>
                    </a>
                </li>
                <li class="treeview <?php echo (Yii::$app->controller->id == in_array(\Yii::$app->controller->id, ['contractor-management', 'sub-contractor-management'])) ? 'active' : '' ?>">
                    <a href="#">
                        <i class="fa fa-users"></i>
                        <span>Vendor Management</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a> 
                    <ul class="treeview-menu main-module"> 
                        <li class="<?php echo (\Yii::$app->controller->id === "contractor-management") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("contractor-management/index") ?>">
                                <i class="fa fa-users"></i> <span>Suppliers</span>
                            </a>
                        </li>
                        <li class="<?php echo (\Yii::$app->controller->id === "sub-contractor-management") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("sub-contractor-management/index") ?>">
                                <i class="fa fa-users"></i> <span> Sub Contractor Management</span>
                            </a>
                        </li>
                    </ul> 
                </li> 
                <li class="<?php echo (\Yii::$app->controller->id === "architect") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("architect/index") ?>">
                        <i class="fa fa-building"></i> <span>Architect Management</span>
                    </a>
                </li>
                <li class="<?php echo (\Yii::$app->controller->id === "landlord") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("landlord/index") ?>">
                        <i class="fa fa-user"></i> <span>Landlord Management</span>
                    </a>
                </li>
                <!-- <li class="<?php echo (\Yii::$app->controller->id === "owner-information") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("owner-information/index") ?>">
                        <i class="fa fa-user"></i> <span>Owner Information</span>
                    </a>
                </li> -->
                <li class="<?php echo (\Yii::$app->controller->id === "lender") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("lender/index") ?>">
                        <i class="fa fa-user"></i> <span>Lender Management</span>
                    </a>
                </li>
                <li class="<?php echo (\Yii::$app->controller->id === "construction-contract-management") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("construction-contract-management/index") ?>">
                        <i class="fa fa-building"></i> <span>Construction Contract</span>
                    </a>
                </li>
                <li class="<?php echo (\Yii::$app->controller->id === "item-work") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("item-work/index") ?>">
                        <i class="fa fa-object-group"></i> <span>Item Work Management</span>
                    </a>
                </li>
                
                <li class="treeview <?php echo (Yii::$app->controller->id == in_array(\Yii::$app->controller->id, ['project','project-budget','punch-list','rfi','rfi-log','project-schedule-management','purchase-order','team','project-proposal','buyout-log','submittal','change-order','change-order-log','submittal-log'])) ? 'active' : '' ?>">
                    <a href="#">
                        <i class="fa fa-building"></i>
                        <span>Project</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a> 
                    <ul class="treeview-menu main-module"> 

                        <li class="<?php echo (\Yii::$app->controller->id === "project") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("project/index") ?>">
                                <i class="fa fa-building"></i> <span>Project Management</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "team") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("team/index") ?>">
                                <i class="fa fa-group"></i> <span>Team</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "project-budget") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("project-budget/index") ?>">
                                <i class="fa fa-usd"></i> <span>Project Budget Management</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "project-proposal") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("project-proposal/index") ?>">
                                <i class="fa fa-usd"></i> <span>Project Proposal</span>
                            </a>
                        </li>
                        
                         <li class="<?php echo (\Yii::$app->controller->id === "punch-list") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("punch-list/index") ?>">
                                <i class="fa fa-building"></i> <span>Punch List</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "rfi") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("rfi/index") ?>">
                                <i class="fa fa-building"></i> <span>RFI</span>
                            </a>
                        </li>
                        
                        <li class="<?php echo (\Yii::$app->controller->id === "rfi-log") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("rfi-log/index") ?>">
                                <i class="fa fa-history"></i> <span>RFI Log</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "project-schedule-management") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("project-schedule-management/index") ?>">
                                <i class="fa fa-building"></i> <span>Project Schedule</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "purchase-order") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("purchase-order/index") ?>">
                                <i class="fa fa-info-circle"></i> <span>Purchase Order</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "buyout-log") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("buyout-log/index") ?>">
                                <i class="fa fa-history"></i> <span>Buyout Log</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "change-order") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("change-order/index") ?>">
                                <i class="fa fa-info-circle"></i> <span>Change Order</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "change-order-log") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("change-order-log/index") ?>">
                                <i class="fa fa-history"></i> <span>Change Order Log</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "submittal") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("submittal/index") ?>">
                                <i class="fa fa-info-circle"></i> <span>Submittal</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "submittal-log") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("submittal-log/index") ?>">
                                <i class="fa fa-history"></i> <span>Submittal Log</span>
                            </a>
                        </li>

                    </ul> 
                </li> 

                <li class="treeview <?php echo (Yii::$app->controller->id == in_array(\Yii::$app->controller->id, ['country', 'state', 'city'])) ? 'active' : '' ?>">
                    <a href="#">
                        <i class="fa fa-map-marker"></i>
                        <span>Location</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a> 
                    <ul class="treeview-menu main-module"> 
                   <!-- <li class="<?php echo (\Yii::$app->controller->id === "country") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("country/index") ?>">
                                    <i class="fa fa-globe"></i> <span>Country</span>
                            </a>
                    </li> -->
                        <li class="<?php echo (\Yii::$app->controller->id === "state") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("state/index") ?>">
                                    <i class="fa fa-flag"></i> <span>State</span>
                            </a>
                        </li>
                        <li class="<?php echo (\Yii::$app->controller->id === "city") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("city/index") ?>">
                                    <i class="fa fa-building"></i> <span>City</span>
                            </a>
                        </li>
                    </ul> 
                </li> 

                      
                <li class="<?php echo (\Yii::$app->controller->id === "task-allocation") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("task-allocation/index") ?>">
                        <i class="fa fa-tasks"></i> <span>Task Allocation</span>
                    </a>
                </li>  

                <li class="<?php echo (\Yii::$app->controller->id === "action-item") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("action-item/index") ?>">
                        <i class="fa fa-tasks"></i> <span>Action Item</span>
                    </a>
                </li>

                <li class="treeview <?php echo (Yii::$app->controller->id == in_array(\Yii::$app->controller->id, ['task-allocation-report','project-report'])) ? 'active' : '' ?>">
                    <a href="#">
                        <i class="fa fa-area-chart"></i>
                        <span>Reports</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a> 
                    <ul class="treeview-menu main-module"> 

                        <li class="<?php echo (\Yii::$app->controller->id === "task-allocation-report") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("task-allocation-report/index") ?>">
                                <i class="fa fa-building"></i> <span>Task Allocation Report</span>
                            </a>
                        </li>

                        <li class="<?php echo (\Yii::$app->controller->id === "project-report") ? 'active' : '' ?>">
                            <a href="<?php echo \Yii::$app->urlManager->createUrl("project-report/index") ?>">
                                <i class="fa fa-building"></i> <span>Project Report</span>
                            </a>
                        </li>

                    </ul> 
                </li>  

                <li class="<?php echo (\Yii::$app->controller->id === "setting") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("setting/index") ?>">
                        <i class="fa fa-gears"></i> <span>Site Configuration</span>
                    </a>
                </li>
                
                <li class="<?php echo (\Yii::$app->controller->id === "site") ? 'active' : '' ?>">
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("site/logout") ?>">
                        <i class="fa fa-sign-out"></i> <span>Signout</span>
                    </a>
                </li>
            </ul>
        </section> 
        <!-- /.sidebar music-->
    </aside>
<?php } ?>