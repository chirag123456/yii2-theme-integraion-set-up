<?php
use yii\helpers\Html;
use backend\assets\AppAsset;
use yii\helpers\Url;

AppAsset::register($this);
$this->title = 'Couch Construction | Admin Panel | Login';

$baseUrl = Url::base(true);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>

<html lang="<?php echo Yii::$app->language ?>">
    <head>
        <meta charset="<?php echo Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- <link rel="icon" type="image/png" href="<?php echo $baseUrl; ?>/web/favicon.ico" /> -->
        <?php echo Html::csrfMetaTags() ?>
        <title><?php echo Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>

    <body class="hold-transition skin-blue sidebar-mini">
        <?php $this->beginBody() ?>

        <div class="wrapper">            
            <?php echo $this->render('header-login'); ?>
              <?php //echo $this->render('side-bar-login');?> 
                <div class="content-wrapper login-box-cust">

                    <?php echo $content ?>
                </div>
            
        </div>
    <?php echo $this->render('footer'); ?>


        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>