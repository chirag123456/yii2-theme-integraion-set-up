
<footer class="main-footer" style='margin: 0px;'>
    
    <strong>Copyright &copy; <?= date('Y')?> <a href="#"> "Couch Construction Services"</a>.</strong> All rights
    reserved.
  </footer>

                        
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
