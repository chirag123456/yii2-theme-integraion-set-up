<?php

use yii\helpers\Url;

$baseUrl = Url::base(true);
?>
<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><img src="<?php echo $baseUrl; ?>/web/images/logo/logo-lg.png" alt="logo-lg"/></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg">
            <img src="<?php echo $baseUrl; ?>/web/images/logo/logo-lg.png" alt="logo-lg"/>
            
        </span>
    </a>





    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <?php if (isset(Yii::$app->user->identity->id)) { ?>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                    <!-- Messages: style can be found in dropdown.less-->

                    <!-- Notifications: style can be found in dropdown.less -->

                    <!-- User Account: style can be found in dropdown.less -->
                    
                    <li class="dropdown user user-menu">
                      

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">

                             <?php 
                             if (isset(Yii::$app->user->identity->user_image) && !empty(Yii::$app->user->identity->user_image)) 
                            
                             	{  
                                $file = Yii::$app->request->hostInfo . USER_PROFILE_PATH . Yii::$app->user->identity->user_image; ?>

                                <img src="<?php echo $file; ?>" class="user-image" alt="User Image">  
                                                                  
                            <?php } else { ?>
                                <img src="<?php echo Yii::$app->request->BaseUrl . 'uploads/default_image.png' ?>" class="user-image" alt="User Image">                                      
                            <?php } ?>
                            <?php if (isset(Yii::$app->user->identity->username)) { ?>
                                <span class="hidden-xs"><?php echo Yii::$app->user->identity->username; /* . ' ' . Yii::$app->user->identity->name */ ?></span>
                            <?php } ?>
                        </a>


                        <ul class="dropdown-menu">
                            <!-- User image -->
                            <li>
                                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['user/update/' . Yii::$app->user->identity->id]) ?>" ><i class="fa fa-edit"></i> Edit Profile</a>
                            </li>
                            <li>
                                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['user/change-password/' . Yii::$app->user->identity->id]) ?>" ><i class="fa fa-lock"></i> Change Password</a>
                            </li><li class="sign-out">   
                                <?php
                                echo \yii\helpers\Html::a(
                                        '<i class="fa fa-sign-out"></i>Sign out', \yii\helpers\Url::to(['site/logout']), [
                                    'data-confirm' => "Do you want to signout?", // <-- confirmation works...
                                        /*  'data-method' => 'post', */
                                        //'class' => "btn btn-default"
                                        ]
                                );
                                ?>
                            </li>

                        </ul>
                    </li>

                </ul>
            </div>
        <?php } ?>
    </nav>
</header>



<?php
//$this->registerJs("
//   $('.sign-out').click(function(){
//        var r= confirm('Do you want to signout?');
//        if (r==true)   {  
//           window.location = 'http://localhost/swift-latest/backend/site/logout';
//        }
//    });    
//");
?>
