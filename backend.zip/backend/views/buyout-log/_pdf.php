<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?>
  
<div class="order-create">
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Buyout Log Details</h3> 
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'options' => ['class' => 'detail1-view'],
                                'attributes' => [
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                ],
                                [
                                    'attribute' => 'purchase_order_no',
                                    'headerOptions' => ['title' => 'sort by'],

                                    
                                ],
                                [
                                    'attribute' => 'architect_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->architect->email;
                                    },
                                ],
                                [
                                    'attribute' => 'contractor_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->contractor->email;
                                    },
                                ],
                                [
                                    'attribute' => 'contract_for',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'job_no',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'job_name',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'order_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'delivery_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'to_be_shipped_via',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'fob',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'issued_by',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'issued_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'accepted_by',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'accepted_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'sub_total',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'tax',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'other_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'total_amt',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                            ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Order Item Information</h3>  
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                   <div class="order-form">
                    <table class="table table-bordered" style="font-family: sans-serif;border: 1px solid #CECECE;
    border-collapse: collapse;">
                        <thead>
                          <tr>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">SR.</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Item Name</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Quantity</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Unit</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Description</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Cost Code</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Unit Price</th>
                            <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Extended Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 

                            if(isset($model1) && $model1 != '')
                            {
                                $i = 1;
                                foreach ($model1 as  $value) {                                   
                                ?>
                                    <tr>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $i; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->item->name; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->qty ; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->unit; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->description; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->cost_code; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->unit_price; ?></td>
                                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->extended_amt; ?></td>
                                    </tr>
                                <?php    $i++;
                                }
                            }
                        ?>
                        </tbody>
                    </table>   
                    </div>     
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>