<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?> 

<div class="order-create">
<section class="content-header">
    <h1> Buyout Log </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("buyout-log/index") ?>" >Buyout Log</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Buyout Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                ],
                                [
                                    'attribute' => 'purchase_order_no',
                                    'headerOptions' => ['title' => 'sort by'],

                                    
                                ],
                                [
                                    'attribute' => 'architect_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->architect->email;
                                    },
                                ],
                                [
                                    'attribute' => 'contractor_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->contractor->email;
                                    },
                                ],
                                [
                                    'attribute' => 'contract_for',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'job_no',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'job_name',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'order_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'delivery_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'to_be_shipped_via',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'fob',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'issued_by',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'issued_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'accepted_by',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'accepted_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'sub_total',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'tax',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'other_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'total_amt',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                            ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Buyout Item Information</h3> 
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                   <div class="order-form">
                    <table class="table">
                        <thead>
                          <tr>
                            <th>SR.</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Description</th>
                            <th>Cost Code</th>
                            <th>Unit Price</th>
                            <th>Extended Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 

                            if(isset($model1) && $model1 != '')
                            {
                                $i = 1;
                                foreach ($model1 as  $value) {                                   
                                ?>
                                    <tr>
                                        <td><?= $i; ?></td>
                                        <td><?= $value->item->name; ?></td>
                                        <td><?= $value->qty ; ?></td>
                                        <td><?= $value->unit; ?></td>
                                        <td><?= $value->description; ?></td>
                                        <td><?= $value->cost_code; ?></td>
                                        <td><?= $value->unit_price; ?></td>
                                        <td><?= $value->extended_amt; ?></td>
                                    </tr>
                                <?php    $i++;
                                }
                            }
                        ?>
                        </tbody>
                    </table>   
                    </div>     
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>