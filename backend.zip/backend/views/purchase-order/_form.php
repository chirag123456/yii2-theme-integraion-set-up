<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use dosamigos\ckeditor\CKEditor; 
use common\models\order\OrderItemForm;
use common\models\order\OrderItem;
use backend\components\CommonFunctions;
use kartik\date\DatePicker;

$this->title = 'Purchase Order | ' . isset($_GET['id']) ? 'Update' : 'Add';
?> 
<section class="content-header">
    <h1> Purchase Order </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("purchase-order/index") ?>" >Purchase Order</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Purchase Order' : 'Add Purchase Order'; ?></li>
    </ol>
</section>
<section class="content">  
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Purchase Order' : 'Add Purchase Order'; ?></h4>
      </div> 
      <div class="card-body project-budget-management-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'order-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
            ]);
                        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Purchase Order Information </h3>
            <hr>
            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();
                ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'purchase_order_no')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter Purchase Order Number','class' => 'form-control']) ?>
                </div>
              </div>

              <?php /*<div class="col-md-4">
                <div class="form-group">
                    
                        $form->field($model, 'owner_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\ownerinformation\OwnerInformation::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'owner_email'),
                            'options' => ['placeholder' => 'Select Owner'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();
                 
                </div>
              </div>*/ ?>

              <!--/span-->
            </div>
            <div class="row p-t-20">             
              <!--/span-->
              
              <div class="col-md-4">
                <div class="form-group"> 
                    <?php 
                    $role = CommonFunctions::getConfigureValueByKey('ARCHITECTURE_USER_ID');
                    //$model->architect_id = $role;
                    echo $form->field($model, 'architect_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            }), 
                              'options' => ['placeholder' => 'Select Architect'],
                      ])->label();  
                   ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                     <?php  
                    $role = CommonFunctions::getConfigureValueByKey('GENERAL_CONTRACTOR_USER_ID');
                    echo $form->field($model, 'contractor_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            }), 
                              'options' => ['placeholder' => 'Select Architect'],
                      ])->label();  
                   ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group"> 
                    <?php 
                          $contract_for1 = ['CONSTRUCTION' => 'Construction', 'DEMOLITION' => 'Demolotion'];

                            echo $form->field($model, 'contract_for')
                            ->dropDownList($contract_for1 ,['prompt' => 'Select Contracto For'])->label(); ?>
                </div>
              </div>

              <!--/span-->
            </div>

           

            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                     <?php echo $form->field($model, 'job_no')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter Job No.','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'job_name')->textInput(['autofocus' => true, 'maxlength' => 100, 'placeholder' => 'Enter Job Name','class' => 'form-control']) ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                     <?php 
                        echo $form->field($model, 'order_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Order Date','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                ?>
                </div>
              </div>
              <!--/span-->
            </div>

            

            <div class="row p-t-20">             
              <!--/span-->
              
              <div class="col-md-3">
                <div class="form-group"> 
                    <?php 
                        echo $form->field($model, 'delivery_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Delivery\ Date','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                ?>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                    <?php echo $form->field($model, 'to_be_shipped_via')->textInput(['autofocus' => true, 'maxlength' => 100, 'placeholder' => 'Enter To Be Shipped Via','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                    <?php echo $form->field($model, 'fob')->textInput(['autofocus' => true, 'maxlength' => 100, 'placeholder' => 'Enter Fob','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'shipping_handling')->textInput(['autofocus' => true, 'maxlength' => 100, 'placeholder' => 'Enter Shipping Handling','class' => 'form-control']) ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <!--/row-->
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Order Item Information</h3>
            <hr>
            
              <?php 
                
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  $details = OrderItem::find()->where(['order_id'=> $_GET['id']] )->all();  
                }
                
                if(isset($details) && !empty($details))
                {
                    $i = 0 ;
                    foreach ($details as $value) {

                      $orderItemForm = new OrderItemForm();
                      $model1 = $orderItemForm->getUpdateModel($value);
                      if($i == 0)
                      {
                        $class =  "row add";
                      }
                      else
                      {
                        $class =  "row add".$i;  
                      }
                      
                      ?>
                      <div class="<?= $class?> cal">
                      <div class="col-md-4">                   
                       <?php //echo $form->field($model1, 'item_name')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Item Name','class' => 'form-control custom-val name-change-item-name','required'=>true]) ?> 
                       <?php
                          $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id',  function($model) {
                                return $model['cost_code'].' - '.$model['name'];
                            });
                          echo $form->field($model1, 'item_id')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Name','required'=>true,'class' => 'form-control custom-val name-change-item-name']);
                        ?> 
                      </div>
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'qty')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Quantity','class' => 'form-control custom-val name-change-qty custom-qty','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div>
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'unit')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Unit','class' => 'form-control custom-val name-change-unit','required'=>true]) ?>
                      </div>
                      <div class=" col-md-3">
                        <?php echo $form->field($model1, 'description')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Descriptions','class' => 'form-control custom-val name-change-desc','required'=>true]) ?>                     
                    </div>
                      <?php /*<div class="col-md-4"> 
                          echo $form->field($model1, 'cost_code')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter Cost Code','class' => 'form-control custom-val name-change-cost-code','required'=>true]) 
                      </div>*/ ?>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'unit_price')->textInput(['autofocus' => true, 'maxlength' => 50, 'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','placeholder' => 'Enter Unit Price','class' => 'form-control custom-val name-change-unit-price custom-unit-price','required'=>true]) ?>
                      </div>  
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'extended_amt')->textInput(['autofocus' => true,'readonly' => true, 'maxlength' => 150, 'placeholder' => 'Enter Extended Amount','class' => 'form-control custom-val custom-val-amt name-change-extended-amt custom-val-amt','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','onKeyUp'=>'return calculateSum(this.id);']) ?>
                      </div> 
                      
                      
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                    </div>
                <?php $i++;    }  
                }
                else
                {
                  $model1 = new OrderItemForm(); 
                ?>
                <div class="row add cal">  
                  <div class="col-md-4">                   
                       <?php
                          $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id',  function($model) {
                                return $model['cost_code'].' - '.$model['name'];
                            });
                          echo $form->field($model1, 'item_id[]')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Name','required'=>true,'class' => 'form-control custom-val']);
                        ?> 
                      </div>
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'qty[]')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Quantity','class' => 'form-control custom-val custom-qty','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div>
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'unit[]')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Unit','class' => 'form-control custom-val','required'=>true]) ?>
                      </div>
                      <div class=" col-md-4">
                        <?php echo $form->field($model1, 'description[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Descriptions','class' => 'form-control custom-val','required'=>true]) ?>                     
                    </div>
                      <?php /*<div class="col-md-4"> 
                          echo $form->field($model1, 'cost_code[]')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Cost Code','class' => 'form-control custom-val','required'=>true]) 
                      </div>*/ ?>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'unit_price[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Unit Price','class' => 'form-control custom-val custom-unit-price','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div>  
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'extended_amt[]')->textInput(['autofocus' => true,'readonly' => true, 'maxlength' => 150, 'placeholder' => 'Enter Extended Amount','class' => 'form-control custom-val custom-val-amt','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','onKeyUp'=>'return calculateSum(this.id);']) ?>
                      </div> 
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                <?php  
                }
              ?>    
            </div>
            <div class="a" id="l"></div>
            <a style="cursor: pointer; margin-right: 36px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>        
            <h3 class="box-title m-t-40"><i class="fa fa-dollar" aria-hidden="true"></i> Costing</h3>
            <hr> 
            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'sub_total')->textInput(['autofocus' => true,'readonly' => true, 'maxlength' => 100, 'placeholder' => 'Enter Sub Total','class' => 'form-control','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                    <?php echo $form->field($model, 'tax')->textInput(['autofocus' => true, 'maxlength' => 100,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);', 'placeholder' => 'Enter Tax','class' => 'form-control','onKeyUp'=>'return calculateTotal(this.id);']) ?>
                </div>
              </div>
              

              <div class="col-md-3">
                <div class="form-group">
                    <?php echo $form->field($model, 'other_cost')->textInput(['autofocus' => true, 'maxlength' => 100,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);', 'placeholder' => 'Enter Othe Cost','class' => 'form-control','onKeyUp'=>'return calculateTotal(this.id);']) ?>
                </div>
              </div>

               <div class="col-md-3">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'total_amt')->textInput(['autofocus' => true, 'maxlength' => 100,'readonly' => true, 'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);' ,'placeholder' => 'Enter Total Amount','class' => 'form-control']) ?>
                </div>
              </div>
              <!--/span-->
            </div>  
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Additional Terms or Comments</h3>
            <hr>
          <div class="row p-t-20">
              <div class="custom-issued">
                  <div class="col-md-6">
                    <div class="form-group">
                        <?php echo $form->field($model, 'issued_by')->textInput(['autofocus' => true, 'maxlength' => 100, 'placeholder' => 'Enter Issued By','class' => 'form-control']) ?>
                    </div>
                  </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php 
                        echo $form->field($model, 'issued_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Issued Date','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                ?>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                    <?php echo $form->field($model, 'accepted_by')->textInput(['autofocus' => true, 'maxlength' => 100, 'placeholder' => 'Enter Accepted By','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php 
                        echo $form->field($model, 'accepted_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Acccepted Date','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                ?>
                </div>
              </div>
              
              <!--/span-->
            </div>
            <div class="row p-t-20">   
                <div class="col-md-12">
                    <div class="form-group">
                        <ul class="conditions-and-exclusions"> 
                            <li><b>ALL QUANTITIES, COLORS, AND SIZES TO BE VERIFIED WITH SUPERINTENDENT BEFORE SHIPMENT</b></li>
                            <li>Include P.O. Number And Job Number On All Invoices And Correspondence</li>
                            <li>Please Notify Us Immediately If This Order Cannot Be Filled On Time</li>
                            <li>All Deliveries Must Be Coordinated With The Project Manager Or Superintendent</li>
                            <li>All Deliveries Must Be Accepted By And Signed For By The Project Manager Or Superintendent</li>
                            <li>This Purchase Order voids any previous Agreements.</li>
                        </ul>
                    </div>
                </div>
            </div>
            
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['purchase-order/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php 
$this->registerJs("
  $('.name-change-item-name').attr('name', 'OrderItemForm[item_id][]');
  $('.name-change-qty').attr('name', 'OrderItemForm[qty][]');
  $('.name-change-unit').attr('name', 'OrderItemForm[unit][]');
  $('.name-change-desc').attr('name', 'OrderItemForm[description][]');
  $('.name-change-cost-code').attr('name', 'OrderItemForm[cost_code][]');
  $('.name-change-unit-price').attr('name', 'OrderItemForm[unit_price][]');
  $('.name-change-extended-amt').attr('name', 'OrderItemForm[extended_amt][]');
        $('.addd').click(function(){
          $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
          //$('.xcas').find(':input').val('');
          calculateSum();
          calculateTotal();
        });   
        $('.remove_daterow').click(function(){      
          $(this).closest('.xcas').remove();
          calculateSum();
          calculateTotal();
        });   

        $('.cal').on('input', '.custom-qty', function(){

          var total_row = $(this).val();
          
          if($(this).parent().parent().parent().children('.col-md-3').children('.field-orderitemform-unit_price').children('.custom-unit-price').val() == '' || $(this).parent().parent().parent().children('.col-md-3').children('.field-orderitemform-unit_price').children('.custom-unit-price').val() == 'undefined')
          {
            var price = 0;
          }
          else
          {
            var price = $(this).parent().parent().parent().children('.col-md-3').children('.field-orderitemform-unit_price').children('.custom-unit-price').val();
          }
          total_row *= price;
          $(this).parent().parent().parent().children('.col-md-4').children('.field-orderitemform-extended_amt').children('.custom-val-amt').val(total_row);
          calculateSum();
          calculateTotal();
    });

    $('.cal').on('input', '.custom-unit-price', function(){

          var total_row = $(this).val();
          
          if($(this).parent().parent().parent().children('.col-md-4').children('.field-orderitemform-qty').children('.custom-qty').val() == '' || $(this).parent().parent().parent().children('.col-md-4').children('.field-orderitemform-qty').children('.custom-qty').val() == 'undefined')
          {
            var qty = 0;
          }
          else
          {
            var qty = $(this).parent().parent().parent().children('.col-md-4').children('.field-orderitemform-qty').children('.custom-qty').val();
          }
          total_row *= qty;
          $(this).parent().parent().parent().children('.col-md-4').children('.field-orderitemform-extended_amt').children('.custom-val-amt').val(total_row);
          calculateSum();
          calculateTotal();
    });
           
  ");
?>
<script type="text/javascript">
  
  // calculate Sub Total      

  function calculateSum() {
    var calculated_total_sum = 0;

    $('.custom-val-amt').each(function () {
     var get_textbox_value = $(this).val();
     if ($.isNumeric(get_textbox_value)) {
      calculated_total_sum += parseFloat(get_textbox_value);
    }                  
  });
    $('#orderform-sub_total').val(calculated_total_sum);  
    calculateTotal();

  }

  // calculate Total

  function calculateTotal() {
    if($("#orderform-sub_total").val() == '')
    {
      var subtotal = 0;
    }
    else
    {
      var subtotal = $("#orderform-sub_total").val(); 
    }
    if($("#orderform-tax").val() == '')
    {
      var tax = 0;
    }
    else
    {
      var tax = $("#orderform-tax").val();
    }
    if($("#orderform-other_cost").val() == '')
    {
      var cost = 0;
    }
    else
    {
      var cost = $("#orderform-other_cost").val();
    }
    var calculated_total_sum = 0;
    calculated_total_sum += parseFloat(subtotal);
    calculated_total_sum += parseFloat(tax);
    calculated_total_sum += parseFloat(cost);
    $('#orderform-total_amt').val(calculated_total_sum);       
  }
</script> 
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>