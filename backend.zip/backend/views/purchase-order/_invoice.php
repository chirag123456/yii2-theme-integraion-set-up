<html>
    <head>
        <meta charset="utf-8">
        <title>Invoice</title>
        <link rel="license" href="https://www.opensource.org/licenses/mit-license/">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
        
        <style>
            /* reset */
            body{font-family: 'Open Sans', sans-serif;}
            *
            {
                border: 0;
                box-sizing: content-box;
                color: inherit;
                font-family: inherit;
                font-size: inherit;
                font-style: inherit;
                font-weight: inherit;
                line-height: inherit;
                list-style: none;
                margin: 0;
                padding: 0;
                text-decoration: none;
                vertical-align: top;
            }

            /* content editable */

            *[contenteditable] { border-radius: 0.25em; min-width: 1em; outline: 0; }

            *[contenteditable] { cursor: pointer; }

            *[contenteditable]:hover, *[contenteditable]:focus, td:hover *[contenteditable], td:focus *[contenteditable], img.hover { background: #DEF; box-shadow: 0 0 1em 0.5em #DEF; }

            span[contenteditable] { display: inline-block; }

            /* heading */

            h1 { font: bold 100% sans-serif; letter-spacing: 0.5em; text-align: center; text-transform: uppercase; }

            /* table */

            table { font-size: 75%; table-layout: fixed; width: 100%; }
            table { border-collapse: separate; border-spacing: 2px; }
            th, td { border-width: 1px; padding: 0.5em; position: relative; text-align: left; }
            th, td { border-radius: 0.25em; border-style: solid; }
            th { background: #EEE; border-color: #BBB; }
            td { border-color: #DDD; }
.main-header-top tr td, .main-header tr td p {
                border: none;
                display: block;
                padding: 3px;
            }
            table.main-header [contenteditable], .imgss{
                float: left;
                /* display: block !important; */
                width: 45%;
                display:inline-block;
            }
            /* page */

           
            html { background: #999; cursor: default; }

            body { box-sizing: border-box; height: 11in; margin: 0 auto; overflow: hidden; padding: 0.5in; width: 8.5in; }
            body { background: #FFF; border-radius: 1px; box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5); }

            /* header */

            header { margin: 0 0 3em; }
            header{padding:50px;}
            header:after { clear: both; content: ""; display: table; }

            header h1 { background: #000; border-radius: 0.25em; color: #FFF; margin: 0 0 1em; padding: 0.5em 0; }
            header address { float: left; font-size: 75%; font-style: normal; line-height: 1.25; display:inline-block;}
            header address p { margin: 0 0 0.25em; }
            header span{ display: inline-block; float:right;}
            header span { margin: 0 0 1em 1em; max-height: 25%; max-width: 60%; position: relative; }
            header img { max-height: 100%; max-width: 100%; margin-right: -38px;position: relative; }
            header input { cursor: pointer; -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"; height: 100%; left: 0; opacity: 0; position: absolute; top: 0; width: 100%; }

            /* article */

            article, article address, table.meta, table.inventory { margin: 0 0 3em; }
            article:after { clear: both; content: ""; display: table; }
            article h1 { clip: rect(0 0 0 0); position: absolute; }

            article address { float: left; font-size: 88%; font-weight: inherit; }

            /* table meta & balance */

            table.meta, table.balance { float: right; width: 50%; }
            table.meta:after, table.balance:after { clear: both; content: ""; display: table; }

            /* table meta */

            table.meta th { width: 40%; }
            table.meta td { width: 60%; }

            /* table items */

            table.inventory { clear: both; width: 100%; }
            table.inventory th { font-weight: bold; text-align: center; }

            table.inventory td:nth-child(1) { width: 26%; }
            table.inventory td:nth-child(2) { width: 38%; }
            table.inventory td:nth-child(3) { text-align: right; width: 12%; }
            table.inventory td:nth-child(4) { text-align: right; width: 12%; }
            table.inventory td:nth-child(5) { text-align: right; width: 12%; }

            /* table balance */

            table.balance th, table.balance td { width: 50%; }
            table.balance td { text-align: right; }

            /* aside */

            aside h1 { border: none; border-width: 0 0 1px; margin: 0 0 1em; }
            aside h1 { border-color: #999; border-bottom-style: solid; }

            /* javascript */

            .add, .cut
            {
                border-width: 1px;
                display: block;
                font-size: .8rem;
                padding: 0.25em 0.5em;  
                float: left;
                text-align: center;
                width: 0.6em;
            }

            .add, .cut
            {
                background: #9AF;
                box-shadow: 0 1px 2px rgba(0,0,0,0.2);
                background-image: -moz-linear-gradient(#00ADEE 5%, #0078A5 100%);
                background-image: -webkit-linear-gradient(#00ADEE 5%, #0078A5 100%);
                border-radius: 0.5em;
                border-color: #0076A3;
                color: #FFF;
                cursor: pointer;
                font-weight: bold;
                text-shadow: 0 -1px 2px rgba(0,0,0,0.333);
            }

            .add { margin: -2.5em 0 0; }

            .add:hover { background: #00ADEE; }

            .cut { opacity: 0; position: absolute; top: 0; left: -1.5em; }
            .cut { -webkit-transition: opacity 100ms ease-in; }

            tr:hover .cut { opacity: 1; }
            .main-header{float:left;width:100%;}
            .main-header .contenteditable{float:left;width:70%;}
            .main-header .contenteditable img{text-align:right;}
            .main-header .contenteditable p{
                padding:0;
                margin:0;
            }
            .table-constructions{width:50%;float:left;}
            
            .balance textarea{
                height:250px !important;
            }
            .table-invoice-balance{
                float:left;
                width:100%;
            }
            .invoicess{
                float:left;
                width:49%;
            }
            .job-section{
                float:right !important:
                width:100%;
                text-align:right;
            }
            .invoicess .table-constructions{width:100%; padding:10px;}
            .invoicess table{width:100%; padding:10px;}
            .table-constructions p{margin-bottom:0px;}
            .main-header .imgss{float:left;width:30%;}
            @media print {
                * { -webkit-print-color-adjust: exact; }
                html { background: none; padding: 0; }
                body { box-shadow: none; margin: 0; }
                span:empty { display: none; }
                .add, .cut { display: none; }
            }

            @page { margin: 0; }
        </style>
    </head>
    <body>
        <header  style="margin-top:0px; margin-bottom:0px;">
        <h1>Invoice</h1>
            <div class="main-header" style="margin-top:0px; margin-bottom:0px;">
                <div class="contenteditable">
                    <p style = "font-size: 120%; font-weight: bold;">Purchased By:</p>
                    <p style = "font-size: 100%; font-weight: bold;">Couch Construction Services, LLC</p>
                    <p>333 North Main Street</p>
                    <p>Alpharetta, GA  30009</p>
                    <p>Phone / Fax: 470.336.3355</p>
                </div>
                <div class="imgss"><img alt="" src="https://couchconstruction.xceltec.com/backend/web/images/logo/cc-logo-new.png"></div>
            </div>
        </header>
             <div class="main-header" style="margin-top:0px; margin-bottom:25px;">
                <div class="contenteditable" style="padding-left:50px;">
                    <p style = "font-size: 100%;font-weight: bold;">TO BE SHIPPED TO:</p>
                    <p>Couch Construction Services, LLC</p>
                    <p>333 North Main Street</p>
                    <p>Alpharetta, GA  30009</p>
                    <p>Phone / Fax: 470.336.3355</p>
                </div>
            </div>
            <div class="job-section" style="margin-bottom:25px;">
                    <table style="padding-left:50%; float:right; text-align:right; width:100%; margin-bottom:25px;">
                        <tr>
                            <th><span contenteditable>JOB NAME:</span></th>
                            <td><span contenteditable><?= $model->job_name?></span></td>
                        </tr>
                        <tr>
                            <th><span contenteditable>JOB #:</span></th>
                            <td><span contenteditable><?= $model->job_no?></span></td>
                        </tr>
                        <tr>
                            <th><span contenteditable>PURCHASE ORDER #:</span></th>
                            <td><span id="prefix" contenteditable><?=$model->purchase_order_no?></span></td>
                        </tr>
                        <tr>
                            <th><span contenteditable>ORDER DATE:</span></th>
                            <td><span id="prefix" contenteditable><?= $model->order_date ?></span></td>
                        </tr>
                        <tr>
                            <th><span contenteditable>DELIVERY DATE:</span></th>
                            <td><span id="prefix" contenteditable><?= $model->delivery_date ?></span><span>600.00</span></td>
                        </tr>
                        <tr>
                            <th><span contenteditable>F.O.B.:</span></th>
                            <td><span id="prefix" contenteditable><?= $model->fob ?></span></td>
                        </tr>
                        <tr>
                            <th><span contenteditable>TO BE SHIPPED VIA:</span></th>
                            <td><span id="prefix" contenteditable><?= $model->to_be_shipped_via?></span></td>
                        </tr>
                    </table>
                </div>
            <table class="inventory" style="padding-left:50px; padding-right:50px;">
                <thead>
                    <tr>
                        <th><span contenteditable>ITEM NAME</span></th>
                        <th><span contenteditable>QTY.</span></th>
                        <th><span contenteditable>UNIT</span></th>
                        <th><span contenteditable>DESCRIPTION</span></th>
                        <th><span contenteditable>COST CODE</span></th>
                        <th><span contenteditable>UNIT PRICE</span></th>
                        <th><span contenteditable>EXTENDED AMOUNT</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        if(isset($model1) && !empty($model1))
                        {
                            foreach ($model1 as $value) {
                    ?>
                        <tr>
                            <td><span contenteditable><?= $value->item->name?></span></td>
                            <td><span contenteditable><?= $value->qty ?></span></td>
                            <td><span contenteditable><?= $value->unit ?></span></td>
                            <td><span contenteditable><?= $value->description ?></span></td>
                            <td><span contenteditable><?= $value->cost_code ?></span></td>
                            <td><span data-prefix>$</span><span><?= $value->unit_price ?></span></td>
                            <td><span data-prefix>$</span><span><?= $value->extended_amt ?></span></td>
                        </tr>
                    <?php
                                
                            }
                        }
                    ?>
                    
                </tbody>
            </table>
            
            <div class="table-invoice-balance" style="padding-left:40px; padding-right:40px;">
                <div class="balance invoicess">
                    <div class="table-constructions">
                        <p style="font-weight: bold;font-size: 79%;">Couch Construction Services, LLC. - OFFICE USE ONLY</p>
                        <p style="margin-top: 0px !important;">Comments:</p>
                        <textarea name="" id="" cols="75" rows="10" style="height:90px;"></textarea>
                    </div>
                </div>
                <div class="invoicess">
                    <table class="balance">
                    <tr>
                        <th><span contenteditable>SUBTOTAL</span></th>
                        <td><span data-prefix>$</span><span><?= $model->sub_total ?></span></td>
                    </tr>
                    <tr>
                        <th><span contenteditable>TAX</span></th>
                        <td><span data-prefix>$</span><span contenteditable><?= $model->tax?></span></td>
                    </tr>
                    <tr>
                        <th><span contenteditable>SHIPPING & HANDLING</span></th>
                        <td><span data-prefix>$</span><span><?= $model->shipping_handling?></span></td>
                    </tr>
                    <tr>
                        <th><span contenteditable>OTHER COST</span></th>
                        <td><span data-prefix>$</span><span><?= $model->other_cost?></span></td>
                    </tr>
                    <tr>
                        <th><span contenteditable>TOTAL</span></th>
                        <td><span data-prefix>$</span><span><?= $model->total_amt?></span></td>
                    </tr>
                    </table>
                </div>
            </div>
        <aside style="margin-top:25px;" style="padding-left:40px; padding-right:40px;">
            <h1><span contenteditable>Additional Terms or Comments:</span></h1>
            <div contenteditable>
                <p style="font-weight:bold; font-size:75%">1. ALL QUANTITIES, COLORS, AND SIZES TO BE VERIFIED WITH SUPERINTENDENT BEFORE SHIPMENT</p>
                <p style="font-size:75%; margin-top:10px"> 2.Include P.O. Number And Job Number On All Invoices And Correspondence</p>
                <p style="font-size:75%; margin-top:10px"> 3.Please Notify Us Immediately If This Order Cannot Be Filled On Time</p>
                <p style="font-size:75%; margin-top:10px"> 4.All Deliveries Must Be Coordinated With The Project Manager Or Superintendent</p>
                <p style="font-size:75%; margin-top:10px"> 5.All Deliveries Must Be Accepted By And Signed For By The Project Manager Or Superintendent</p>
                <p style="font-size:75%; margin-top:10px"> 6.This Purchase Order voids any previous Agreements.</p>
            </div>
        </aside>
    </body>
</html>