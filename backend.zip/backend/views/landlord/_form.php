<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
?> 

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<style type="text/css">
    

.card .card-body [type="radio"]:not(:checked), .card .card-body [type="radio"]:checked {
    position: static; 
    left: -9999px; 
    opacity: 1; 
}
.hidden{
    display: none;
}
</style>
<section class="content-header">
    <h1> Landlord </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("landlord/index") ?>" >Landlord</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Landlord' : 'Add Landlord'; ?></li>
    </ol>
</section>

<section class="content"> 
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Landlord' : 'Add Landlord'; ?></h4>
      </div>
      <div class="card-body project-landlord-form">
        <?php
            $form = ActiveForm::begin([
                        'id' => 'landlord-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data']
            ]);
        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Landlord Contact information </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?php
                      if(isset($_GET['id']) && !empty($_GET['id']))
                      {
                        echo $form->field($model, 'landlord_email')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Landlord Email','disabled'=>true]) ;
                      } 
                      else
                      {
                        echo $form->field($model, 'landlord_email')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Landlord Email']) ;
                      }
                      ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'landlord_phone')->textInput(['maxlength' => 12, 'placeholder' => 'Enter Landlord Phone Number']) ?>
                </div>
              </div> 
              <!--/span-->

              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'landlord_contact_person')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Landlord Contact Person']) ?>
                </div>
              </div> 
              <!--/span-->
            </div>
            <h3 class="card-title"><i class="fa fa-map-marker" aria-hidden="true"></i> Landlord Address </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'landlord_address')->textArea(['maxlength' => 300,'placeholder' => 'Enter Landlord Address']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                    <?php 
                                    
                      echo $form->field($model, 'landlord_state_id')->widget(
                       Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\state\State::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'state_name'),
                      'options' => ['placeholder' => 'Select State','onchange' => '
                          $.post( "' . Yii::$app->urlManager->createUrl('city/set-city?id=') . '"+$(this).val(), function( data ) {
                          $("#title").html( data );
                          });
                      '],
                      'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                       ])->label(); 
                  ?>
                  
                </div>
              </div>
              <!--/span-->
            </div>
            
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?php 
                    echo $form->field($model, 'landlord_city_id')->widget(
                          Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\city\City::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED,'state_id' => $model->landlord_state_id])->asArray()->all(), 'id', 'name'),
                     'options' => ['placeholder' => 'Please Select state','id' => 'title'],
                     'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                      ])->label();
                  ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                    <?= $form->field($model, 'landlord_zipcode')->textInput(['maxlength' => 8, 'placeholder' => 'Enter Landlord Zipcode']) ?>
                </div>
              </div>
              <!--/span-->
            </div>

            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Landlord Requirements </h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 
                    'will_landlord_require_special_documentation_for_billing')->radioList(array('Y'=>'Yes','N'=>'No'));  ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6 custom-radio-hide hidden">
                <div class="form-group">
                    <?= $form->field($model, 'if_special_documentation_required_if_yes_list')->textArea(['maxlength' => 300,'placeholder' => 'Enter Documentations Requireents'])?>
                  
                </div>
              </div>
              <!--/span-->
            </div>

          </div>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php 
$this->registerJs("
    
    $('input[type=radio]').change(function() {
        if (this.value == 'Y') {
          $('#landlordform-if_special_documentation_required_if_yes_list').attr('required', true);
            $('.custom-radio-hide').removeClass('hidden');
        }
        else{
            $('.custom-radio-hide').addClass('hidden');
            $('#landlordform-if_special_documentation_required_if_yes_list').attr('required', false);
        }
    });
"); 

if(isset($_GET['id']) && !empty($_GET['id']))
{
  $this->registerJs("   
     var val = '".$model->will_landlord_require_special_documentation_for_billing."'; 
     

      if(val == 'N')
      {
        $('.custom-radio-hide').addClass('hidden');
        $('#landlordform-if_special_documentation_required_if_yes_list').attr('required', false);
      }
      else
      {
         $('.custom-radio-hide').removeClass('hidden');

          $('#landlordform-if_special_documentation_required_if_yes_list').attr('required', true);
      }
  ");
}

?>