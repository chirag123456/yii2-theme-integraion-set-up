<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Landlord */

$this->title = 'Update Landlord: {nameAttribute}';
$this->params['breadcrumbs'][] = ['label' => 'Landlords', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="landlord-update">

    

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
