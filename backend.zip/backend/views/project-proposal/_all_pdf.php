<?php
use yii\helpers\Html;
use common\models\project\ProjectProposal;
use common\models\project\ProjectProposalItem;

?> 

<div class="pdf-dealer container">
    <?php 
        foreach ($data as $val) {
    ?>
            <h4>Project Proposal</h4>
                <table class="table table-bordered" style="font-family: sans-serif;
                border: 1px solid #CECECE;
                border-collapse: collapse;">
                <thead>
                    <tr>
                        <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Project</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Project Size</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Cost Per Sf</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Estimated Design Duration Days</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item Sub Total</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Overall Overhead Per</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Overall Fee Per</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Contractor Fee</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item Total Cost</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Sub Contractor Total Cost</th>
                        <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Proposal Total Cost</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->project->project_name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->project->project_size ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->cost_per_sf ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->estimated_design_duration_days ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->item_sub_total ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->overhead ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->fee ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->item_total_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->sub_contractor_total_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->p_total_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $val->p_total_cost ?></td>
                    </tr> 



                </tbody>
            </table>

            <h4>Project Proposal Item</h4>

            <table class="table table-bordered" style="font-family: sans-serif;
            border: 1px solid #CECECE;
            border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Sr.</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item Work</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Cost</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Cost/SF</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Total %</th>
                    
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Subcontractor</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Subcontractor Estimate</th>
                    <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Proposed Spread</th>
                </tr>
            </thead>
            <tbody>

                <?php 
                $model1 = ProjectProposalItem::find()->where(['project_proposal_id' => $val->id ])->all();
                //$model1 = $porojectbudget->getProjectBudgetItemData($value['pb_id']);
                if(isset($model1) && !empty($model1))
                {
                    foreach ($model1 as $value) {
                        $i = 1;
                        ?>
                        <tr>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $i ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->item->cost_code.' - '.$value->item->name ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->cost ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->cost_sf ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->per_total ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->subcontractor->email ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->sub_contractor_estimate_cost ?></td>
                            <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->proposed_spread_per ?></td>
                        </tr> 
                        <?php
                        $i++;
                    }
                }                
                ?>
            </tbody>
        </table>
<?php
}
?>
</div>