<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Project Proposal </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project-proposal/index") ?>" >Project Proposal</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Project Proposal Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [
                                
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by last name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'project_size',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_size;
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by last name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'cost_per_sf',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'estimated_design_duration_days',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'item_sub_total',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'overhead',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'fee',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ], 
                                [
                                    'attribute' => 'contractor_overhead',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'contractor_fee',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'item_total_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'sub_contractor_total_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'p_total_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'p_desc',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function($model)
                                    {
                                        return strip_tags(trim($model->p_desc));
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                    ],
                                ],
                                    
                            ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Item Work Details</h3> 
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                   <div class="order-form">
                    <table class="table">
                        <thead>
                          <tr>
                            <th>Sr.</th>
                            <th>Item Work</th>
                            <th>Cost</th>
                            <th>Cost/SF</th>
                            <th>Total %</th>
                            <th>Comment</th>
                            <th>Subcontractor</th>
                            <th>Subcontractor Estimate</th>
                            <th>Proposed Spread</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 

                            if(isset($model1) && $model1 != '')
                            {
                                $i = 1;
                                foreach ($model1 as  $value) {                                   
                                ?>
                                    <tr>
                                        <td><?= $i?></td>
                                        <td><?php echo $value->item->cost_code.' - '.$value->item->name;  ?></td>
                                        <td><?php echo $value->cost; ?></td>
                                        <td><?php echo $value->cost_sf; ?></td>
                                        <td><?php echo $value->per_total; ?></td>
                                        <td><?php echo $value->comment; ?></td>
                                        <td><?php echo $value->subcontractor->first_name .' '.$value->subcontractor->last_name.'-'.$value->subcontractor->email ; ?></td>
                                        <td><?php echo $value->sub_contractor_estimate_cost; ?></td>
                                        <td><?php echo $value->proposed_spread_per; ?></td>
                                        
                                    </tr>
                                <?php  
                                $i++;   
                                }
                            }
                        ?>
                        </tbody>
                    </table>   
                    </div>     
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>