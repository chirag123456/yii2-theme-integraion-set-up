<?php

use yii\helpers\Html;
?>

<section class="content-header">
      <h1>
        Project Proposal
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
       <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("project-proposal/index") ?>" >Project Proposal</a></li>
        <li class="active">Edit Project Proposal</li>
      </ol>
  </section>
 <?= $this->render('_form', [
                            'model' => $model,
                        ]) ?>
