<?php
use yii\helpers\Html;

?>

<div class="pdf-dealer container">
    <h4>Project Proposal</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
    border: 1px solid #CECECE;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Project</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Project Size</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Cost Per Sf</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Estimated Design Duration Days</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item Sub Total</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Overall Overhead Per</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Overall Fee Per</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Contractor Fee</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item Total Cost</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Sub Contractor Total Cost</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Proposal Total Cost</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model) && !empty($model))
                {
            ?>
                    <tr>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->project->project_name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->project->project_size ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->cost_per_sf ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->estimated_design_duration_days ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->item_sub_total ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->overhead ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->fee ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->item_total_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->sub_contractor_total_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->p_total_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $model->p_total_cost ?></td>
                    </tr> 
            <?php
                }
                else
                {
            ?>
                    <tr>
                        <p> No Data Available</p>     
                    </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>

<div class="pdf-dealer container">
    <h4>Project Proposal Item</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Sr.</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Item Work</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Cost</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Cost/SF</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Total %</th>
                
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Subcontractor</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Subcontractor Estimate</th>
                <th style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px">Proposed Spread</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model1) && !empty($model1))
                {
                    $i = 1;
                    foreach ($model1 as $value) {
            ?>
                    <tr>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $i ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->item->cost_code.' - '.$value->item->name ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->cost_sf ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->per_total ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->subcontractor->email ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->sub_contractor_estimate_cost ?></td>
                        <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value->proposed_spread_per ?></td>
                    </tr> 
            <?php
                    $i++;
                    }
                }
                else
                {
            ?>
                <tr>
                    <p> No Data Available</p>     
                </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>