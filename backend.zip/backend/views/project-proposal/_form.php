<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use dosamigos\ckeditor\CKEditor; 
use common\models\projectbudget\ProjectBudgetItemForm;
use common\models\projectbudget\ProjectBudgetItem;
use backend\components\CommonFunctions;
use common\models\project\ProjectProposalItemForm;
use common\models\project\ProjectProposalItem;

$this->title = 'Project Proposal | ' . isset($_GET['id']) ? 'Update' : 'Add';
?>
<section class="content">  
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Project Proposal' : 'Add Project Proposal'; ?></h4>
      </div> 
      <div class="card-body project-budget-management-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'projectbudget-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
                  ]);
                        ?> 
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Project Proposal Information</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4"> 
                <?php echo $form->field($model, 'p_name')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Proposal Name'])?>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();
                ?>
                </div>
              </div>
              <div class="col-md-4"> 
                <?php echo $form->field($model, 'project_size')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Project Size'])?>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-6"> 
                <?php echo $form->field($model, 'estimated_design_duration_days')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Estimated Design Duration Days'])?>
              </div>
              <div class="col-md-6"> 
                <?php echo $form->field($model, 'cost_per_sf')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Cost SF'])?>
              </div>
              <!--/span-->
            </div>
            <!--/row-->
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Item Work</h3>
            <hr>
            
              <?php 
                
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  $details = ProjectProposalItem::find()->where(['project_proposal_id'=> $_GET['id']] )->all();  
                }
                
                if(isset($details) && !empty($details))
                {
                    $i = 0 ;
                    foreach ($details as $value) {
                      $projectBudgetItemForm = new ProjectProposalItemForm();
                      $model1 = $projectBudgetItemForm->getUpdateModel($value);
                      if($i == 0)
                      {
                        $class =  "row add";
                      }
                      else
                      {
                        $class =  "row add".$i;   
                      }
                      
                      ?>
                      <div class="<?= $class?> cal"> 
                      <div class="col-md-2">                   
                        <?php
                          $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['cost_code'].' - '.$model['name'];
                            });
                          echo $form->field($model1, 'item_id')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Work','required'=>true,'class' => 'form-control name-change-item']);
                        ?> 
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'cost')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Item Work Cost','class' => 'form-control custom-val name-change-cost custom-val-cost','onKeyUp'=>'return calculateSum(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','required'=>true,'onKeyUp'=>'return calculateSumOfItemSubTotal(this.id);','readonly'=>true]) ?>
                      </div>
                      <div class="col-md-2"> 
                        <?php echo $form->field($model1, 'cost_sf')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Cost SF','class' => 'form-control custom-val-cost-sf name-change-cost-sf','required'=>true]) ?>
                      </div>
                      <div class="col-md-2"> 
                        <?php echo $form->field($model1, 'per_total')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Percentage of Total','class' => 'form-control name-change-custom-per-total custom-val-per-total','required'=>true]) ?>
                      </div>
                      <div class="col-md-4"> 
                          <?php echo $form->field($model1, 'comment')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Comment','required'=>true,'class' => 'form-control name-change-comment']) ?>
                      </div>
                      <div class=" col-md-4">
                        <?php 
                            $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                            $dataPost = \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            });                          
                            echo $form->field($model1, 'sub_contractor_id')
                            ->dropDownList(
                            $dataPost ,['id' => 'title111', 'prompt' => 'Select Sub Contractor','required'=>true,'class' => 'form-control name-change-subcontractor'])->label('Sub Contractor');
                        ?>                       
                    </div>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'sub_contractor_estimate_cost')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Sub Contractor Estimate Cost','class' => 'form-control custom-val-contractor name-change-contractor-cost','onKeyUp'=>'return calculateSumOfContractor(this.id);','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div> 
                      <div class="col-md-4"> 
                        <?php echo $form->field($model1, 'proposed_spread_per')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Proposed Spread','class' => 'form-control custom-val-proposed_spread_per name-change-proposed-spread-per','required'=>true]) ?>
                      </div>  
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                    </div>
                <?php $i++;    } 
                }
                else
                {
                  $model1 = new ProjectProposalItemForm();
                ?>
                <div class="row add cal">  
                  <div class="col-md-2">                   
                    <?php
                      $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['cost_code'].' - '.$model['name'];
                            });
                        echo $form->field($model1, 'item_id[]')
                        ->dropDownList(
                        $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Work','required'=>true]);
                      ?> 
                  </div>
                  <div class="col-md-2"> 
                      <?php echo $form->field($model1, 'cost[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Item Work Cost','class' => 'form-control custom-val-cost','onKeyUp'=>'return calculateSum(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','required'=>true,'onKeyUp'=>'return calculateSumOfItemSubTotal(this.id);','readonly'=>true]) ?>
                  </div>
                  <div class="col-md-2"> 
                      <?php echo $form->field($model1, 'cost_sf[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Cost SF','class' => 'form-control custom-val-cost-sf','required'=>true]) ?>
                  </div>
                  <div class="col-md-2"> 
                      <?php echo $form->field($model1, 'per_total[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Percentage of Total','class' => 'form-control custom-val-per-total','required'=>true,'readonly'=>true]) ?>
                  </div>
                  <div class="col-md-4"> 
                      <?php echo $form->field($model1, 'comment[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Comment','required'=>true]) ?>
                  </div>
                  <div class=" col-md-4">
                    <?php 
                        $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                        $dataPost = \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                            return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                        });
                        echo $form->field($model1, 'sub_contractor_id[]')
                        ->dropDownList(
                        $dataPost ,['id' => 'title111', 'prompt' => 'Select Sub Contractor','required'=>true])->label('Sub Contractor');;
                    ?>
                                               
                  </div>
                  <div class="col-md-3"> 
                      <?php echo $form->field($model1, 'sub_contractor_estimate_cost[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Sub Contractor Estimate Cost','class' => 'form-control custom-val-contractor','onKeyUp'=>'return calculateSumOfContractor(this.id);','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                  </div>  
                  <div class="col-md-4"> 
                      <?php echo $form->field($model1, 'proposed_spread_per[]')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Proposed Spread','class' => 'form-control custom-val-proposed_spread_per','required'=>true]) ?>
                  </div> 
                  <div class="col-md-1" style="    margin-top: 26px;">                
                    <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 
                  </div>
                <?php  
                }
              ?>    
            </div>
            <div class="a" id="l"></div>
            <a style="cursor: pointer; margin-right: 36px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>

            <h3 class="box-title m-t-40"><i class="fa fa-usd" aria-hidden="true"></i> Costing </h3>
            <hr>
            <div class="row"> 
              <div class="col-md-6">
               <?php echo $form->field($model, 'sub_contractor_total_cost')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Sub Contractor Total Cost','readonly'=>true]) ?>
              </div>
              <div class="col-md-6">
                <?php echo $form->field($model, 'item_sub_total')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Item Total Cost','readonly'=>true]) ?>
              </div>               
            </div>
            
            <div class="row"> 
              <div class="col-md-6">
               <?php echo $form->field($model, 'overall_overhead_per')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Overall Overhead Percentage','readonly'=>false,'onKeyUp'=>'return calculateContractorOverhead();']) ?>
              </div>
              <div class="col-md-6">
                <?php echo $form->field($model, 'overall_fee_per')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Overall Fee Percentage','readonly'=>false,'onKeyUp'=>'return calculateContractorFee();']) ?>
              </div>              
            </div>

             <div class="row"> 
              <div class="col-md-6">
               <?php echo $form->field($model, 'contractor_overhead')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Contractor Overhead','readonly'=>true]) ?>
              </div>
              <div class="col-md-6">
                <?php echo $form->field($model, 'contractor_fee')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Contractor fee','readonly'=>true]) ?>
              </div>              
            </div>

            <div class="row"> 
              <div class="col-md-6">
                <?php echo $form->field($model, 'item_total_cost')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Item Total Cost','readonly'=>false]) ?>
              </div>
              <div class="col-md-6">
                <?php echo $form->field($model, 'p_total_cost')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Proposal Total Cost','readonly'=>false]) ?>
              </div>              
            </div>

            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Project Proposal Description</h3>
            <hr>
            <div class="row">
              <div class="col-md-12"> 
                  <?php echo $form->field($model, 'p_desc')->widget(CKEditor::className(), [
                          'options' => ['rows' => 6],
                          'preset' => 'basic'
                  ]) ?>
              </div>              
            </div>
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Conditions and Exclusions </h3>
            <hr style="border-top: 2px solid #ccc !important;">
                  <ul class="conditions-and-exclusions"> 
                    <li>Excludes "Service or Warranty" on existing fixtures and equipment.</li>
                    <li>Excludes cost of building permit, tap and utility fees.</li>
                    <li>NIC means not in contract.</li>
                    <li>Scope of work is based upon.</li>
                  </ul>             
          
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['project-proposal/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php
$this->registerJs("
  $('.name-change-cost').attr('name', 'ProjectProposalItemForm[cost][]');
  $('.name-change-item').attr('name', 'ProjectProposalItemForm[item_id][]');
  $('.name-change-comment').attr('name', 'ProjectProposalItemForm[comment][]');
  $('.name-change-subcontractor').attr('name', 'ProjectProposalItemForm[sub_contractor_id][]');
  $('.name-change-cost-sf').attr('name', 'ProjectProposalItemForm[cost_sf][]');
  $('.name-change-custom-per-total').attr('name', 'ProjectProposalItemForm[per_total][]');
  $('.name-change-proposed-spread-per').attr('name', 'ProjectProposalItemForm[proposed_spread_per][]');
  $('.name-change-contractor-cost').attr('name', 'ProjectProposalItemForm[sub_contractor_estimate_cost][]');

        $('.addd').click(function(){
          $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
          calculateSumOfItemSubTotal();
          calculateSumOfContractor();
          calculateContractorOverhead();
          calculateContractorFee();
          calculateSumOfItemSubTotalPer();
        });   

        $('.remove_daterow').click(function(){      
          $(this).closest('.xcas').remove();
          calculateSumOfItemSubTotal();
          calculateSumOfContractor();
          calculateContractorOverhead();
          calculateContractorFee();
          calculateSumOfItemSubTotalPer();
        });   

        // calculate Item Cost
        $('.cal').on('input', '.custom-val-contractor', function(){

          var total_row = $(this).val();
          
          if($(this).parent().parent().parent().children('.col-md-4').children('.field-projectproposalitemform-proposed_spread_per').children('.custom-val-proposed_spread_per').val() == '' || $(this).parent().parent().parent().children('.col-md-4').children('.field-projectproposalitemform-proposed_spread_per').children('.custom-val-proposed_spread_per').val() == 'undefined')
          {
            var proposed_spread_per = 0;
          }
          else
          {
            var proposed_spread_per = $(this).parent().parent().parent().children('.col-md-4').children('.field-projectproposalitemform-proposed_spread_per').children('.custom-val-proposed_spread_per').val();
          }

          per_total = (total_row * proposed_spread_per) / 100 ;
          total_row = parseFloat(total_row) + parseFloat(per_total);

          $(this).parent().parent().parent().children('.col-md-2').children('.field-projectproposalitemform-cost').children('.custom-val-cost').val(total_row);

          calculateSumOfItemSubTotal();
          calculateSumOfContractor();
          calculateContractorOverhead();
          calculateContractorFee();
          calculateSumOfItemSubTotalPer();
          
        });

        // calculate Item Cost

        $('.cal').on('input', '.custom-val-proposed_spread_per', function(){
          var percentage = $(this).val();
          
          if($(this).parent().parent().parent().children('.col-md-3').children('.field-projectproposalitemform-sub_contractor_estimate_cost').children('.custom-val-contractor').val() == '' || $(this).parent().parent().parent().children('.col-md-3').children('.field-projectproposalitemform-sub_contractor_estimate_cost').children('.custom-val-contractor').val() == 'undefined')
          {
            var contractor_cost = 0;
          }
          else
          {
            var contractor_cost = $(this).parent().parent().parent().children('.col-md-3').children('.field-projectproposalitemform-sub_contractor_estimate_cost').children('.custom-val-contractor').val();
          }

          per_total = (contractor_cost * percentage) / 100 ;

          total_row = parseFloat(contractor_cost) + parseFloat(per_total);


          $(this).parent().parent().parent().children('.col-md-2').children('.field-projectproposalitemform-cost').children('.custom-val-cost').val(total_row);

          calculateSumOfItemSubTotal();
          calculateSumOfContractor();
          calculateContractorOverhead();
          calculateContractorFee();
          calculateSumOfItemSubTotalPer();
        });
           
  ");
?>
<script type="text/javascript">

  function calculateSumOfItemSubTotal() {
          var calculated_total_sum = 0;
      
          $('.custom-val-cost').each(function () {
             var get_textbox_value = $(this).val();
             if ($.isNumeric(get_textbox_value)) {
                calculated_total_sum += parseFloat(get_textbox_value);
              }                  
            });
          $('#projectproposalform-item_sub_total').val(calculated_total_sum);       
        }
  function calculateSumOfItemSubTotalPer() {
          $('.custom-val-cost').each(function () {
             var get_textbox_value = $(this).val();
             if ($.isNumeric(get_textbox_value)) {
              var sub_total =  $('#projectproposalform-item_sub_total').val();
              count_per = 0;
              count_per = get_textbox_value * 100 / sub_total;
                calculated_total_sum += parseFloat(get_textbox_value);
                $(this).parent().parent().parent().children('.col-md-2').children('.field-projectproposalitemform-per_total').children('.custom-val-per-total').val(count_per.toFixed(2));
              }                  
            });
          $('#projectproposalform-item_sub_total').val(calculated_total_sum);       
        }
  function calculateSumOfContractor() {
          var calculated_total_sum = 0;
      
          $('.custom-val-contractor').each(function () {
             var get_textbox_value = $(this).val();
             if ($.isNumeric(get_textbox_value)) {
                calculated_total_sum += parseFloat(get_textbox_value);
              }                  
            });
          $('#projectproposalform-sub_contractor_total_cost').val(calculated_total_sum);       
        }

  function calculateContractorOverhead() {
          var contractor_overhead_per = $('#projectproposalform-overall_overhead_per').val();
          var item_sub_total = $('#projectproposalform-item_sub_total').val();
          per_total = (item_sub_total * contractor_overhead_per) / 100 ;          
          $('#projectproposalform-contractor_overhead').val(per_total);       
          calculateTotal();
        }

  function calculateContractorFee() {
          var contractor_fee_per = $('#projectproposalform-overall_fee_per').val();
          var item_sub_total = $('#projectproposalform-item_sub_total').val();
          per_total = 170 + parseFloat((item_sub_total * contractor_fee_per) / 100) ;          
          $('#projectproposalform-contractor_fee').val(per_total); 
          calculateTotal();      
        }
  function calculateTotal() {
          var item_sub_total = $('#projectproposalform-item_sub_total').val();
          var contractor_overhead = $('#projectproposalform-contractor_overhead').val();
          var contractor_fee = $('#projectproposalform-contractor_fee').val();
          per_total = parseFloat(item_sub_total) + parseFloat(contractor_overhead) + parseFloat(contractor_fee) ;          
          $('#projectproposalform-p_total_cost').val(per_total);       
          $('#projectproposalform-item_total_cost').val(per_total);       
        }
</script>
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>