<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax; 
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel common\models\ContractorManagementSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

//$this->title = 'Contractor Managements';
$this->params['breadcrumbs'][] = $this->title;
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
        Change Order Log
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Change Order Log</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <!-- /.box-header -->
                <div class="box-body">

                    <div class="contractor-management-index">
                        <div class="table-responsive">
                        <?php
                            $form = \yii\widgets\ActiveForm::begin([
                                        'method' => 'get', 'id' => 'super'
                            ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();?>
                        <?php
                            $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>

                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel5 = '';
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '5') {
                                        $sel5 = 'selected="selected"';
                                    } else if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="5" <?php echo $sel5; ?>>5</option>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            <?= Html::a('Reset', ['index'], ['class' => 'btn btn-primary']) ?>
                        </p>

                        <?php Pjax::begin(['id' => 'change-order-log']) ?> 
                        
                        <?= GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'columns' => [
                                [   'attribute' => 'id', 
                                        'label' => '#ID',
                                        'contentOptions' => ['style' => 'width:30px;'],
                                ],
                                [
                                    'attribute' => 'change_order_no',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Change Order No.'
                                        ],
                                ],
                                [
                                    'attribute' => 'project_id',
                                    'value' => 'project.project_name',
                                    'label' => 'Project',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Project'
                                        ],
                                ],
                                [
                                    'attribute' => 'current_status',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By Current Status'
                                        ],
                                ],
                                [
                                    'attribute' => 'new_order_contract_sum',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search By New Order Contract Sum'
                                        ],
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '  {view} {pdf}',//{status} {update}  {delete}
                                    'buttons' => [
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                            ]);
                                        },
                                        'pdf' => function ($url, $model) {
                                            return Html::a('<span class="fa fa-file-pdf-o" style="color:#000000;"></span>', $url, [
                                                             
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Export to Pdf',
                                                            'target' => '_blank'

                                                ]); 
                                        },
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {
                                        
                                        if ($action === 'view') {
                                            return \yii\helpers\Url::toRoute(['change-order-log/view/' . $key]);
                                        }

                                        if ($action === 'pdf') {
                                            return \yii\helpers\Url::toRoute(['change-order-log/export-one-pdf/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
