<html>
    <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
    </head>
    <body>
        <caption style="border:1px solid #ccc;padding:10px;border-bottom: 0px;font-size: 24px; font-family: 'Roboto', sans-serif;
            font-weight: 600;">Change Order Log
        </caption>
        <table style="width:100%;border:1px solid #ccc; font-family: 'Roboto', sans-serif;">
            <thead>
                <tr style="border:1px solid #ccc;">
                    <th style="padding:5px; border:1px solid #ccc; width: 50%;">PROJECT AND NUMBER</th>
                    <th style="padding:5px; border:1px solid #ccc; width: 50%;"><?= $model->project->project_name .' AND '. $model->project->project_number ?></th>
                </tr>
                <tr style="border:1px solid #ccc;">
                    <th style="padding:5px; border:1px solid #ccc; width: 50%;">BASE CONTRACT AMOUNT</th>
                    <th style="padding:5px; border:1px solid #ccc; width: 50%;"><?= $model->old_contract_sum ?>
                    </th>
                </tr>
            </thead>
        </table>
        <table style="width:100%;border:1px solid #ccc; font-family: 'Roboto', sans-serif;">
             
           
            <tbody>
                 <tr style="border:1px solid #ccc;">
                    <td style="text-align:center; border:1px solid #ccc;">CO NUMBER</td>
                    <td style="text-align:center; border:1px solid #ccc;">DESCRIPTION</td>
                    <td style="text-align:center; border:1px solid #ccc;">COST CODE</td>
                    <td style="text-align:center; border:1px solid #ccc;">CHANGE CLASS</td>
                    <td style="text-align:center; border:1px solid #ccc;">DATE SUBMITTED FOR APPROVAL</td>
                    <td style="text-align:center; border:1px solid #ccc;">CURRENT STATUS</td>
                    <td style="text-align:center; border:1px solid #ccc;">DATE RECEIVED RESPONSE</td>
                    <td style="text-align:center; border:1px solid #ccc;">TIME EXT. (# OF DAYS)</td>
                    <td style="text-align:center; border:1px solid #ccc;">CO AMOUNT</td>
                    <td style="text-align:center; border:1px solid #ccc;">UPDATED CONTRACT AMOUNT</td>
                    <td style="text-align:center; border:1px solid #ccc;">NOTES</td>
                </tr>
                <?php 
                    if(isset($model1) && !empty($model))
                    {
                        foreach ($model1 as  $value) {
                ?>      
                        <tr style="border:1px solid #ccc;">
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->changeorder->change_order_no ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->description ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->item->cost_code ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->change_class ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $model->date_submited_approval ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->change_class ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $model->date_recived_response ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->time_ext ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->co_amt?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $model->old_contract_sum + $value->co_amt ?></td>
                            <td style="text-align:center; border:1px solid #ccc;"><?= $value->notes?></td>
                        </tr>
                <?php            
                        }
                    }
                ?>
            </tbody>     
        </table>
    </body>
</html>