<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\helpers\Url;
?>
<div class="">
 <section class="content-header">
      <h1>Test</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
  </section>
    <section class="content">
      <?php 
      if( isset( $data ) ){
            
            $url = Url::base(true).'/site/test/1';
            echo Html::img($url , ['class'=>'image-show']);
            
            echo Html::button('Call API',['class' => 'call-api' , 'data-url' => $data['url'] ,'data-image' => $data['imgData'] , 'data-phone' => $data['mobile'] ]);  
            
            
          }else{
            echo Html::beginForm('' ,'post',['enctype'=>'multipart/form-data','name'=>'frmImage']);
            echo Html::label('Mobile NO:').'<br>';
            echo Html::input('text','userMobile',null,[]).'<br><br>';
            echo Html::label('Upload Image File:').'<br>';
            echo Html::fileInput('userImage').'<br><br>';
            echo Html::input('submit',['value'=>'Submit']);
            echo Html::endForm();
      }                    
      ?>
    </section>
    
</div>
<?php
$this->registerJs("
   $(document).on('ready', function () {
                            
        $('.call-api').on('click', function() {
        
           var image = $(this).data('image');
           var phone = $(this).data('phone');
           var Url   = $(this).data('url');
           var Data = { Img : image, Phn : phone }
                $.ajax({
                        url:   Url,
                        type:  'POST',
                        data: Data,
                        dataType: 'JSON',
                        success: function(result) { 
                           if( result.code == 200 ){
                               $('.call-api').hide();
                           }          
                        }
                    });

        });
    });
");
?>