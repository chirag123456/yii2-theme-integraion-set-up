<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\ResetPasswordForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Reset password';
?>
<style type="text/css">
    .content-wrapper.login-box-cust {
     margin: 0 auto!important; 
     width: 80% !important; 
    display: block !important;
    float: none !important;
    background: #fff;
    margin-left: 15% !important;
}
</style>
<div class="col-md-8 col-md-offset-2">
    <div class="login-box-body">
        <div class="site-request-password-reset">
            <h3><?php echo Html::encode($this->title) ?></h3>
            <div class="row">
                <div class="col-lg-12">
                    <?php $form = ActiveForm::begin(['id' => 'reset-password-form']); ?>
                    <?php echo $form->field($model, 'password')->passwordInput(['autofocus' => true, 'placeholder' => 'Enter New Password']) ?>
                    <?php echo $form->field($model, 'confirm_password')->passwordInput(['autofocus' => true, 'placeholder' => 'Confirm New Password']) ?>
                    <div class="form-group">
                        <?php echo Html::submitButton('Save', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>
    </div>
</div>