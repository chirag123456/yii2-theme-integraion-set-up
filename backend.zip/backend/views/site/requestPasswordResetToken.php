<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\PasswordResetRequestForm */

use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;

$this->title = 'Forgot Password';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<div class="col-md-12 col-xs-12 login-content">
    <div class="login-box-body">
        <div class="site-request-password-reset">
            <h3><?php echo Html::encode($this->title) ?></h3>
            <p>Please fill out your email. A link to reset password will be sent there.</p>
            <div class="row">
                <div class="col-lg-12">
                    <?php $form = ActiveForm::begin(['id' => 'request-password-reset-form']); ?>
                    <?php echo $form->field($model, 'email')->textInput(['autofocus' => true,'placeholder'=>"Enter your email address"]) ?>
                    <div class="form-group">
                        <?php echo Html::submitButton('Send', ['class' => 'btn btn-primary']) ?>
                        <?php echo Html::a( 'Back to Login.', Url::to(['site/login']), ['style'=>'float: right;padding-top: 7px;']);?>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$this->registerJs("
    $('body').addClass('body-login');
");
?>
