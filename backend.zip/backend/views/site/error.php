<?php
/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;
use yii\helpers\Url;

$this->title = $name;
?>
<div class="col-md-12 error-message" style="padding-top: 100px;">
    <div class="col-middle">
        <div class="text-center text-center">
            <?php if ($error->statusCode == 404) { ?>
                <h1 style="color: black !important;" class="error-number">Error 404</h1>
                <h2 style="color: black !important;">Sorry but we could not find this page</h2>
                <p style="color: black !important;">This page you are looking for does not exist.
                </p>
                <a href="<?= Url::to(['site/login']);?>"class="btn btn-primary add-button"><i class="fa fa-home" aria-hidden="true"> Home</i></a>

            <?php } else if ($error->statusCode == 403) { ?>
                <h1 style="color: black !important;" class="error-number">Error 403</h1>
                <h2 style="color: black !important;">Unauthorized Access</h2>
                <p style="color: black !important;">you are unauthorized for this page, but if you think it is problem then feel free to contact us. In the meantime, try refreshing.
                </p>
            <?php } else if ($error->statusCode == 500) { ?>
                <h1 class="error-number" style="color: black !important;">Error 500</h1>
                <h2 style="color: black !important;">Internal Server Error</h2>
                <p style="color: black !important;"> We track these errors automatically, but if the problem persists feel free to contact us. In the meantime, try refreshing.
                </p>
            <?php } else { ?>
                <h1 style="color: black !important;" class="error-number">Error 404</h1>
                <h2 style="color: black !important;">Sorry but we could not find this page</h2>
                <p style="color: black !important;">This page you are looking for does not exist.
                </p>
                <!-- <a href="<?= Url::to(['site/login']);?>"class="btn btn-primary add-button"><i class="fa fa-home" aria-hidden="true"> Home</i></a> -->

                <?php if (!Yii::$app->user->isGuest) { ?>
                <a href="<?= Url::to(['dashboard/']);?>"class="btn btn-primary add-button"><i class="fa fa-dashboard" aria-hidden="true"> Go to Dashboard</i></a>
                <?php } else { ?>
                    <a href="<?= Url::to(['site/login']);?>"class="btn btn-primary add-button"><i class="fa fa-dashboard" aria-hidden="true"> Go to Login</i></a>
                <?php } ?>

           <?php } ?>
        </div>
    </div>
</div>