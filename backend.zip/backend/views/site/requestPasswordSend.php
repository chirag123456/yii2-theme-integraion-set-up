<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\PasswordResetRequestForm */

use yii\helpers\Html;
use yii\helpers\Url;

$this->title = 'Thank You';
?>
<style type="text/css">
    .content-wrapper.login-box-cust {
     margin: 0 auto!important; 
     width: 80% !important; 
    display: block !important;
    float: none !important;
    background: #fff;
    margin-left: 15% !important;
}
.login-box-body, .register-box-body {
    background: #fff;
    padding: 20px;
    border-top: 0;
    color: #666;
    margin: 26px 162px ; 
    margin-top: 200px;
    margin-left: 40% !important;
}
</style>
<div class="col-md-8 col-md-offset-2">
    <div class="login-box-body">
        <div class="site-request-password-reset">
            <h3><?php echo Html::encode($this->title) ?></h3>
            <p>Please check email reset password instruction.</p>
            <a href="<?php echo Url::to(['site/login']) ?>">Back to login.</a>
        </div>
    </div>
</div>
