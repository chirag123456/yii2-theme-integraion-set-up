<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>
<div class="col-md-12 col-xs-12 login-content">
    <div class="login-box-body">
        <div id="wrapper">
            <div id="login" class=" form">
                <section class="login_content">
                  <?php $form = ActiveForm::begin(
                      [
                          'enableAjaxValidation' => true,
                          'enableClientValidation'=>true
                      ]
                  ); ?>
                  <!--<form>-->
                  <h1><?php echo APP_NAME;?></h1>
                  <div>
                      <?php echo $form->field($model, 'email')->textInput(['maxlength' => true,'placeholder'=>"Your email here"]); ?>
                  </div>

                  <div>
                      <?php echo Html::submitButton("Send me my Password", ['class' => 'btn btn-default submit']) ?>
                          <!--<a class="reset_pass" href="#">Lost your password?</a>-->
                      <?php echo \yii\helpers\Html::a(
                          'Back to Login?',
                          \yii\helpers\Url::to(['site/login'])
                      );?>
                  </div>
                  <div class="clearfix"></div>
                  <div class="separator">
                      <div class="clearfix"></div>
                      <br />
                      <div>
                          <h1><i class="fa fa-futbol-o" style="font-size: 26px;"></i> <?php echo COMPANY_NAME;?></h1>

                          <p>© <?php echodate("Y")?> All Rights Reserved. <?php echo COMPANY_NAME;?></p>
                      </div>
                  </div>
                  <!--</form>-->
                  <?php ActiveForm::end(); ?>
                </section>
            </div>
        </div>
      
    </div>
</div>  


