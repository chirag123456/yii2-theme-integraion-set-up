<?php

use yii\helpers\Url;

$this->title = 'Admin';
$baseUrl = Url::base(true);
?>
<div class="col-md-12 col-xs-12 login-content">
    
    <div class="login-box-body">
        <div style="text-align: center">
            <img width="50%" src="<?php echo $baseUrl; ?>/web/images/logo/cc-logo-new.png" alt="logo-lg"/> 
            <h3><b><span><!---Couch Construction Services --></span></b>
        </div>
        <?php
        $form = \yii\widgets\ActiveForm::begin([
                    'id' => "change-password",
                        //'enableAjaxValidation' => true,
                        //'enableClientValidation' => true,
        ]);
        ?>
        <div class="form-group has-feedback">
            <?php echo
            $form->field($model, 'email')->textInput(['autofocus' => true,'maxlength' => true, 'placeholder' => 'Enter Email',
                'inputTemplate' => 'glyphicon glyphicon-envelope form-control-feedback'
            ])
            ?>
        </div>
        <div class="form-group has-feedback">
            <?php echo $form->field($model, 'password')->passwordInput(['placeholder' => 'Enter Password']) ?>
        </div>
        <div class="row">
            <div class="col-xs-7">
                <div class="checkbox icheck">
                    <label>
                        <?php echo $form->field($model, 'rememberMe')->checkbox() ?>
                    </label>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-xs-5">
                <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </div>
            <!-- /.col -->
        </div>
        <?php \yii\widgets\ActiveForm::end(); ?>


        <!-- /.social-auth-links -->

        <a href="<?php echo Url::to(['site/request-password-reset']) ?>"> Forgot Password ?</a><br>


    </div>
    <!-- /.login-box-body -->
</div>
<?php
if(!empty(Yii::$app->user->identity->id)){
    //$this->registerCss('.skin-blue .main-sidebar{height:20%;}');
}
?>
<?php
$this->registerJs("
    $('body').addClass('body-login');
");
?>