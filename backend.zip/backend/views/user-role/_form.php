<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use common\models\module\Module;
use common\models\module\Action;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'CCS | Add Role';
?>
<section class="content-header">
      <h1>
        User Role
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
         <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("user-role/index") ?>" >User Role</a></li>
        <li class="active">Add Role</li>
      </ol>
</section>
<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
          <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">
                  <h4 class="m-b-0 text-white">Add Role</h4>
                  <!-- <a href="<?= yii\helpers\Url::to(['user-role/index'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a> -->
                   <?php /*<a href="<?= yii\helpers\Url::to(['user-role/index'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>*/ ?>
                </div>
                <div class="card-body user-role-form"> 
                    <?php
                    $form = ActiveForm::begin([
                            'id' => 'userrole-form',
                            'enableAjaxValidation' => true,
                            'enableClientValidation' => true,
                    ]);
                    ?>
                    <div class="form-body">
                        <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> User Role</h3>
                        <hr>
                        <div class="row p-t-20">
                            <div class="col-md-6" id="role-name">
                <div class="form-group">
                <?= $form->field($model, 'name')->textInput(['maxlength' => 70, 'placeholder' => 'Enter Role Name', 'id'=>'name']) ?>
                <div class="help-block-name" style="display:none;color: #dd4b39;">Role Name cannot be blank.</div>
            </div>
            </div>
            <div class="col-md-6">
                <?php
                    /*$data = ['1' => 'Super Admin', '2' => 'Admin', '3' => 'Principle', '4' => 'Teacher', '5' =>'Clerk', '6' => 'Student'];
                    echo $form->field($model, 'type')->widget(
                                    Select2::classname(), [
                            'data' => $data,
                            'options' => ['placeholder' => 'Select Role Type'],
                    ])->label();*/
                    //echo $form->field( $model, 'is_admin')->dropDownList( ['0'=>'No','1'=>'Yes'] , ['class' =>'form-control input-medium' ] );
                ?>
            </div>
        </div>

        <div class="col-md-12 add-module" style="display: none;">
            <?php
                //echo Html::button('Check All ', ['class' => 'btn btn-primary check-module pull-left', 'id'=>'check-all-mod']);
            ?>
            <?php 
                $selectArray1 = Module::find()->where(['is_delete'=>INACTIVE] )->all();
                $module_arr = [];
                foreach($selectArray1 as $karr=>$varr){
                    $selectArray[$varr->module_name] = implode(' ', array_map('ucfirst', explode('-', $varr->module_name)));
                }
        
                 //, 'site-configuration' => 'Site Configuration'
                    echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                    echo Html::label('Modules List'); ?>
                    
                    <p><label><input type="checkbox" id="check-all-mod"/> All Modules</label></p>
                <?php   echo Html::Tag('div' ,
                                    Html::checkboxList(
                                                    'access_role' , [] , $selectArray ,
                                                    [ 'class' => 'icheck-inline icheck-inline-custom lbl_modules custom-add-role-check ' , 'itemOptions' => [ 'class' => 'icheck' ] ], ['separator'=>'br']
                                    ) . Html::tag( 'div' , 'Note : Above all are list of Menu(Left Side). Select from list to access it.' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                    );
                    echo Html::endTag('div');
                
                    //echo $form->field( $model , 'description')->textarea();
                ?>
                <div class="help-block-mod" style="display:none;color: #dd4b39;">Please select Module.</div>
        </div>
        
        <div class="add-action user-role-access-tab" style="display:none;">
            
            <div class="col-md-12 role-access-tab">
                <div class="form-group">
                    <label>Action List</label>
                    <p><label><input type="checkbox" id="check-all-action"/> All Actions</label></p>
                </div>
            </div>

            <?php 
               $selectArray1 = Module::find()->where(['is_delete'=>INACTIVE] )->all();
               foreach($selectArray1 as $ksel => $vsel){
                    $module_name = $vsel->module_name;
                    $module_label = implode(' ', array_map('ucfirst', explode('-', $module_name)));
                    $module_id = $vsel->id;
                    $action_arr = Action::find()->where(['is_delete'=>INACTIVE] )->andWhere(['module_id' => $module_id])->all();

                    $act_arr = [];
                    foreach($action_arr as $kact=>$vact){
                        if($vact->action_name=='index'){
                            $act_arr[$vact->action_name] = 'List';
                        }else{
                            $act_arr[$vact->action_name] = ucfirst($vact->action_name);    
                        }
                    }
                    
            ?>
                <div class="col-md-12 role-access-tab" id="div_<?php echo $module_name; ?>" style="display: none;">
                    <input type="hidden" name="<?php echo $module_name; ?>">
                    <?php 
                        //$selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        $selectActionArray = $act_arr;
                            echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                            echo Html::label($module_label);
                            echo Html::Tag('div' ,
                                            Html::checkboxList(
                                                            'access_'.$module_name , [] , $selectActionArray ,
                                                            [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                            ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                            );
                            echo Html::endTag('div');
                    ?>
                    <div class="help-block-mod" style="display:none;color: #dd4b39;">Please select Atleast One</div>
                </div>
            <?php
                }
            ?>
        </div>
        <div class="help-block-action" style="display:none;color: #dd4b39;">Please select Atleast One</div>
        </div>

        <div class="form-actions">
                <?php  echo Html::a('<i class="fa fa-close"></i> Cancel', ['user-role/index'], ['class' => 'btn btn-default cancel-button back1', 'style' => 'margin-right: 5px;']);
                    //echo Html::button('Back', ['class' => 'btn btn-primary pull-right cancel-button back1', 'style' => 'margin-right: 5px;display:none;']);
                ?>
                <?php
                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                        echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-success', 'style' => 'margin-right: 5px;']);
                    } else {
                        echo Html::button('Previous', ['class' => 'btn btn-primary add-button', 'id'=>'back-button1', 'style'=>'display:none;margin-right: 5px;']);
                        echo Html::button('Previous', ['class' => 'btn btn-primary add-button', 'id'=>'back-button2', 'style'=>'display:none;margin-right: 5px;']);
                        echo Html::button('Next', ['class' => 'btn btn-primary add-button', 'id'=>'add-button', 'style' => 'margin-right: 5px;']);
                        echo Html::button('Next', ['class' => 'btn btn-primary add-button', 'id'=>'add-button2', 'style'=>'display:none;margin-right: 5px;']);
                      
                        
                        //echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'add-button3', 'style'=>'display:none;']);
                      
                        echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id'=>'add-button-sub', 'style'=>'display:none;margin-right: 5px;']);
                        //echo Html::button('Previous', ['class' => 'btn btn-primary back-button pull-right']);
                    }
                ?>
                
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>
</div>
</div>

</section>
<?php
$this->registerJs("
    //$('#check-all-mod').on('click', function (e) {
        //$('input:checkbox').attr('checked','checked');
    //});
    
    $('#check-all-mod').change(function () {
        $('.icheck').prop('checked', $(this).prop('checked'));
    });
    
    $('#check-all-action').change(function () {
        $('.actioncheck').prop('checked', $(this).prop('checked'));
    });
");
$this->registerJs("
    $('#add-button').on('click', function (e) {
        var role = $('#name').val();
        
            if(role==''){
                $('.help-block-name').show();
                return false;
            } else {

                $('.add-module').show();
                $('#role-name').hide();
                $(this).hide();
                $('#add-button2').show();
                //$('.back1').show();
                $('#back-button1').show();
            }
        });
        
    $('#back-button1').on('click', function (e) {
            $('.add-module').hide();
            $('#role-name').show();
            $(this).hide();
            $('#add-button2').hide();
            $('#add-button').show();
    });    
        
    // $('#add-button2').on('click', function (e) {
    //         var con = [];
    //         $('.icheck:checkbox:checked').each(function(i){
    //           con[i] = $(this).val();
    //           $('#div_'+con[i]).show();

    //         });
        
    //         if(con==''){
    //             $('.help-block-mod').show();
    //             return false;
    //         } else {
    //             $('.help-block-mod').hide();
    //             $('.add-module').hide();
    //             $('.add-action').show();
    //             $(this).hide();
    //             $('#back-button1').hide();
    //             $('#add-button-sub').show();
    //             $('#back-button2').show();
    //         }
                
    // });


    // $('#add-button2').on('click', function (e) {
    //         var con = [];
    //         $('.icheck:checkbox:checked').each(function(i){
    //           con[i] = $(this).val();
    //           $('#div_'+con[i]).show();
    //         });
        
    //         if(con==''){
    //             $('.check-all-action').show();
    //             return false;
    //         } else {
    //             $('.add-module').hide();
    //             $('.add-action').show();
    //             $(this).hide();
    //             $('#back-button1').hide();
    //             $('#add-button-sub').show();
    //             $('#back-button2').show();
    //         }
                
    // });


    $('#back-button2').on('click', function (e) {
            $('.add-module').show();
            $('#add-button-sub').hide();
            $(this).hide();
            $('.add-action').hide();
            $('#add-button2').show();
            $('#back-button2').hide();
            $('#back-button1').show();
            bindjson();
            $.each(json_array,function(key,val){
                console.log('##'+val);
                $('#div_'+val).hide();
                $('#div_'+val+'>.help-block-mod').hide();
            });
    });
    
    $('#add-button-sub').on('click', function (e) {
        var action = [];  
        i=0;      
        $('input:checkbox[class=actioncheck]:checked').each(function () {
            action[i] = $(this).val();
            i++;
        });
     
        if(action==''){
            $('.help-block-action').show();
            return false;
        } else {
            //$('#add-action').hide();
             //$(this).hide();
            //$('#add-button-sub').show();
        }
                
    });
        
");
$this->registerJs("
    function bindjson(){
        json_array1=[];
        json_array=[];
        j=0;
        $('input:checkbox[class=icheck]:checked').each(function (key,val) {
          console.log(val.value);
          json_array1[j]=val.value;
          json_array[j]=val.value;
          j++;
        });
    }
    $(document).ready(function(){   
            $('#userrole-form').on('submit',function(){


/**/
json_array1=[];
json_array=[];
j=0;
$('input:checkbox[class=icheck]:checked').each(function (key,val) {
    console.log(val.value);
          json_array1[j]=val.value;
          json_array[j]=val.value;
          j++;
});
/**/

            var flag=true;
            $.each(json_array1,function(key,val){
                //console.log(val+'###');        
                div=$('#div_'+val+' input[type=checkbox]:checked');

                //console.log(val+'###'+div.length);
              
                if(div.length<=0){
                    console.log('#div_'+val+'>.help-block-mod');
                    $('#div_'+val+'>.help-block-mod').show();
                    $('.help-block-action').hide();
                        flag=false;
                }else{
                    $('#div_'+val+'>.help-block-mod').hide();
                }
            });
            if(flag==false){                                        
                return false;       
            }else{              
                return true;
            }
        });         
    });
");


$this->registerCss("

    .lbl_modules label{
        display: inherit;
    }
    .lbl_actions label{
        display: inherit;
    }
");

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function(){

        $('#add-button2').on('click', function (e) {

            // For Location State and City 
            /*if($('input[value="location"]').prop("checked") == true){
                if($('input[value="city"]').prop("checked") == false && $('input[value="state"]').prop("checked") == false ){
                       alert('Please Select State or City for Location.')
                       return false;
                }       
            }

            if($('input[value="city"]').prop("checked") == true){
                if($('input[value="location"]').prop("checked") == false){
                    alert('Please Select Location for City.')
                    return false;
                }  
            }

            if($('input[value="state"]').prop("checked") == true ){
                if($('input[value="location"]').prop("checked") == false){
                    alert('Please Select Location for State.')
                    return false;
                }  
            }

            // For Project Project Managemnt and Project Budget Management 

            if($('input[value="project"]').prop("checked") == true){
                if($('input[value="project-management"]').prop("checked") == false && $('input[value="project-budget-management"]').prop("checked") == false ){
                       alert('Please Select Project Management or Project Budget Management for Project.')
                       return false;
                }       
            }

            if($('input[value="project-management"]').prop("checked") == true){
                if($('input[value="project"]').prop("checked") == false){
                    alert('Please Select Project for Project Management.')
                    return false;
                }  
            }

            if($('input[value="project-budget-management"]').prop("checked") == true ){
                if($('input[value="project"]').prop("checked") == false){
                    alert('Please Select Project for Project Budget Management.')
                    return false;
                }  
            }*/

            var con = [];
                $('.icheck:checkbox:checked').each(function(i){
                  con[i] = $(this).val();
                  $('#div_'+con[i]).show();

                });
            
                if(con==''){
                    $('.help-block-mod').show();
                    return false;
                } else {
                    $('.help-block-mod').hide();
                    $('.add-module').hide();
                    $('.add-action').show();
                    $(this).hide();
                    $('#back-button1').hide();
                    $('#add-button-sub').show();
                    $('#back-button2').show();
                }
        });
    });
</script>