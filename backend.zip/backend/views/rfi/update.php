<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Rfi */

$this->title = 'Update Rfi: {nameAttribute}';
$this->params['breadcrumbs'][] = ['label' => 'Rfis', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="rfi-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
