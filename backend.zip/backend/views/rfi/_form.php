<?php  

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;
use dosamigos\ckeditor\CKEditor; 
use kartik\file\FileInput;
use common\models\project\ProjectDocument;
use backend\components\CommonFunctions;

$this->title = 'Rfi | ' . isset($_GET['id']) ? 'Update' : 'Add';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<style type="text/css">
    

.card .card-body [type="radio"]:not(:checked), .card .card-body [type="radio"]:checked {
    position: static; 
    left: -9999px; 
    opacity: 1; 
}
.hidden{ 
    display: none;
}
</style>
<section class="content-header">
    <h1> Request For Information </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("rfi/index") ?>" >Rfi</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Request For Information' : 'Add Request For Information'; ?></li>
    </ol>
</section> 

<section class="content"> 
<div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Request For Information' : 'Add Request For Information'; ?></h4>
      </div>
      <div class="card-body project-management-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'rfi-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
            ]);
                        ?>
          <div class="form-body">

            <!--Owner Information-->


            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Request For Information</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group"> 
                 <?=
                    $form->field($model, 'project_id')->widget(Select2::classname(), [
                        'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                        'options' => ['placeholder' => 'Select Project','onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('rfi/get-project?id=') . '"+$(this).val(), function( data ) {
                                      var result = $.parseJSON(data);
                                      
                                      $("#rfiform-project_location").val(result.model.project_physical_address + " " + result.city + " " +result.state);
                                      $("#rfiform-project_number").val(result.model.project_number);
                                    });
                                '],
                        'pluginOptions' => [
                            'allowClear' => true
                        ],
                    ])->label();
                ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'project_number')->textInput([ 'placeholder' => 'Enter Project Number','readOnly' => true]) ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                   <?= $form->field($model, 'project_location')->textArea(['placeholder' => 'Enter Project Location','readOnly' => true]) ?>
                  </div>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group"> 
                  <?php echo $form->field($model, 'client_id')->widget(
                       Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\client\Client::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'client_name'),
                      'options' => ['placeholder' => 'Select Client'], 
                      'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                       ])->label(); ?> 
                </div>
              </div>
              <!--/span-->
              <div class="col-md-4">
                <div class="form-group">
                  <?php 
                    $role = CommonFunctions::getConfigureValueByKey('ARCHITECTURE_USER_ID');
                    //$model->architect_id = $role;
                    echo $form->field($model, 'architect_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            }), 
                              'options' => ['placeholder' => 'Select Architect'],
                      ])->label();  
                   ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <?php 
                      $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                    ?>
                    <?=
                        $form->field($model, 'sub_contractor_id')->widget(Select2::classname(), [
                            'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role' => $role])->all(), 'id', function($model) {
                    return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                }),
                            'options' => ['placeholder' => 'Select Sub Contractor','id' => 'title1'],
                            'pluginOptions' => [
                                'allowClear' => true
                            ],
                        ])->label();
                    ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-6">
                <?php 
                    if(isset($_GET['id']) && !empty($_GET['id']))
                    {
                ?>
                        <div class="form-group"> 
                            <?= $form->field($model, 'rfi_code')->textInput(['maxlength' => 25, 'placeholder' => 'Enter RFI Code','readOnly' => true]) ?>
                        </div>
                <?php        
                    }
                    else
                    {
                ?>
                        <div class="form-group"> 
                            <?= $form->field($model, 'rfi_code')->textInput(['maxlength' => 25, 'placeholder' => 'Enter RFI Code','value' => 'RFI'.uniqid(),'readOnly' => true]) ?>
                        </div>
                <?php        
                    }
                ?>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?= $form->field($model, 'response')->textArea(['maxlength' => 400, 'placeholder' => 'Enter Response']) ?>
                </div>
              </div>

             
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'request_for_information')->textArea(['maxlength' => 400, 'placeholder' => 'Enter Request For Information']) ?>
                </div>
              </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <?= $form->field($model, 'responded_by')->textInput(['maxlength' => 30, 'placeholder' => 'Enter Responded By']) ?>
                    </div>
                </div>
              <div class="col-md-4">
                <div class="form-group"> 
                 <?php 
                    echo $form->field($model, 'rfi_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Rfi Date','autocomplete'=> 'off'],

                          'pluginOptions' => [    
                          'language' => 'en',                
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                  ?>
                </div>
              </div>
            </div>
          </div>
          <br/>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['rfi/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>
<?php
   
    $this->registerJs("
        $(document).ready(function() {
            $('#datepicker').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
             $('#datepicker1').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker1').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
             $('#datepicker2').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker2').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
        });
    ");
?>