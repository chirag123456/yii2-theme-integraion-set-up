<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?> 
<style type="text/css">
    table th a, table th, footer a {
    color: #000 !important;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 1px;
}
</style>
<div class="order-create">
<section class="content-header">
    <h1> Request For Information </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("rfi/index") ?>" >Rfi</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Request For Information Details</h3> 
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("rfi/index"); ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [                                
                                [
                                    'attribute' => 'client_id', 
                                    'value' => $model->client->client_name,
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by first name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'architect_id',
                                    'value' => $model->architect->email,
                                ],
                                [
                                    'attribute' => 'sub_contractor_id',
                                    'value' => $model->subContractor->email,
                                ],
                                [
                                    'attribute' => 'project_id',
                                    'value' => $model->project->project_name,
                                ],
                                [
                                    'attribute' => 'project_number',
                                ],
                                [
                                    'attribute' => 'project_location',
                                    
                                ],
                                [
                                    'attribute' => 'rfi_code',
                                ],
                                [
                                    'attribute' => 'response',
                                ],
                                [
                                    'attribute' => 'responded_by',
                                ],
                                [
                                    'attribute' => 'rfi_date',
                                ],
                            ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>
<?php 
$this->registerJs("
     var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
    ");

$this->registerJs(\yii\web\View::POS_BEGIN);

$this->registerCssFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.css');
$this->registerCssFile('http://www.jqueryscript.net/css/jquerysctipttop.css');

$this->registerJsFile(Yii::$app->homeUrl . 'resource/drivers/views.js', ['depends' => 'yii\web\JqueryAsset']);

$this->registerCss('.detail-view{text-align:left;}')

?>