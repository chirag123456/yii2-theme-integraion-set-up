<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\ProjectScheduleManagement */

$this->title = 'Create Project Schedule Management';
$this->params['breadcrumbs'][] = ['label' => 'Project Schedule Managements', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="project-schedule-management-create">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
