<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;

$this->title = 'CCS | Project Schedule ';
?>        
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<style type="text/css">
  .box-body .fc {
    margin-top: 41px;
}
</style>
<section class="content-header">
    <h1>
        Project Schedule
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Project Schedule </li>
    </ol>
</section>
<section class="content">
      <div class="row">
        <!-- /.col -->
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-body no-padding">
              <?php echo Html::a('Back', ['project-schedule-management/index'], ['class' => 'btn btn-primary filter-reset pull-right']) ?>
              <!-- THE CALENDAR -->
              <div id="calendar" class="m-t-20 fc fc-unthemed fc-ltr"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="http://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<?php
$this->registerJsFile(Yii::$app->homeUrl . 'js/moment.js?v=010101', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile(Yii::$app->homeUrl . 'js/fullcalendar.min.js?v=010101', ['depends' => 'yii\web\JqueryAsset']);
    
?>
<?php   
$i = 0;
$a = [];
foreach ($model as $key => $event_list) { 
        $date = new \DateTime($event_list->schedule_end_date);
        $date->modify("+1 day");

        $Callender_arr = [
            'title' => $event_list->schedule_title,
            'start' =>  date('Y-m-d',strtotime($event_list->schedule_start_date)) , 
            'end' =>  $date->format("Y-m-d"), 
            'backgroundColor' => '#03a9f4', 
            'borderColor' => '#03a9f4'
        ];
        array_push($a,$Callender_arr);
        $i++;
    }
    //print_r($a); exit();
    $this->registerJs('

        function init_events(ele) {
            ele.each(function () {


                var eventObject = {
                  title: $.trim($(this).text()) 
              }

        // store the Event Object in the DOM element so we can get to it later
              $(this).data("eventObject", eventObject)

        // make the event draggable using jQuery UI
              $(this).draggable({
                  zIndex        : 1070,
                  revert        : true, // will cause the event to go back to its
                  revertDuration: 0  //  original position after the drag
                  })

                  })
              }

              init_events($("#external-events div.external-event"))

              /* initialize the calendar
              -----------------------------------------------------------------*/
    //Date for the calendar events (dummy data)
              var date = new Date()
              var d    = date.getDate(),
              m    = date.getMonth(),
              y    = date.getFullYear()
              $("#calendar").fullCalendar({
                  header    : {
                    left  : "prev,next today",
                    center: "title",
                    right : "month,agendaWeek,agendaDay"
                    },
                    buttonText: {
                        today: "today",
                        month: "month",
                        week : "week",
                        day  : "day"
                        },
      //Random default events
                        events    : 
                        '.json_encode($a).'
                        ,
                        editable  : true,
                        droppable : true, // this allows things to be dropped onto the calendar !!!
                        drop      : function (date, allDay) { // this function is called when something is dropped


                            var originalEventObject = $(this).data(eventObject)


                            var copiedEventObject = $.extend({}, originalEventObject)

        // assign it the date that was reported
                            copiedEventObject.start           = date
                            copiedEventObject.allDay          = allDay
                            copiedEventObject.backgroundColor = $(this).css("background-color")
                            copiedEventObject.borderColor     = $(this).css("border-color")

        // render the event on the calendar
        // the last `true` argument determines if the event "sticks" (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
                            $("#calendar").fullCalendar("renderEvent", copiedEventObject, true)

        // is the "remove after drop" checkbox checked?
                            if ($("#drop-remove").is(":checked")) {
          // if so, remove the element from the "Draggable Events" list
                              $(this).remove()
                          }

                      }
                      })
                      ');
?>

