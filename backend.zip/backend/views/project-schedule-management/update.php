<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\ProjectScheduleManagement */

$this->title = 'Update Project Schedule Management: {nameAttribute}';
$this->params['breadcrumbs'][] = ['label' => 'Project Schedule Managements', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="project-schedule-management-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
