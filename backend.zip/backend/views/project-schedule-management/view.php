<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Project Schedule </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project-schedule-management/index") ?>" >Project Schedule</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content">
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Project Schedule Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [

                                
                                [
                                    'attribute' => 'project_name',
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                    
                                ],
                                [
                                    'attribute' => 'schedule_title',
                                ],
                                [
                                    'attribute' => 'schedule_start_date',
                                ],
                                [
                                    'attribute' => 'schedule_end_date',
                                ],
                                [
                                    'attribute' => 'item_name',
                                     'value' => function ($model) {
                                            return $model->item->name;
                                    },
                                ],
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
</section>  
</div>

<?php 

$this->registerCss('.detail-view{text-align:left;}')

?>