<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>


<div class="city-form">
    <?php
    $form = ActiveForm::begin([
                'id' => 'country-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="row box-body">
			<div class="col-md-12">
				<div class="col-md-4">
					<?= $form->field($model, 'country_name')->textInput(['maxlength' => true, 'placeholder' => 'Enter Country Name']) ?>
				</div>
			</div>
          
            <div class="col-md-12">
            <div class="col-md-8">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {

                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                } else {
                    echo Html::submitButton('Create', ['class' => 'btn btn-primary pull-right']);
                }
                ?>
                <?php echo Html::a('Cancel', ['country/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>