<?php

use yii\helpers\Html;
?>

<div class="punchlist-edit">
 <?= $this->render('_form', ['model' => $model]) ?>
</div>