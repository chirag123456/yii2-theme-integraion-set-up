<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use dosamigos\ckeditor\CKEditor; 
use common\models\project\Project;
use common\models\user\User;
use backend\components\CommonFunctions;
use kartik\date\DatePicker;
use common\models\projectbudget\ProjectBudgetItemForm;
use common\models\punchlist\PunchListDetailForm;
use common\models\contractor\ContractorManagement;

$this->title = 'Project Budget | ' . isset($_GET['id']) ? 'Update' : 'Add';
?>

<section class="content-header">
  <h1>
    Construction Punch List
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
    <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("punch-list/index") ?>" >Construction PunchList</a></li>
    <li class="active">Add Construction PunchList</li>

  </ol>
</section>

<section class="content">  
  <div class="row new-classic-form">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-header bg-info">
          <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Construction PunchList' : 'Add Construction PunchList'; ?></h4>
        </div> 
        <div class="card-body project-budget-management-form">
          <?php
          $form = ActiveForm::begin([
            'id' => 'punchlist-form',
            'enableAjaxValidation' => true,
            'enableClientValidation' => true,
            'options' => ['enctype' => 'multipart/form-data']
          ]);
          ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Construction PunchList Information</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <?php $project = ArrayHelper::map(Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->asArray()->all(), 'id', 'project_name'); ?>

                  <?php
                  echo $form->field($model, 'project_id')->widget(
                    Select2::classname(), [
                      'data' => $project,
                      'options' => ['placeholder' => 'Select Project'],
                    ])->label();
                    ?>
                  </div>
                </div>
                <!--/span-->
                <div class="col-md-4">
                  <div class="form-group">
                    <?php 
                    $role = CommonFunctions::getConfigureValueByKey('PROJECT_MANAGER_USER_ID');
                    $projectmanager = ArrayHelper::map(User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role'=> $role])->asArray()->all(), 'id', 'first_name'); 
                    ?>

                    <?php
                    echo $form->field($model, 'project_manager_user_id')->widget(
                      Select2::classname(), [
                        'data' => $projectmanager,
                        'options' => ['placeholder' => 'Select Project Manager'],
                      ])->label();
                      ?>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <?php

                      $present = ['Y' => 'Yes', 'N' => 'No'];

                      echo $form->field($model, 'present')->widget(
                        Select2::classname(), [
                          'data' => $present,
                          'options' => ['placeholder' => 'Select Present'],
                        ])->label();
                        ?>
                      </div>
                    </div>
                    <!--/span-->
                  </div>
                  <div class="row p-t-20">
                    <div class="col-md-4">
                      <div class="form-group">
                        <?php 
                        echo $form->field($model, 'walkthrough_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date of Walkthrough',
                          'autocomplete'=> 'off',],
                          'pluginOptions' => [  
                            'language' => 'en',                  
                            'autoclose' => true,
                            'format' => 'yyyy-mm-dd',
                            'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                        ]);
                        ?>
                      </div>
                    </div>
                    <!--/span-->
                    <div class="col-md-4">
                      <div class="form-group">
                        <?php 
                        $role1 = CommonFunctions::getConfigureValueByKey('SUPERINTENDENT_USER_ID');
                        $projectmanager = ArrayHelper::map(User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role'=> $role1])->asArray()->all(), 'id', 'first_name'); 
                        ?>
                        <?php
                        echo $form->field($model, 'superintendent_user_id')->widget(
                          Select2::classname(), [
                            'data' => $projectmanager,
                            'options' => ['placeholder' => 'Select superintendent'],
                          ])->label();
                          ?>
                        </div>
                      </div>
                      <!--/span-->
                      <div class="col-md-4">
                        <div class="form-group">
                          <?php echo $form->field($model, 'cell_phone')->textInput(['autofocus' => true, 'maxlength' => true, 'placeholder' => 'Enter Cell Phone']) ?>
                        </div>
                      </div>
                      <!--/span-->
                    </div>
                    <!--/row-->

                    <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Punch List</h3>
                    <hr>

                    <?php 

                    if(isset($_GET['id']) && !empty($_GET['id']))
                    {
                      $details = PunchListDetail::find()->where(['punch_id'=> $_GET['id']] )->all();  
                    }

                    if(isset($details) && !empty($details))
                    {
                      $i = 0 ;
                      foreach ($details as $value) {

                        $punchListDetailForm = new PunchListDetailForm();
                        //$projectBudgetItemForm = new PunchListDetailForm();
                        $model1 = $punchListDetailForm->getUpdateModel($value);
                        if($i == 0)
                        {
                          $class =  "row add";
                        }
                        else
                        {
                          $class =  "row add".$i;  
                        }

                        ?>
                        <div class="<?= $class?>">
                          <div class="col-md-4">
                            <?php 
                            echo $form->field($model1, 'location')->textArea(['maxlength' => 255, 'placeholder' => 'Enter Location','class' => 'form-control name-change-location']);
                            ?>
                          </div>
                          <div class="col-md-4"> 
                            <?php echo $form->field($model1, 'description')->textArea(['autofocus' => true, 'maxlength' => 255, 'placeholder' => 'Enter description','class' => 'form-control custom-val name-change-description','onKeyUp'=>'return calculateSum(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                          </div>
                          <div class="col-md-4"> 
                            <?php 
                            $role2 = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                            $subcontractor1 = ArrayHelper::map(User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role' => $role2])->asArray()->all(), 'id', 'email');

                            echo $form->field($model1, 'subcontractor_id')
                            ->dropDownList($subcontractor1 ,['id' => 'title11', 'prompt' => 'Select Sub Contractor','required'=>true,'class' => 'form-control name-change-subcontractorid'])->label();

                            ?>
                            <?php
                            /*echo $form->field($model1, 'subcontractor_id')->widget(
                              Select2::classname(), [
                                'data' => $subcontractor1,
                                'options' => [
                                  'placeholder' => 'Select Project Manager',
                                  'required'=>true,
                                  'class' => 'form-control name-change-subcontractorid',
                                ],
                              ])->label();*/
                              ?>

                              <?php //echo $form->field($model1, 'comment')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Comment','required'=>true,'class' => 'form-control name-change-comment']) ?>
                            </div>
                            <div class="col-md-4"> 
                              <?php echo $form->field($model1, 'gc_initial')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Gc Initial','class' => 'form-control custom-val-contractor name-change-gc_initial','onKeyUp'=>'return calculateSumOfContractor(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                            </div>  
                            <div class="col-md-4"> 
                              <?php echo $form->field($model1, 'owner_pm_initial')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Owner PM Initial','class' => 'form-control custom-val-contractor name-change-owner_pm_initial','onKeyUp'=>'return calculateSumOfContractor(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                            </div> 
                            <div class="col-md-4">
                              <?php 
                              echo $form->field($model1, 'completed_date')->widget(DatePicker::classname(), [
                                'options' => ['placeholder' => 'Select Completed Date','autocomplete'=> 'off','class' => 'form-control name-change-completed_date'],
                                  'pluginOptions' => [  
                                  'language' => 'en',                  
                                  'autoclose' => true,
                                  'format' => 'yyyy-mm-dd',
                                  'startDate' => date("yyyy-MM-dd H:i:s"),
                                ]
                              ]);
                              ?>                        
                            </div>
                            <div class="col-md-1" style="margin-top: 26px;">

                              <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                            </div>
                          </div>
                          <?php $i++;    } 
                        }
                        else
                        {
                          $model1 = new PunchListDetailForm();
                          ?>
                          <div class="row add"> 
                            <div class="col-lg-12">
                            <div class="col-md-4"> 

                              <?php 
                              echo $form->field($model1, 'location[]')->textArea(['maxlength' => 255, 'placeholder' => 'Enter Location','required'=>true,]);
                              ?>
                            </div>
                            <div class="col-md-4"> 
                              <?php echo $form->field($model1, 'description[]')->textArea(['required'=>true,'autofocus' => true, 'maxlength' => 255, 'placeholder' => 'Enter description','class' => 'form-control custom-val','onKeyUp'=>'return calculateSum(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                            </div>
                            <div class="col-md-4"> 
                              <?php 

                              $role2 = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                            $subcontractor1 = ArrayHelper::map(User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role' => $role2])->asArray()->all(), 'id', 'email'); 

                               echo $form->field($model1, 'subcontractor_id[]')
                                ->dropDownList($subcontractor1 ,['id' => 'title11', 'prompt' => 'Select  Sub Contractor','required'=>true])->label();

                              ?>

                              <?php
                              /*echo $form->field($model1, 'subcontractor_id[]')->widget(
                                Select2::classname(), [
                                  'data' => $subcontractor1,
                                  'options' => [
                                    'placeholder' => 'Select Project Manager',
                                    'required'=>true
                                  ],
                                ])->label();*/
                                ?>

                                <?php //echo $form->field($model1, 'comment[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Comment','required'=>true]) ?>
                              </div>
                              </div> 
                              <div class="col-lg-12">
                              <div class="col-md-3"> 
                                <?php echo $form->field($model1, 'gc_initial[]')->textInput(['required'=>true,'autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Gc Initial','class' => 'form-control custom-val-contractor','onKeyUp'=>'return calculateSumOfContractor(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                              </div>  
                              <div class="col-md-4"> 
                                <?php echo $form->field($model1, 'owner_pm_initial[]')->textInput(['required'=>true,'autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Owner PM Initial','class' => 'form-control custom-val-contractor','onKeyUp'=>'return calculateSumOfContractor(this.id);','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                              </div>
                              <div class="col-md-4">
                                <?php 
                                // echo $form->field($model1, 'completed_date[]')->widget(DatePicker::classname(), [
                                //   'options' => ['placeholder' => 'Select Completed Date',
                                //   'autocomplete'=> 'off',],
                                //   'pluginOptions' => [  
                                //     'language' => 'en',                  
                                //     'autoclose' => true,
                                //     'format' => 'yyyy-mm-dd',

                                //     'startDate' => date("yyyy-MM-dd H:i:s"),
                                //   ]
                                // ]);
                                echo $form->field($model1, 'completed_date[]')->input('date',['required'=>true,])
                                ?>    
                                
                                <!-- <div class="input-group">
                                    <input id="date" type="date" class="form-control">
                                    <div class="input-group-addon">
                                        <span class="glyphicon glyphicon-th"></span>
                                    </div>
                                </div> -->
                              </div>
                              <div class="col-md-1" style="margin-top: 26px;">

                                <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                              </div>
                              </div>
                              <?php } ?>
                          </div>
                          
                          <div class="a" id="l"></div>
                          <a style="cursor: pointer; margin-right: 45px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>

                <div class="form-actions">
                  <a href="<?php echo yii\helpers\Url::to(['punch-list/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
                <?php
                  if (isset($_GET['id']) && !empty($_GET['id'])) {
                            echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                  echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
              ?>

            </div>
          <?php ActiveForm::end(); ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
  $this->registerJs("
    $('.name-change-description').attr('name', 'PunchListDetailForm[description][]');
    $('.name-change-location').attr('name', 'PunchListDetailForm[location][]');
    $('.name-change-subcontractorid').attr('name', 'PunchListDetailForm[subcontractor_id][]');
    $('.name-change-gc_initial').attr('name', 'PunchListDetailForm[gc_initial][]');
    $('.name-change-owner_pm_initial').attr('name', 'PunchListDetailForm[owner_pm_initial][]');
    $('.name-change-completed_date').attr('name', 'PunchListDetailForm[completed_date][]');

    var n = 1;
    $('.addd').click(function(){
        $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
        $('.xcas').find(':input').val('');
        var val = $('.xcas').find('#punchlistdetailform-completed_date-kvdate .krajee-datepicker').prop('id');
        var len = $('.xcas').find('#punchlistdetailform-completed_date-kvdate .krajee-datepicker').length;

        if(len>1){
          //var date_id = val+int(1);
          
          var date_id = val + n;
          n++;
          //alert(date_id);
          $('.xcas #punchlistdetailform-completed_date-kvdate .krajee-datepicker').attr('id', date_id);
        }
        //alert(len);
    });   
    $('.remove_daterow').click(function(){      
        $(this).closest('.xcas').remove();
    });   
 ");
?>