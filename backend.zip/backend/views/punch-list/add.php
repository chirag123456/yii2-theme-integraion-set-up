<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\Country */
?>

<div class="user-create">
  <?= $this->render('_form', [
      'model' => $model
  ]) ?>
</div>