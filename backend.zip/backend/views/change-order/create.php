<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\ChangeOrder */

$this->title = 'Create Change Order';
$this->params['breadcrumbs'][] = ['label' => 'Change Orders', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="change-order-create">

    <?= $this->render('_form', [
        'model' => $model,
        'model2' => $model2,
        'details' => $details,
    ]) ?> 

</div>
