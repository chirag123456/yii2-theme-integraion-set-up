<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use dosamigos\ckeditor\CKEditor; 
use kartik\date\DatePicker;
use common\models\changeorder\ChangeOrderItem;
use common\models\changeorder\ChangeOrderItemForm; 
use backend\components\CommonFunctions;
use common\models\order\OrderItemForm;
use common\models\order\OrderItem; 
//echo "<pre>"; print_r($details); exit();
$this->title = 'Change Order | ' . isset($_GET['id']) ? 'Update' : 'Add'; 
?>
<section class="content-header">
    <h1> Change Order </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("change-order/index") ?>" >Change Order</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Add Change Order' : 'Add Change Order'; ?></li>
    </ol>
</section>
<section class="content">  
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Add Change Order' : 'Add Project Proposal'; ?></h4>
      </div> 
      <div class="card-body change-order-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'projectbudget-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
                  ]);
                        ?> 
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Change Order Information</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?php 
                    $model->project_id = $details->project_id;
                    $model->contract_for = $details->contract_for;
                    $model->project_no = $details->project->project_number;
                    $model->old_contract_sum = $details->total_amt;
                  ?>
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project','disabled' => 'disabled'],
                                        'pluginOptions' => [
                                            'allowClear' => true,
                                           
                                        ],
                    ])->label();
                ?> 
                </div>  
              </div>
              <div class="col-md-6"> 
                <?php echo $form->field($model, 'project_no')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Project Number','readonly' => true])?>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-6"> 
                <?php echo $form->field($model, 'change_order_no')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Change Order Number','value' => uniqid(),])?>
              </div>
              <div class="col-md-6"> 
                <?php 
                  echo $form->field($model, 'contract_date')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Contract Date','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          //'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]); 
                ?>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-6"> 
                <?php 
                  echo $form->field($model, 'date_submited_approval')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date Submited Approval','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          //'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]); 
                ?>
              </div>
              <div class="col-md-6"> 
                <?php 
                  echo $form->field($model, 'date_recived_response')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date Recived Response','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          //'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]); 
                ?>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4"> 
                <?php 
                        $current_status = [
                            'OPEN' => 'Open', 
                            'SUBMITED' => 'Submited',
                            'APPROVED' => 'Approved',
                            'REJECTED' => 'Rejected'
                        ];

                        echo $form->field($model, 'current_status')
                        ->dropDownList($current_status ,['prompt' => 'Select Current Status'])->label(); ?>
              </div>
              <div class="col-md-4"> 
                <?php echo $form->field($model, 'contract_for')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Contract For','readonly' => true])?>
              </div>
              <div class="col-md-4"> 
                <?php /*echo $form->field($model, 'to_contractor')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter To Contractor'])*/
                $dataPost = ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'id' => $details->contractor_id])->all(), 'id',  function($model) {
                                return $model['email'].' - '.$model['first_name'].' - '.$model['last_name'];
                            });
                          echo $form->field($model, 'to_contractor')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11','required'=>true,'readonly'=>true,'class' => 'form-control']);
                ?>

              </div>
              <!--/span-->
            </div>
            <!--/row-->
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Change Order Item Information</h3>
            <hr>
            
              <?php 
                
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  $details = ChangeOrderItem::find()->where(['change_order_id'=> $_GET['id']] )->all();    
                }
                
                if(isset($details) && !empty($details))
                {
                    $i = 0 ;
                    foreach ($details as $value) {

                      $orderItemForm = new ChangeOrderItemForm();
                      $model1 = $orderItemForm->getUpdateModel($value);
                      if($i == 0)
                      {
                        $class =  "row add";
                      }
                      else
                      {
                        $class =  "row add".$i;  
                      }
                      
                      ?>
                      <div class="<?= $class?> cal">
                      <div class="col-md-2">                   
                       <?php
                          $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id',  function($model) {
                                return $model['cost_code'].' - '.$model['name'];
                            });
                          echo $form->field($model1, 'item_id')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Name','required'=>true,'class' => 'form-control name-change-item-name']);
                        ?> 
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'qty')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Quantity','class' => 'form-control  name-change-qty custom-qty','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);'])->label('Quantity') ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'unit')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Unit','class' => 'form-control  name-change-unit','required'=>true]) ?>
                      </div>
                      <div class=" col-md-4">
                        <?php echo $form->field($model1, 'description')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Descriptions','class' => 'form-control  name-change-desc','required'=>true]) ?>                     
                    </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'unit_price')->textInput(['autofocus' => true, 'maxlength' => 50, 'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','placeholder' => 'Enter Unit Price','class' => 'form-control  name-change-unit-price custom-unit-price','required'=>true]) ?>
                      </div>  
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'extended_amt')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Extended Amount','class' => 'form-control custom-val name-change-extended-amt custom-val-amt','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);','readonly'=>true]) ?>
                      </div> 
                      <div class="col-md-3">
                            <?php 
                                $contract_for1 = [
                                    'Owner Requested Changes' => 'Owner Requested Changes', 
                                    'Materials or Equipment Unavailable' => 'Materials or Equipment Unavailable',
                                    'Misc. / Other' => 'Misc. / Other',
                                    'Regulatory Requirements' => 'Regulatory Requirements',
                                    'Unforseen Conditions' => 'Unforseen Conditions',
                                    'Omission' => 'Omission',
                                    'Error' => 'Error',
                                ];

                                echo $form->field($model1, 'change_class[]')
                                ->dropDownList($contract_for1 ,['prompt' => 'Select Change Class'])->label(); ?>
                      </div>
                      <div class="col-md-2">
                             <?php echo $form->field($model1, 'time_ext[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Time Ext','class' => 'form-control  name-change-time-ext','required'=>true]) ?>
                      </div>
                      <div class="col-md-3">
                             <?php echo $form->field($model1, 'notes[]')->textArea(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Notes','class' => 'form-control  name-change-notes','required' => true]) ?>
                      </div>
                      <div class="col-md-1" style="    margin-top: 26px;">                        
                        <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                      </div>
                    </div>
                <?php $i++;    } 
                }
                else
                {
                  $model1 = new ChangeOrderItemForm(); 
                ?>
                <div class="row add cal">  
                  <div class="col-md-2">                   
                       <?php //echo $form->field($model1, 'item_name[]')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Item Name','class' => 'form-control custom-val','required'=>true]) ?> 
                       <?php
                          $dataPost = ArrayHelper::map(\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id',  function($model) {
                                return $model['cost_code'].' - '.$model['name'];
                            });
                          echo $form->field($model1, 'item_id[]')
                          ->dropDownList(
                          $dataPost ,['id' => 'title11', 'prompt' => 'Select Item Name','required'=>true,'class' => 'form-control ']);
                        ?> 
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'qty[]')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Quantity','class' => 'form-control custom-qty','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'unit[]')->textInput(['autofocus' => true, 'maxlength' => 200, 'placeholder' => 'Enter Unit','class' => 'form-control','required'=>true]) ?>
                      </div>
                      <div class=" col-md-4">
                        <?php echo $form->field($model1, 'description[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Descriptions','class' => 'form-control','required'=>true]) ?>                     
                    </div>
                      
                      <div class="col-md-2"> 
                          <?php echo $form->field($model1, 'unit_price[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Unit Price','class' => 'form-control custom-unit-price','required'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div>  
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'extended_amt[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Extended Amount','class' => 'form-control custom-val custom-val-amt','required'=>true,'readonly'=>true,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                      </div> 
                      <div class="col-md-3">
                            <?php 
                                $contract_for1 = [
                                    'Owner Requested Changes' => 'Owner Requested Changes', 
                                    'Materials or Equipment Unavailable' => 'Materials or Equipment Unavailable',
                                    'Misc. / Other' => 'Misc. / Other',
                                    'Regulatory Requirements' => 'Regulatory Requirements',
                                    'Unforseen Conditions' => 'Unforseen Conditions',
                                    'Omission' => 'Omission',
                                    'Error' => 'Error',
                                ];

                                echo $form->field($model1, 'change_class[]')
                                ->dropDownList($contract_for1 ,['prompt' => 'Select Change Class'])->label(); ?>
                      </div>
                      <div class="col-md-2">
                             <?php echo $form->field($model1, 'time_ext[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Time Ext','class' => 'form-control  name-change-time-ext','required'=>true]) ?>
                      </div>
                      <div class="col-md-3">
                             <?php echo $form->field($model1, 'notes[]')->textArea(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Notes','class' => 'form-control  name-change-notes','required' => true]) ?>
                      </div>
                      <div class="col-md-1" style="   margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                <?php  
                }
              ?>    
            </div>
            <div class="a" id="l"></div>
            <a style="cursor: pointer; margin-right: 36px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>      

            <h3 class="box-title m-t-40"><i class="fa fa-usd" aria-hidden="true"></i> Costing </h3>
            <hr>
            <div class="row"> 
              <div class="col-md-6">
               <?php echo $form->field($model, 'old_contract_sum')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Sub Contractor Total Cost','readonly'=>true]) ?>
              </div>
              <div class="col-md-6">
                <?php echo $form->field($model, 'change_order_total_sum')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Item Total Cost','readonly'=>true]) ?>
              </div>              
            </div>
            
            <div class="row"> 
              <div class="col-md-6">
               <?php echo $form->field($model, 'new_order_contract_sum')->textInput(['autofocus' => 10, 'maxlength' => 50, 'placeholder' => 'Enter Sub Contractor Total Cost','readonly'=>true]) ?>
              </div>                            
            </div>       
          
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['change-order/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php
$this->registerJs("
  calculateTotal();
        $('.addd').click(function(){
          $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
          //$('.xcas').find(':input').val('');
          calculateSum();
          calculateTotal();
        });   
        $('.remove_daterow').click(function(){      
          $(this).closest('.xcas').remove();
         calculateSum();
          calculateTotal();
        }); 

        $('.cal').on('input', '.custom-qty', function(){
          var total_row = $(this).val();

          if($(this).parent().parent().parent().children('.col-md-2').children('.field-changeorderitemform-unit_price').children('.custom-unit-price').val() == '' || $(this).parent().parent().parent().children('.col-md-2').children('.field-changeorderitemform-unit_price').children('.custom-unit-price').val() == 'undefined')
          {
            var price = 0;
          }
          else
          {
            var price = $(this).parent().parent().parent().children('.col-md-2').children('.field-changeorderitemform-unit_price').children('.custom-unit-price').val();
          }
          total_row *= price;
          $(this).parent().parent().parent().children('.col-md-3').children('.field-changeorderitemform-extended_amt').children('.custom-val-amt').val(total_row);
          calculateSum();
          calculateTotal();
	    });

	    $('.cal').on('input', '.custom-unit-price', function(){
	          var total_row = $(this).val();
	          
	          if($(this).parent().parent().parent().children('.col-md-2').children('.field-changeorderitemform-qty').children('.custom-qty').val() == '' || $(this).parent().parent().parent().children('.col-md-2').children('.field-changeorderitemform-qty').children('.custom-qty').val() == 'undefined')
	          {
	            var qty = 0;
	          }
	          else
	          {
	            var qty = $(this).parent().parent().parent().children('.col-md-2').children('.field-changeorderitemform-qty').children('.custom-qty').val();
	          }
	          total_row *= qty;

	          $(this).parent().parent().parent().children('.col-md-3').children('.field-changeorderitemform-extended_amt').children('.custom-val-amt').val(total_row);
	          calculateSum();
	          calculateTotal();
	    });  
           
  ");
?>
<script type="text/javascript">
  
  // calculate Sub Total      

  function calculateSum() {
    var calculated_total_sum = 0;

    $('.custom-val-amt').each(function () {
     var get_textbox_value = $(this).val();
     if ($.isNumeric(get_textbox_value)) {
      calculated_total_sum += parseFloat(get_textbox_value);
    }                  
  });
    $('#changeorderform-change_order_total_sum').val(calculated_total_sum);  
    calculateTotal();

  }

  // calculate Total

  function calculateTotal() {
    if($("#changeorderform-change_order_total_sum").val() == '')
    {
      var change_order_total_sum = 0;
    }
    else
    {
      var change_order_total_sum = $("#changeorderform-change_order_total_sum").val(); 
    }
    if($("#changeorderform-old_contract_sum").val() == '')
    {
      var old_contract_sum = 0;
    }
    else
    {
      var old_contract_sum = $("#changeorderform-old_contract_sum").val();
    }
    var calculated_total_sum = 0;
    
    calculated_total_sum += parseFloat(change_order_total_sum);
    calculated_total_sum += parseFloat(old_contract_sum);
    
    $('#changeorderform-new_order_contract_sum').val(calculated_total_sum);       
  }
</script>
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>
