<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
?>

<div class="card">
    <div class="card-header bg-info">
        <h4 class="m-b-0 text-white">New Project </h4>
        <a href="<?= yii\helpers\Url::to(['/project/add'])?>" class="btn btn-default pull-right custom-add-dashboard-project">Add Project</a>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        
        <div class="user-index">
            <div class="table-responsive">
            <?php
            $form = \yii\widgets\ActiveForm::begin([
                'method' => 'get', 'id' => 'super'
            ]);
            ?>
            

            <?php ActiveForm::end();
            ?>
            
                       
            <?php Pjax::begin(['id' => 'projects']) ?>  
            <?=
            GridView::widget([
                'dataProvider' => $dataProvider1,
                'showOnEmpty' => true,
                //'filterModel' => $searchModel,
                'columns' => [
                [
                    'attribute' => 'id',
                    'label' => '#ID',
                    'contentOptions' => ['style' => 'width:40px;'],
                ],
                
                [
                    'attribute' => 'project_name',
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'project_number',
                   
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'project_cost',
                   
                    'format' => 'raw',
                ],
                
            ],
        ]);
        ?>
        <?php Pjax::end() ?>
    </div>
    </div>
</div>
</div> 

<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}

$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");

$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});
");
?>