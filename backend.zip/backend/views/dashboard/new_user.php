<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
?>

<div class="card">
    <div class="card-header bg-info">
        <h4 class="m-b-0 text-white">New User </h4>
    </div>
    <!-- /.box-header -->
    <div class="box-body">

        <div class="user-index">
            <div class="table-responsive">
            <?php
            $form = \yii\widgets\ActiveForm::begin([
                'method' => 'get', 'id' => 'super'
            ]);
            ?>


            <?php ActiveForm::end();
            ?>

            <?php Pjax::begin(['id' => 'users']) ?>  
            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                'showOnEmpty' => true,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn',
                    'header' => '#ID',
                    'contentOptions' => ['style' => 'width:40px;'],
                    'headerOptions' => ['style' => 'color:#3C8DBC;'],
                ],

                [
                    'attribute' => 'first_name',
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'last_name',
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'email',
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'contact_number',
                    'format' => 'raw',
                ],
            ],
        ]);
        ?>
        <?php Pjax::end() ?>
        </div>
    </div>
    <a href="<?= yii\helpers\Url::to(['/user/index'])?>" class="btn btn-default pull-right">Show More</a>
</div>
</div>

