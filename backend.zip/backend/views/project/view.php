<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Project </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project/index") ?>" >Project</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content">
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Project Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [
 
                                
                                [
                                    'attribute' => 'project_name',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by first name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'project_cost',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by last name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'project_size',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by email'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'project_number',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'project_estimated_days',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'date_of_commencement',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                    'value' => function($model)
                                    {
                                        return date("d/m/Y", strtotime($model->date_of_commencement));
                                    }
                                ],
                                [
                                    'attribute' => 'date_of_substantial_completion',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                    'value' => function($model)
                                    {
                                        return date("d/m/Y", strtotime($model->date_of_substantial_completion));
                                    }
                                ],
                                [
                                    'attribute' => 'date_of_completion',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                    'value' => function($model)
                                    {
                                        return date("d/m/Y", strtotime($model->date_of_completion));
                                    }
                                ],
                                [
                                    'attribute' => 'project_physical_address',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],

                                ],
                                [
                                    'attribute' => 'project_state_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],

                                    'value' => function($model)
                                    {
                                        return $model->city->name;
                                    }
                                ],
                                [
                                    'attribute' => 'project_city_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                    'value' => function($model)
                                    {
                                        return $model->state->state_name;
                                    }
                                ],   
                                [
                                    'attribute' => 'project_zipcode',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],  
                                [
                                    'attribute' => 'project_desc',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                    'value' => function($model)
                                    {
                                        return strip_tags($model->project_desc);
                                    }
                                ],
                                [
                                    'attribute' => 'is_architect_ca',
                                    'lable' => 'CA ?',
                                    'value' => function($model)
                                    {
                                        return isset($model->is_architect_ca) && $model->is_architect_ca == 'Y' ? 'Yes' : 'No';
                                    }
                                ],
                                [
                                    'attribute' => 'construction_plan_dated',
                                    
                                ],    
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Architect Details</h3> 
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $architect,
                                'attributes' => [
                                
                                [
                                    'attribute' => 'first_name',
                                    'lable' => 'Architect Contact Person',
                                    'value' => function($model)
                                    {
                                        return $model->first_name . ' '. $model->last_name;
                                    }
                                   
                                ],
                                [
                                    'attribute' => 'email',
                                    
                                ],
                                [
                                    'attribute' => 'contact_number',
                                    'lable' => 'Phone'
                                ],
                                [
                                    'attribute' => 'architect_firm',
                                    
                                ],
                                [
                                    'attribute' => 'address',
                                    
                                ],
                                [
                                    'attribute' => 'city_id',
                                    'value' => function($model)
                                    {
                                        return $model->city->name;
                                    }
                                    
                                ],
                                [
                                    'attribute' => 'state_id',
                                    
                                    'value' => function($model)
                                    {
                                        return  $model->state->state_name;
                                    }
                                ],
                               
                                [
                                    'attribute' => 'zipcode',                                    
                                ], 
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Landlord Details</h3> 
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $landlord,
                                'attributes' => [
                                
                                [
                                    'attribute' => 'landlord_email',
                                    
                                ],
                                [
                                    'attribute' => 'landlord_phone',
                                    'lable' => 'Phone'
                                ],
                                [
                                    'attribute' => 'landlord_contact_person',
                                    
                                ],
                                [
                                    'attribute' => 'will_landlord_require_special_documentation_for_billing',
                                    'lable' => 'Will Landlord require special documentation for Billing/Project Close-out?',
                                    'value' => function($model)
                                    {
                                        return isset($model->will_landlord_require_special_documentation_for_billing) && !empty($model->will_landlord_require_special_documentation_for_billing) && $model->will_landlord_require_special_documentation_for_billing == 'Y' ? "Yes" : "No" ;
                                    }
                                   
                                ],
                                [
                                    'attribute' => 'if_special_documentation_required_if_yes_list',
                                    
                                ],
                                [
                                    'attribute' => 'landlord_address',
                                    
                                ],
                                [
                                    'attribute' => 'landlord_city_id',
                                    'value' => function($model)
                                    {
                                        return $model->city->name;
                                    }
                                    
                                ],
                                [
                                    'attribute' => 'landlord_state_id',
                                    
                                    'value' => function($model)
                                    {
                                        return  $model->state->state_name;
                                    }
                                ],
                               
                                [
                                    'attribute' => 'landlord_zipcode',                                    
                                ], 
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Lender Details</h3> 
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $lender,
                                'attributes' => [
                                
                                [
                                    'attribute' => 'lender_email',
                                    
                                ],
                                [
                                    'attribute' => 'lender_phone',
                                    'lable' => 'Phone'
                                ],
                                [
                                    'attribute' => 'lender_or_bank_contact_person',
                                    
                                ],
                                [
                                    'attribute' => 'bank_require_special_documentation_for_billing_project_closeout',
                                    'lable' => 'Will Lender/Bank require special documentation for Billing/Project Close-out?',
                                    'value' => function($model)
                                    {
                                        return isset($model->bank_require_special_documentation_for_billing_project_closeout) && !empty($model->bank_require_special_documentation_for_billing_project_closeout) && $model->bank_require_special_documentation_for_billing_project_closeout == 'Y' ? "Yes" : "No" ;
                                    }
                                   
                                ],
                                [
                                    'attribute' => 'lender_special_documentation_list_requirements',
                                    
                                ],
                                [
                                    'attribute' => 'lender_address',
                                    
                                ],
                                [
                                    'attribute' => 'lender_city_id',
                                    'value' => function($model)
                                    {
                                        return $model->city->name;
                                    }
                                    
                                ],
                                [
                                    'attribute' => 'lender_state_id',
                                    
                                    'value' => function($model)
                                    {
                                        return  $model->state->state_name;
                                    }
                                ],
                               
                                [
                                    'attribute' => 'lender_zipcode',                                    
                                ], 
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div>
</section>  
</div>

<?php 

$this->registerCss('.detail-view{text-align:left;}')

?>