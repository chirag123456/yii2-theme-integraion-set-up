<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = '';
$this->params['breadcrumbs'][] = ['label' => 'User', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="user-create">

    <?php echo
    $this->render('_form', [
        'model' => $model,
        'model1' => $model1,
    ])
    ?>

</div>
<?php
if (isset($_GET['image-not-found']) && !empty($_GET['image-not-found'])) {

    $this->registerJs("
        $('#user_image').css('border', '1px solid red');
    ");
}
?>