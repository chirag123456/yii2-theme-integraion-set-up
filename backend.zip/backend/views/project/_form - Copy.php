<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;
use dosamigos\ckeditor\CKEditor; 
/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Project | ' . isset($_GET['id']) ? 'Update' : 'Add';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Project </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project/index") ?>" >Project</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Project' : 'Add Project'; ?></li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo isset($_GET['id']) ? 'Update Project' : 'Add Project'; ?></h3> 

                    <a href="<?php echo yii\helpers\Url::to(['project/index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>

                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">

                <div class="project-management-form">
                   <?php
                        $form = ActiveForm::begin([
                                    'id' => 'project-form',
                                    'enableAjaxValidation' => true,
                                    'enableClientValidation' => true,
                                    'options' => ['enctype' => 'multipart/form-data']
                        ]);
                        ?>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class=" col-md-6">
                                    <?php echo $form->field($model, 'project_name')->textInput(['autofocus' => true, 'maxlength' => 30, 'placeholder' => 'Enter Project Name']) ?>
                                </div>
                                <div class=" col-md-6">
                                    <?php echo $form->field($model, 'project_cost')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Project Cost','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                                </div>
                        </div>
                        <div class="col-md-12">
                          <div class=" col-md-4">
                                  <?php 
                                    echo $form->field($model, 'project_physical_address')->textArea(['maxlength' => 300, 'placeholder' => 'Enter Project physical address']);
                                  ?>
                          </div>
                                 <div class=" col-md-3">
                                    <?php 
                                    
                                        echo $form->field($model, 'project_state_id')->widget(
                                         Select2::classname(), [
                                        'data' => ArrayHelper::map(\common\models\state\State::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'state_name'),
                                        'options' => ['placeholder' => 'Select State','onchange' => '
                                            $.post( "' . Yii::$app->urlManager->createUrl('city/set-city?id=') . '"+$(this).val(), function( data ) {
                                            $("#title").html( data );
                                            });
                                        '],
                                        'pluginOptions' => [                   
                                                'initialize' => true,
                                        ],
                                         ])->label(); 
                                    ?>
                                </div>   
                                <div class=" col-md-3">
                                    <?php 
                                        echo $form->field($model, 'project_city_id')->widget(
                                            Select2::classname(), [
                                        'data' => ArrayHelper::map(\common\models\city\City::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED,'state_id' => $model->project_state_id])->asArray()->all(), 'id', 'name'),
                                       'options' => ['placeholder' => 'Please Select state','id' => 'title'],
                                       'pluginOptions' => [                   
                                                'initialize' => true,
                                        ],
                                        ])->label();
                                     ?>
                                </div> 
                                <div class=" col-md-2">
                                    <?php echo $form->field($model, 'project_zipcode')->textInput(['autofocus' => true, 'maxlength' => 8, 'placeholder' => 'Enter Project Zipcode']) 

                                    ?>
                                </div> 
                        </div>
                        <div class="col-md-12">
                                <div class="col-md-4">
                                    <?php 
                                        echo $form->field($model, 'date_of_commencement')->widget(DatePicker::classname(), [
                                                'options' => ['placeholder' => 'Select Date of Commencement',],
                
                                                'pluginOptions' => [  
                                                'language' => 'en',                  
                                                'autoclose' => true,
                                                'format' => 'yyyy-mm-dd',
                                                'startDate' => date("yyyy-MM-dd H:i:s"),
                                                ]
                                        ]);
                                    ?>
                                </div> 
                                <div class="col-md-4">
                                    <?php 
                                        echo $form->field($model, 'date_of_substantial_completion')->widget(DatePicker::classname(), [
                                                'options' => ['placeholder' => 'Select Date of Substantial Completion',],
                
                                                'pluginOptions' => [  
                                                'language' => 'en',                  
                                                'autoclose' => true,
                                                'format' => 'yyyy-mm-dd',
                                                'startDate' => date("yyyy-MM-dd H:i:s"),
                                                ]
                                        ]);
                                    ?>
                                    <?php $form->field($model, 'date_of_substantial_completion')->textInput(['placeholder' => 'Select Date','id' => 'datepicker1']) ?> 
                                </div>  
                                <div class="col-md-4">
                                    <?php 
                                        echo $form->field($model, 'date_of_completion')->widget(DatePicker::classname(), [
                                                'options' => ['placeholder' => 'Select Date of Completion',],
                
                                                'pluginOptions' => [    
                                                'language' => 'en',                
                                                'autoclose' => true,
                                                'format' => 'yyyy-mm-dd',
                                                'startDate' => date("yyyy-MM-dd H:i:s"),
                                                ]
                                        ]);
                                    ?>
                                    <?php $form->field($model, 'date_of_completion')->textInput(['placeholder' => 'Select Date','id' => 'datepicker2']) ?> 
                                </div>                      
                            </div>
                            <div class="col-md-12">   
                                <div class=" col-md-4">
                                        <?php 
                                          echo $form->field($model, 'project_estimated_days')->textInput(['maxlength' => 100, 'id' => 'project_estimated_days', 'placeholder' => 'Enter Project estimated days','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']);
                                        ?>
                                 </div>
                                 <div class=" col-md-4">
                                    <?php echo $form->field($model, 'project_number')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Project Number']) ?>
                                </div>   
                                <div class=" col-md-4">
                                    <?php
                                        echo $form->field($model, 'project_size')->widget(
                                            Select2::classname(), [
                                        'data' => (  array('LARGE' =>'Large' ,'MEDIUM' =>'Medium','SMALL' =>'Small')),
                                       'options' => ['placeholder' => 'Please Select Project Size'],
                                       'pluginOptions' => [                   
                                                'initialize' => true,
                                        ],
                                        ])->label();
                                    ?>
                                </div>                           
                            </div>
                            <div class="col-md-12">
                   
                                <div class=" col-md-12"> 
                                    <?= $form->field($model, 'project_desc')->widget(CKEditor::className(), [
                                            'options' => ['rows' => 6],
                                            'preset' => 'basic'
                                    ]) ?>
                                </div>
                            </div>
                        <div class=" col-md-12">
                            <div class="col-md-6 col-md-offset-6">
                                <?php
                                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                                        echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                                } else {
                                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                                }
                                ?>
                                <a href="<?php echo yii\helpers\Url::to(['project/index']) ?>" style = "margin-right: 5px;" class="btn btn-default pull-right"> Cancel</a>
                            </div>
                        </div>
                    </div>
                    <?php ActiveForm::end(); ?>

                </div>
                </div>
         </div>
    </div>
</div>
</section>
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>
<?php
   
    $this->registerJs("
        $(document).ready(function() {
            $('#datepicker').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
             $('#datepicker1').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker1').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
             $('#datepicker2').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker2').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
        });
    ");

?>