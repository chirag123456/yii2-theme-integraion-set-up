<?php  

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;
use dosamigos\ckeditor\CKEditor; 
use kartik\file\FileInput;
use common\models\project\ProjectDocument;
use backend\components\CommonFunctions;

$this->title = 'Project | ' . isset($_GET['id']) ? 'Update' : 'Add';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<style type="text/css">
    

.card .card-body [type="radio"]:not(:checked), .card .card-body [type="radio"]:checked {
    position: static; 
    left: -9999px; 
    opacity: 1; 
}
.hidden{ 
    display: none;
}
</style>
<section class="content-header">
    <h1> Project </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project/index") ?>" >Project</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Project' : 'Add Project'; ?></li>
    </ol>
</section> 

<section class="content"> 
<div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Project' : 'Add Project'; ?></h4>
      </div>
      <div class="card-body project-management-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'project-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
            ]);
                        ?>
          <div class="form-body">

            
            <!--ARCHITECT INFORMATION-->

            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Architect Information</h3>
            <hr> 
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group"> 
                  <?php 
                    $role = CommonFunctions::getConfigureValueByKey('ARCHITECTURE_USER_ID');
                    //$model->architect_id = $role;
                    echo $form->field($model, 'architect_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            }), 
                              'options' => ['placeholder' => 'Select Architect','onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('project/get-architect?id=') . '"+$(this).val(), function( data ) {
                                      var result = $.parseJSON(data);
                                      
                                      $("#projectform-architect-contact-person").val(result.model.first_name + " " +result.model.last_name);
                                      $("#projectform-architect-email").val(result.model.email);
                                      $("#projectform-architect-phone").val(result.model.contact_number);
                                      $("#projectform-architect-address").val(result.model.address);
                                      $("#projectform-architect-zipcode").val(result.model.zipcode);
                                      $("#projectform-architect-city").val(result.city);
                                      $("#projectform-architect-state").val(result.state);
                                      $("#projectform-architect-firm").val(result.model.architect_firm);
                                    });
                                '],
                      ])->label();  
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Architect Contact Person</label>
                    <input type="text" id="projectform-architect-contact-person" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->first_name . $architect->last_name : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Email</label>
                    <input type="text" id="projectform-architect-email" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->email  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-2">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Phone</label>
                    <input type="text" id="projectform-architect-phone" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->contact_number  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Architect Firm</label>
                    <input type="text" id="projectform-architect-firm" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->architect_firm  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Address</label>
                    <textarea id="projectform-architect-address" class="form-control" name="permissible-working-hours" autofocus="" readonly><?php echo isset($architect) && !empty($architect) ? $architect->address  : '' ?></textarea>
                  </div>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">City</label>
                    <input type="text" id="projectform-architect-city" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->city->name : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">State</label>
                    <input type="text" id="projectform-architect-state" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->state->state_name : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Zipcode</label>
                    <input type="text" id="projectform-architect-zipcode" class="form-control" name="permissible-working-hours" value="<?php echo isset($architect) && !empty($architect) ? $architect->zipcode : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <?= $form->field($model, 'is_architect_ca')->radioList(array('Y'=>'Yes','N'=>'No'));  ?>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">

                  <?php 
                    echo $form->field($model, 'construction_plan_dated')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date of Completion','autocomplete'=> 'off'],

                          'pluginOptions' => [    
                          'language' => 'en',                
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                  ?>
                </div>
              </div>
              <!--/span-->
            </div>

             <!-- LANDLORD INFORMATION-->

            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Landlord Information</h3>
            <hr> 
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group"> 
                  <?php 
                    echo $form->field($model, 'landlord_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\landlord\Landlord::find()->where(['is_active' => ACTIVE,'is_delete' => INACTIVE])
                              ->asArray()->all(), 'id', 'landlord_email'),
                              'options' => ['placeholder' => 'Select Landlord','onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('project/get-landlord?id=') . '"+$(this).val(), function( data ) {
                                      var result = $.parseJSON(data);
                                      
                                      $("#projectform-landlord-address").val(result.model.landlord_address);
                                      $("#projectform-landlord-zipcode").val(result.model.landlord_zipcode);
                                      $("#projectform-landlord-contact").val(result.model.landlord_contact_person);
                                      $("#projectform-landlord-email").val(result.model.landlord_email);
                                      $("#projectform-landlord-phone").val(result.model.landlord_phone);
                                      $("#projectform-landlord-city").val(result.city);
                                      $("#projectform-landlord-state").val(result.state);
                                      if(result.model.will_landlord_require_special_documentation_for_billing == "Y")
                                      {
                                        $("#projectform-landlord-doc").val("Yes");
                                        $(".custom-if-yes").removeClass("hidden");
                                        $("#if-yes").val(result.model.if_special_documentation_required_if_yes_list);
                                      }
                                      else
                                      {
                                        $("#projectform-landlord-doc").val("No");
                                      }

                                    });
                                '],
                      ])->label();  
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Address</label>
                    <textarea id="projectform-landlord-address" class="form-control" name="permissible-working-hours"  autofocus="" readonly> <?php echo isset($landlord) && !empty($landlord) ? $landlord->landlord_address  : '' ?> </textarea>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">City</label>
                    <input type="text" id="projectform-landlord-city" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) ? $landlord->city->name  : '' ?>"  autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-2">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">State</label>
                    <input type="text" id="projectform-landlord-state" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) ? $landlord->state->state_name  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Zipcode</label>
                    <input type="text" id="projectform-landlord-zipcode" class="form-control" name="permissible-working-hours"  value="<?php echo isset($landlord) && !empty($landlord) ? $landlord->landlord_zipcode  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Landlord Contact Person</label>
                    <input type="text" id="projectform-landlord-contact" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) ? $landlord->landlord_contact_person  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Email</label>
                    <input type="text" id="projectform-landlord-email" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) ? $landlord->landlord_email  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Phone</label>
                    <input type="text" id="projectform-landlord-phone" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) ? $landlord->landlord_phone  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">
              
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Will Landlord require special documentation for Billing/Project Close-out?</label>
                    <input type="text" id="projectform-landlord-doc" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) && $landlord->will_landlord_require_special_documentation_for_billing == 'Y' ? 'Yes'  : 'No' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-6  <?php echo isset($landlord) && !empty($landlord) && $landlord->will_landlord_require_special_documentation_for_billing == 'Y' ? ''  : 'custom-if-yes hidden' ?>">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">if yes, list requirements below</label>
                    <textarea id="if-yes" class="form-control" name="permissible-working-hours"  autofocus=""  readonly><?php echo isset($landlord) && !empty($landlord)   ? $landlord->if_special_documentation_required_if_yes_list  : '' ?></textarea>
                  </div>
                </div>
              </div>
              <!--/span-->
            </div>

            <!-- LENDER INFORMATION-->

            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Lender Information</h3>
            <hr> 
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group"> 
                  <?php 
                    echo $form->field($model, 'lender_id')->widget(
                                      Select2::classname(), [
                              'data' => ArrayHelper::map(\common\models\lender\Lender::find()->where(['is_active' => ACTIVE,'is_delete' => INACTIVE])
                              ->asArray()->all(), 'id', 'lender_email'),
                              'options' => ['placeholder' => 'Select Lender','onchange' => '
                                    $.post( "' . Yii::$app->urlManager->createUrl('project/get-lender?id=') . '"+$(this).val(), function( data ) {
                                      var result = $.parseJSON(data);
                                      
                                      $("#if-address-lender").val(result.model.lender_address);
                                      $("#projectform-lender-zipcode").val(result.model.lender_zipcode);
                                      $("#projectform-lender-contact").val(result.model.lender_or_bank_contact_person);
                                      $("#projectform-lender-email").val(result.model.lender_email);
                                      $("#projectform-lender-phone").val(result.model.lender_phone);
                                      $("#projectform-lender-city").val(result.city);
                                      $("#projectform-lender-state").val(result.state);
                                      if(result.model.bank_require_special_documentation_for_billing_project_closeout == "Y")
                                      {
                                        $("#projectform-lender-close").val("Yes");
                                        $(".custom-if-yes1").removeClass("hidden");
                                        $("#projectform-lender-if-yes").val(result.model.lender_special_documentation_list_requirements);
                                      }
                                      else
                                      {
                                        $("#projectform-landlord-doc").val("No");
                                      }

                                    });
                                '],
                      ])->label();  
                   ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Address</label>
                    <textarea id="if-address-lender" class="form-control" name="permissible-working-hours"  autofocus="" readonly><?php echo isset($lender) && !empty($lender) ? $lender->lender_address  : '' ?></textarea>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">City</label>
                    <input type="text" id="projectform-lender-city" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->city->name  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-2">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">State</label>
                    <input type="text" id="projectform-lender-state" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->state->state_name  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <!--/span-->
            </div>

            <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Zipcode</label>
                    <input type="text" id="projectform-lender-zipcode" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->lender_zipcode  : '' ?>"  autofocus="" readonly>
                  </div>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Lender/Bank Contact Person</label>
                    <input type="text" id="projectform-lender-contact" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->lender_or_bank_contact_person  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Email</label>
                    <input type="text" id="projectform-lender-email" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->lender_email  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group"> 
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Phone</label>
                    <input type="text" id="projectform-lender-phone" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->lender_phone  : '' ?>" autofocus="" readonly>
                  </div>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">
              
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">Will Lender/Bank require special documentation for Billing/Project Close-out?</label>
                    <input type="text" id="projectform-lender-close" class="form-control" name="permissible-working-hours" value="<?php echo isset($landlord) && !empty($landlord) && $lender->bank_require_special_documentation_for_billing_project_closeout == 'Y' ? 'Yes'  : 'No' ?>"  autofocus="" readonly>
                  </div>
                </div>
              </div>

              <div class="col-md-6  <?php echo isset($lender) && !empty($lender) && $lender->bank_require_special_documentation_for_billing_project_closeout == 'Y' ? ''  : 'custom-if-yes1 hidden' ?>"">
                <div class="form-group">
                  <div class="form-group field-projectform-project_cost">
                    <label class="control-label has-success" for="">if yes, list requirements below</label>
                    <input type="text" id="projectform-lender-if-yes" class="form-control" name="permissible-working-hours" value="<?php echo isset($lender) && !empty($lender) ? $lender->lender_special_documentation_list_requirements  : '' ?>"  autofocus="" readonly>
                  </div>
                </div>
              </div>
              <!--/span-->
            </div>

            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Project General Information</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo $form->field($model, 'project_name')->textInput(['autofocus' => true, 'maxlength' => 30, 'placeholder' => 'Enter Project Name']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo $form->field($model, 'project_cost')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Project Cost','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo $form->field($model, 'project_number')->textInput(['autofocus' => true, 'maxlength' => 10, 'placeholder' => 'Enter Project Number']) ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo $form->field($model, 'project_size')->textInput(['autofocus' => true, 'maxlength' => 15, 'placeholder' => 'Enter Project Size']) ?> 
                </div>
              </div>
              <!--/span-->
            </div>
            <!--/row-->
            
            <!--/row-->
            <h3 class="box-title m-t-40"> <i class="fa fa-map-marker" aria-hidden="true"></i> Address</h3>
            <hr>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <?php 
                      echo $form->field($model, 'project_physical_address')->textArea(['maxlength' => 300, 'placeholder' => 'Enter Project Physical Address']);
                  ?>
                </div>
              </div>
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <?php 
                                    
                      echo $form->field($model, 'project_state_id')->widget(
                       Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\state\State::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'state_name'),
                      'options' => ['placeholder' => 'Select State','onchange' => '
                          $.post( "' . Yii::$app->urlManager->createUrl('city/set-city?id=') . '"+$(this).val(), function( data ) {
                          $("#title").html( data );
                          });
                      '],
                      'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                       ])->label(); 
                  ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <!--/row-->
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <?php 
                      echo $form->field($model, 'project_city_id')->widget(
                          Select2::classname(), [
                      'data' => ArrayHelper::map(\common\models\city\City::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED,'state_id' => $model->project_state_id])->asArray()->all(), 'id', 'name'),
                     'options' => ['placeholder' => 'Please Select state','id' => 'title'],
                     'pluginOptions' => [                   
                              'initialize' => true,
                      ],
                      ])->label();
                  ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <?php echo $form->field($model, 'project_zipcode')->textInput(['autofocus' => true, 'maxlength' => 8, 'placeholder' => 'Enter Project Zipcode']) 
                  ?>
                </div>
              </div>
            </div>
 
            <h3 class="box-title m-t-40"><i class="fa fa-calendar" aria-hidden="true"></i> Costing and Estimated Date</h3>
            <hr>
            <div class="row">
              <div class="col-md-6">
                <?php 
                  echo $form->field($model, 'date_of_commencement')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date of Commencement','autocomplete'=> 'off',],

                          'pluginOptions' => [  
                          'language' => 'en',                  
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                ?>
              </div>
              <div class="col-md-6">
                <?php 
                    echo $form->field($model, 'date_of_substantial_completion')->widget(DatePicker::classname(), [
                            'options' => ['placeholder' => 'Select Date of Substantial Completion','autocomplete'=> 'off',],

                            'pluginOptions' => [  
                            'language' => 'en',                  
                            'autoclose' => true,
                            'format' => 'yyyy-mm-dd',
                            
                            'startDate' => date("yyyy-MM-dd H:i:s"),
                            ]
                    ]);
                ?>
              </div>
              
            </div>
            <div class="row">
              <div class=" col-md-6"> 
                  <?php 
                  echo $form->field($model, 'date_of_completion')->widget(DatePicker::classname(), [
                          'options' => ['placeholder' => 'Select Date of Completion','autocomplete'=> 'off'],

                          'pluginOptions' => [    
                          'language' => 'en',                
                          'autoclose' => true,
                          'format' => 'yyyy-mm-dd',
                          'startDate' => date("yyyy-MM-dd H:i:s"),
                          ]
                  ]);
                ?>
              </div>
              <div class=" col-md-6"> 
                  <?php 
                    echo $form->field($model, 'project_estimated_days')->textInput(['maxlength' => 100, 'id' => 'project_estimated_days', 'placeholder' => 'Enter Project estimated days','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']);
                  ?>
              </div>
              
            </div>
            <h3 class="box-title m-t-40"><i class="fa fa-paragraph" aria-hidden="true"></i> Project Description</h3>
            <hr>
            <div class="row">
              <div class=" col-md-12"> 
                  <?= $form->field($model, 'project_desc')->widget(CKEditor::className(), [
                          'options' => ['rows' => 6],
                          'preset' => 'basic'
                  ]) ?>
              </div>
              
            </div>
             <h3 class="box-title m-t-40"><i class="fa fa-file" aria-hidden="true"></i> Project Documents</h3>
            <hr> 
             <div class="row">
              <div class=" col-md-12"> 
                  <?php   
                    echo FileInput::widget([
                      'model' => $model1,
                      'attribute' => 'file_name[]',
                      'options' => ['multiple' => true],
                      'pluginOptions' => [
                          'maxFileCount' => 5,
                          'maxFileSize'=>2500
                      ]
                    ]);
                  ?>
              </div>
            </div> 
             <?php 
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  ?>
            <h3 class="box-title m-t-40"><i class="fa fa-file" aria-hidden="true"></i> Project's Uploaded Documents</h3>
            <hr> 
             <div class="row">
              
              <?php 
                if(isset($_GET['id']) && !empty($_GET['id']))
                {

                  $details = ProjectDocument::find()->where(['project_id'=> $_GET['id']] )->all();  
                  if(isset($details) && !empty($details))
                  { 
                    foreach ($details as $value) {
              ?>
                    <div class="col-md-3">
                      <?php 
                        $basePath = Yii::$app->request->hostInfo.$value->file_path.'/'.$value->file_name;
                      ?>
                      <p> <a href="<?= $basePath ?>" target="_blank"> <?= $value->file_name; ?>   </a></p>
                    </div>
              <?php
                    } 

                  }  
                  
                }
              ?>
              
            </div> 
             <?php
                    } 

                 
              ?>
          </div>
          <br/>
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['project/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>
<?php
   
    $this->registerJs("
        $(document).ready(function() {
            $('#datepicker').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
             $('#datepicker1').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker1').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
             $('#datepicker2').datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                maxDate: '0'
            });
             $('#datepicker2').datepicker().datepicker('setDate', 'today').attr('readOnly', true);
        });
    ");
?>