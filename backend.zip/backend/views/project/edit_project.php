<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = '';
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="user-create">



    <?=
    $this->render('_form', [
        'model' => $model,
        'model1' => $model1,
        'lender' => isset($lender) && !empty($lender) ? $lender : '',
        'architect' => isset($architect) && !empty($architect) ? $architect : '',
        'landlord' => isset($landlord) && !empty($landlord) ? $landlord : '',
        //'owner' => isset($owner) && !empty($owner) ? $owner : '', 
    ])
    ?>

</div>
