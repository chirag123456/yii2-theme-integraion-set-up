<?php
use yii\helpers\Html;

?>

<div class="pdf-dealer container">
    <table class="table table-bordered" style="font-family: sans-serif;
    border: 1mm solid;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Name</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Cost</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Size</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Estimated Days</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Number</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Date of Commencement</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Date of Substantial Completion</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Date of Completion</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Physical Address</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project City</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project State</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Project Zipcode</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Contact Person</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Email</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Phone</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Firm</td>
                <!-- <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Address</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect City</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect State</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Zipcode</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect CA?</td> -->
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Architect Construction Plan Date</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lendlord Contact Person</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lendlord Email</td>
                <!-- <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lendlord Phone</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Landlord Address</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Landlord State</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Landlord City</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lendlord Zipcode</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Will Landlord Require Special Documentation For Billing</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">If Special Documentation Required If Yes List</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender Or Bank Contact Person</td> -->
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender Email</td>
                <!-- <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender Phone</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Bank Require Special Documentation For Billing Project Closeout</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender Special Documentation List Requirements</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender Address</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender State</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender City</td>
                <th style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;">Lender Zipcode</td> -->
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model) && !empty($model))
                {
                    foreach ($model as $value) {
            ?>
                <tr>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_name'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_cost'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_size'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_estimated_days'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_number'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['date_of_commencement'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['date_of_substantial_completion'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['date_of_completion'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_physical_address'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['p_city_name'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['project_zipcode'] ?></td>
    <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['p_state_name'] ?></td>
                
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_first_name']. ' '.$value['architect_last_name'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_email'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_contact_number'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_firm'] ?></td>
                <?php /*<td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_address'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_city'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_state'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['architect_zipcode'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['is_architect_ca'] ?></td>*/ ?>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['construction_plan_dated'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_contact_person'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_email'] ?></td>
                <?php /*<td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_phone'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_address'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_city'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_state'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['landlord_zipcode'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['will_landlord_require_special_documentation_for_billing'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['if_special_documentation_required_if_yes_list'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_or_bank_contact_person'] ?></td>*/ ?>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_email'] ?></td>
                <?php /*<td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_phone'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['bank_require_special_documentation_for_billing_project_closeout'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_special_documentation_list_requirements'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_address'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_city_name'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_state_name'] ?></td>
                <td style="padding: 3mm;
    border: 1mm solid;
    vertical-align: middle;"><?= $value['lender_zipcode'] ?></td>*/ ?>
                
            </tr> 
            <?php
                    }
                }
                else
                {
            ?>
                <tr>
                    <p> No Data Available</p>     
                </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>