<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use common\models\userrole\UserAccess;
use yii\helpers\ArrayHelper;
use common\models\contractor\ContractorManagement;
use backend\components\CommonFunctions;
use kartik\date\DatePicker;


$project_id = isset($_GET['RfiReportForm']['project_id']) && ($_GET['RfiReportForm']['project_id']) != '' ? $_GET['RfiReportForm']['project_id']  : '';

$architect_id = isset($_GET['RfiReportForm']['architect_id']) && ($_GET['RfiReportForm']['architect_id']) != '' ? $_GET['RfiReportForm']['architect_id']  : '';

$rfi_date = isset($_GET['RfiReportForm']['rfi_date']) && ($_GET['RfiReportForm']['rfi_date']) != '' ? $_GET['RfiReportForm']['rfi_date']  : '';


$this->title = 'Admin';
$this->params['breadcrumbs'][] = $this->title;
?> 
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
        Rfi Report
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Rfi Report</li>
    </ol>
</section>
<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">

                    <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Filter Rfi' : 'Filter Rfi'; ?></h4> 

                </div>
                
                <div class="card-body task-allocation-form">    
                    <?php
                    $form = ActiveForm::begin([
                        'id' => 'rfi-form',
                        'enableAjaxValidation' => false,
                        'enableClientValidation' => true,
                        'options' => ['enctype' => 'multipart/form-data'],
                        'method' => 'GET'
                    ]);
                    ?>
                    
                    <div class="form-body">
                        <div class="row p-t-20"> 
                            <div class=" col-md-4">
                                <div class="form-group">
                                    <?php 
                                        $model->project_id = $project_id;            
                                        $model->architect_id = $architect_id;            
                                        $model->rfi_date = $rfi_date;            
                                    ?>
                                    <?=

                                    $form->field($model, 'project_id')->widget(Select2::classname(), [
                                        'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                                        'options' => ['prompt' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                                    ])->label();
                                    ?>
                                </div>
                            </div>
                            <div class=" col-md-4">
                                <div class="form-group">
                                    <?php 
                                        $role = CommonFunctions::getConfigureValueByKey('ARCHITECTURE_USER_ID');
                                        echo $form->field($model, 'architect_id')->widget(
                                                          Select2::classname(), [
                                                  'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE,'role' => $role])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                                    return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                                                }), 
                                                  'options' => ['placeholder' => 'Select Architect'],
                                          ])->label();  
                                       ?>
                                    </div>
                                </div>
                                <div class=" col-md-4">
                                    <div class="form-group">
                                        <?php 
                                            echo $form->field($model, 'rfi_date')->widget(DatePicker::classname(), [
                                                  'options' => ['placeholder' => 'Select Rfi Date','autocomplete'=> 'off'],

                                                  'pluginOptions' => [    
                                                  'language' => 'en',                
                                                  'autoclose' => true,
                                                  'format' => 'yyyy-mm-dd',
                                                  ]
                                          ]);
                                          ?>
                                    </div>
                                </div>
                            </div>
                </div>
                <div class="form-actions">

                    <a href="<?php echo yii\helpers\Url::to(['rfi-report/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"> <i class="fa fa-close"></i> Cancel</a>

                    <?php
                    echo Html::submitButton('<i class="fa fa-check"></i> Filter', ['class' => 'btn btn-primary', 'id' => 'img']);
                    ?>


                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </section>
<section class="content">
    <div class="row">
        
        <div class="col-xs-12">
            <div class="box box-primary">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="state-index">
                        <div class="table-responsive">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                            $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>

                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel5 = '';
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '5') {
                                        $sel5 = 'selected="selected"';
                                    } else if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="5" <?php echo $sel5; ?>>5</option>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            
                            <?php echo Html::a('Export Excel', ['export-excel?project_id='.$project_id. '&architect_id='.$architect_id.'&rfi_date='.$rfi_date], ['class' => 'btn btn-primary filter-reset']) ?>
                            <?php echo Html::a('Reset', ['index'], ['class' => 'btn btn-primary filter-reset']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'task-allocation']) ?>  

                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            //'filterModel' => $searchModel,
                            'columns' => [
                                [
                                    'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                                
                                [
                                    'attribute' => 'rfi_code',
                                    'headerOptions' => ['title' => 'sort by project name'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Project Name'
                                    ],
                                ],
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by project name'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Project Name'
                                    ],
                                    'value' => 'project.project_name'
                                ],
                                [
                                    'attribute' => 'project_number',
                                    'headerOptions' => ['title' => 'sort by project number'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Project Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'project_location',
                                    'headerOptions' => ['title' => 'sort by project location'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Project Location'
                                    ],
                                ],
                                [
                                    'attribute' => 'is_active',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:150px;'],
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select status'
                                    ],
                                    'filter' => [ACTIVE => "Active", INACTIVE => "InActive"],
                                    'value' => function ($model) {
                                        if ($model->is_active == ACTIVE) {
                                            return Html::tag('span', 'Active', ['class' => ['label', 'label-success']]);
                                        } elseif ($model->is_active == INACTIVE) {
                                            return Html::tag('span', 'InActive', ['class' => ['label', 'label-danger']]);
                                        }
                                    },
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{view}',
                                    'buttons' => [
                                        
                                        
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                                        'target' => '_blank'
                                            ]);
                                        },
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {
                                        if ($action === 'view') {
                                            return \yii\helpers\Url::toRoute(['rfi-report/view/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
