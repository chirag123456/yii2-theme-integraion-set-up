<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Task Allocation Report </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("task-allocation-report/index") ?>" >Task Allocation Report </a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content">
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Task Allocation Report Detail</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [                                 
                                [
                                    'attribute' => 'project_id',  
                                    'value' => function ($model) {
                                            return $model->project->project_name; 
                                    },                                 
                                ],
                                [
                                    'attribute' => 'task_name', 
                                ],
                                [
                                    'attribute' => 'priority',
                                ],
                                [
                                    'attribute' => 'user_id',  
                                    'value' => function ($model) {
                                            return $model->user->email; 
                                    },                                 
                                ],
                                [
                                    'attribute' => 'role_id',  
                                    'value' => function ($model) {
                                            return $model->role->name; 
                                    },                                 
                                ],
                                [
                                    'attribute' => 'task_status',  
                                                                     
                                ],
                                [
                                    'attribute' => 'start_date',       
                                ],
                                [
                                    'attribute' => 'due_date',  
                                ],
                                [
                                    'attribute' => 'description',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function($model)
                                    {
                                        return strip_tags(trim($model->description));
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                    ],
                                ],
                                    
                                ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>

