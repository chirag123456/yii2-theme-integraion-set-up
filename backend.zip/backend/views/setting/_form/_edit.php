<?php
use yii\widgets\ActiveForm;
use yii\bootstrap\Html;
?>
<div class="box-header with-border">
    <h3 class="box-title">Update Site Configuration</h3>
</div>
<?php
$form = ActiveForm::begin([
            'id' => 'site-configuration-form',
            'enableAjaxValidation' => true,
            'enableClientValidation' => true,
            'action' => \yii\helpers\Url::to(['setting/update/' . $_GET['id']]),
        ]);
?>
<div class="row">
    <div class="col-md-12">
        <div class="col-md-4">
            <?php echo $form->field($model, 'config_key')->textInput(['disabled' => 'true', 'maxlength' => true, 'placeholder' => 'Enter Config key']) ?>
        </div>
        <div class="col-md-4">
            <?php echo $form->field($model, 'config_value')->textInput(['maxlength' => true, 'placeholder' => 'Enter Config Value']) ?>
        </div>
        <div class="col-md-4">
            <?php
            echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right create-button']);
            echo Html::a('Cancel', ['index'], ['class' => 'btn btn-default pull-right cancel-button']);
            ?>                              
        </div>
        
    </div>
    <?php ActiveForm::end(); ?>
</div>

