<?php
use yii\widgets\ActiveForm;
use yii\bootstrap\Html;
?>
<div class="box-header with-border">
    <h3 class="box-title">Add Site Configuration</h3>
</div>
<?php
$form = ActiveForm::begin([
            'id' => 'site-configuration-form',
            'enableAjaxValidation' => true,
            'enableClientValidation' => true,
            'action' => \yii\helpers\Url::to(['setting/add'])
]);
?>
<div class="row">
    <div class="col-md-12">
        <div class="col-md-4">
            <?php echo $form->field($model, 'config_key')->textInput(['maxlength' => true, 'placeholder' => 'Enter Config key' , 'autofocus'=>true]) ?>
        </div>
        <div class="col-md-4">
            <?php echo $form->field($model, 'config_value')->textInput(['maxlength' => true, 'placeholder' => 'Enter Config Value']) ?>
        </div>
        <div class="col-md-4">
            <?php
            echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary pull-right create-button']);
            echo Html::button('<i class="fa fa-close"></i> Cancel', ['class' => 'btn btn-default pull-right cancel-button remove']);
            ?>                              
        </div>
    </div>
</div>
<?php ActiveForm::end(); ?>

