<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\Country */
?>

<section class="content-header">
      <h1>
        City
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
         <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("city/index") ?>" >City</a></li>
        <li class="active">Add City</li>
      
      </ol>
  </section>
   <?= $this->render('_form', [
      'model' => $model,
  ]) ?>
