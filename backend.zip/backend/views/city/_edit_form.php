<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>


<div class="city-form">
    <?php
    $form = ActiveForm::begin([
                'id' => 'city-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="row box-body">
        <div class=" col-md-12">
            <div class=" col-md-6">
                <?=
                    $form->field($model, 'country_id')->widget(Select2::classname(), [
                        'data' => \yii\helpers\ArrayHelper::map(\common\models\country\Country::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'country_name'),
                        'options' => ['placeholder' => 'Select Country', 'onchange' => '
                                            $.post( "' . Yii::$app->urlManager->createUrl('city/set-action?id=') . '"+$(this).val(), function( data ) {
                                              $("#title").html( data );
                                            });
                                        '],
                        'pluginOptions' => [
                            'allowClear' => true
                        ],
                    ])->label();
                ?>
            </div>
            <div class="col-md-6">
                  <?php
                        $dataPost = ArrayHelper::map(\common\models\state\State::find()->asArray()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['country_id' => $model->country_id])->all(), 'id', 'state_name');

                        
                    ?>
                    <?=
                    $form->field($model, 'state_id')->widget(Select2::classname(), [
                    'data' => $dataPost,
                    'options' => ['placeholder' => 'Please select country', 
                    'id' => 'title', 'prompt' => 'Please select country'

                   
                                ],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ])->label();
                ?>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-6">
                <?= $form->field($model, 'name')->textInput(['maxlength' => true, 'placeholder' => 'Enter City']) ?>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {

                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                } else {
                    echo Html::submitButton('Create', ['class' => 'btn btn-primary pull-right']);
                }
                ?>
                <?php echo Html::a('Cancel', ['city/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>