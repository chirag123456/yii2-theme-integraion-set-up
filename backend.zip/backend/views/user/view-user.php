<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?>
<style type="text/css">
    table th a, table th, footer a {
    color: #000 !important;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 1px;
}
</style>
<div class="order-create">
<section class="content-header">
    <h1> User </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>" >User</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">User Details</h3> 
                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [                                
                                [
                                    'attribute' => 'first_name',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by first name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'last_name',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by last name'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'email',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by email'
                                        
                                    ],
                                ],
                                [
                                    'attribute' => 'contact_number',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Contact Number'
                                    ],
                                ],
                                [
                                    'attribute' => 'role',
                                    'label' => 'Role',
                                    'format' => 'raw',
                                    'value' => $model->rolename->item_name,
                                    
                                ],
                                [
                                    'label' => 'User Image',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:70px;float:left'],
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                            $imgUrl = Yii::$app->request->hostInfo.(isset($model->user_image)? USER_PROFILE_PATH. $model->user_image: USER_PROFILE_PATH.'default_image.png');
                                            //$name = (isset($model->first_name)?$model->first_name:$model->last_name);
                                            return '<img data-toggle="tooltip"  alt="User Image" src="'.$imgUrl.'" style="width:170px;height:120px;">';
                                    },
                                ],
                                [
                                    'label' => 'State',
                                     'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                     'format' => 'raw',
                                     'value' => function ($model) {
                                         $statename = (isset($model->state->state_name)?$model->state->state_name: 'N/A');
                                         return $statename;    
                                     },  
 
                                 ],
                                [
                                    'label' => 'City',
                                     'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                     'format' => 'raw',
                                     'value' => function ($model) {
                                         $cityname = (isset($model->city->name)?$model->city->name: 'N/A');
                                         return $cityname;    
                                     },  
 
                                 ],
                                [
                                    'attribute' => 'address',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by address'
                                    ],
                                ],
                                [
                                    'attribute' => 'zipcode',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by zipcode'
                                    ],
                                ],
                                    
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
    
</section> 
</div>

<?php 
$this->registerJs("
     var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
    ");

$this->registerJs(\yii\web\View::POS_BEGIN);

$this->registerCssFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.css');
$this->registerCssFile('http://www.jqueryscript.net/css/jquerysctipttop.css');

$this->registerJsFile(Yii::$app->homeUrl . 'resource/drivers/views.js', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.js', ['depends' => 'yii\web\JqueryAsset']);
$this->registerCss('.detail-view{text-align:left;}')

?>