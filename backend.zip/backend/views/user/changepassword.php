<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
?> 

<div class="user-create">
      <section class="content-header">
        <h1>Change Password</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>" >User</a></li>
            <li class="active"><?php echo 'Change Password'; ?></li>
        </ol>
    </section>
<section class="content"> 
  
    <section class="content1">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Change Password</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['user/index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">
                    <div class="user-form">
                        <?php
            $form = ActiveForm::begin([
                        'id' => "change-password",
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true]);
            ?>
            <div class="row">
                <div class="col-md-12">
                    <div class=" col-md-6">
                        <?php echo $form->field($model, 'old_password')->passwordInput(['autofocus' => true,'maxlength' => 100, 'placeholder' => 'Enter Current Password']) ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class=" col-md-6">
                        <?php echo $form->field($model, 'new_password')->passwordInput(['maxlength' => 100, 'placeholder' => 'Enter New Password']) ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class=" col-md-6">
                        <?php echo $form->field($model, 'confirm_password')->passwordInput(['maxlength' => 100, 'placeholder' => 'Enter Confirm new Password']) ?>
                    </div>
                </div>
            </div>
            
            <div class=" col-md-12">
                <div class="col-md-6 col-md-offset-6">
                    <?php echo Html::submitButton("Change Password", ['class' => 'btn btn-primary submit pull-right']); ?>
                    <a href="<?php echo yii\helpers\Url::to(['user/index']) ?>" style = "margin-right: 5px;" class="btn btn-default pull-right"> Cancel</a>
                </div>
            </div>
            
            <?php ActiveForm::end(); ?>
             </div>                        
                </div>        
            </div>
        </div>
    </div> 
</section>  
</section>             
</div>
