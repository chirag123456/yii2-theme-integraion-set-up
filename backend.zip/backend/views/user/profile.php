<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php');
?>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title"><?= $model->name ?></h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <?php if (isset(Yii::$app->user->identity->icon) && !empty(Yii::$app->user->identity->icon)) { ?>

                                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="<?= \Yii::$app->request->BaseUrl . 'uploads/' . $model->image ?>" class="img-circle img-responsive"> </div>
                            <?php } else { ?>
                                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="<?= \Yii::$app->request->BaseUrl . 'uploads/default_image.png' ?>" class="img-circle img-responsive"> </div>

                            <?php } ?>
                            <div class=" col-md-9 col-lg-9 "> 
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td>Name </td>
                                            <td class=""> <?= $model->name  ?></td>
                                        </tr>
                                        <tr>
                                            <td>Address</td>
                                            <td>Ahmedabad</td>
                                        </tr>
                                        <tr>
                                            <td>Email</td>
                                            <td class="fa fa-envelope-o"> <a href="mailto:info@support.com"><?= $model->email ?></a></td>
                                        </tr>
                                    <td>Mobile</td>
                                    <td class="fa fa-phone"> 8490910000                                    </td>

                                    </tr>

                                    </tbody>
                                </table>

                                <a href="<?= \Yii::$app->getUrlManager()->createUrl(['user/change-password']) ?>" class="btn btn-primary"><span class="fa fa-key">Change Password</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">

                        <a href="<?= \Yii::$app->getUrlManager()->createUrl(['user/update/' . Yii::$app->user->identity->id]) ?>" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
