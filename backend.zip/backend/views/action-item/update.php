<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\ActionItem */

$this->title = 'Update Action Item: {nameAttribute}';
$this->params['breadcrumbs'][] = ['label' => 'Action Items', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="action-item-update">


    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
