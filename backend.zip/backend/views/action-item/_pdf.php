<?php
use yii\helpers\Html;
?>
<div class="pdf-dealer container">
    <h4>Action Item</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
    border: 1px solid #CECECE;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CDCDCD;
                    vertical-align: middle;
                    font-size: 12px ">Action Item ID</th>
                <th style="padding: 5px;
                    border: 1px solid #CDCDCD;
                    vertical-align: middle;
                    font-size: 12px ">Project Name</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Meeting Location</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Facilitators</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Invitees</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Participants</th>    
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model) && !empty($model))
                { ?>
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $model[0]['ac_id'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $model[0]['project_name'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $model[0]['meeting_location'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $model[0]['facilitators'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $model[0]['invitees'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $model[0]['participants'] ?></td> 
                    </tr> 
            <?php }
                else
                {
            ?>
                    <tr>
                        <p> No Data Available</p>     
                    </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>

<div class="pdf-dealer container">
    <h4>Action Item List</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item No</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Date Of Origin</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Priority</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Desc</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Current Status</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Action Item Owner</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Origin</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Due Date</th>    
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Completed Or Received</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model) && !empty($model))
                {
                    foreach ($model as $value) { ?>
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['item_no'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['date_of_origin'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['priority'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['item_desc'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['current_status'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['action_item_owner'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['item_origin'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['due_date'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $value['completed_or_received'] ?></td>    
                    </tr> 
            <?php
                    }
                }
                else
                { ?>
                <tr>
                    <p> No Data Available</p> 
                </tr>
            <?php        
                }
            ?>
        </tbody>
    </table>
</div>