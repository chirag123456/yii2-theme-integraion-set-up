<?php
use yii\helpers\Html;
use common\models\actionitem\ActionItem;
use common\models\actionitem\ActionItemList;
?>
<div class="pdf-dealer container">
    <?php 
        if(isset($data) && !empty($data)){
            foreach ($data as $val) {

            $actionItem = new ActionItem();
            $model = $actionItem->getActionItemListData($val->id);
            if(isset($model) && !empty($model))
                {
                    foreach ($model as $value) {
    ?>
    <h4>Action Item</h4>
    <table class="table table-bordered" style="font-family: sans-serif;border: 1px solid #CECECE;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;border: 1px solid #CDCDCD;vertical-align: middle;font-size: 12px ">Action Item ID</th>
                <th style="padding: 5px;
                    border: 1px solid #CDCDCD;
                    vertical-align: middle;
                    font-size: 12px ">Project Name</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Meeting Location</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Facilitators</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Invitees</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Participants</th>    
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="padding: 5px;border: 1px solid #CECECE;vertical-align: middle; font-size: 12px"><?= $value['ac_id'] ?></td>
                <td style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px"><?= $value['project_name'] ?></td>
                <td style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px"><?= $value['meeting_location'] ?></td>
                <td style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px"><?= $value['facilitators'] ?></td>
                <td style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px"><?= $value['invitees'] ?></td>
                <td style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px"><?= $value['participants'] ?></td> 
            </tr> 
        </tbody>
    </table>

    <h4>Action Item List</h4>
    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item No</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Date Of Origin</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Priority</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Desc</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Current Status</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Action Item Owner</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Item Origin</th>
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Due Date</th>    
                <th style="padding: 5px;
                    border: 1px solid #CECECE;
                    vertical-align: middle; font-size: 12px">Completed Or Received</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if(isset($status) && !empty($status) && $status == OPEN)
            {
                $model1 = ActionItemList::find()->where(['action_item_id' => $val->id,'current_status' => $status ])->all();
            }
            else
            {
                $model1 = ActionItemList::find()->where(['action_item_id' => $val->id])->all();
            }
                
                
                if(isset($model1) && !empty($model1))
                {
                    foreach ($model1 as $val2) {  
                    ?>
                    <tr>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['item_no'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['date_of_origin'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['priority'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['item_desc'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['current_status'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['action_item_owner'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['item_origin'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['due_date'] ?></td>
                        <td style="padding: 5px;
                            border: 1px solid #CECECE;
                            vertical-align: middle; font-size: 12px"><?= $val2['completed_or_received'] ?></td>    
                    </tr> 
            <?php
            }
        }
            ?>
        </tbody>
    </table>
<?php   }
        }
    }
}else{ ?>
    <table class="table table-bordered" style="font-family: sans-serif;
        border: 1px solid #CECECE;
        border-collapse: collapse;">
        <tr>
            <p> No Data Available</p> 
        </tr>
    </table>            
<?php } ?>
</div>