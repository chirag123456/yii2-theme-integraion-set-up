<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\ActionItem */

$this->title = 'Create Action Item';
$this->params['breadcrumbs'][] = ['label' => 'Action Items', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="action-item-create">

    

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
