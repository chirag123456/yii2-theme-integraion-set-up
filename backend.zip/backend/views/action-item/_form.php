<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use dosamigos\ckeditor\CKEditor; 
use common\models\actionitem\ActionItemListForm;
use common\models\actionitem\ActionItemList;
use backend\components\CommonFunctions;
use kartik\date\DatePicker;

$this->title = 'Action Item | ' . isset($_GET['id']) ? 'Update' : 'Add';
?> 
<section class="content-header">
    <h1> Action Item </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("action-item/index") ?>" >Action Item</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Action Item' : 'Add Action Item'; ?></li>
    </ol>
</section>
<section class="content">  
    <div class="row new-classic-form">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header bg-info">
        <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Action Item' : 'Add Action Item'; ?></h4>
      </div> 
      <div class="card-body project-budget-management-form">
        <?php
            $form = ActiveForm::begin([
                    'id' => 'actionlist-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
            ]);
                        ?>
          <div class="form-body">
            <h3 class="card-title"><i class="fa fa-info-circle" aria-hidden="true"></i> Action Item Information</h3>
            <hr>
            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                    <?=
                        $form->field($model, 'project_id')->widget(Select2::classname(), [
                            'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                            'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                    ])->label();
                ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php 
                        echo $form->field($model, 'meeting_date')->widget(DatePicker::classname(), [
                              'options' => ['placeholder' => 'Select Meeting Date','autocomplete'=> 'off'],
                              'pluginOptions' => [    
                              'language' => 'en',                
                              'autoclose' => true,
                              'format' => 'yyyy-mm-dd',
                              'startDate' => date("yyyy-MM-dd H:i:s"),
                              ]
                    ]);
                  ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                     <?php echo $form->field($model, 'meeting_location')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Meeting Location','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'next_meeting_details')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Next Meeting Details','class' => 'form-control']) ?>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                     <?php echo $form->field($model, 'facilitators')->textInput(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Facilitators','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'invitees')->textInput(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Invitees','class' => 'form-control']) ?>
                </div>
              </div>
              <!--/span-->
            </div>

            <div class="row p-t-20">             
              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                     <?php echo $form->field($model, 'participants')->textInput(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Participants','class' => 'form-control']) ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"> 
                    <?php echo $form->field($model, 'objective')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Objective','class' => 'form-control']) ?>
                </div>
              </div>
              <!--/span-->
            </div>
            <!--/row-->
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Topics of Discussion</h3>
            <hr>
            
              <?php 
                
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                  $details = ActionItemList::find()->where(['action_item_id'=> $_GET['id']] )->all();  
                }
                
                if(isset($details) && !empty($details))
                {
                    $i = 0 ;
                    foreach ($details as $value) {

                      $actionItemListForm = new ActionItemListForm();
                      $model1 = $actionItemListForm->getUpdateModel($value);
                      if($i == 0)
                      {
                        $class =  "row add";
                      }
                      else
                      {
                        $class =  "row add".$i;//." xcas";  
                      }
                      
                      ?>
                      <div class="<?= $class?>">
                      <div class="col-md-2">                   
                       <?php echo $form->field($model1, 'item_no')->textInput(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Item No','class' => 'form-control custom-val name-change-item-no','required'=>true]) ?> 
                      </div>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'date_of_origin')->input('date',['required'=>true,'class' => 'form-control custom-val name-change-date-of-origin']) ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php 
                          $priority = ['HIGH' => 'High', 'STANDARD' => 'Standard','LOW' => 'Low'];

                            echo $form->field($model1, 'priority')
                            ->dropDownList($priority ,['id' => 'title11', 'prompt' => 'Select Priority','required'=>true,'class' => 'form-control name-change-priority'])->label(); ?>
                      </div>
                      <div class=" col-md-3">
                        <?php echo $form->field($model1, 'item_desc')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Action Item Descriptions','class' => 'form-control custom-val name-change-item-desc','required'=>true]) ?>                     
                    </div>
                      <div class="col-md-2"> 
                          <?php 
                          $current_status = ['OPEN' => 'Open', 'ASSIGNED' => 'Assigned','INPROGRESS' => 'In Progress','ESCALATED' => 'Escalated' , 'CLOSED' => 'Closed'];

                            echo $form->field($model1, 'current_status')
                            ->dropDownList($current_status ,['id' => 'title111', 'prompt' => 'Select Current Status','required'=>true,'class' => 'form-control name-change-current-status'])->label(); ?>
                      </div> 
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'action_item_owner')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Item Origin','class' => 'form-control custom-val name-change-item-owner','required'=>true]) ?>
                      </div>  
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'item_origin')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Item Origin','class' => 'form-control custom-val name-change-item-origin','required'=>true]) ?>
                      </div> 
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'due_date')->input('date',['required'=>true,'class' => 'form-control custom-val name-change-due-date']) ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php 
                          $completed_or_received = ['COMPLETED' => 'Completed', 'RECEIVED' => 'Received'];

                            echo $form->field($model1, 'completed_or_received')
                            ->dropDownList($completed_or_received ,['id' => 'title111', 'prompt' => 'Select Priority','required'=>true,'class' => 'form-control name-change-completed-or-received'])->label(); ?>
                      </div>
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                    </div>
                <?php $i++;    } 
                }
                else
                {
                  $model1 = new ActionItemListForm(); 
                ?>
                <div class="row add">  
                  <div class="col-md-2">                   
                       <?php echo $form->field($model1, 'item_no[]')->textInput(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Item No','class' => 'form-control custom-val name-change-item-no','required'=>true]) ?> 
                      </div>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'date_of_origin[]')->input('date',['required'=>true,]) ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php 
                          $priority = ['HIGH' => 'High', 'STANDARD' => 'Standard','LOW' => 'Low'];

                            echo $form->field($model1, 'priority[]')
                            ->dropDownList($priority ,['id' => 'title11', 'prompt' => 'Select Priority','required'=>true,'class' => 'form-control name-change-priority'])->label(); ?>
                      </div>
                      <div class=" col-md-3">
                        <?php echo $form->field($model1, 'item_desc[]')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Action Item Descriptions','class' => 'form-control custom-val name-change-item-desc','required'=>true]) ?>                     
                    </div>
                      <div class="col-md-2"> 
                          <?php 
                          $current_status = ['OPEN' => 'Open', 'ASSIGNED' => 'Assigned','INPROGRESS' => 'In Progress','ESCALATED' => 'Escalated' , 'CLOSED' => 'Closed'];

                            echo $form->field($model1, 'current_status[]')
                            ->dropDownList($current_status ,['id' => 'title111', 'prompt' => 'Select Current Status','required'=>true,'class' => 'form-control name-change-current-status'])->label(); ?>
                      </div>  
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'action_item_owner[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Item Origin','class' => 'form-control custom-val name-change-item-owner','required'=>true]) ?>
                      </div>
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'item_origin[]')->textInput(['autofocus' => true, 'maxlength' => 150, 'placeholder' => 'Enter Item Origin','class' => 'form-control custom-val name-change-item-origin','required'=>true]) ?>
                      </div> 
                      <div class="col-md-3"> 
                          <?php echo $form->field($model1, 'due_date[]')->input('date',['required'=>true,]) ?>
                      </div>
                      <div class="col-md-2"> 
                          <?php 
                          $completed_or_received = ['COMPLETED' => 'Completed', 'RECEIVED' => 'Received'];

                            echo $form->field($model1, 'completed_or_received[]')
                            ->dropDownList($completed_or_received ,['id' => 'title111', 'prompt' => 'Select Priority','required'=>true,'class' => 'form-control name-change-completed-or-received'])->label(); ?>
                      </div>
                      <div class="col-md-1" style="    margin-top: 26px;">
                        
                          <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 

                          </div>
                <?php  
                }
              ?>    
            </div>
            <div class="a" id="l"></div>
            <a style="cursor: pointer; margin-right: 36px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>           
          
          <div class="form-actions">
             <a href="<?php echo yii\helpers\Url::to(['action-item/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
            <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                } else {
                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                }
            ?>
           
          </div>
        <?php ActiveForm::end(); ?>
      </div>
    </div>
  </div>
</div>
</section>
<?php
$this->registerJs("
  $('.name-change-item-no').attr('name', 'ActionItemListForm[item_no][]');
  $('.name-change-date-of-origin').attr('name', 'ActionItemListForm[date_of_origin][]');
  $('.name-change-current-status').attr('name', 'ActionItemListForm[current_status][]');
  $('.name-change-item-owner').attr('name', 'ActionItemListForm[action_item_owner][]');
  $('.name-change-item-origin').attr('name', 'ActionItemListForm[item_origin][]');
  $('.name-change-due-date').attr('name', 'ActionItemListForm[due_date][]');
  $('.name-change-priority').attr('name', 'ActionItemListForm[priority][]');
  $('.name-change-item-desc').attr('name', 'ActionItemListForm[item_desc][]');
  $('.name-change-completed-or-received').attr('name', 'ActionItemListForm[completed_or_received][]');
        $('.addd').click(function(){
          $('.add').clone(true).addClass('xcas').removeClass('add').appendTo('#l');
          $('.xcas').find(':input').val('');
        });   
        $('.remove_daterow').click(function(){      
          $(this).closest('.xcas').remove();
        });   
           
  ");
?>