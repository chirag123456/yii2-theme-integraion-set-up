<?php
use yii\helpers\Html;
use yii\widgets\DetailView; 
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Action Item </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("action-item/index") ?>" >Action Item</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Action Item Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form"> 
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [
                                [
                                    'attribute' => 'project_id',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'value' => function ($model) {
                                            return $model->project->project_name;
                                    },
                                ],
                                [
                                    'attribute' => 'meeting_date',
                                    'headerOptions' => ['title' => 'sort by'],
                                    
                                ],
                                [
                                    'attribute' => 'meeting_location',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'next_meeting_details',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'facilitators',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'invitees',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'participants',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                                [
                                    'attribute' => 'objective',
                                    'headerOptions' => ['title' => 'sort by'],
                                ],
                            ],
                        ]);
                        ?>
                    </div>  
                           
                </div>        
            </div>
        </div>
    </div> 
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Topics of Discussion Details</h3> 
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                   <div class="order-form">
                    <table class="table">
                        <thead>
                          <tr>
                            <th>Item No</th>
                            <th>Date Of Origin</th>
                            <th>Priority</th>
                            <th>Item Desc</th>
                            <th>Current Status</th>
                            <th>Action Item Owner</th>
                            <th>Item Origin</th>
                            <th>Due Date</th>
                            <th>Completed Or Received</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 

                            if(isset($model1) && $model1 != '')
                            {
                                foreach ($model1 as  $value) {                                   
                                ?>
                                    <tr>
                                        <td><?php echo $value->item_no; ?></td>
                                        <td><?php echo $value->date_of_origin ; ?></td>
                                        <td><?= $value->priority; ?></td>
                                        <td><?= $value->item_desc; ?></td>
                                        <td><?= $value->current_status; ?></td>
                                        <td><?= $value->action_item_owner; ?></td>
                                        <td><?= $value->item_origin; ?></td>
                                        <td><?= $value->due_date; ?></td>
                                        <td><?= $value->completed_or_received; ?></td>
                                    </tr>
                                <?php    
                                }
                            }
                        ?>
                        </tbody>
                    </table>   
                    </div>     
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>