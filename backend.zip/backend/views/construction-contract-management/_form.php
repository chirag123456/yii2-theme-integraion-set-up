<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\components\CommonFunctions;

//print_r($model);die;
/* @var $this yii\web\View */
/* @var $model common\models\ContractorManagement */
/* @var $form yii\widgets\ActiveForm */
?>

<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Construction Contract </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("construction-contract-management/index") ?>" >Construction Contract</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Construction Contract' : 'Add Construction Contract'; ?></li>
    </ol>
</section> 

<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">
                     
                    <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Construction Contract' : 'Add Construction Contract'; ?></h4> 

                    <!-- <a href="<?php echo yii\helpers\Url::to(['construction-contract-management/index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a> -->

                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="card-body user-form">  
                    <?php
                        $form = ActiveForm::begin([
                                    'id' => 'contractor-management-form',
                                    'enableAjaxValidation' => false,
                                    'enableClientValidation' => true,
                                    'options' => ['enctype' => 'multipart/form-data']
                        ]);
                    ?>
                    
                    <div class="form-body">
                        <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Construction Information</h3>
                        <hr>
                        <div class="row p-t-20">
                            <div class=" col-md-4">
                              <div class="form-group">
                                <?=
                                    $form->field($model, 'project_id')->widget(Select2::classname(), [
                                        'data' => \yii\helpers\ArrayHelper::map(\common\models\project\Project::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', 'project_name'),
                                        'options' => ['placeholder' => 'Select Project'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                                    ])->label();
                                ?>
                              </div>
                            </div>
                            <div class=" col-md-4">
                              <div class="form-group">
                                <?php 
                                  $role = CommonFunctions::getConfigureValueByKey('GENERAL_CONTRACTOR_USER_ID');
                                ?>
                                <?=
                                    $form->field($model, 'contractor_id')->widget(Select2::classname(), [
                                        'data' => \yii\helpers\ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role'=> $role])->all(), 'id',    function($model) {
                                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                                            }),
                                        'options' => ['placeholder' => 'Select Contractor', 'onchange' => '
                                                        $.post( "' . Yii::$app->urlManager->createUrl('construction-contract-management/set-contractor?id=') . '"+$(this).val(), function( data ) {
                                                          $("#title1").html( data );
                                                        });
                                                    '],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                                    ])->label(); 
                                ?>
                              </div>
                            </div>
                            <div class=" col-md-4">
                              <div class="form-group">
                                <?php 
                                  $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                                ?>
                                <?=
                                    $form->field($model, 'sub_contractor_id')->widget(Select2::classname(), [
                                        'data' => ArrayHelper::map(\common\models\user\User::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'role' => $role])->all(), 'id', function($model) {
                                return $model['first_name'].' '.$model['last_name'].' - '.$model['email'];
                            }),
                                        'options' => ['placeholder' => 'Select Sub Contractor','id' => 'title1'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                                    ])->label();
                                ?>
                              </div>
                            </div>
                        </div>
                        <div class="row p-t-20">        
                            <div class=" col-md-4">
                              <div class="form-group">
                                <?= $form->field($model, 'sub_contractor_price')->textInput(['maxlength' => 6, 'placeholder' => 'Enter Subcontactor Price','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                              </div>
                            </div>
                            <div class=" col-md-4">
                              <div class="form-group">
                                <?= $form->field($model, 'construction_contract_cost')->textInput(['maxlength' => 6, 'placeholder' => 'Enter Construction Contact Price','onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                              </div>
                            </div>
                            <div class=" col-md-4">
                              <div class="form-group">
                                <?=
                                    $form->field($model, 'client_id')->widget(Select2::classname(), [
                                        'data' => \yii\helpers\ArrayHelper::map(\common\models\client\Client::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->all(), 'id', function($model) {
                                return $model['client_name'].' - '.$model['client_email'];
                            }),
                                        'options' => ['placeholder' => 'Select Client'],
                                        'pluginOptions' => [
                                            'allowClear' => true
                                        ],
                                    ])->label(); 
                                ?>
                              </div>
                            </div>
                        </div>
                        
                        <div class="row p-t-20">
                            <div class=" col-md-6">
                              <div class="form-group">
                                <?= $form->field($model, 'construction_estimated_days')->textInput(['maxlength' => 4, 'placeholder' => 'Enter Construction Estimated Days' ,'onKeyPress'=>'return fun_AllowOnlyAmountAndDot(this.id);']) ?>
                              </div>
                            </div>
                            <div class=" col-md-6">
                              <div class="form-group">
                                <?= $form->field($model, 'construction_address')->textArea(['maxlength' => 255, 'placeholder' => 'Enter Construction Address']) ?>
                              </div>
                            </div>
                        </div>

                        <div class="form-actions">
                          <a href="<?php echo yii\helpers\Url::to(['construction-contract-management/index']) ?>" style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
                                <?php
                                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                                        echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                                } else {
                                    echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img']);
                                }
                                ?>
                                
                        </div>
                    </div>
                    <?php ActiveForm::end(); ?>

                </div>
                
         </div>
    </div>
</div>
</section>
<script type="text/javascript">
 function fun_AllowOnlyAmountAndDot(txt)
        {
            if(event.keyCode > 47 && event.keyCode < 58 || event.keyCode == 46)
            {
               var txtbx=document.getElementById(txt);
               var amount = document.getElementById(txt).value;
               var present=0;
               var count=0;

               if(amount.indexOf(".",present)||amount.indexOf(".",present+1));
               {
              // alert('0');
               }

              /*if(amount.length==2)
              {
                if(event.keyCode != 46)
                return false;
              }*/
               do
               {
               present=amount.indexOf(".",present);
               if(present!=-1)
                {
                 count++;
                 present++;
                 }
               }
               while(present!=-1);
               if(present==-1 && amount.length==0 && event.keyCode == 46)
               {
                    event.keyCode=0;
                    //alert("Wrong position of decimal point not  allowed !!");
                    return false;
               }

               if(count>=1 && event.keyCode == 46)
               {

                    event.keyCode=0;
                    //alert("Only one decimal point is allowed !!");
                    return false;
               }
               if(count==1)
               {
                var lastdigits=amount.substring(amount.indexOf(".")+1,amount.length);
                if(lastdigits.length>=2)
                            {
                              //alert("Two decimal places only allowed");
                              event.keyCode=0;
                              return false;
                              }
               }
                    return true;
            }
            else
            {
                    event.keyCode=0;
                    //alert("Only Numbers with dot allowed !!");
                    return false;
            }

        }

    </script>