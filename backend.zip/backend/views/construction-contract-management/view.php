<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?>

<div class="order-create">
<section class="content-header">
    <h1> Construction Contract </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Dashboard</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("project/index") ?>" >Construction Contract</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content">
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Construction Contract Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['index']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [

                                
                                [
                                    'attribute' => 'project_id',
                                    'label' => 'Project Name',
                                    'format' => 'raw',
                                    'value' => function($model)
                                    {
                                        return $model->project->project_name;
                                    }
                                    
                                ],                                
                                [
                                    'attribute' => 'client_id',
                                    'label' => 'Client Name',
                                    'format' => 'raw',
                                    'value' => function($model)
                                    {
                                        return $model->client->client_name;
                                    }
                                    
                                ],
                                [
                                    'attribute' => 'construction_contract_cost',
                                    'label' => 'Construction Contract Cost',
                                    'format' => 'raw',
                                    
                                ],
                                [
                                    'attribute' => 'construction_estimated_days',
                                    'label' => 'Construction Estimated Days',
                                    'format' => 'raw',
                                ],
                                [
                                    'attribute' => 'contractor_id',
                                    'label' => 'General Contractor',
                                    'format' => 'raw',
                                    'value' => function($model)
                                    {
                                        return $model->contractor->first_name . ' '. $model->contractor->last_name. '-'. $model->contractor->email;
                                    }
                                    
                                ],
                                [
                                    'attribute' => 'sub_contractor_id',
                                    'label' => 'Sub Contractor Name',
                                    'format' => 'raw',
                                    'value' => function($model)
                                    {
                                        return $model->subcontractor->first_name.' '.$model->contractor->last_name.'-'.$model->contractor->email;
                                    }
                                    
                                ],
                                [
                                    'attribute' => 'sub_contractor_price',
                                    'label' => 'Sub Contractor Price',
                                    'format' => 'raw',
                                ],
                                [
                                    'attribute' => 'construction_address',
                                    'label' => 'Construction Address',
                                    'format' => 'raw',
                                ],
                                 
                                ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
    
</section> 
</div>

<?php 

$this->registerCss('.detail-view{text-align:left;}')

?>