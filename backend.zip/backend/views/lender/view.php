<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;

?> 
<style type="text/css">
    table th a, table th, footer a {
    color: #000 !important;
    font-size: 14px; 
    font-weight: 600;
    letter-spacing: 1px;
}
</style>
<div class="order-create">
<section class="content-header">
    <h1> Lender </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("landlord/index") ?>" >Lender</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content"> 
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Lender Details</h3> 
                    <a href="<?php echo ($_SERVER['HTTP_REFERER']); ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [                                
                                [
                                    'attribute' => 'lender_email', 
                                ],
                                [
                                    'attribute' => 'lender_phone',
                                ],
                                [
                                    'attribute' => 'lender_or_bank_contact_person',
                                ],
                                [
                                    'attribute' => 'lender_address',
                                ],
                                [
                                    'attribute' => 'lender_state_id',
                                    'value' => $model->state->state_name,
                                    
                                ],
                                [
                                    'attribute' => 'lender_city_id',
                                    'value' => $model->city->name,
                                    
                                ],
                                [
                                    'attribute' => 'lender_zipcode',
                                ],
                                [
                                    'attribute' => 'bank_require_special_documentation_for_billing_project_closeout',
                                    'label' => 'Bank Require Special Documentation For Billing Project Closeout ?',
                                    'value' => isset($model->bank_require_special_documentation_for_billing_project_closeout) && $model->bank_require_special_documentation_for_billing_project_closeout == 'Y' ? 'Yes' : 'No',
                                ],
                                [
                                    'attribute' => 'if_special_documentation_required_if_yes_list',
                                    'value' => isset($model->lender_special_documentation_list_requirements) ? $model->lender_special_documentation_list_requirements : 'N/A',
                                ],
                            ],
                        ]);
                        ?>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
</section> 
</div>
<?php 
$this->registerJs("
     var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
    ");

$this->registerJs(\yii\web\View::POS_BEGIN);

$this->registerCssFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.css');
$this->registerCssFile('http://www.jqueryscript.net/css/jquerysctipttop.css');

$this->registerJsFile(Yii::$app->homeUrl . 'resource/drivers/views.js', ['depends' => 'yii\web\JqueryAsset']);

$this->registerCss('.detail-view{text-align:left;}')

?>