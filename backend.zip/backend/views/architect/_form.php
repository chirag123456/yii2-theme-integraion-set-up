<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\components\CommonFunctions;

//$this->title = 'Architect | ' . isset($_GET['id']) ? 'Update' : 'Add';
//print_r( $_SERVER['HTTP_REFERER']); exit();

?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Architect </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("architect/index") ?>" >Architect</a></li>
        <li class="active"><?php echo isset($_GET['id']) ? 'Update Architect' : 'Add Architect'; ?></li>
    </ol>
</section>
<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">
                     
                    <h4 class="m-b-0 text-white"><?php echo isset($_GET['id']) ? 'Update Architect' : 'Add Architect'; ?></h4>
                    
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="card-body user-form">                    
                    <?php
                    $form = ActiveForm::begin([
                                'id' => 'user-form',
                                'enableAjaxValidation' => true,
                                'enableClientValidation' => true,
                                'options' => ['enctype' => 'multipart/form-data']
                    ]);
                    ?>
                    <div class="form-body">
                        <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Architect Information</h3>
                        <hr>
                        <div class="row p-t-20">
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php echo $form->field($model, 'first_name')->textInput(['autofocus' => true, 'maxlength' => 30, 'placeholder' => 'Enter First Name']) ?>
                            </div>
                          </div>
                          <!--/span-->
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php echo $form->field($model, 'last_name')->textInput(['autofocus' => true, 'maxlength' => 30, 'placeholder' => 'Enter Last Name']) ?>
                            </div>
                          </div>
                          <!--/span--> 
                        </div>
                        <div class="row p-t-20">
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php 
                                if(isset($_GET['id'])){
                                echo $form->field($model, 'contact_number')->textInput(['maxlength' => 12, 'id' => 'phone', 'placeholder' => 'Enter Contact Number','disabled'=>true]);
                                }else{
                                echo $form->field($model, 'contact_number')->textInput(['maxlength' => 12, 'id' => 'phone', 'placeholder' => 'Enter Contact Number']);    
                                }
                                 ?>
                            </div>
                          </div>
                          <!--/span-->
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php 
                                if(isset($_GET['id'])){
                                echo $form->field($model, 'email')->textInput(['maxlength' => 100, 'id' => 'email', 'placeholder' => 'Enter Email','disabled'=>true]);
                                }else{
                                echo  $form->field($model, 'email')->textInput(['maxlength' => 100, 'id' => 'email', 'placeholder' => 'Enter Email']) ;  
                                }
                                 ?>
                            </div>
                          </div>
                          <!--/span-->
                        </div>
                        <?php if (!isset($_GET['id']) && empty($_GET['id'])) { ?>
                        <div class="row p-t-20">
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php echo $form->field($model, 'password')->passwordInput(['maxlength' => 100, 'placeholder' => 'Enter Password']) ?>
                            </div>
                          </div>
                          <!--/span-->
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php echo $form->field($model, 'confirm_password')->passwordInput(['maxlength' => 100, 'placeholder' => 'Enter Confirm Password']) ?>
                            </div>
                          </div>
                          <!--/span-->
                        </div>
                        <?php } ?>
                        <div class="row p-t-20">
                          <div class="col-md-6">
                            <div class="form-group <?= $subcontractor ?>">
                                <?php
                                  if(!isset($_GET['id']) && empty($_GET['id']))
                                  {
                                    if(isset($subcontractor) && !empty($subcontractor) && $subcontractor == 1)
                                    {
                                      $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
                                      $model->role = $role;
                                      echo $form->field($model, 'role')->widget(
                                                        Select2::classname(), [
                                                'data' => ArrayHelper::map(\common\models\userrole\UserAccess::find()->where(['id' => $role])
                                                ->asArray()->all(), 'id', 'name'),
                                                'options' => ['placeholder' => 'Select Role','disabled' => 'disabled'],
                                        ])->label();  
                                    }
                                    elseif (isset($subcontractor) && !empty($subcontractor) && $subcontractor == 2) {

                                      $role = CommonFunctions::getConfigureValueByKey('ARCHITECTURE_USER_ID');
                                      $model->role = $role;
                                      echo $form->field($model, 'role')->widget(
                                                        Select2::classname(), [
                                                'data' => ArrayHelper::map(\common\models\userrole\UserAccess::find()->where(['id' => $role])
                                                ->asArray()->all(), 'id', 'name'),
                                                'options' => ['placeholder' => 'Select Role','disabled' => 'disabled'],
                                        ])->label();
                                    }
                                    else
                                    {
                                      echo $form->field($model, 'role')->widget(
                                                        Select2::classname(), [
                                                'data' => ArrayHelper::map(\common\models\userrole\UserAccess::find()
                                                ->asArray()->all(), 'id', 'name'),
                                                'options' => ['placeholder' => 'Select Role'],
                                        ])->label(); 
                                    }
                                  }
                                  else
                                  {
                                    echo $form->field($model, 'role')->widget(
                                                        Select2::classname(), [
                                                'data' => ArrayHelper::map(\common\models\userrole\UserAccess::find()
                                                ->asArray()->all(), 'id', 'name'),
                                                'options' => ['placeholder' => 'Select Role','disabled' => 'disabled'],
                                        ])->label(); 
                                  }
                                ?>
                            </div>
                          </div>
                          <!--/span-->
                          <div class="col-md-6">
                            <div class="form-group">
                                <label class="lbl-usr-img">Select User Image</label>
                              <div class="cropme" id="user_image" style="     margin-top: 30px; width: 200px; height: 200px;" data-image="true"></div>
                                    <input type="hidden" name="UserForm[user_image]" id="set_user_img">
                                    <input type="hidden" name="imageRemove" id="imgRemove" value="0">

                                    <button class="img-usr-btn" type="button" id="remove" class="btn btn-default"> 
                                        <span class="fa fa-remove"></span>
                                    </button>
                            </div>
                          </div>
                          <div  style="display:none; color: red;margin-top: 5px; margin-left: 575px; margin-bottom: 10px;" 
                          class="image-error">Image cannot be blank.</div>
                          <!--/span-->
                        </div>
                        <h3 class="card-title"><i class="fa fa-map-marker" aria-hidden="true"></i> Address Information</h3>
                        <hr>
                        <div class="row p-t-20">
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php                                     
                                  echo $form->field($model, 'state_id')->widget(
                                   Select2::classname(), [
                                  'data' => ArrayHelper::map(\common\models\state\State::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'state_name'),
                                  'options' => ['placeholder' => 'Select State','onchange' => '
                                      $.post( "' . Yii::$app->urlManager->createUrl('city/set-city?id=') . '"+$(this).val(), function( data ) {
                                      $("#title").html( data );
                                      });
                                  '],
                                  'pluginOptions' => [                   
                                          'initialize' => true,
                                  ],
                                   ])->label('State'); 
                              ?>
                            </div>
                          </div>
                          <!--/span-->
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php 
                                  echo $form->field($model, 'city_id')->widget(
                                      Select2::classname(), [
                                  'data' => ArrayHelper::map(\common\models\city\City::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED,'state_id' => $model->state_id])->asArray()->all(), 'id', 'name'),
                                 'options' => ['placeholder' => 'Please Select state','id' => 'title'],
                                 'pluginOptions' => [                   
                                          'initialize' => true,
                                  ],
                                  ])->label('City');
                              ?>
                            </div>
                          </div>
                          <!--/span-->
                          
                        </div>
                        <div class="row p-t-20">
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php echo $form->field($model, 'address')->textArea(['autofocus' => true, 'maxlength' => 300, 'placeholder' => 'Enter Address']) ?>
                            </div>
                          </div>
                          <!--/span-->
                          <div class="col-md-6">
                            <div class="form-group">
                              <?php echo $form->field($model, 'zipcode')->textInput(['autofocus' => true, 'maxlength' => 8, 'placeholder' => 'Enter Zipcode']) ?>
                            </div>
                          </div>
                          <!--/span-->
                        </div>                            
                    </div>
                    <div class="form-actions">
                         <a href="<?php echo \Yii::$app->urlManager->createUrl("architect/index") ?>"  style = "margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
                        <?php
                            if (isset($_GET['id']) && !empty($_GET['id'])) {
                                echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary', 'id' => 'img']);
                            } else {
                                echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary', 'id' => 'img',]);
                            }
                        ?>                       
                    </div>                        
                        <?php ActiveForm::end(); ?>                                            
                </div>        
            </div>
        </div>
    </div> 
</section> 
<?php

if (isset($model->user_image) && !empty($model->user_image)) {
   
     $mediaFileUrl2 = Yii::$app->request->hostInfo . USER_PROFILE_PATH. $model->user_image;

    $this->registerJs("
        $(document).ready(function() {
            var user_image_url = 'url($mediaFileUrl2)';
            $('#user_image').css('background-image', user_image_url);
        });
    ");
}

$default_img = Yii::$app->urlManager->createAbsoluteUrl(USER_PROFILE_PATH. "default_image.png");
$this->registerJs("

   $('.cropme').simpleCropper();  
   
    $('#img').click(function() {
       var user_img_src =  $('#user_image').children().attr('src');
       $('#set_user_img').val(user_img_src);
    });
 ");

if (!isset($_GET['id']) && empty($_GET['id'])) {

    $this->registerJs("
        $('.ok').click(function() {      
            $('#user_image').css('border', '1px solid green');
            $('.image-label').css('color', '#00a65a');
             $('#user_image').css('background-image', 'none');
            $('.image-error').hide();
        });
        $('#user-form').on('submit', function() {        
            if( $('#user_image img').length == 0  || $('#imgRemove').val() == 1  ) {
                 $('#user_image').css('border', '1px solid red');
                 $('.image-label').css('color', '#dd4b39');
                 $('.image-error').show();
                  return false;
            } else {
                $('#user_image').css('border', '1px solid green');
                $('.image-label').css('color', '#00a65a');
                $('.image-error').hide();
            }
        });
        $('#remove').click(function() {
            $('#user_image img').remove();
            $('#user_image').css('background-image', 'url($default_img)');
        });
    ");
} else {
    $this->registerJs("
        $('#remove').click(function() {
            $('#user_image img').remove();
            $('#user_image').css('background-image', 'url($default_img)');
            $('#imgRemove').val(1);
            $('#user_image').attr('data-image', 'false');
        });
        $('.ok').click(function() {
            $('#user_image').css('border', '1px solid green');
            $('.image-label').css('color', '#00a65a');
            $('#user_image').css('background-image', 'none'); 
            $('.image-error').hide();
        });
        $('#user-form').on('submit', function() {
            if($('#user_image img').length == 0) {
                if( $('#user_image').data('image') == 'true'  || $('#imgRemove').val() == 0  ) {
                    var a = 2;
                } else {
                    $('#user_image').css('border', '1px solid red');
                    $('.image-label').css('color', '#dd4b39');
                    $('.image-error').show();
                    var a = 1;     
                } 
            } else {
                var a = 3;
            }
            if(a == 2 || a == 3) {
                return true;
            } else {
                return false;
            }

        });
         
    ");
}

if (isset($model->user_image) && !empty($model->user_image)) {
    $mediaFileUrl = Yii::$app->request->hostInfo . '/media/uploads/user_profile/' . $model->user_image;

    $this->registerJs("
        $(document).ready(function() {
            $( '#email' ).prop( 'disabled', true );
            $( '#phone' ).prop( 'disabled', true );
            var user_image_url = 'url($mediaFileUrl)';
            $('#user_image').css('background-image', user_image_url);
        });
    ");
}


?>