<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>

<section class="content-header">
  <h1>
    Item Work
</h1>
<ol class="breadcrumb">
    <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
    <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("item-work/index") ?>" >Item Work</a></li>
    <li class="active">Add Item Work</li>

</ol>
</section>
<section class="content">
    <div class="row new-classic-form">
        <div class="col-lg-12">
            <!-- general form elements -->
            <div class="card">
                <div class="card-header bg-info">

                    <h4 class="m-b-0 text-white">Add Item Work</h4>
                    <!-- <a href="<?= yii\helpers\Url::to(['country/index'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a> -->
                </div>
                <div class="card-body itemwork-form">         
                    <?php
                    $form = ActiveForm::begin([
                        'id' => 'itemwork-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                    ]);
                    ?>
                    <div class="form-body">
                        <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Item Work Information</h3>
                        <hr>
                        <div class="row p-t-20">
                            <div class="form-group">
                                <div class="col-md-6">
                                    <?= $form->field($model, 'name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Item Work Name']) ?>
                                </div>
                                <div class="col-md-6">
                                    <?= $form->field($model, 'cost_code')->textInput(['placeholder' => 'Enter Cost Code']) ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-actions">
                        
                                    <?php echo Html::a('<i class="fa fa-close"></i> Cancel', ['item-work/index'], ['class' => 'btn btn-default cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
                                    <?php
                                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                                        echo Html::submitButton('<i class="fa fa-check"></i> Update', ['class' => 'btn btn-primary']);
                                    } else {
                                        echo Html::submitButton('<i class="fa fa-check"></i> Add', ['class' => 'btn btn-primary']);
                                    }
                                    ?>
                                
                        </div>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>
            </div>
        </div>
    </div>
</section>