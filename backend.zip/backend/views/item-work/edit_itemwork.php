<?php
use yii\helpers\Html;
?>

                  <div class="item-work-create">
                        <?= $this->render('_edit_form', [
                            'model' => $model,
                        ]) ?>
                  </div>
            