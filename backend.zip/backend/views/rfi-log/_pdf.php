<?php
use yii\helpers\Html;

?>

<div class="pdf-dealer container">
    <table class="table table-bordered" style="font-family: sans-serif;
    border: 0.1mm solid;
    border-collapse: collapse;">
        <thead>
            <tr>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Project</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Project Number</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Project Location</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Client</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Architect</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Sub Contractor</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Rfi Code</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Request For Information</th>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Response</td>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Responded By</td>
                <th style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;">Rfi Date</td>
            </tr>
        </thead>
        <tbody>
            <?php 
                if(isset($model) && !empty($model))
                {
                    foreach ($model as $value) {
            ?>
                <tr>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->project->project_name ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->project->project_number ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->project->project_physical_address. ' '.$value->project->city->name.' '.$value->project->state->state_name ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->client->client_name.' '.$value->client->client_email ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= isset($value->architect->first_name) && !empty($value->architect->first_name) ? $value->architect->first_name : ''.' '.isset($value->architect->last_name) && !empty($value->architect->last_name) ? $value->architect->last_name : ''.' '.isset($value->architect->email) && !empty($value->architect->email) ? $value->architect->email : '' ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= isset($value->subContractor->first_name) && !empty($value->subContractor->first_name) ? $value->subContractor->first_name : ''.' '.isset($value->subContractor->last_name) && !empty($value->subContractor->last_name) ? $value->subContractor->last_name : ''.' '.$value->subContractor->email ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->rfi_code ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->request_for_information ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= isset($value->response) && !empty($value->response) ? $value->response : '' ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->responded_by ?></td>
                <td style="padding: 3mm;border: 0.1mm solid;vertical-align: middle;"><?= $value->rfi_date ?></td>
            </tr> 
            <?php
                    }
                }
                else
                {
            ?>
                <tr>
                    <p> No Data Available</p>     
                </tr>
            <?php        
                }
            ?>
            
        </tbody>
    </table>
</div>