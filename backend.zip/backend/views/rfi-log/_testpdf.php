<?php
use yii\helpers\Html;

?>

<div class="pdf-dealer container">
    <section class="content"> 
        <div class="row new-classic-form">
          <div class="col-lg-12">
            <div class="card">
            <div class="card-body project-submittal-form">
                <form id="submittal-form" action="/backend/submittal/add" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="_csrf" value="wSdtUTvhIU4FvXez2fbasUNqg4daJGBhou-Jl1Xqex23CiBlbIVTBm78H8SBhZz1LBjT4hQVMxXuouLFIrk8LQ==">          <div class="form-body">
                        <h3 class="card-title"><i class="fa fa-user" aria-hidden="true"></i> Submittal Information </h3>
                        <hr>
                        <div class="row p-t-20">
                          <div class="col-md-4">
                            <div class="form-group">
                              <div class="form-group field-submittalform-date required">
                                <label class="control-label" for="submittalform-date">Date</label>
                                <label class="control-label" for="submittalform-date">Date</label>
                              </div>                
                            </div>
                        </div>
                        <!--/span-->
                        <div class="col-md-4">
                            <div class="form-group">
                              <div class="form-group field-submittalform-to_user_id required">
                                <label class="control-label" for="submittalform-to_user_id">To User</label>
                                <label class="control-label" for="submittalform-to_user_id">To User</label>
                              </div>                
                            </div> 
                        </div> 
                  <!--/span-->

                  <div class="col-md-4">
                    <div class="form-group">
                        <div class="form-group field-submittalform-project_id required">
                            <label class="control-label" for="submittalform-project_id">Project</label>
                            <label class="control-label" for="submittalform-project_id">Project</label>
                        </div>                
                    </div>
                  </div> 
                    <!--/span-->
                </div>
                <div class="row p-t-20">
                  <div class="col-md-4">
                    <div class="form-group">
                      <div class="form-group field-submittalform-re required">
                        <label class="control-label" for="submittalform-re">Regarding</label>
                        <label class="control-label" for="submittalform-re">Regarding</label>
                        
                      </div>
                  </div>
                </div>
                <!--/span-->
                <div class="col-md-4">
                    <div class="form-group">
                      <div class="form-group field-submittalform-phone required">
                        <label class="control-label" for="submittalform-phone">Phone</label>
                        <label class="control-label" for="submittalform-phone">Phone</label>
                      </div>                
                  </div> 
                </div> 
                <!--/span-->

                <div class="col-md-4">
                    <div class="form-group">
                        <div class="form-group field-submittalform-email required">
                            <label class="control-label" for="submittalform-email">Email</label>
                            <label class="control-label" for="submittalform-email">Email</label>
                        </div>                
                    </div>
                </div> 
                    <!--/span-->
                </div>
                <div class="row p-t-20">
                  <div class="col-md-6">
                    <div class="form-group">
                      <div class="form-group field-submittalform-attention required">
                        <label class="control-label" for="submittalform-attention">Attention</label>
                        <label class="control-label" for="submittalform-attention">Attention</label>

                        
                    </div>                </div>
                </div>
                <!--/span-->
                <div class="col-md-6">
                    <div class="form-group">
                      <div class="form-group field-submittalform-review_date_of_resubmittal required">
                        <label class="control-label" for="submittalform-review_date_of_resubmittal">Review Date Of Resubmittal</label>
                        <div id="submittalform-review_date_of_resubmittal-kvdate" class="input-group  date"><span class="input-group-addon kv-date-picker" title="Select date"><i class="glyphicon glyphicon-calendar kv-dp-icon"></i></span><span class="input-group-addon kv-date-remove" title="Clear field"><i class="glyphicon glyphicon-remove kv-dp-icon"></i></span><input type="text" id="submittalform-review_date_of_resubmittal" class="form-control krajee-datepicker" name="SubmittalForm[review_date_of_resubmittal]" placeholder="Select Review Date of Resubmittal " autocomplete="off" aria-required="true" data-datepicker-source="submittalform-review_date_of_resubmittal-kvdate" data-datepicker-type="2" data-krajee-kvdatepicker="kvDatepicker_81be57fd"></div>

                        <div class="help-block"></div>
                    </div>                </div> 
                </div> 
            </div>
            <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> We are sending you following Items</h3>
            <hr>
            <div class="row p-t-20">
              <div class="col-md-6">
                <div class="form-group">
                    <div class="form-group field-submittalform-under_separate_cover required">
                        <label class="control-label" for="submittalform-under_separate_cover">Under Separate Cover</label>
                        <input type="text" id="submittalform-under_separate_cover" class="form-control" name="SubmittalForm[under_separate_cover]" maxlength="100" placeholder="Enter Under Seprate Cover" aria-required="true">

                        <div class="help-block"></div>
                    </div>                </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                      <div class="form-group field-submittalform-under_separate_cover_via required">
                        <label class="control-label" for="submittalform-under_separate_cover_via">Under Separate Cover Via</label>
                        <input type="text" id="submittalform-under_separate_cover_via" class="form-control" name="SubmittalForm[under_separate_cover_via]" maxlength="100" placeholder="Enter Under Seprate Cover Via" aria-required="true">

                        <div class="help-block"></div>
                    </div>                </div>
                </div>

            </div>
            <div class="row p-t-20">

              <!--/span-->
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-submittalform-shop_drawings">

                    <input type="hidden" name="SubmittalForm[shop_drawings]" value="0"><label><input type="checkbox" id="submittalform-shop_drawings" name="SubmittalForm[shop_drawings]" value="1"> Shop Drawings</label>

                    <div class="help-block"></div>
                </div>                </div> 
            </div> 
            <div class="col-md-3">
                <div class="form-group">
                    <div class="form-group field-submittalform-prints">

                        <input type="hidden" name="SubmittalForm[prints]" value="0"><label><input type="checkbox" id="submittalform-prints" name="SubmittalForm[prints]" value="1"> Prints</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                      <div class="form-group field-submittalform-plans">

                        <input type="hidden" name="SubmittalForm[plans]" value="0"><label><input type="checkbox" id="submittalform-plans" name="SubmittalForm[plans]" value="1"> Plans</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div>
                <!--/span-->
                <div class="col-md-3">
                    <div class="form-group">
                      <div class="form-group field-submittalform-samples">

                        <input type="hidden" name="SubmittalForm[samples]" value="0"><label><input type="checkbox" id="submittalform-samples" name="SubmittalForm[samples]" value="1"> Samples</label>

                        <div class="help-block"></div>
                    </div>                </div> 
                </div>
                <!--/span-->
            </div>
            
            <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group">
                    <div class="form-group field-submittalform-specifications">

                        <input type="hidden" name="SubmittalForm[specifications]" value="0"><label><input type="checkbox" id="submittalform-specifications" name="SubmittalForm[specifications]" value="1"> Specifications</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                      <div class="form-group field-submittalform-copy_of_letter">

                        <input type="hidden" name="SubmittalForm[copy_of_letter]" value="0"><label><input type="checkbox" id="submittalform-copy_of_letter" name="SubmittalForm[copy_of_letter]" value="1"> Copy Of Letter</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div>
                <!--/span-->
                <div class="col-md-3">
                    <div class="form-group">
                      <div class="form-group field-submittalform-change_order">

                        <input type="hidden" name="SubmittalForm[change_order]" value="0"><label><input type="checkbox" id="submittalform-change_order" name="SubmittalForm[change_order]" value="1"> Change Order</label>

                        <div class="help-block"></div>
                    </div>                </div> 
                </div> 
                <!--/span-->

                <div class="col-md-3">
                    <div class="form-group">
                        <div class="form-group field-submittalform-other">

                            <input type="hidden" name="SubmittalForm[other]" value="0"><label><input type="checkbox" id="submittalform-other" name="SubmittalForm[other]" value="1"> Other</label>

                            <div class="help-block"></div>
                        </div>                </div>
                    </div> 
                    <!--/span-->
                </div>
                <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> Item Work</h3>
                <hr>

                <div class="row add">  
                  <div class="col-md-2">                   
                      <div class="form-group field-submittalitemform-copies has-success">
                        <label class="control-label" for="submittalitemform-copies">Copies</label>
                        <input type="text" id="submittalitemform-copies" class="form-control custom-val name-change-copies" name="SubmittalItemForm[copies][]" maxlength="10" autofocus="" placeholder="Enter Copies" required="" aria-invalid="false">

                        <div class="help-block"></div>
                    </div>                  </div>
                    <div class="col-md-3">  
                        <div class="form-group field-submittalitemform-item_date">
                            <label class="control-label" for="submittalitemform-item_date">Date</label>
                            <input type="date" id="submittalitemform-item_date" class="form-control custom-val name-change-item_date" name="SubmittalItemForm[item_date][]" required="">

                            <div class="help-block"></div>
                        </div>                  </div>
                        <div class="col-md-2"> 
                          <div class="form-group field-submittalitemform-number">
                            <label class="control-label" for="submittalitemform-number">Number</label>
                            <input type="text" id="submittalitemform-number" class="form-control custom-val name-change-number" name="SubmittalItemForm[number][]" maxlength="10" autofocus="" placeholder="Enter Number" required="">

                            <div class="help-block"></div>
                        </div> 
                    </div>
                    <div class=" col-md-4">
                        <div class="form-group field-submittalitemform-description">
                            <label class="control-label" for="submittalitemform-description">Description</label>
                            <textarea id="submittalitemform-description" class="form-control name-change-description" name="SubmittalItemForm[description][]" maxlength="300" autofocus="" placeholder="Enter Description" required=""></textarea>

                            <div class="help-block"></div>
                        </div>                                               
                    </div>
                    
                    <div class="col-md-1" style="    margin-top: 26px;">                
                        <a href="JavaScript:void(0);" class="remove_daterow"><i style="font-size:30px" class="fa fa-trash aa"></i></a> 
                    </div>
                    
                </div>
                <div class="a" id="l"></div>
                <a style="cursor: pointer; margin-right: 35px;" class="addd pull-right"><i style="font-size:30px" class="fa fa-plus" aria-hidden="true"></i></a>

                <h3 class="box-title m-t-40"><i class="fa fa-info-circle" aria-hidden="true"></i> There are transmitted as below:</h3>
                <hr>
                <div class="row p-t-20">
                  <div class="col-md-4">
                    <div class="form-group">
                      <div class="form-group field-submittalform-for_approval">

                        <input type="hidden" name="SubmittalForm[for_approval]" value="0"><label><input type="checkbox" id="submittalform-for_approval" name="SubmittalForm[for_approval]" value="1"> For Approval</label>

                        <div class="help-block"></div>
                    </div>
                </div>
            </div>
            <!--/span-->
            <div class="col-md-4">
                <div class="form-group">
                  <div class="form-group field-submittalform-approved_as_submitted">

                    <input type="hidden" name="SubmittalForm[approved_as_submitted]" value="0"><label><input type="checkbox" id="submittalform-approved_as_submitted" name="SubmittalForm[approved_as_submitted]" value="1"> Approved As Submitted</label>

                    <div class="help-block"></div>
                </div>                </div> 
            </div> 
            <!--/span-->

            <div class="col-md-4">
                <div class="form-group">
                    <div class="form-group field-submittalform-resubmit">

                        <input type="hidden" name="SubmittalForm[resubmit]" value="0"><label><input type="checkbox" id="submittalform-resubmit" name="SubmittalForm[resubmit]" value="1"> Resubmit</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <div class="form-group field-submittalform-copies_for_approval">

                    <input type="hidden" name="SubmittalForm[copies_for_approval]" value="0"><label><input type="checkbox" id="submittalform-copies_for_approval" name="SubmittalForm[copies_for_approval]" value="1"> Copies For Approval</label>

                    <div class="help-block"></div>
                </div>                </div>
            </div>
            <!--/span-->
            <div class="col-md-4">
                <div class="form-group">
                  <div class="form-group field-submittalform-for_your_use">

                    <input type="hidden" name="SubmittalForm[for_your_use]" value="0"><label><input type="checkbox" id="submittalform-for_your_use" name="SubmittalForm[for_your_use]" value="1"> For Your Use</label>

                    <div class="help-block"></div>
                </div>                </div> 
            </div> 
            <!--/span-->

            <div class="col-md-4">
                <div class="form-group">
                    <div class="form-group field-submittalform-approved_as_noted">

                        <input type="hidden" name="SubmittalForm[approved_as_noted]" value="0"><label><input type="checkbox" id="submittalform-approved_as_noted" name="SubmittalForm[approved_as_noted]" value="1"> Approved As Noted</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-4">
                <div class="form-group">
                  <div class="form-group field-submittalform-submit">

                    <input type="hidden" name="SubmittalForm[submit]" value="0"><label><input type="checkbox" id="submittalform-submit" name="SubmittalForm[submit]" value="1"> Submit</label>

                    <div class="help-block"></div>
                </div>                </div>
            </div>
            <!--/span-->
            <div class="col-md-4">
                <div class="form-group">
                  <div class="form-group field-submittalform-copies_for_distribution">

                    <input type="hidden" name="SubmittalForm[copies_for_distribution]" value="0"><label><input type="checkbox" id="submittalform-copies_for_distribution" name="SubmittalForm[copies_for_distribution]" value="1"> Copies For Distribution</label>

                    <div class="help-block"></div>
                </div>                </div> 
            </div> 
            <!--/span-->

            <div class="col-md-4">
                <div class="form-group">
                    <div class="form-group field-submittalform-as_requested">

                        <input type="hidden" name="SubmittalForm[as_requested]" value="0"><label><input type="checkbox" id="submittalform-as_requested" name="SubmittalForm[as_requested]" value="1"> As Requested</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <!--/span-->
            </div>
            <div class="row p-t-20">
              <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-submittalform-returned_for_corrections">

                    <input type="hidden" name="SubmittalForm[returned_for_corrections]" value="0"><label><input type="checkbox" id="submittalform-returned_for_corrections" name="SubmittalForm[returned_for_corrections]" value="1"> Returned For Corrections</label>

                    <div class="help-block"></div>
                </div>                </div>
            </div>
            <!--/span-->
            <div class="col-md-3">
                <div class="form-group">
                  <div class="form-group field-submittalform-return">

                    <input type="hidden" name="SubmittalForm[return]" value="0"><label><input type="checkbox" id="submittalform-return" name="SubmittalForm[return]" value="1"> Return</label>

                    <div class="help-block"></div>
                </div>                </div> 
            </div> 
            <!--/span-->

            <div class="col-md-3">
                <div class="form-group">
                    <div class="form-group field-submittalform-corrected_prints">

                        <input type="hidden" name="SubmittalForm[corrected_prints]" value="0"><label><input type="checkbox" id="submittalform-corrected_prints" name="SubmittalForm[corrected_prints]" value="1"> Corrected Prints</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                      <div class="form-group field-submittalform-review_comment">

                        <input type="hidden" name="SubmittalForm[review_comment]" value="0"><label><input type="checkbox" id="submittalform-review_comment" name="SubmittalForm[review_comment]" value="1"> Review Comment</label>

                        <div class="help-block"></div>
                    </div>                </div>
                </div>
                <!--/span-->
            </div>
            <div class="row p-t-20">

              <!--/span-->
              <div class="col-md-6">
                <div class="form-group">
                  <div class="form-group field-submittalform-for_bids_due required">
                    <label class="control-label" for="submittalform-for_bids_due">For Bids Due</label>
                    <input type="text" id="submittalform-for_bids_due" class="form-control" name="SubmittalForm[for_bids_due]" maxlength="100" placeholder="Enter For Bids Due" aria-required="true">

                    <div class="help-block"></div>
                </div>                </div> 
            </div> 
            <!--/span-->

            <div class="col-md-6">
                <div class="form-group">
                    <div class="form-group field-submittalform-remarks required">
                        <label class="control-label" for="submittalform-remarks">Remarks</label>
                        <input type="text" id="submittalform-remarks" class="form-control" name="SubmittalForm[remarks]" maxlength="100" placeholder="Enter Remarks" aria-required="true">

                        <div class="help-block"></div>
                    </div>                </div>
                </div> 
                <!--/span-->
            </div>
            
            
        </div>
        <div class="form-actions">
           <a href="/backend/submittal/index" style="margin-right: 5px;" class="btn btn-default"><i class="fa fa-close"></i> Cancel</a>
           <button type="submit" id="img" class="btn btn-primary"><i class="fa fa-check"></i> Add</button>           
       </div>
   </form>      </div>
</div>
</div>

</div></section>
</div>