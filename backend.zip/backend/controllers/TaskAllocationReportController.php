<?php
namespace backend\controllers;

use Yii; 
use common\models\taskallocation\TaskAllocation;
use common\models\taskallocation\TaskAllocationSearch;
use common\models\taskallocation\TaskAllocationReportForm; 
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CustController;

/**
 * TaskAllocationController implements the CRUD actions for TaskAllocation model.
 */
class TaskAllocationReportController extends CustController
{
    
    /**
     * Lists all TaskAllocation models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TaskAllocationSearch();
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
        $model = new TaskAllocationReportForm();
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'model' => $model
        ]);
    }

    /**
     * Displays a single TaskAllocation model.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id) {

        $model = TaskAllocation::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['task-allocation-report/index']);
        }

        return $this->render('view', ['model' => $model]);
    }

    /**
     * Export CSV of Task Allocation Data
     * 
     */
    public function actionExportExcel() 
    {
        $id = 1;
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Project Data".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');

        $data_key1 = [

                        'Project Name',
                        'Task Name',
                        'Priority',
                        'User',
                        'User Type',
                        'Task Status',
                        'Start Date',
                        'Due Date',
                       // 'Description',
        ];

        fputcsv($output, $data_key1);

        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];
        $params = $_GET;
        
         if($_GET['due_date'] == '' && 
            $_GET['start_date'] == '' && 
            $_GET['user_id'] == '' && 
            $_GET['role_id'] == '' && 
            $_GET['project_id'] == '' && 
            $_GET['task_status'] == '' && 
            $_GET['priority'] == '')
        {
            
            $data = TaskAllocation::find()->where(['task_allocation.is_delete' => NOT_DELETED])->joinWith(['user'])->all();
            
        }
        else
        {
            $searchModel = new TaskAllocationSearch();
            $data = $searchModel->search2(Yii::$app->request->queryParams);    
        }
        
        
        foreach ($data as $value) {
           $data_val[$i][] =  $value->project->project_name;
           $data_val[$i][] =  $value->task_name;
           $data_val[$i][] =  $value->priority;
           $data_val[$i][] =  $value->user->first_name. ' '.$value->user->last_name.' '.$value->user->email;
           $data_val[$i][] =  $value->role->name;
           $data_val[$i][] =  $value->task_status;
           $data_val[$i][] =  $value->start_date;
           $data_val[$i][] =  $value->due_date;
           //$data_val[$i][] =  ($value->description);
           $i++;
        }  
        
        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }


    /** 
     * SetUser Action
     * @dependent drop down for user _form
     * $id is role id
     * @return
     */
    public function actionSetUser($id) {
        if (Yii::$app->request->isAjax) {

            $model = \common\models\user\User::find()->where(['role' => $id])->andWhere(['is_delete' => NOT_DELETED , 'is_active' => ACTIVE])->orderBy(['id'=>SORT_DESC])->all();
        
            $modelcount = count((array) $model);

            if ($modelcount > 0) {

                echo "<option>Please Select User</option>";
                foreach ($model as $action) {
                    
                    echo "<option value='" . $action->id . "'>" . $action->first_name . ' '. $action->last_name . '-'. $action->email . "</option>";
                }
            } else {
                echo "<option>Please Select User</option>";
            }
        }
        return false;
    }
}