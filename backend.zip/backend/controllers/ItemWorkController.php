<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\itemwork\ItemWork;
use common\models\itemwork\ItemWorkSearch;
use common\models\itemwork\ItemWorkForm;
use backend\components\CustController;
/**
 * Item Work Controller
 *  This controller used for Item Work list , add , update , delete.
 * @author Xceltec01
 * @since Jun,2017
 */
class ItemWorkController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {		
        $searchModel = new ItemWorkSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
		return $this->render('index', [
				'searchModel' => $searchModel,
				'dataProvider' => $dataProvider,
		]);
        
    }
	
    /**
     * Add Action
     *  In this action use for Add new data in Item Work.
     * @return
     */
    public function actionAdd() {		
        $model = new ItemWorkForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $itemwork = new ItemWork();
                $itemwork->attributes = $model->attributes;
        
                $itemwork->name = trim($model->name);
                $itemwork->cost_code = $model->cost_code;
                $itemwork->created_by = Yii::$app->user->identity->id;
                $itemwork->updated_by = Yii::$app->user->identity->id;
                $itemwork->created_date = date("Y-m-d H:i:s");
                $itemwork->updated_date = date("Y-m-d H:i:s");
                $itemwork->is_active = ACTIVE;
                $itemwork->is_delete = NOT_DELETED;
	
                if ($itemwork->validate()) {
                    $itemwork->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Item Work ' . ADDED,
                        'title' => 'Item Work Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['item-work/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Item Work not added',
                        'title' => 'Item Work Year Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['item-work/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Update Action
     *  In this action use for update Item Work.
     * $id is Item Work id
     * @return mixed
     */
    public function actionUpdate($id) {

        $details = ItemWork::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();        
       
       if($details == NULL){
					Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['item-work/index']);
        }
        $itemForm = new ItemWorkForm();
        $model = $itemForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $item = ItemWork::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $item->attributes = $model->attributes;
                $item->name = trim($model->name);
                $item->cost_code = $model->cost_code;
				
                $item->created_by = Yii::$app->user->identity->id;
                $item->updated_by = Yii::$app->user->identity->id;
                $item->created_date = date("Y-m-d H:i:s");
                $item->updated_date = date("Y-m-d H:i:s");

                if ($item->validate()) {
                    $item->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Item Work ' . UPDATED,
                        'title' => 'Item Work Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['item-work/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Item Work not updated',
                        'title' => 'Item Work',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['item-work/index']);
                }
            }
        }
        return $this->render('edit_itemwork', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for ItemWork.
     * $id is ItemWork id
     * @return mixed
     */
    public function actionStatus($id) {
		
        $model = ItemWork::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Item Work' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Item Work' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['item-work/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete ItemWork data.
     * $id is ItemWork id
     * @return
     */
    public function actionDelete($id) {
		
        if ($id) {
            $model = ItemWork::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Item Work' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['item-work/index']));
            }
        }
    }
}