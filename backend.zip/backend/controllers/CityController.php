<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\city\City;
use common\models\city\CityForm;
use common\models\city\CitySearch;
use backend\components\CustController;
/**
 * CityController
 *  This controller used for City list , add , update , delete.
 * @author Xceltec01
 * @since Jun,2017
 */
class CityController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new CitySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Add Action
     *  In this action use for Add new data in City.
     * @return
     */
    public function actionAdd() {
        $model = new CityForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $city = new City();
                $city->attributes = $model->attributes;
                $city->country_id = $model->country_id;
                $city->state_id = $model->state_id;
                $city->name = trim($model->name);
                $city->created_by = Yii::$app->user->identity->id;
                $city->updated_by = Yii::$app->user->identity->id;
                $city->created_date = date("Y-m-d H:i:s");
                $city->updated_date = date("Y-m-d H:i:s");
                $city->is_active = ACTIVE;
                $city->is_delete = NOT_DELETED;

                if ($city->validate()) {
                    $city->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'City' . ADDED,
                        'title' => 'City Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['city/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'City not added',
                        'title' => 'Academic Year Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['city/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Update Action
     *  In this action use for update City.
     * $id is City id
     * @return mixed
     */
    public function actionUpdate($id) {
        $details = City::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();        
       
       if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['city/index']);
        }
        $CityForm = new \common\models\city\CityForm();
        $model = $CityForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $city = City::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $city->attributes = $model->attributes;
                $city->country_id = $model->country_id;
                $city->name = trim($model->name);
                $city->state_id = $model->state_id;
                $city->created_by = Yii::$app->user->identity->id;
                $city->updated_by = Yii::$app->user->identity->id;
                $city->created_date = date("Y-m-d H:i:s");
                $city->updated_date = date("Y-m-d H:i:s");

                if ($city->validate()) {
                    $city->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'City' . UPDATED,
                        'title' => 'City Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['city/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'City not updated',
                        'title' => 'City Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['city/index']);
                }
            }
        }
        return $this->render('edit_city', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for City.
     * $id is City id
     * @return mixed
     */
    public function actionStatus($id) {
        $model = City::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'City' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'City' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['city/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete City data.
     * $id is City id
     * @return
     */
    public function actionDelete($id) {
        if ($id) {
            $model = City::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'City' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['city/index']));
            }
        }
    }

    /**
     * SetAction Action
     * @dependent drop down for city _form
     * @return
     */
    public function actionSetAction($id) {
        if (Yii::$app->request->isAjax) {
            $model = \common\models\state\State::find()->where(['country_id' => $id])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => ACTIVE])->all();

            $modelcount = count((array) $model);
            if ($modelcount > 0) {
                echo "<option>Please select state</option>";
                foreach ($model as $action) {

                    echo "<option value='" . $action->id . "'>" . $action->state_name . "</option>";
                }
            } else {
                echo "<option>Please insert state</option>";
            }
        }
        return false;
    }

    /**
     * SetCity Action
     * @dependent drop down for user _form
     * $id is state id
     * @return
     */
    public function actionSetCity($id) {
        if (Yii::$app->request->isAjax) {

            $model = \common\models\city\City::find()->where(['state_id' => $id])->andWhere(['is_delete' => NOT_DELETED , 'is_active' => ACTIVE])->orderBy(['id'=>SORT_DESC])->all();
        
            $modelcount = count((array) $model);

            if ($modelcount > 0) {

                echo "<option>Please Select City</option>";
                foreach ($model as $action) {
                    
                    echo "<option value='" . $action->id . "'>" . $action->name . "</option>";
                }
            } else {
                echo "<option>Please Select State</option>";
            }
        }
        return false;
    }

}