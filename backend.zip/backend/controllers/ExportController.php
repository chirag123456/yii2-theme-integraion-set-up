<?php

namespace backend\controllers;
ini_set('memory_limit', '512M');

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\projectbudget\ProjectBudget;
use common\models\projectbudget\ProjectBudgetSearch;
use common\models\projectbudget\ProjectBudgetForm;
use common\models\projectbudget\ProjectBudgetItemForm;
use common\models\projectbudget\ProjectBudgetItem;
use backend\components\CustController;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;

class ExportController extends CustController {

    public $enableCsrfValidation = true;
  /**
     * Export Data Action
     *  In this action for Export the data.
     * @return mixed
     */
    
    public function actionExportData()
    {
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Project Budget ".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');
        $data_key1 = ['Project Name', 'Sub Contractor Total Cost','Project Budget Total Cost'];
        $data_key2 = ['Item Work Name', 'Item Work Cost','Comment', 'Sub Contractor','Sub Contractor Total Cost'];

        fputcsv($output, $data_key1);
        //fputcsv($output, $data_key2);
        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];
        
        $query = ProjectBudget::find()->where(['is_delete' => INACTIVE])->all();
        // print_r($query); exit();
        //$query1 = ProjectBudgetItem::find()->where(['is_delete' => INACTIVE])->andWhere('project_budget_id = ' . $id)->joinWith('subcontractor')->all();
        
            foreach ($query as $val) {
            $data_val[$i][] = $val->project->project_name;
            $data_val[$i][] = $val->sub_contractor_total_cost;
            $data_val[$i][] = $val->pb_total_cost;
            $i++;
        } 
        

        /*foreach ($query1 as $val) { 
            $data_val_new[$i][] = $val->item->name;
            $data_val_new[$i][] = $val->cost;
            $data_val_new[$i][] = $val->comment;
            $data_val_new[$i][] = $val->subcontractor->first_name . ' '.$val->subcontractor->last_name;
            $data_val_new[$i][] = $val->sub_contractor_estimate_cost;
            $J++;
        }*/

        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }

        /*foreach ($data_val_new as $val) {
            fputcsv($output, $val);
        }*/
    }

}
