<?php

namespace backend\controllers;

use Yii;
use common\models\project\ProjectScheduleManagement;
use common\models\project\ProjectScheduleManagementSearch;
use common\models\project\ProjectScheduleManagementForm;
use yii\web\Controller;
use backend\components\CustController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;

/**
 * ProjectScheduleManagementController implements the CRUD actions for ProjectScheduleManagement model.
 */
class ProjectScheduleManagementController extends CustController
{ 

    /**
     * Lists all ProjectScheduleManagement models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ProjectScheduleManagementSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single ProjectScheduleManagement model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        if($id)
        {
            $details = ProjectScheduleManagement::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
            if(!empty($details))
            {
                return $this->render('view', [
                    'model' => $details,
                ]);    
            }
            else
            {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['project-schedule-management/index']);
            }
        }
        else
        {
            Yii::$app->getSession()->setFlash('danger', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['project-schedule-management/index']);
        }
    } 

    /**
     * Creates a new ProjectScheduleManagement model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new ProjectScheduleManagementForm();

         if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {

            $psm = new ProjectScheduleManagement();
            $psm->attributes = $model->attributes;
            
            $psm->created_by = Yii::$app->user->identity->id;
            $psm->updated_by = Yii::$app->user->identity->id;
            $psm->updated_date = date("Y-m-d H:i:s");
            $psm->created_date = date("Y-m-d H:i:s");
            $psm->is_active = ACTIVE;
            $psm->is_delete = INACTIVE;
            if($psm->validate()){
                $psm->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['project-schedule-management/index']);
        } 
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing ProjectScheduleManagement model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = ProjectScheduleManagement::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-schedule-management/index']);
        }
 
        $model = new ProjectScheduleManagementForm();

        $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $psm = ProjectScheduleManagement::find()->where(['id' => $_GET['id']])->one();
            $psm->attributes = $model->attributes;
            $psm->updated_by = Yii::$app->user->identity->id;
            $psm->updated_date = date("Y-m-d H:i:s");
            $psm->is_active = ACTIVE;
            $psm->is_delete = INACTIVE;
            if($psm->validate() && $psm->save()){
                Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Automotive Product Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-schedule-management/index']);
            }else{
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['project-schedule-management/index']);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing ProjectScheduleManagement model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        if ($id) {
            $model = ProjectScheduleManagement::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['project-schedule-management/index']);
            }
            else
            {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
                return $this->redirect(['project-schedule-management/index']);
            }
        }
        else
        {
            Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
            return $this->redirect(['project-schedule-management/index']);        
        }
    }

    /**
     * Active / Inactive an existing ProjectScheduleManagement model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */

    public function actionStatus($id) {
        $model = ProjectScheduleManagement::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['project-schedule-management/index']);        
    }

    /**
     * Calender View an existing ProjectScheduleManagement model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */

    public function actionCalenderView()
    {
        $details = ProjectScheduleManagement::find()->where(['is_delete'=>INACTIVE] )/*->andWhere(['>=' , 'schedule_start_date', date('Y-m-d')])*/->all();
        return $this->render('calender', [
            'model' => $details,
        ]);
    }
} 