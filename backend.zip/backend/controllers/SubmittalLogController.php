<?php

namespace backend\controllers;

use Yii;
use common\models\submittal\Submittal;
use common\models\submittal\SubmittalSearch; 
use common\models\submittal\SubmittalForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\components\CustController;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CommonFunctions;
use common\models\submittal\SubmittalItem;
use yii\helpers\Url;

 
/**
 * SubmittalLogController implements the CRUD actions for Submittal model.
 */
class SubmittalLogController extends CustController
{

    /**
     * Lists all Submittal models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SubmittalSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Submittal model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */ 
    public function actionView($id)
    {
        $model = Submittal::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000, 
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['submittal-log/index']);
        }
        $model1 = SubmittalItem::find()->where(['is_delete' => INACTIVE])->andWhere('submittal_id = ' . $id)->all();
        return $this->render('view', ['model' => $model,'model1' => $model1]);
    }

    public function actionExportOnePdf($id) 
    {
        $data =Submittal::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        
        if(empty($data))
        { 
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['submittal-log/index']);
        }
        $data1  = SubmittalItem::find()->where(['is_delete' => INACTIVE])->andWhere('submittal_id = ' . $id)->all();
        $content = $this->renderPartial('_pdf', [
                     'model' => $data,
                     'model1' => $data1
                     ]);
        //echo "<pre>"; print_r($content); exit();
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }

    public function actionExportPdf() 
    {
        $data =Submittal::find()->where(['is_delete' => INACTIVE])->all();
        
        if(empty($data))
        { 
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-budget/index']);
        }
        $content = $this->renderPartial('_all_pdf', [
                     'data' => $data,
                     ]);
        //echo "<pre>"; print_r($content); exit();
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
}