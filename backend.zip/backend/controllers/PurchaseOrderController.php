<?php 

namespace backend\controllers; 

use Yii;
use common\models\order\Order;
use common\models\project\Project;
use common\models\order\OrderForm;
use common\models\order\OrderSearch;
use common\models\order\OrderItem;
use common\models\order\OrderItemForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CommonFunctions;
use backend\components\CustController;

/**
 * OrderController implements the CRUD actions for Order model.
 */
class PurchaseOrderController extends CustController
{
    /**
     * Lists all Order models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new OrderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Order model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = Order::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['purchase-order/index']);
        }

        $model1 = OrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('order_id = ' . $id)->all();
        
        return $this->render('view', [
            'model' => $model,
            'model1' => $model1
        ]);
    }

    /**
     * Creates a new Order model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new OrderForm();
        $model1 = new OrderItemForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $order = new Order();
                $order->attributes = $model->attributes;
                $order->contract_for = $_POST['OrderForm']['contract_for'];
                $order->created_by = Yii::$app->user->identity->id;
                $order->updated_by = Yii::$app->user->identity->id;
                $order->created_date = date("Y-m-d H:i:s");
                $order->updated_date = date("Y-m-d H:i:s");
                $order->is_active = ACTIVE;
                $order->is_delete = NOT_DELETED;
                //echo "<pre>"; print_r($order->attributes); 
                //echo "<pre>"; print_r($model->attributes); exit();
                if ($order->validate()) {
                    $order->save();
                    $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['OrderItemForm']['item_id']  as  $value) {
                         
                        $orderItem = new OrderItem();
                        $orderItem->order_id = $order->id;
                        $orderItem->item_id = $_POST['OrderItemForm']['item_id'][$i];
                        $orderItem->qty = $_POST['OrderItemForm']['qty'][$i];
                        $orderItem->unit = $_POST['OrderItemForm']['unit'][$i];
                        $orderItem->description = $_POST['OrderItemForm']['description'][$i];
                        //$orderItem->cost_code = $_POST['OrderItemForm']['cost_code'][$i];
                        $orderItem->unit_price = $_POST['OrderItemForm']['unit_price'][$i];
                        $orderItem->extended_amt = $_POST['OrderItemForm']['extended_amt'][$i];
                        $orderItem->created_by = Yii::$app->user->identity->id;
                        $orderItem->updated_by = Yii::$app->user->identity->id;
                        $orderItem->created_date = date("Y-m-d H:i:s");
                        $orderItem->updated_date = date("Y-m-d H:i:s");
                        $orderItem->is_active = ACTIVE;
                        $orderItem->is_delete = NOT_DELETED;
                        if($orderItem->validate())
                        { 
                            $orderItem->save();
                        }
                        else
                        {
                            echo "<pre>"; print_r($orderItem->getErrors()); exit;
                        }
                        $i++;
                    }
                    
                    $transaction->commit();

                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Order ' . ADDED,
                        'title' => 'Order Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['purchase-order/index']);
                } else {
                    echo "<pre>"; print_r($order->getErrors()); exit;
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Order not added',
                        'title' => 'Order Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['purchase-order/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model,
                    'model1' => $model1
        ]);
    }

    /**
     * Updates an existing Order model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    /*public function actionUpdate($id)
    { 
        $details = Order::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
        if($details == NULL){
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['order/index']);
        }
        $orderItemForm = new OrderForm();
        $model = $orderItemForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {

                $order = Order::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $order->attributes = $model->attributes;
                $order->purchase_order_no = $model->purchase_order_no;
                $order->updated_by = Yii::$app->user->identity->id;                
                $order->updated_date = date("Y-m-d H:i:s");                
                if ($order->validate()) {
                    $order->save();
                    //echo "<pre>"; print_r($order->attributes); exit();
                    \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('order_item', ['order_id' => $id])
                    ->execute();
                    $postdata = $_POST;                
                    $i = 0;

                    foreach ($postdata['OrderItemForm']['item_name']  as  $value) {
                         
                        $orderItem = new OrderItem();
                        $orderItem->order_id = $order->id;
                        $orderItem->item_name = $_POST['OrderItemForm']['item_name'][$i];
                        $orderItem->qty = $_POST['OrderItemForm']['qty'][$i];
                        $orderItem->unit = $_POST['OrderItemForm']['unit'][$i];
                        $orderItem->description = $_POST['OrderItemForm']['description'][$i];
                        $orderItem->cost_code = $_POST['OrderItemForm']['cost_code'][$i];
                        $orderItem->unit_price = $_POST['OrderItemForm']['unit_price'][$i];
                        $orderItem->extended_amt = $_POST['OrderItemForm']['extended_amt'][$i];
                        $orderItem->created_by = Yii::$app->user->identity->id;
                        $orderItem->updated_by = Yii::$app->user->identity->id;
                        $orderItem->created_date = date("Y-m-d H:i:s");
                        $orderItem->updated_date = date("Y-m-d H:i:s");
                        $orderItem->is_active = ACTIVE;
                        $orderItem->is_delete = NOT_DELETED;
                        if($orderItem->validate())
                        { 
                            $orderItem->save();
                        }
                        else
                        {
                            echo "<pre>"; print_r($orderItem->getErrors()); exit;
                        }
                        $i++;
                    } 

                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Order ' . UPDATED,
                        'title' => 'Order Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['purchase-order/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Order not updated',
                        'title' => 'Order Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['purchase-order/index']);
                }
            }
        }
        return $this->render('update', [
                    'model' => $model
        ]);
    }*/

    /**
     * Deletes an existing Order model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        if ($id) {
            $model = Order::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['purchase-order/index']);
            }
        }
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = Order::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['purchase-order/index']);
    }

    // Generate Invoice Function
    public function actionGenerateInvoice($id)
    {
        $model = Order::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['purchase-order/index']);
        }

        $model1 = OrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('order_id = ' . $id)->all();
     
        $content = $this->renderPartial('_invoice', [
                     'model' => $model,
                     'model1' => $model1,
                     ]);
        
        // $css = '            
        //      ';
        // $pdf = new \kartik\mpdf\Pdf([
        //     'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
        //     'content' => $content,
        // 'cssInline' => $css,
        // 'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
        //     'options' => [
        //         'title' => 'Factuur',
        //         'subject' => 'Generating PDF files via yii2-mpdf extension has never been easy'
        //     ],
        // ]);
        // return $pdf->render();
        
            $file_name= 'abc.pdf';
            $pdf = new \kartik\mpdf\Pdf(); // or new Pdf();
            $mpdf = $pdf->api; // fetches mpdf api
            //$mpdf->SetHeader('Prescription');            
            $mpdf->WriteHtml($content);            
            $mpdf->Output($file_name, 'I');
    }
}