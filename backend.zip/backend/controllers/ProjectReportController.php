<?php

/*
 * To change this license header, choose License Headers in Project Properties. 
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\controllers;
ini_set('memory_limit', '512M');

use Yii;
use yii\helpers\Url;

use yii\helpers\ArrayHelper;
use common\models\project\Project;
use common\models\lender\Lender;
use common\models\landlord\Landlord;
use common\models\user\User;
use backend\components\CustController;
use common\models\project\ProjectSearch;
use common\models\project\ProjectForm;
use common\models\project\ProjectReportForm;
use common\models\project\ProjectDocument;
use common\models\project\ProjectDocumentForm;
use yii\web\Response;
use yii\web\UploadedFile;
use yii\bootstrap\ActiveForm;
use common\models\ownerinformation\OwnerInformation;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;
use yii\db\Query;

/**
 * Project Controller implements the CRUD actions.
 */
class ProjectReportController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new ProjectSearch();
        $dataProvider = $searchModel->searchReport(Yii::$app->request->queryParams);
        $model = new ProjectReportForm();
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model
        ]);
    }

    /**
     *  View Action
     *  In this action Project View of data.
     */
    public function actionView($id) {

        $model = Project::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['project-report/index']);
        }

        $architect = User::findOne(['id' => $model->architect_id]);
        $lender = Lender::findOne(['id' => $model->lender_id]);
        $landlord = Landlord::findOne(['id' => $model->landlord_id]);
        $owner = OwnerInformation::findOne(['id' => $model->owner_id]);

        return $this->render('view', ['model' => $model,'architect' => $architect , 'lender' => $lender , 'landlord' => $landlord , 'owner' => $owner]); 
    }

    /**
     * Export CSV of Project Data
     * 
     */
    public function actionExportExcel() 
    {
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Project Data Report".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');

        $data_key1 = [

                        'Project ID',
                        'Project Name',
                        'Project Cost',
                        'Project Size',
                        'Project Estimated Days',
                        'Project Number',
                        'Date of Commencement',
                        'Date of Substantial Completion',
                        'Date of Completion',
                        'Construction Plan Dated',
                        'Physical Address',
                        'City',
                        'State',
                        'Zipcode',
                        'Architect Email',
                        'Lendlord Email',
                        'Lender Email',
                    ];
        

        fputcsv($output, $data_key1);
        
        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];

        $poroject = new Project();
        $data = $poroject->getProjectFilterData($_GET);
        
        foreach ($data as $value) {
            
           $data_val[$i][] =  $value['pid'];
           $data_val[$i][] =  $value['project_name'];
           $data_val[$i][] =  $value['project_cost'];
           $data_val[$i][] =  $value['project_size'];
           $data_val[$i][] =  $value['project_estimated_days'];
           $data_val[$i][] =  $value['project_number'];
           $data_val[$i][] =  $value['date_of_commencement'];
           $data_val[$i][] =  $value['date_of_substantial_completion'];
           $data_val[$i][] =  $value['date_of_completion'];
           $data_val[$i][] =  $value['construction_plan_dated'];
           $data_val[$i][] =  $value['project_physical_address'];
           $data_val[$i][] =  $value['p_city_name'];
           $data_val[$i][] =  $value['p_state_name'];
           $data_val[$i][] =  $value['project_zipcode'];
           $data_val[$i][] =  $value['architect_email'];
           $data_val[$i][] =  $value['landlord_email'];
           $data_val[$i][] =  $value['lender_email'];
           $i++;
        }  
        
        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }
}