<?php
 
namespace backend\controllers;

use Yii;
use common\models\lender\Lender;
use common\models\lender\LenderSearch;
use common\models\lender\LenderForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CustController;

/**
 * LenderController implements the CRUD actions for Lender model.
 */
class LenderController extends CustController
{
    /**
     * Lists all Lender models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LenderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Lender model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = Lender::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['lender/index']);
        }
        return $this->render('view', ['model' => $model]);
    }

    /**
     * Creates a new Lender model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new LenderForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $lender = new Lender();
                $lender->attributes = $model->attributes;
                $lender->created_by = Yii::$app->user->identity->id;
                $lender->updated_by = Yii::$app->user->identity->id;
                $lender->created_date = date("Y-m-d H:i:s");
                $lender->updated_date = date("Y-m-d H:i:s");
                $lender->is_active = ACTIVE;
                $lender->is_delete = NOT_DELETED;
    
                if ($lender->validate()) {
                    $lender->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Lender ' . ADDED,
                        'title' => 'Lender Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['lender/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Lender not added',
                        'title' => 'Lender Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['lender/index']);
                }
            }
        }
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Lender model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
       $details = Lender::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       if($details == NULL){
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['lender/index']);
        }
        $lenderForm = new lenderForm();
        $model = $lenderForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $lender = Lender::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $lender->attributes = $model->attributes;
                $lender->updated_by = Yii::$app->user->identity->id;
                $lender->updated_date = date("Y-m-d H:i:s");

                if ($lender->validate()) {
                    $lender->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Lender ' . UPDATED,
                        'title' => 'Lender Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['lender/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Lender not updated',
                        'title' => 'Lender',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['lender/index']);
                }
            }
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for Lender.
     * $id is Lender id
     * @return mixed
     */
    public function actionStatus($id) {
        
        $model = Lender::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Lender ' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Lender ' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['lender/index']));
    }

    /**
     * Deletes an existing Lender model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id) {
        
        if ($id) {
            $model = Lender::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Lender ' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['lender/index']));
            }
        }
    }

    /**
     * Finds the Lender model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Lender the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Lender::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
