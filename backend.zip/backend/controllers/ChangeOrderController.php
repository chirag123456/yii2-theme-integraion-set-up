<?php

namespace backend\controllers;

use Yii;
use common\models\order\Order;
use common\models\changeorder\ChangeOrder;
use common\models\changeorder\ChangeOrderForm;
use common\models\changeorder\ChangeOrderSearch;
use common\models\changeorder\ChangeOrderItem;
use common\models\changeorder\ChangeOrderItemForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException; 
use yii\filters\VerbFilter; 
use yii\web\Response;
use yii\bootstrap\ActiveForm;

/**
 * ChangeOrderController implements the CRUD actions for ChangeOrder model.
 */
class ChangeOrderController extends Controller
{

    /**
     * Lists all ChangeOrder models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ChangeOrderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single ChangeOrder model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    { 
        $model = ChangeOrder::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['change-order/index']);
        }

        $model1 = ChangeOrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('change_order_id = ' . $id)->all();
        
        return $this->render('view', [
            'model' => $model,
            'model1' => $model1
        ]);
    }

    /**
     * Creates a new ChangeOrder model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd($id) 
    {
        if($id)
        {
            $details = Order::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
           // echo "<pre>"; print_r($details); exit();
            if($details == NULL){
                        Yii::$app->getSession()->setFlash('success', [
                            'type' => 'danger',
                            'duration' => 12000,
                          // 'icon' => 'glyphicon glyphicon-remove-sign',
                            'message' => DATA_NOT_VALID,
                            'title' => 'Error',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]); 
                  return $this->redirect(['purchase-order/index']);
            }
            $model = new ChangeOrderForm();
            $model2 = new ChangeOrderItemForm();
            if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ActiveForm::validate($model);
            }
        
            if ($model->load(Yii::$app->request->post())) {     
                //echo "<pre>"; print_r($details->project->architect_id); exit();
                $changeOrder = new ChangeOrder();
                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $changeOrder->attributes = $model->attributes;
                $changeOrder->project_id = $details->project_id;
                $changeOrder->architect_id = $details->project->architect_id;
                $changeOrder->contractor_id = $details->contractor_id;
                $changeOrder->is_delete = INACTIVE;
                $changeOrder->is_active = ACTIVE;
                $changeOrder->created_by = Yii::$app->user->id;
                $changeOrder->updated_by = Yii::$app->user->id;
                $changeOrder->date_approval_recived_back = date("Y-m-d H:i:s");
                $changeOrder->updated_date = date("Y-m-d H:i:s");
                $changeOrder->created_date = date("Y-m-d H:i:s");
                if ($changeOrder->validate()) {
                    $changeOrder->save();                   

                        // Insert Code for Change order Item
                        $postdata = $_POST;                
                        $i = 0;
                        foreach ($postdata['ChangeOrderItemForm']['item_id']  as  $value) {
                             
                            $changeOrderItem = new ChangeOrderItem();
                            $changeOrderItem->change_order_id = $changeOrder->id;
                            $changeOrderItem->item_id = $postdata['ChangeOrderItemForm']['item_id'][$i];
                            $changeOrderItem->qty = $postdata['ChangeOrderItemForm']['qty'][$i];
                            $changeOrderItem->unit = $postdata['ChangeOrderItemForm']['unit'][$i];
                            $changeOrderItem->description = $postdata['ChangeOrderItemForm']['description'][$i];
                            $changeOrderItem->unit_price = $postdata['ChangeOrderItemForm']['unit_price'][$i];
                            $changeOrderItem->extended_amt = $postdata['ChangeOrderItemForm']['extended_amt'][$i];
                            $changeOrderItem->change_class = $postdata['ChangeOrderItemForm']['change_class'][$i];
                            $changeOrderItem->time_ext = $postdata['ChangeOrderItemForm']['time_ext'][$i]; 
                            $changeOrderItem->co_amt = $postdata['ChangeOrderItemForm']['extended_amt'][$i];
                            $changeOrderItem->notes = $postdata['ChangeOrderItemForm']['notes'][$i];
                            $changeOrderItem->updated_contract_amt = $details->total_amt + $postdata['ChangeOrderItemForm']['extended_amt'][$i];
                            $changeOrderItem->created_by = Yii::$app->user->identity->id;
                            $changeOrderItem->updated_by = Yii::$app->user->identity->id;
                            $changeOrderItem->created_date = date("Y-m-d H:i:s");
                            $changeOrderItem->updated_date = date("Y-m-d H:i:s");
                            $changeOrderItem->is_active = ACTIVE;
                            $changeOrderItem->is_delete = NOT_DELETED;
                            if($changeOrderItem->validate())
                            { 
                                $changeOrderItem->save(); 
                            }
                            else
                            {
                                $transaction->rollback();
                                echo "<pre>"; print_r($changeOrderItem->getErrors()); exit;
                            }
                            $i++;
                        }
                    $transaction->commit();
                    $changeOrder->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => ADDED,
                        'title' => 'User Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    echo "<pre>"; print_r($changeOrder->getErrors()); exit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
                return $this->redirect(['change-order/index']);
            }
            return $this->render('create', [
                        'model' => $model,
                        'model2' => $model2,
                        'details' => $details 
            ]);
        }
        else
        {
            Yii::$app->getSession()->setFlash('success', [
                            'type' => 'danger',
                            'duration' => 12000,
                          // 'icon' => 'glyphicon glyphicon-remove-sign',
                            'message' => DATA_NOT_VALID,
                            'title' => 'Error',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]); 
            return $this->redirect(['purchase-order/index']);
        }
    }

    /**
     * Updates an existing ChangeOrder model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    /*public function actionUpdate($id)
    {
        $details = ChangeOrder::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
        if($details == NULL){
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['change-order/index']);
        }
        $projectBudgetForm = new ChangeOrderForm();
        $model = $projectBudgetForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $chageOrder = ChangeOrder::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $chageOrder->attributes = $model->attributes;
                $chageOrder->updated_by = Yii::$app->user->identity->id;                
                $chageOrder->updated_date = date("Y-m-d H:i:s");                
                if ($chageOrder->validate()) {
                    $chageOrder->save();
                    
                    \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('change_order_item', ['change_order_id' => $id])
                    ->execute();
                    $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['ChangeOrderItemForm']['item_id']  as  $value) {
                         
                        $changeOrderItem = new ChangeOrderItem();
                        $changeOrderItem->change_order_id = $changeOrder->id;
                        $changeOrderItem->item_id = $postdata['ChangeOrderItemForm']['item_id'][$i];
                        $changeOrderItem->qty = $postdata['ChangeOrderItemForm']['qty'][$i];
                        $changeOrderItem->unit = $postdata['ChangeOrderItemForm']['unit'][$i];
                        $changeOrderItem->description = $postdata['ChangeOrderItemForm']['description'][$i];
                        $changeOrderItem->unit_price = $postdata['ChangeOrderItemForm']['unit_price'][$i];
                        $changeOrderItem->extended_amt = $postdata['ChangeOrderItemForm']['extended_amt'][$i];
                        $changeOrderItem->change_class = $postdata['ChangeOrderItemForm']['change_class'][$i];
                        $changeOrderItem->time_ext = $postdata['ChangeOrderItemForm']['time_ext'][$i]; 
                        $changeOrderItem->co_amt = $postdata['ChangeOrderItemForm']['co_amt'][$i];
                        $changeOrderItem->notes = $postdata['ChangeOrderItemForm']['notes'][$i];
                        $changeOrderItem->updated_contract_amt = $postdata['ChangeOrderItemForm']['updated_contract_amt'][$i];
                        $changeOrderItem->created_by = Yii::$app->user->identity->id;
                        $changeOrderItem->updated_by = Yii::$app->user->identity->id;
                        $changeOrderItem->created_date = date("Y-m-d H:i:s");
                        $changeOrderItem->updated_date = date("Y-m-d H:i:s");
                        $changeOrderItem->is_active = ACTIVE;
                        $changeOrderItem->is_delete = NOT_DELETED;
                        if($changeOrderItem->validate())
                        { 
                            $changeOrderItem->save();
                        }
                        else
                        {
                            $transaction->rollback();
                            echo "<pre>"; print_r($changeOrderItem->getErrors()); exit;
                        }
                        $i++;
                    }

                    $transaction->commit();
                    $chageOrder->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Action Item ' . UPDATED,
                        'title' => 'Action Item Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['change-order/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Action Item not updated',
                        'title' => 'Action Item Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['change-order/index']);
                }
            }
        }
        return $this->render('update', [
                    'model' => $model
        ]);
    }*/
} 