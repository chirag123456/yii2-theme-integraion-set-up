<?php
namespace backend\controllers;

use Yii;
use common\models\taskallocation\TaskAllocation;
use common\models\taskallocation\TaskAllocationSearch;
use common\models\taskallocation\TaskAllocationForm; 
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CustController;

/**
 * TaskAllocationController implements the CRUD actions for TaskAllocation model.
 */
class TaskAllocationController extends CustController
{
    
    /**
     * Lists all TaskAllocation models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TaskAllocationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single TaskAllocation model.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id) {

        $model = TaskAllocation::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['task-allocation/index']);
        }

        return $this->render('view', ['model' => $model]);
    }
 
    /**
     * Creates a new TaskAllocation model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    { 
        $model = new TaskAllocationForm();
        
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        
        if ($model->load(Yii::$app->request->post())) {

            $task = new TaskAllocation();
            $task->attributes = $model->attributes;
            
            $task->created_by = Yii::$app->user->identity->id;
            $task->updated_by = Yii::$app->user->identity->id;
            $task->updated_date = date("Y-m-d H:i:s");
            $task->created_date = date("Y-m-d H:i:s");
            $task->is_active = ACTIVE;
            $task->is_delete = INACTIVE;
            if($task->validate()){
                $task->save();
                $data = [
                   'msg' => 'Belows are your Task Details',
                   'task_name' => $task->task_name,
                   'task_status' => $task->task_status,
                   'priority' => $task->priority,
                   'description' => $task->description,
                   'start_date' => $task->start_date,
                   'due_date' => $task->due_date,
                   'user' => $task->user->email,
                   'project_name' => $task->project->project_name,
                   'userfirstname' => isset($task->user->first_name) ? $task->user->first_name : '',
                   'userlastname' => isset($task->user->last_name) ? $task->user->last_name : ''
                ]; 
                $task->sendTaskEmail($data);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                echo "<pre>";
                print_r($task->getErrors());
                die();
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['task-allocation/index']);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /** 
     * Updates an existing TaskAllocation model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = TaskAllocation::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['contractor-management/index']);
        }

        $model = new TaskAllocationForm(); 

        // $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $task = TaskAllocation::find()->where(['id' => $_GET['id']])->one();
            $task->attributes = $model->attributes;
            
            $task->updated_by = Yii::$app->user->identity->id;
            $task->updated_date = date("Y-m-d H:i:s");
            $task->is_active = ACTIVE;
            $task->is_delete = INACTIVE;
            if($task->validate() && $task->save()){
                $data = [
                   'msg' => 'Your Task Details are updated:',
                   'task_name' => $task->task_name,
                   'task_status' => $task->task_status,
                   'priority' => $task->priority,
                   'description' => $task->description,
                   'start_date' => $task->start_date,
                   'due_date' => $task->due_date,
                   'user' => $task->user->email,
                   'project_name' => $task->project->project_name,
                   'userfirstname' => isset($task->user->first_name) ? $task->user->first_name : '',
                   'userlastname' => isset($task->user->last_name) ? $task->user->last_name : ''
                ]; 
                $task->sendTaskEmail($data);
                Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Task Allocation',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['task-allocation/index']);
            }else{
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['task-allocation/index']);
        }


        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Status an existing TaskAllocation model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
    */ 
    public function actionStatus($id) {
        $model = TaskAllocation::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Task Allocation ' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Task Allocation ' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['task-allocation/index']));
    }

    /**
     * Deletes an existing TaskAllocation model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id) {
        if ($id) {
            $model = TaskAllocation::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Task Allocation ' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['task-allocation/index']));
            }
        }
    }


    /**
     * Finds the TaskAllocation model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return TaskAllocation the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = TaskAllocation::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    /** 
     * SetUser Action
     * @dependent drop down for user _form
     * $id is role id
     * @return
     */
    public function actionSetUser($id) {
        if (Yii::$app->request->isAjax) {

            $model = \common\models\user\User::find()->where(['role' => $id])->andWhere(['is_delete' => NOT_DELETED , 'is_active' => ACTIVE])->orderBy(['id'=>SORT_DESC])->all();
        
            $modelcount = count((array) $model);

            if ($modelcount > 0) {

                echo "<option>Please Select User</option>";
                foreach ($model as $action) {
                    
                    echo "<option value='" . $action->id . "'>" . $action->first_name . ' '. $action->last_name . '-'. $action->email . "</option>";
                }
            } else {
                echo "<option>Please Select User</option>";
            }
        }
        return false;
    }
}
