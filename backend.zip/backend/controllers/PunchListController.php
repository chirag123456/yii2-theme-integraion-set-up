<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\punchlist\PunchList; 
use common\models\punchlist\PunchListForm;
use common\models\punchlist\PunchListSearch;
use backend\components\CustController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\punchlist\PunchListDetail;
use common\models\punchlist\PunchListDetailForm;

/**
 * ClientController implements the CRUD actions for Client model.
 */
class PunchListController extends CustController
{
    /**
     * Lists all Client models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PunchListSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single PunchList model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id) 
    {
        $model = PunchList::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['punch-list/index']);
        }
        $model1 = PunchListDetail::find()->where(['is_delete' => INACTIVE])->andWhere('punch_id = ' . $id)->all();
        return $this->render('view', [
            'model' => $model,
            'model1' => $model1,
        ]);
    }

    /**
     * Creates a new Client model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new PunchListForm();
        $model1 = new PunchListDetailForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        
        if ($model->load(Yii::$app->request->post())) {
            
            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();
            $punch = new PunchList();
            $punch->attributes = $model->attributes;
            
            $punch->created_by = Yii::$app->user->identity->id;
            $punch->updated_by = Yii::$app->user->identity->id;
            $punch->updated_date = date("Y-m-d H:i:s");
            $punch->created_date = date("Y-m-d H:i:s");
            $punch->is_active = ACTIVE;
            $punch->is_delete = INACTIVE; 

            if($punch->validate() && $punch->save()){               
                    $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['PunchListDetailForm']['location']  as  $value) {
                        
                        $punchdetail = new PunchListDetail();
                        $punchdetail->punch_id = $punch->id;
                        $punchdetail->location = $_POST['PunchListDetailForm']['location'][$i];
                        $punchdetail->description = $_POST['PunchListDetailForm']['description'][$i];
                        $punchdetail->subcontractor_id = $_POST['PunchListDetailForm']['subcontractor_id'][$i];
                        $punchdetail->gc_initial = $_POST['PunchListDetailForm']['gc_initial'][$i];
                        $punchdetail->owner_pm_initial = $_POST['PunchListDetailForm']['owner_pm_initial'][$i];
                        $punchdetail->completed_date = date("Y-m-d",strtotime($_POST['PunchListDetailForm']['completed_date'][$i]));

                        $punchdetail->created_by = Yii::$app->user->identity->id;
                        $punchdetail->updated_by = Yii::$app->user->identity->id;
                        $punchdetail->updated_date = date("Y-m-d H:i:s");
                        $punchdetail->created_date = date("Y-m-d H:i:s");
                        $punchdetail->is_active = ACTIVE;
                        $punchdetail->is_delete = INACTIVE;
                        $punchdetail->save();
                        $i++;
                    }
                    
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Construction Punch List ' . ADDED,
                        'title' => 'Construction Punch List Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['punch-list/index']);
                }else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Construction Punch List not added',
                        'title' => 'Construction Punch List Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['punch-list/index']);
                }
            }
            return $this->render('add', [
                'model' => $model,
                'model1' => $model1,
        ]);
    }
}