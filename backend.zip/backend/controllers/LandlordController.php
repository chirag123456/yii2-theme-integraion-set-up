<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;  
use common\models\landlord\Landlord;
use common\models\landlord\LandlordSearch;
use common\models\landlord\LandlordForm;
use backend\components\CustController;

/**
 * LandlordController implements the CRUD actions for Landlord model.
 */
class LandlordController extends CustController
{
    /**
     * Lists all Landlord models.
     * @return mixed
     */ 
    public function actionIndex()
    {
        $searchModel = new LandlordSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    } 

    /**
     * Displays a single Landlord model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id) {

        $model = Landlord::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['landlord/index']);
        }

        return $this->render('view', ['model' => $model]);
    }

    /**
     * Creates a new Landlord model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new LandlordForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $landlord = new Landlord();

                $landlord->attributes = $model->attributes;
                $landlord->created_by = Yii::$app->user->identity->id;
                $landlord->updated_by = Yii::$app->user->identity->id;
                $landlord->created_date = date("Y-m-d H:i:s");
                $landlord->updated_date = date("Y-m-d H:i:s");
                $landlord->is_active = ACTIVE;
                $landlord->is_delete = NOT_DELETED;
    
                if ($landlord->validate()) {
                    $landlord->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Landlord ' . ADDED,
                        'title' => 'Landlord Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['landlord/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Landlord not added',
                        'title' => 'Landlord Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['landlord/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Updates an existing Landlord model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
       $details = Landlord::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       if($details == NULL){
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['landlord/index']);
        }
        $landlordForm = new LandlordForm();
        $model = $landlordForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $landlord = Landlord::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $landlord->attributes = $model->attributes;
                $landlord->updated_by = Yii::$app->user->identity->id;
                $landlord->updated_date = date("Y-m-d H:i:s");
                if ($landlord->validate()) {
                    $landlord->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Landlord ' . UPDATED,
                        'title' => 'Landlord Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['landlord/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Landlord updated',
                        'title' => 'Landlord',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['landlord/index']);
                }
            }
        }
        return $this->render('update', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for Landlord.
     * $id is Landlord id
     * @return mixed
     */
    public function actionStatus($id) {
        
        $model = Landlord::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Landlord ' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Landlord ' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['landlord/index']));
    }

    /**
     * Deletes an existing Landlord model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    { 
        if ($id) {
            $model = Landlord::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Landlord ' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

             return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['landlord/index']));
            }
        }
    }
}