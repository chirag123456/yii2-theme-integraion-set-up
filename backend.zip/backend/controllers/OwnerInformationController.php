<?php

namespace backend\controllers;

use Yii;
use common\models\ownerinformation\OwnerInformation;
use common\models\ownerinformation\OwnerInformationSearch;
use common\models\ownerinformation\OwnerInformationForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm; 
use backend\components\CustController;

/**
 * OwnerInformationController implements the CRUD actions for OwnerInformation model.
 */
class OwnerInformationController extends CustController
{
    /**
     * Lists all OwnerInformation models.
     * @return mixed
     */

    public function actionIndex()
    {
        $searchModel = new OwnerInformationSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single OwnerInformation model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    
    public function actionView($id) {

        $model = OwnerInformation::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['owner-information/index']);
        }

        return $this->render('view', ['model' => $model]);
    }

    /**
     * Creates a new OwnerInformation model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */

    public function actionAdd()
    {
        $model = new OwnerInformationForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
               
                $ownerinfo = new OwnerInformation();

                $ownerinfo->attributes = $model->attributes;
                $ownerinfo->created_by = Yii::$app->user->identity->id;
                $ownerinfo->updated_by = Yii::$app->user->identity->id;
                $ownerinfo->created_date = date("Y-m-d H:i:s");
                $ownerinfo->updated_date = date("Y-m-d H:i:s");
                $ownerinfo->is_active = ACTIVE;
                $ownerinfo->is_delete = NOT_DELETED;
    
                if ($ownerinfo->validate()) {
                    $ownerinfo->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Owner Information ' . ADDED,
                        'title' => 'Owner Information Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['owner-information/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Owner Information not added',
                        'title' => 'Owner Information Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['owner-information/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Updates an existing OwnerInformation model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */

    public function actionUpdate($id)
    {
        $details = OwnerInformation::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       if($details == NULL){
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['owner-information/index']);
        }
        $landlordForm = new OwnerInformationForm();
        $model = $landlordForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $ownerinfo = OwnerInformation::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $ownerinfo->attributes = $model->attributes;
                $ownerinfo->updated_by = Yii::$app->user->identity->id;
                $ownerinfo->updated_date = date("Y-m-d H:i:s");
                if ($ownerinfo->validate()) {
                    $ownerinfo->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Owner Information ' . UPDATED,
                        'title' => 'Owner Information Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['owner-information/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Owner Information not updated',
                        'title' => 'Owner Information',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['owner-information/index']);
                }
            }
        }
        return $this->render('update', [
                    'model' => $model
        ]);
    }

    /**
     * Deletes an existing OwnerInformation model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
 
    public function actionDelete($id)
    {
        if ($id) {
            $model = OwnerInformation::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Owner Information' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['owner-information/index']));
            }
        }
    }

    /**
     * Inactive/Active an existing OwnerInformation model.
     * If operation is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionStatus($id) {
        $model = OwnerInformation::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['owner-information/index']);
    }
}