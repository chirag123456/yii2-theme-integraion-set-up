<?php

/*
 * To change this license header, choose License Headers in Project Properties. 
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\controllers; 
ini_set('memory_limit', '512M');

use Yii;
use yii\helpers\Url;

use yii\helpers\ArrayHelper;
use common\models\project\Project;
use common\models\lender\Lender;
use common\models\landlord\Landlord;
use common\models\project\FolderCreate;
use common\models\user\User;
use backend\components\CustController;
use common\models\project\ProjectSearch;
use common\models\project\ProjectForm;
use common\models\project\ProjectDocument;
use common\models\project\ProjectDocumentForm;
use yii\web\Response;
use yii\web\UploadedFile;
use yii\bootstrap\ActiveForm;
use common\models\ownerinformation\OwnerInformation;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;
use yii\db\Query;

/**
 * Project Controller implements the CRUD actions.
 */
class ProjectController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() { 
        $searchModel = new ProjectSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    } 

     /**
     * Add Action
     *  In this action Add of data.
     */
    public function actionAdd() {
        $model = new ProjectForm();
        $model1 = new ProjectDocumentForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {     
            
            $project = new Project();
            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();
            $project->attributes = $model->attributes;
            $project->is_delete = INACTIVE;
            $project->is_active = ACTIVE;
            $project->created_by = Yii::$app->user->id;
            $project->updated_by = Yii::$app->user->id;
            $project->updated_date = date("Y-m-d H:i:s");
            $project->created_date = date("Y-m-d H:i:s");
            if ($project->validate()) {
                $project->save();                   
                    
                    $basePath = dirname(\Yii::$app->basePath).'/media/uploads/project_document/'.$project->id.'/Default/';
                    
                        if (!is_dir(dirname(\Yii::$app->basePath) .'/media/uploads/project_document/'.$project->id.'/Default')) {
                            $targetDir = dirname(\Yii::$app->basePath).'/media/uploads/project_document/'.$project->id;
                            $targetDir1 = dirname(\Yii::$app->basePath).'/media/uploads/project_document/'.$project->id . '/Default';
                                
                            if (!file_exists($targetDir) && !is_dir($targetDir)) {
                                mkdir($targetDir, 0777);
                                mkdir($targetDir1, 0777);
                            }
                        }
                        $foldercreate = new FolderCreate();
                        $foldercreate->project_id = $project->id;
                        $foldercreate->folder_name = 'Default';
                        $foldercreate->folder_path = '/media/uploads/project_document/'.$project->id.'/'.'Default/';
                        $foldercreate->created_by = Yii::$app->user->id;
                        $foldercreate->updated_by = Yii::$app->user->id;
                        $foldercreate->updated_date = date("Y-m-d H:i:s");
                        $foldercreate->created_date = date("Y-m-d H:i:s");
                        $foldercreate->is_active = ACTIVE;
                        $foldercreate->is_delete = NOT_DELETED;
                        $foldercreate->save();
                        $model1->file_name = UploadedFile::getInstances($model1, 'file_name');
                        foreach ($model1->file_name as $fileval) { 
                                $savefilename = uniqid() . '.' . $fileval->extension;
                                $fileval->saveAs($basePath . $savefilename);
                                $projectd = new ProjectDocument();
                                $projectd->project_id = $project->id;
                                $projectd->file_name = $savefilename;
                                $projectd->project_folder_id = $foldercreate->id;
                                $projectd->file_path = '/media/uploads/project_document/'.$project->id.'/'.'Default/';
                                $projectd->project_id = $project->id;
                                $projectd->is_delete = INACTIVE;
                                $projectd->is_active = ACTIVE;
                                $projectd->created_by = Yii::$app->user->id;
                                $projectd->updated_by = Yii::$app->user->id;
                                $projectd->updated_date = date("Y-m-d H:i:s");
                                $projectd->created_date = date("Y-m-d H:i:s");
                                $projectd->save();
                            }
                    $transaction->commit();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            } else {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_SAVED,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['project/index']);
        }
        return $this->render('create', [
                    'model' => $model,
                    'model1' => $model1
        ]);
    }
   
    
    /**
     * Update Action
     *  In this action Update Project of data.
     */
    public function actionUpdate($id) {
 
        $details = Project::findOne(['id' => $id, 'is_delete' => NOT_DELETED]);

        if (empty($details)) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Invalid data!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['project/index']);
        }
        
        $architect = User::findOne(['id' => $details->architect_id]);
        $lender = Lender::findOne(['id' => $details->lender_id]);
        $landlord = Landlord::findOne(['id' => $details->landlord_id]);
        //$owner = OwnerInformation::findOne(['id' => $details->owner_id]);

        $model = new ProjectForm();
        $model1 = new ProjectDocumentForm();

        $model->attributes = $details->attributes;

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {
      
            $project = Project::findOne(['id' => $id]);
            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();
            $project->attributes = $model->attributes;
            $project->updated_by = Yii::$app->user->id;
            $project->updated_date = date("Y-m-d H:i:s");

            
            if ($project->validate() && $project->save()) {
                 $basePath = dirname(\Yii::$app->basePath).'/media/uploads/project_document/'.$project->id.'/Default/';
                    
                        if (!is_dir(dirname(\Yii::$app->basePath) .'/media/uploads/project_document/'.$project->id.'/Default')) {

                            $targetDir = dirname(\Yii::$app->basePath).'/media/uploads/project_document/'.$project->id;
                            $targetDir1 = dirname(\Yii::$app->basePath).'/media/uploads/project_document/'.$project->id . '/Default';
                            //echo "sdcsd"; print_r(file_exists($targetDir1)); die();    
                            if (!file_exists($targetDir) || !is_dir($targetDir) || !file_exists($targetDir1) || !is_dir($targetDir1)) {
                                // if(file_exists($targetDir) && is_dir($targetDir))
                                // {
                                //     mkdir($targetDir, 0777);    
                                // }
                                
                                mkdir($targetDir1, 0777);

                                $foldercreate = new FolderCreate();
                                $foldercreate->project_id = $project->id;
                                $foldercreate->folder_name = 'Default';
                                $foldercreate->folder_path = '/media/uploads/project_document/'.$project->id.'/'.'Default/';
                                $foldercreate->created_by = Yii::$app->user->id;
                                $foldercreate->updated_by = Yii::$app->user->id;
                                $foldercreate->updated_date = date("Y-m-d H:i:s");
                                $foldercreate->created_date = date("Y-m-d H:i:s");
                                $foldercreate->is_active = ACTIVE;
                                $foldercreate->is_delete = NOT_DELETED;
                                $foldercreate->save();
                            }
                        }
                        
                        
                        $model1->file_name = UploadedFile::getInstances($model1, 'file_name');
                        $folder = FolderCreate::findOne(['folder_name' => 'Default','project_id' => $project->id]);

                        foreach ($model1->file_name as $fileval) { 
                                //$fileval->saveAs($basePath . uniqid() . '.' . $fileval->extension);
                                $savefilename = uniqid() . '.' . $fileval->extension;
                                $fileval->saveAs($basePath . $savefilename);
                                $projectd = new ProjectDocument();
                                $projectd->project_id = $project->id;
                                $projectd->project_folder_id = $folder->id;
                                $projectd->file_name = $savefilename;
                                $projectd->file_path = '/media/uploads/project_document/'.$project->id.'/Default/';
                                $projectd->project_id = $project->id;
                                $projectd->is_delete = INACTIVE;
                                $projectd->is_active = ACTIVE;
                                $projectd->created_by = Yii::$app->user->id;
                                $projectd->updated_by = Yii::$app->user->id;
                                $projectd->updated_date = date("Y-m-d H:i:s");
                                $projectd->created_date = date("Y-m-d H:i:s");
                                $projectd->save(); 

                            }
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
               
            } else {
                
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

            if (isset($_GET['page'])) {
                return $this->redirect(['project/index?page=' . $_GET['page']]);
            } else {
                return $this->redirect(['project/index']);
            }
        } 

        return $this->render('edit_project', [
                'model' => $model,
                'model1' => $model1,
                'lender' => isset($lender) && !empty($lender) ? $lender : '',
                'architect' => isset($architect) && !empty($architect) ? $architect : '',
                'landlord' => isset($landlord) && !empty($landlord) ? $landlord : '',
                //'owner' => isset($owner) && !empty($owner) ? $owner : '', 
         ]);
    }


    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = Project::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => 'Project'.DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => 'Project'.ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['project/index']);
    }

      /**
     * Delete Action
     *  In this action Delete of data.
     */
    public function actionDelete($id) {
        if ($id) {
            $model = Project::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['project/index']);
            }
        }
    }

    /**
     *  View Action
     *  In this action Project View of data.
     */
    public function actionView($id) {

        $model = Project::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['project/index']);
        }

        $architect = User::findOne(['id' => $model->architect_id]);
        $lender = Lender::findOne(['id' => $model->lender_id]);
        $landlord = Landlord::findOne(['id' => $model->landlord_id]);
        $owner = OwnerInformation::findOne(['id' => $model->owner_id]);

        return $this->render('view', ['model' => $model,'architect' => $architect , 'lender' => $lender , 'landlord' => $landlord , 'owner' => $owner]); 
    }

   

    /**
     * base_64_image function
     *  In this image function.
     */
   public function base64_to_image($imageData) {

        $basePath = dirname(\Yii::$app->basePath);
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]); 
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile/' . DIRECTORY_SEPARATOR . $imagename;
        file_put_contents($file, $image_base64);

        return $imagename;
        //return '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile' . DIRECTORY_SEPARATOR . $imagename;    
    }

    /**
     * Get Owner Data.
     *  In this image function.
     */
    public function actionGetOwner($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = OwnerInformation::find()->joinWith(['state','city'])->where(['owner_information.is_delete' => INACTIVE])->andWhere('owner_information.id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model,'state' => $model->state->state_name,'city' => $model->city->name];
           return \yii\helpers\Json::encode($model1);
        }
    }

    /**
     * Get Architect Data.
     *  In this image function.
     */
    public function actionGetArchitect($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = User::find()->joinWith(['state','city'])->where(['users.is_delete' => INACTIVE])->andWhere('users.id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model,'state' => $model->state->state_name,'city' => $model->city->name];
           return \yii\helpers\Json::encode($model1);
        }
    }

    /**
     * Get Landlord Data.
     *  In this image function.
     */
    public function actionGetLandlord($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = Landlord::find()->joinWith(['state','city'])->where(['landlord.is_delete' => INACTIVE])->andWhere('landlord.id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model,'state' => $model->state->state_name,'city' => $model->city->name];
           return \yii\helpers\Json::encode($model1);
        }
    }

    /**
     * Export CSV of Project Data
     * 
     */
    public function actionExportExcel() 
    {

        $id = 1;
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Project Data".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');

        $data_key1 = [

                        'Project Name',
                        'Project Cost',
                        'Project Size',
                        'Project Estimated Days',
                        'Project Number',
                        'Project Date of Commencement',
                        'Project Date of Substantial Completion',
                        'Project Date of Completion',
                        'Project Physical Address',
                        'Project City',
                        'Project State',
                        'Project Zipcode',

                        'Architect Contact Person',
                        'Architect Email',
                        'Architect Phone',
                        'Architect Firm',
                        /*'Architect Address',
                        'Architect City',
                        'Architect State',
                        'Architect Zipcode',
                        'Architect CA?',*/
                        'Architect Construction Plan Date',

                        'Lendlord Contact Person',
                        'Lendlord Email',
                        /*'Lendlord Phone',                        
                        'Landlord Address',
                        'Landlord State',
                        'Landlord City',
                        'Lendlord Zipcode',
                        'Will Landlord Require Special Documentation For Billing',
                        'If Special Documentation Required If Yes List',
                        'Lender Or Bank Contact Person',*/

                        'Lender Email',
                        /*'Lender Phone',
                        'Bank Require Special Documentation For Billing Project Closeout',
                        'Lender Special Documentation List Requirements',
                        'Lender Address',
                        'Lender State',
                        'Lender City',
                        'Lender Zipcode',*/    
        ];
        

        fputcsv($output, $data_key1);
        
        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];

        $poroject = new Project();
        $data = $poroject->getProjectData();
       
        foreach ($data as $value) {
            
           $data_val[$i][] =  $value['project_name'];
           $data_val[$i][] =  $value['project_cost'];
           $data_val[$i][] =  $value['project_size'];
           $data_val[$i][] =  $value['project_estimated_days'];
           $data_val[$i][] =  $value['project_number'];
           $data_val[$i][] =  $value['date_of_commencement'];
           $data_val[$i][] =  $value['date_of_substantial_completion'];
           $data_val[$i][] =  $value['date_of_completion'];
           $data_val[$i][] =  $value['project_physical_address'];
           $data_val[$i][] =  $value['p_city_name'];
           $data_val[$i][] =  $value['p_state_name'];

          
           $data_val[$i][] =  $value['architect_first_name']. ' '.$value['architect_last_name'];
           $data_val[$i][] =  $value['architect_email'];
           $data_val[$i][] =  $value['architect_contact_number'];
           $data_val[$i][] =  $value['architect_firm'];
           /*$data_val[$i][] =  $value['architect_address'];
           $data_val[$i][] =  $value['architect_city'];
           $data_val[$i][] =  $value['architect_state'];
           $data_val[$i][] =  $value['architect_zipcode'];
           $data_val[$i][] =  $value['is_architect_ca'];*/
           $data_val[$i][] =  $value['construction_plan_dated'];

           $data_val[$i][] =  $value['landlord_contact_person'];
           $data_val[$i][] =  $value['landlord_email'];
           /*$data_val[$i][] =  $value['landlord_phone'];
           $data_val[$i][] =  $value['landlord_address'];
           $data_val[$i][] =  $value['landlord_city'];
           $data_val[$i][] =  $value['landlord_state'];
           $data_val[$i][] =  $value['landlord_zipcode'];
           $data_val[$i][] =  $value['will_landlord_require_special_documentation_for_billing'];
           $data_val[$i][] =  $value['if_special_documentation_required_if_yes_list'];

           $data_val[$i][] =  $value['lender_or_bank_contact_person'];*/
           $data_val[$i][] =  $value['lender_email'];
           /*$data_val[$i][] =  $value['lender_phone'];
           $data_val[$i][] =  $value['bank_require_special_documentation_for_billing_project_closeout'];
           $data_val[$i][] =  $value['lender_special_documentation_list_requirements'];
           $data_val[$i][] =  $value['lender_address'];
           $data_val[$i][] =  $value['lender_city_name'];
           $data_val[$i][] =  $value['lender_state_name'];
           $data_val[$i][] =  $value['lender_zipcode'];*/
           $i++;
        }  
        
        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }
    //export pdf function
    public function actionExportPdf()
    {
        $poroject = new Project();
        $data = $poroject->getProjectData();
     
        $content = $this->renderPartial('_pdf', [
                     'model' => $data,
                     ]);
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
        'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
        'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Factuur',
                'subject' => 'Generating PDF files via yii2-mpdf extension has never been easy'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="50" style = "display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }

     /**
     * Get Lender Data.
     *  In this image function.
     */
    public function actionGetLender($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = Lender::find()->joinWith(['state','city'])->where(['lender.is_delete' => INACTIVE])->andWhere('lender.id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model,'state' => $model->state->state_name,'city' => $model->city->name];
           return \yii\helpers\Json::encode($model1);
        }
    }
}