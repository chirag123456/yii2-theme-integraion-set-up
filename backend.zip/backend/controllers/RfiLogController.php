<?php

namespace backend\controllers;
ini_set('memory_limit', '512M');


use Yii;
use common\models\rfi\Rfi;
use common\models\project\Project;
use common\models\rfi\RfiSearch;
use common\models\rfi\RfiForm;
use yii\web\Controller;
use yii\helpers\Url;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\components\CustController;
use yii\web\Response; 
use yii\web\UploadedFile;
use yii\bootstrap\ActiveForm;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;
use yii\db\Query;

/**
 * RfiLogController implements the CRUD actions for Rfi model.
 */
class RfiLogController extends CustController 
{
    /**
     * Lists all Rfi models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RfiSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Rfi model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = Rfi::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['rfi-log/index']);
        }

        return $this->render('view', ['model' => $model]);
    }

    //export pdf function
    public function actionExportPdf()
    {
        
        $data = Rfi::find()->where(['is_delete' => INACTIVE])->all();
     
        $content = $this->renderPartial('_pdf', [
                     'model' => $data, 
                     ]);
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
        'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
        'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Factuur',
                'subject' => 'Generating PDF files via yii2-mpdf extension has never been easy'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="50" style = "display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
}