<?php

/*
 * To change this license header, choose License Headers in Project Properties. 
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\controllers;

use Yii;
use common\models\user\User;
use common\models\userrole\UserAccess;
use common\models\userrole\AuthAssignment;
use backend\components\CustController;
use common\models\user\UserSearch;
use common\models\user\UserForm;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use common\models\ChangePasswordForm;
use backend\components\CommonFunctions;
 
/**
 * User Controller implements the CRUD actions.
 */
class UserController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

     /**
     * Add Action
     *  In this action Add of data.
     */
    public function actionAdd() {
        $model = new UserForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $user = new User();
            $user->attributes = $model->attributes;
            $user->username = $model->first_name;
            $user->created_by = Yii::$app->user->id;
            $user->updated_by = Yii::$app->user->id;
            $user->updated_date = date("Y-m-d H:i:s");
            $user->created_date = date("Y-m-d H:i:s");
            $user->setPassword($model->password);
            $user->generateAuthKey();
            $user->generatePasswordResetToken();

             if (!empty($_POST['UserForm']['user_image'])) {
                $user->user_image = $this->base64_to_image($_POST['UserForm']['user_image'], 'users/image');
            }
            $post = Yii::$app->request->post();
            $role_id = $post['UserForm']['role'];
            $user_acc = UserAccess::findOne(['id'=>$role_id]);
            $role_name = $user_acc->name;

            $auth_assign = new AuthAssignment();
            $auth_assign->item_name = $role_name;
            $auth_assign->created_at = date("Y-m-d H:i:s");
            if ($user->validate()) {
                $user->save();
                $auth_assign->user_id = $user->id;
                $auth_assign->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            } else {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    //'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => DATA_NOT_SAVED,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['user/index']);
        }
        return $this->render('create', [
                    'model' => $model,
                    'subcontractor' => false,  
        ]);
    }

    /**
     * Update Action
     *  In this action Update User of data.
     */
    public function actionUpdate($id) {

        if ($id == 1 && Yii::$app->user->id != 1) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Unauthorized attempt!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['user/index']);
        }

        $details = User::findOne(['id' => $id, 'is_delete' => NOT_DELETED]);

        if (empty($details)) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Invalid data!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['user/index']);
        }
        $model = new UserForm();

        $model->attributes = $details->attributes;

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {
      
            $user = User::findOne(['id' => $id]);
            //$user->username = $model->username;
            $user->attributes = $model->attributes;
            $user->username = $model->first_name;
            $user->first_name=$model->first_name;
            $user->last_name=$model->last_name;
            $user->contact_number = $model->contact_number;
            $user->role = $model->role;
            $user->updated_by = Yii::$app->user->id;
            $user->updated_date = date("Y-m-d H:i:s");

            if (empty($_POST['UserForm']['user_image'])) {
                $user->user_image = $details->user_image;
            } else {
                $user->user_image = $this->base64_to_image($_POST['UserForm']['user_image'], 'user_profile/image');
            }

            if ($user->validate()) {
                if ($user->save()) {
                    if(Yii::$app->user->id == $id)
                    {
                        Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => 'Profile Updated Successfully',
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                        ]);
                        return $this->redirect(['dashboard/index']);
                    }
                    else
                    {
                        if(Yii::$app->user->id == $id)
                        {
                            Yii::$app->getSession()->setFlash('success', [
                            'type' => 'success',
                            'duration' => 12000,
                            'image' => 'glyphimage glyphimage-ok-sign',
                            'message' => 'Profile Updated Error',
                            'title' => 'User Updated',
                            'positonY' => 'top',
                            'positonX' => 'right'
                            ]);
                            return $this->redirect(['dashboard/index']);
                        }
                        Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                        ]);
                    }
                    
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

            if (isset($_GET['page'])) {
                return $this->redirect(['user/index?page=' . $_GET['page']]);
            } else {
                return $this->redirect(['user/index']);
            }
        }

        return $this->render('edit-user', [
                    'model' => $model,
                    'subcontractor' => 0,
        ]);
    }

    /**
     * Admin Profile Action
     *  In this action show Admin Profile of data.
     */
    public function actionAdminProfile() {
        $model = User::findOne(['id' => Yii::$app->user->identity->id]);

        return $this->render('profile', [
                    'model' => $model,
        ]);
    }

    /**
     * Admin Profile Action
     *  In this action Change Password of data.
     */
    public function actionChangePassword() {

        if (Yii::$app->user->identity->id != $_GET['id']) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Invalid data!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['dashboard/index']);
        }
        $model = new ChangePasswordForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                return $errors;
            } else {
               // Yii::$app->user->logout();

                if ($model->resetPassword()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => 'Password has been changed successfully',
                        'title' => 'Password Change',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(\Yii::$app->urlManager->createUrl("dashboard/"));
                }
            }
        }
        return $this->render('changepassword', ['model' => $model]);
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = User::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    }

    /**
     * Delete Action
     *  In this action Delete of data.
     */
    public function actionDelete($id) {
        if ($id) {
            $model = User::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

    /**
     *  View Action
     *  In this action User View of data.
     */
    public function actionView($id) {

        $model = User::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['user/index']);
        }

        return $this->render('view-user', ['model' => $model]);
    }

    public function actionImageUrl($id) {
        $user = User::findOne($id);
        header("Content-type: image/png");
        echo $user->image;
    }

    /**
     * base_64_image function
     *  In this image function.
     */
   public function base64_to_image($imageData) {

        $basePath = dirname(\Yii::$app->basePath); 
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile/' . DIRECTORY_SEPARATOR . $imagename;
        file_put_contents($file, $image_base64);

        return $imagename;
        //return '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile' . DIRECTORY_SEPARATOR . $imagename;    
    }
}
