<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\state\State;
use common\models\state\StateForm;
use common\models\state\StateSearch;

use backend\components\CustController;
/**
 * StateController
 *  This controller used for State list , add , update , delete.
 * @author Xceltec01
 * @since Jun,2017
 */
class StateController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new StateSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Add Action
     *  In this action use for Add new data in State.
     * @return
     */
    public function actionAdd() {
        $model = new StateForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $state = new State();
                $state->attributes = $model->attributes;
                $state->state_name = trim($model->state_name);
                $state->created_by = Yii::$app->user->identity->id;
                $state->updated_by = Yii::$app->user->identity->id;
                $state->created_date = date("Y-m-d H:i:s");
                $state->updated_date = date("Y-m-d H:i:s");
                $state->is_active = ACTIVE;
                $state->is_delete = NOT_DELETED;

                if ($state->validate()) {
                    $state->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'State'.ADDED,
                        'title' => 'State Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['state/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'State not'.ADDED,
                        'title' => 'State Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['state/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Update Action
     *  In this action use for update State.
     * $id is State id
     * @return mixed
     */
    public function actionUpdate($id) {
        $details = State::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
       if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['state/index']);
        }
        
        $StateForm = new StateForm();
        $model = $StateForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $state = State::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $state->attributes = $model->attributes;
                $state->state_name = trim($model->state_name);
                $state->created_by = Yii::$app->user->identity->id;
                $state->updated_by = Yii::$app->user->identity->id;
                $state->created_date = date("Y-m-d H:i:s");
                $state->updated_date = date("Y-m-d H:i:s");
                
                if ($state->validate()) {
                    $state->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'State'.UPDATED,
                        'title' => 'State Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    $transaction->commit();

                    return $this->redirect(['state/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'State not'.UPDATED,
                        'title' => 'State Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['state/index']);
                }
            }
        }
        return $this->render('edit_state', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for State.
     * $id is State id
     * @return mixed
     */
    public function actionStatus($id) {
        $model = State::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'State'.DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'State'.ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['state/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete State data.
     * $id is State id
     * @return
     */
    public function actionDelete($id) {
        if ($id) {
            $model = State::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'State'.DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['state/index']));
            }
        }
    }
	
	/**
     * SetState Action
     * @dependent drop down on country
     * $id is country id
     * @return
     */
    public function actionSetState($id) {
		
        if (Yii::$app->request->isAjax) {
		
            $model = State::find()
					->where(['country_id' => $id , 'is_delete' => NOT_DELETED , 'is_active' => ACTIVE])
					->orderBy(['id'=>SORT_DESC])->all();
        
            $modelcount = count((array) $model);

            if ($modelcount > 0) {

                echo "<option>Please Select State</option>";
                foreach ($model as $action) {
                    
                    echo "<option value='" . $action->id . "'>" . $action->state_name . "</option>";
                }
            } else {
                echo "<option>Please Select Country</option>";
            }
        }
        return false;
    }

}
