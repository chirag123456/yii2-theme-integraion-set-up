<?php

namespace backend\controllers;

use Yii;
use common\models\module\Module;
use common\models\module\ModuleForm;
use common\models\module\ModuleSearch;
use yii\web\Controller;
use backend\components\CustController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\module\Action;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
/**
 * ModuleController implements the CRUD actions for Module model.
 */
class ModuleController extends CustController
{
    /**
     * Lists all Module models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ModuleSearch();
        $dataProvider = $searchModel->searchmodule(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Module model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Module model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new ModuleForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {
            $post = Yii::$app->request->post();
            $module = new Module();
            $module->attributes = $model->attributes;
            
            $mod_name = htmlentities($model->module_name);
            $mod_name = preg_replace('/(?<!\ )[A-Z]/', ' $0', $mod_name);
            $mod_name = str_replace(' ', '-', strtolower($mod_name));
            $mod_name = ltrim($mod_name, '-');

            $module->module_name = $mod_name;
            $module->icon = $post['ModuleForm']['icon'];
            $module->created_by = Yii::$app->user->identity->id;
            $module->updated_by = Yii::$app->user->identity->id;
            $module->updated_date = date("Y-m-d H:i:s");
            $module->created_date = date("Y-m-d H:i:s");
            $module->is_active = ACTIVE;
            $module->is_delete = INACTIVE;

            if($module->validate() && $module->save()){
                //$module->save();

                $post['ModuleForm']['action_name'] = $post['action_name'];
                unset($post['action_name']);
        
                foreach ($post['ModuleForm']['action_name'] as $key => $val) {
                    $action = new Action();
                    //$action->attributes = $action->attributes;
                    $action->action_name = $val;
                    $action->created_by = Yii::$app->user->identity->id;
                    $action->updated_by = Yii::$app->user->identity->id;
                    $action->updated_date = date("Y-m-d H:i:s");
                    $action->created_date = date("Y-m-d H:i:s");
                    $action->is_active = ACTIVE;
                    $action->is_delete = INACTIVE;
                    $action->module_id = $module->id;    
                    $action->save();
                }
                
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['module/index']);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Module model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = Module::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['module/index']);
        }

        $model = new ModuleForm();

        $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $post = Yii::$app->request->post();
            $module = Module::find()->where(['id' => $_GET['id']])->one();
            
            $mod_name = htmlentities($model->module_name);
            $mod_name = preg_replace('/(?<!\ )[A-Z]/', ' $0', $mod_name);
            $mod_name = str_replace(' ', '-', strtolower($mod_name));
            $mod_name = ltrim($mod_name, '-');
        
            $module->module_name = $mod_name;
            $module->icon = $post['ModuleForm']['icon'];
            $module->updated_by = Yii::$app->user->identity->id;
            $module->updated_date = date("Y-m-d H:i:s");
            $module->is_active = ACTIVE;
            $module->is_delete = INACTIVE;

            if($module->validate() && $module->save()){

                $post['ModuleForm']['action_name'] = $post['action_name'];
                unset($post['action_name']);
       
                $actions = Action::deleteAll(['module_id' => $_GET['id']]);
                foreach ($post['ModuleForm']['action_name'] as $key => $val) {
                    $action = new Action();
                    
                    //$action->attributes = $action->attributes;
                    $action->action_name = $val;
                    $action->created_by = Yii::$app->user->identity->id;
                    $action->updated_by = Yii::$app->user->identity->id;
                    $action->updated_date = date("Y-m-d H:i:s");
                    $action->created_date = date("Y-m-d H:i:s");
                    $action->is_active = ACTIVE;
                    $action->is_delete = INACTIVE;
                    $action->module_id = $module->id;    
                    $action->save();
                }
                Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Automotive Product Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['module/index']);
            }else{
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['module/index']);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Module model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        //if ($id) {
            $model = Module::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                $actions = Action::find()->where(['module_id' => $id])->all();
                foreach($actions as $key=>$val){
                    $val->is_delete = DELETED;
                    $val->save(false);
                }
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['module/index']);
            }
        //}
    }

    public function actionStatus($id) {
        $model = Module::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['module/index']);
    }
}
