<?php

namespace backend\controllers;

use Yii;
use common\models\submittal\Submittal;
use common\models\submittal\SubmittalSearch; 
use common\models\submittal\SubmittalForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\components\CustController;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CommonFunctions;
use common\models\submittal\SubmittalItem;

/**
 * SubmittalController implements the CRUD actions for Submittal model.
 */
class SubmittalController extends CustController
{

    /**
     * Lists all Submittal models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SubmittalSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Submittal model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */ 
    public function actionView($id)
    {
        $model = Submittal::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000, 
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['submittal/index']);
        }
        $model1 = SubmittalItem::find()->where(['is_delete' => INACTIVE])->andWhere('submittal_id = ' . $id)->all();
        return $this->render('view', ['model' => $model,'model1' => $model1]);
    } 

    /**
     * Creates a new Submittal model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new SubmittalForm(); 

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) { 
            // echo "<pre>";
            // print_r(Yii::$app->request->post()); exit();
            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();
            $submittal = new Submittal();
            $submittal->attributes = $model->attributes;            
            $submittal->from_user_id = Yii::$app->user->identity->id;
            $submittal->created_by = Yii::$app->user->identity->id;
            $submittal->updated_by = Yii::$app->user->identity->id;
            $submittal->updated_date = date("Y-m-d H:i:s");
            $submittal->created_date = date("Y-m-d H:i:s");
            $submittal->is_active = ACTIVE;
            $submittal->is_delete = INACTIVE;
            if($submittal->validate()){
                $submittal->save();
                $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['SubmittalItemForm']['copies']  as  $value) { 
                         
                        $submittalItem = new SubmittalItem();
                        $submittalItem->submittal_id = $submittal->id;
                        $submittalItem->copies = $_POST['SubmittalItemForm']['copies'][$i];
                        $submittalItem->item_date = $_POST['SubmittalItemForm']['item_date'][$i];
                        $submittalItem->number = $_POST['SubmittalItemForm']['number'][$i];
                        $submittalItem->description = $_POST['SubmittalItemForm']['description'][$i];
                        $submittalItem->created_by = Yii::$app->user->identity->id;
                        $submittalItem->updated_by = Yii::$app->user->identity->id;
                        $submittalItem->created_date = date("Y-m-d H:i:s");
                        $submittalItem->updated_date = date("Y-m-d H:i:s");
                        $submittalItem->is_active = ACTIVE;
                        $submittalItem->is_delete = NOT_DELETED;
                        if($submittalItem->validate())
                        { 
                            $submittalItem->save();
                        }
                        else
                        {
                            $transaction->rollBack();
                            echo "<pre>"; print_r($submittalItem->getErrors()); exit;
                        }
                        $i++;
                    }
                    
                    $transaction->commit();
                    $submittal->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'Rfi Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                $transaction->rollBack();
                echo "<pre>"; print_r($submittal->getErrors()); exit();
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['submittal/index']);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Submittal model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = Submittal::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['submittal/index']);
        }
        $model = new SubmittalForm();

        $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {

            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();      
            $submittal = Submittal::findOne(['id' => $id]);
            $submittal->attributes = $model->attributes;
            $submittal->from_user_id = Yii::$app->user->identity->id;
            $submittal->updated_by = Yii::$app->user->id;
            $submittal->updated_date = date("Y-m-d H:i:s");

            if ($submittal->validate()) {
                    $submittal->save();
                     \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('submittal_item', ['submittal_id' => $id])
                    ->execute();

                    $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['SubmittalItemForm']['copies']  as  $value) { 
                         
                        $submittalItem = new SubmittalItem();
                        $submittalItem->submittal_id = $submittal->id;
                        $submittalItem->copies = $_POST['SubmittalItemForm']['copies'][$i];
                        $submittalItem->item_date = $_POST['SubmittalItemForm']['item_date'][$i];
                        $submittalItem->number = $_POST['SubmittalItemForm']['number'][$i];
                        $submittalItem->description = $_POST['SubmittalItemForm']['description'][$i];
                        $submittalItem->created_by = Yii::$app->user->identity->id;
                        $submittalItem->updated_by = Yii::$app->user->identity->id;
                        $submittalItem->created_date = date("Y-m-d H:i:s");
                        $submittalItem->updated_date = date("Y-m-d H:i:s");
                        $submittalItem->is_active = ACTIVE;
                        $submittalItem->is_delete = NOT_DELETED;
                        if($submittalItem->validate())
                        { 
                            $submittalItem->save();
                        }
                        else
                        {
                            $transaction->rollBack();
                            echo "<pre>"; print_r($submittalItem->getErrors()); exit;
                        }
                        $i++;
                    }

                    $transaction->commit();
                    $submittal->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Rfi Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
            }

            return $this->redirect(['submittal/index']);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Submittal model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    
    public function actionDelete($id)
    {
        if ($id) {
            $model = Submittal::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['submittal/index']);
            }
        }
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = Submittal::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else { 
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['submittal/index']);
    } 

    /**
     * Get Lender Data.
     *  In this image function.
     */
    public function actionGetUser($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = \common\models\user\User::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model];
           return \yii\helpers\Json::encode($model1);
        }
    }
}