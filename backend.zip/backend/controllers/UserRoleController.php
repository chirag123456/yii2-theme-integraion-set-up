<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\userrole\UserRole;
use common\models\userrole\UserRoleSearch;
//use common\models\RolePermission;
use backend\components\CustController;
use common\models\userrole\UserAccess;
use common\models\userrole\AuthAssignment;

/**
 * UserRoleController
 *  This controller used for Area list , add , update , delete.
 * @author Xceltec01
 * @since Jun,2017
 */
class UserRoleController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
	
        $searchModel = new UserRoleSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $details = UserRole::find()->all();
       
        return $this->render('index', [
                        'searchModel' => $searchModel,
                        'dataProvider' => $dataProvider,
        ]);
        
    }

    /**
     * View Action
     *  In this action use for View data in User Role.
     * @return
     */
    public function actionView($id) {
        $details = UserAccess::find()->where('name = "'.$id.'"')->one();
        
        $data_arr = [];
        foreach($details as $key=>$val){
            $data_arr['role_name'] = $details->name;
            $json_mod = json_decode($details->access);
            
            if(!empty($json_mod)){
                foreach($json_mod as $k=>$v){
                    $data_arr['modules'][$k] = $v->module;
                    
                    foreach($v->act as $ak=>$av){
                        $data_arr['actions'][$k][$ak] = $av;
                    }
                }
            }
        }

        return $this->render('view', [
                        'data' => $data_arr
        ]);
        
    }
	
    /**
     * Add Action
     *  In this action use for Add new data in User Role.
     * @return
     */
    public function actionAdd() {
        $model = new \common\models\userrole\UserRoleForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
       
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $modelrole = new UserRole();
                $modelrole->type = '1';
                $modelrole->name = $model->name;
                $modelrole->created_at = date("Y-m-d H:i:s");
                $modelrole->updated_at = date("Y-m-d H:i:s");
                
                $model_user_access = new UserAccess();
    	    	$model_user_access->name = $model->name;                
                if( isset( $_POST['access_role'] ) && ( $_POST['access_role'] != null ) ){
                    $module_arr = [];
                    $access_mod = $_POST['access_role'];
                    $i = 0; $p=0;
                    foreach($access_mod as $k=>$v){
                        //$module_arr[$k]['module'] = $v;

                        if(isset($_POST['access_'.$v]) && $_POST['access_'.$v]!=''){ 
                            
                            $module_arr[$p]['module'] = $v;
                            $action_arr = $_POST['access_'.$v];
                            
                            foreach($action_arr as $ackey => $acval){
                                if($p==0)
                                    $module_arr[$p]['act'][$ackey] = $acval;
                                else
                                    $module_arr[$p]['act'][$ackey] = $acval;
                            }
                            $p++;
                        }
                        $i++;
                    }
                    $json_mod = json_encode($module_arr);
                    $model_user_access->access = $json_mod;
                }
                $model_user_access->is_admin = 0;
    		  $model_user_access->status = '1';
          
                if ($model_user_access->validate() && $modelrole->validate()) {
                    $modelrole->save();
                    $model_user_access->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User Role ' . ADDED,
                        'title' => 'User Role Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['user-role/index']);
                } else {
                    echo "<pre>";
                    print_r($modelrole->getErrors());
                    echo "<pre>";
                    print_r($model_user_access->getErrors()); exit();
                     Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User Role not ' . ADDED,
                        'title' => 'User Role Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['user-role/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Update Action
     *  In this action use for update User Role.
     * $id is User Role id
     * @return mixed
     */
    public function actionUpdate($id) {
        $details = UserRole::findOne($id);
       
        if($details == NULL){
		Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['user-role/index']);
        }
      else{
            $userAccess = UserAccess::find()->where(['name' => $details->name])->one();
            $json_arr = json_decode($userAccess->access);
            $module = '';
            $act = '';

             if(!empty($json_arr)){
                foreach($json_arr as $k=>$v){
                    if($module=='')
                        $module = $v->module;
                    else
                        $module = $module.','.$v->module;

                    foreach ($v->act as $ak=>$av){
                        if($act=='')
                            $act = $av;
                        else
                            $act = $act.','.$av;
                        $action['access_'.$v->module] = $act;
                    }
                }
            }
        }
        $UserRoleForm = new \common\models\userrole\UserRoleForm();
        $model = $UserRoleForm->getUpdateModel($details);
        
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $userRole = UserRole::find()->where(['name' => $details->name])->one();
    
                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $userRole->attributes = $model->attributes;
                $userRole->name = $model->name;
                
                $model_user_access = UserAccess::find()->where(['name' => $details->name])->one();
               
                    $userAccess->access = '';  //$userAccess->delete();
            
    		$model_user_access->name = $model->name;
        
                if( isset( $_POST['access_role'] ) && ( $_POST['access_role'] != null ) ){
                    $module_arr = [];
                    $access_mod = $_POST['access_role'];
                    $i = 0;
                    foreach($access_mod as $k=>$v){
                        $module_arr[$k]['module'] = $v;

                        $action_arr = $_POST['access_'.$v];
						
                            foreach($action_arr as $ackey => $acval){
                                $module_arr[$k]['act'][$ackey] = $acval;
                            }
                        
                        $i++;
                    }
					
                    $json_mod = json_encode($module_arr);
                    $model_user_access->access = $json_mod;
				
                }
                	
    		$model_user_access->is_admin = 0; 
                $model_user_access->status = '1';
                
                if ($userRole->validate()) {
                    $userRole->save();
                    $model_user_access->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User Role ' . UPDATED,
                        'title' => 'User Role Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['user-role/index']);
                } else {
                    $transaction->rollBack();
                     Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User Role not ' . UPDATED,
                        'title' => 'User Role Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['user-role/index']);
                }
            }
        }
        
        return $this->render('edit_user_role', [
                    'model' => $model
        ]);
    }
    
    /**
     * Delete Action
     *  In this action use for Status User Role data.
     * $id is User Role id
     * @return
     */
    public function actionStatus($id) {
		
        $model = UserRole::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'User Role' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'User Role' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['user-role/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete User Role data.
     * $id is User Role id
     * @return
     */
    public function actionDelete($id) {
		
        if ($id) {
            $model = UserRole::findOne($id);
            
            if(!empty($model)){
                $userAccess = UserAccess::find()->where(['name' => $model->name])->one();    
                if(!empty($userAccess))
                {
                    $userAccess->delete();
                }
                $model->delete();

                $auth_assign = AuthAssignment::find()->where(['item_name' => $model->name])->one();
                if(!empty($auth_assign))
                {
                    $auth_assign->delete();
                }

                Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User Role' . DELETEDMESSAGE,
                        'title' => 'Active Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                ]);
            }
            return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['user-role/index']));
        }
    }

}