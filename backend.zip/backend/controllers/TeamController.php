<?php
 
namespace backend\controllers;

use Yii;
use yii\helpers\Url;
use common\models\team\Team;
use common\models\team\TeamSearch;
use common\models\team\TeamForm;
use yii\web\Controller;
use backend\components\CustController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;

/**
 * TeamController implements the CRUD actions for Team model.
 */
class TeamController extends CustController
{
    /**
     * Lists all Team models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TeamSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Team model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        if($id)
        {
            $details = Team::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
            if(!empty($details))
            {
                return $this->render('view', [
                    'model' => $details,
                ]);    
            }
            else
            {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['team/index']);
            }
        }
        else
        {
            Yii::$app->getSession()->setFlash('danger', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['team/index']);
        }
    }

    /**
     * Creates a new Team model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new TeamForm();

         if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {

            $team = new Team();
            $team->attributes = $model->attributes;
            
            $team->created_by = Yii::$app->user->identity->id;
            $team->updated_by = Yii::$app->user->identity->id;
            $team->updated_date = date("Y-m-d H:i:s");
            $team->created_date = date("Y-m-d H:i:s");
            $team->is_active = ACTIVE;
            $team->is_delete = INACTIVE;
            if($team->validate()){
                $team->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['team/index']);
        } 
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Team model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = Team::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['team/index']);
        }
 
        $model = new TeamForm();

        $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $team = Team::find()->where(['id' => $_GET['id']])->one();
            $team->attributes = $model->attributes;
            $team->updated_by = Yii::$app->user->identity->id;
            $team->updated_date = date("Y-m-d H:i:s");
            $team->is_active = ACTIVE;
            $team->is_delete = INACTIVE;
            if($team->validate() && $team->save()){
                Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['team/index']);
            }else{
                echo "<pre>"; print_r($team->getErrors()); exit();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['team/index']);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Team model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        if ($id) {
            $model = Team::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top', 
                    'positonX' => 'right'
                ]);
                return $this->redirect(['team/index']);
            }
            else
            {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
                return $this->redirect(['team/index']);
            }
        }
        else
        {
            Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
            return $this->redirect(['team/index']);        
        }
    }

    /**
     * Active / Inactive an existing ProjectScheduleManagement model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */

    public function actionStatus($id) {
        $model = Team::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['team/index']);        
    }

    /**
     * SetUser Action
     * @dependent drop down for user _form
     * $id is state id
     * @return
     */
    public function actionSetAction($id) {
        if (Yii::$app->request->isAjax) {

            $model = \common\models\user\User::find()->where(['role' => $id])->andWhere(['is_delete' => NOT_DELETED , 'is_active' => ACTIVE])->orderBy(['id'=>SORT_DESC])->all();
        
            $modelcount = count((array) $model);

            if ($modelcount > 0) {

                echo "<option>Please Select User</option>";
                foreach ($model as $action) {
                    
                    echo "<option value='" . $action->id . "'>" . $action->email . "</option>";
                }
            } else {
                echo "<option>Please Select Role</option>";
            }
        }
        return false;
    }

    /**
     * Get User Data.
     *  In this image function.
     */
    public function actionGetUser($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = \common\models\user\User::find()->joinWith(['state','city'])->where(['users.is_delete' => INACTIVE])->andWhere('users.id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model,'state' => isset($model->state->state_name) ? $model->state->state_name : '','city' => isset($model->city->name) ? $model->city->name : ''];
           return \yii\helpers\Json::encode($model1);
        }
    }

    /**
     * Get SubcontractorItem Data.
     *  In this image function.
     */
    public function actionSetItem($id)
    {
        if (Yii::$app->request->isAjax) {
            $model =\common\models\user\SubcontractorItem::find()->select('item_id')->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED,'user_id' => $id])->asArray()->all();
            $i = 0;
            foreach ($model as  $value) {
                $arr[$i] = $value['item_id'];
                $i++;
            }
            $model1 =\common\models\itemwork\ItemWork::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['IN', 'id', $arr])->all();
            $modelcount = count((array) $model1);

            if ($modelcount > 0) {

                echo "<option>Please Select Item</option>";
                foreach ($model1 as $action) {
                    
                    echo "<option value='" . $action->id . "'>" . $action->cost_code .' - '.$action->name ."</option>";
                }
            } else {
                echo "<option>Please Select Role</option>";
            }
        }
        return false;
    }

    //Export pdf for all action Item data
    public function actionExportPdf() 
    {
        $data = Team::find()->where(['is_delete' => INACTIVE])->all();

        if(empty($data))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
            return $this->redirect(['action-item/index']);
        }
        
        $content = $this->renderPartial('_pdf', [
                     'data' => $data,
        ]);
        //echo "<pre>"; print_r($content); exit();
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Team Data',
                'subject' => 'Team Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }

    /**
     * Export CSV of Project Data
     * 
     */
    public function actionExportExcel() 
    {

        $id = 1;
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Team".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');

        $data_key1 = [

                        'Project',
                        'Role',
                        'User',
                        'Business Name',
                        'Contact Name',
                        'Email',
                        'Phone Number',
                        'Fax',
                        'Address',
                        'Item',
        ];
        fputcsv($output, $data_key1);
        
        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];

        $data = Team::find()->where(['is_delete' => INACTIVE])->all();
       
        foreach ($data as $value) {  
            
           $data_val[$i][] =  $value->project->project_name;
           $data_val[$i][] =  $value->role->name;
           $data_val[$i][] =  $value->user->email;
           $data_val[$i][] =  $value->business_name;
           $data_val[$i][] =  $value->contact_name;
           $data_val[$i][] =  $value->email;
           $data_val[$i][] =  $value->phone;
           $data_val[$i][] =  isset($value->fax) ?  $value->fax : '';
           $data_val[$i][] =  $value->address;
           $data_val[$i][] =  isset($value->item) ?  $value->item->cost_code.' - '.$value->item->name : '';
           $i++;
        }  
        //echo "<pre>"; print_r($data_val); exit();
        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }
}