<?php 

namespace backend\controllers; 
 
use Yii;
use yii\helpers\Url;
use common\models\order\Order;
use common\models\project\Project;
use common\models\order\OrderForm;
use common\models\order\OrderSearch;
use common\models\order\OrderItem;
use common\models\order\OrderItemForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CommonFunctions;
use backend\components\CustController;

/**
 * OrderController implements the CRUD actions for Order model.
 */
class BuyoutLogController extends CustController
{
    /**
     * Lists all Order models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new OrderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Order model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = Order::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['purchase-order/index']);
        }

        $model1 = OrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('order_id = ' . $id)->all();
        
        return $this->render('view', [
            'model' => $model,
            'model1' => $model1
        ]);
    }

    

    // Generate Invoice Function
    public function actionExportOnePdf($id)
    {
        $model = Order::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        
        if(empty($model))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['buyout-log/index']);
        }
         $model1 = OrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('order_id = ' . $id)->all();
        $content = $this->renderPartial('_pdf', [  
                     'model' => $model,
                     'model1' => $model1
                     ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}.detail1-view {
    margin-left:20px;
    margin-bottom:20px;
    float:left;
    width: 300px; 
    border:1px solid #000;
}',
            'options' => [
                'title' => 'Buyout Log',
                'subject' => 'Buyout Log'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
}