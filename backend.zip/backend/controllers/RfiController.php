<?php

namespace backend\controllers;

use Yii;
use common\models\rfi\Rfi;
use common\models\project\Project;
use common\models\rfi\RfiSearch;
use common\models\rfi\RfiForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\components\CustController;
use yii\web\Response; 
use yii\web\UploadedFile;
use yii\bootstrap\ActiveForm;

/**
 * RfiController implements the CRUD actions for Rfi model.
 */
class RfiController extends CustController 
{
    /**
     * Lists all Rfi models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RfiSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Rfi model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = Rfi::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['rfi/index']);
        }

        return $this->render('view', ['model' => $model]);
    } 

    /**
     * Creates a new Rfi model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new RfiForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {

            $rfi = new Rfi();
            $rfi->attributes = $model->attributes;
            
            $rfi->created_by = Yii::$app->user->identity->id;
            $rfi->updated_by = Yii::$app->user->identity->id;
            $rfi->updated_date = date("Y-m-d H:i:s");
            $rfi->created_date = date("Y-m-d H:i:s");
            $rfi->is_active = ACTIVE;
            $rfi->is_delete = INACTIVE;
            if($rfi->validate()){
                $rfi->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'Rfi Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                echo "<pre>"; print_r($rfi->getErrors()); exit();
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['rfi/index']);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Rfi model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = Rfi::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['rfi/index']);
        }
        $model = new RfiForm();

        $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {
      
            $rfi = Rfi::findOne(['id' => $id]);
            $rfi->attributes = $model->attributes;
            
            $rfi->updated_by = Yii::$app->user->id;
            $rfi->updated_date = date("Y-m-d H:i:s");

            

            if ($rfi->validate()) {
                if ($rfi->save()) {
                    
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Rfi Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
            }

            return $this->redirect(['rfi/index']);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Rfi model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        if ($id) {
            $model = Rfi::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = Rfi::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    } 

    /**
     * Get Project Data.
     *  
     */
    public function actionGetProject($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = Project::find()->joinWith(['state','city'])->where(['project_management.is_delete' => INACTIVE])->andWhere('project_management.id = ' . $id)->one();
           $model1 = [];
           $model1 = ['model' => $model,'state' => $model->state->state_name,'city' => $model->city->name];
           return \yii\helpers\Json::encode($model1);
        }
    }
}