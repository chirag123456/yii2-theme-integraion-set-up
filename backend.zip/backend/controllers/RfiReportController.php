<?php

namespace backend\controllers;

use Yii;
use common\models\rfi\Rfi;
use common\models\project\Project;
use common\models\rfi\RfiSearch;
use common\models\rfi\RfiReportForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\components\CustController;
use yii\web\Response; 
use yii\bootstrap\ActiveForm;

/**
 * RfiController implements the CRUD actions for Rfi model.
 */
class RfiReportController extends CustController 
{
    /**
     * Lists all Rfi models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RfiSearch();
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
        $model = new RfiReportForm();
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'model' => $model
        ]);
    }

    /**
     * Displays a single Rfi model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $model = Rfi::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['rfi-report/index']);
        }

        return $this->render('view', ['model' => $model]);
    }

    /**
     * Export CSV of Rfi Data
     * 
     */
    public function actionExportExcel() 
    {
        //print_r($_GET); exit();
        
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Rfi Data Report".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');

        $data_key1 = [
                        'Rfi Code',
                        'Project Name',
                        'Project Number',
                        'Project Location',
                        'Client',
                        'Architect',
                        'Subcontractor',
                        'Response',
                        'Response By',
                        'Rfi Date',
                    ];

        fputcsv($output, $data_key1);
        
        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];

        $searchModel = new RfiSearch();
        $data = $searchModel->search2(Yii::$app->request->queryParams);
        
        foreach ($data as $value) {
            
           $data_val[$i][] =  $value->rfi_code;
           $data_val[$i][] =  $value->project->project_name;
           $data_val[$i][] =  $value->project->project_number;
           $data_val[$i][] =  $value->project->project_physical_address;
           $data_val[$i][] =  $value->client->client_name.' '.$value->client->client_email;
           $data_val[$i][] =  $value->architect->first_name.' '.$value->architect->last_name.' ' .$value->architect->email;
           $data_val[$i][] =  $value->subContractor->first_name.' '.$value->subContractor->last_name.' ' .$value->subContractor->email;
           $data_val[$i][] =  $value->response;
           $data_val[$i][] =  $value->responded_by;
           $data_val[$i][] =  $value->rfi_date;
           $i++;
        }
        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }
}