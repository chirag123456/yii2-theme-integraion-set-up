<?php
namespace backend\controllers;
ini_set('memory_limit', '512M');

use Yii;
use yii\helpers\Url;
use yii\web\Response;
use yii\web\Controller;
use yii\helpers\ArrayHelper;
use yii\bootstrap\ActiveForm;
use common\models\projectbudget\ProjectBudget;
use common\models\projectbudget\ProjectBudgetSearch;
use common\models\projectbudget\ProjectBudgetForm;
use common\models\projectbudget\ProjectBudgetItemForm;
use common\models\projectbudget\ProjectBudgetItem;
use backend\components\CustController;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;
use yii\db\Query;
/** 
 * ProjectBudgetController
 *  This controller used for ProjectBudget list , add , update , delete.
 */ 
class ProjectBudgetController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {		
        $searchModel = new ProjectBudgetSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
		return $this->render('index', [
				'searchModel' => $searchModel,
				'dataProvider' => $dataProvider,
		]);        
    }
	
    /**
     * Add Action
     *  In this action use for Add new data in Country.
     * @return
     */
    public function actionAdd() {		

        $model = new ProjectBudgetForm();
        $model1 = new ProjectBudgetItemForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                 
                $projectBudget = new ProjectBudget();
                $projectBudget->attributes = $model->attributes;
                $projectBudget->created_by = Yii::$app->user->identity->id;
                $projectBudget->updated_by = Yii::$app->user->identity->id;
                $projectBudget->created_date = date("Y-m-d H:i:s");
                $projectBudget->updated_date = date("Y-m-d H:i:s");
                $projectBudget->is_active = ACTIVE;
                $projectBudget->is_delete = NOT_DELETED;
	
                if ($projectBudget->validate()) {
                    $projectBudget->save();
                    $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['ProjectBudgetItemForm']['item_id']  as  $value) {
                        
                        $projectBudgetItem = new ProjectBudgetItem();
                        $projectBudgetItem->project_id = $projectBudget->project_id;
                        $projectBudgetItem->project_budget_id = $projectBudget->id;
                        $projectBudgetItem->item_id = $_POST['ProjectBudgetItemForm']['item_id'][$i];
                        $projectBudgetItem->sub_contractor_id = $_POST['ProjectBudgetItemForm']['sub_contractor_id'][$i];
                        $projectBudgetItem->cost = $_POST['ProjectBudgetItemForm']['cost'][$i];
                        $projectBudgetItem->comment = $_POST['ProjectBudgetItemForm']['comment'][$i];
                        $projectBudgetItem->sub_contractor_estimate_cost = $_POST['ProjectBudgetItemForm']['sub_contractor_estimate_cost'][$i];
                        $projectBudgetItem->created_by = Yii::$app->user->identity->id;
                        $projectBudgetItem->updated_by = Yii::$app->user->identity->id;
                        $projectBudgetItem->created_date = date("Y-m-d H:i:s");
                        $projectBudgetItem->updated_date = date("Y-m-d H:i:s");
                        $projectBudgetItem->is_active = ACTIVE;
                        $projectBudgetItem->is_delete = NOT_DELETED;
                        $projectBudgetItem->save();
                        $i++;
                    }
                    
                    $transaction->commit();

                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Project Budget ' . ADDED,
                        'title' => 'Project Budget Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-budget/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Project Budget not added',
                        'title' => 'Project Budget Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-budget/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model,
                    'model1' => $model1
        ]);
    }

    /**
     * Update Action
     *  In this action use for update ProjectBudget.
     * $id is ProjectBudget id
     * @return mixed
     */
    public function actionUpdate($id) {

        $details = ProjectBudget::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       if($details == NULL){
					Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-budget/index']);
        }
        $projectBudgetForm = new ProjectBudgetForm();
        $model = $projectBudgetForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $projectbudget = ProjectBudget::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $projectbudget->attributes = $model->attributes;
                $projectbudget->updated_by = Yii::$app->user->identity->id;                
                $projectbudget->updated_date = date("Y-m-d H:i:s");                
                if ($projectbudget->validate()) {
                    $projectbudget->save();
                    /*$projectbudgetItem1 = ProjectBudgetItem::find()->where(['project_budget_id' => $id]);
                    $projectbudgetItem1->delete();*/
                    \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('project_budget_item', ['project_budget_id' => $id])
                    ->execute();
                    $postdata = $_POST;                
                    $i = 0;

                    foreach ($postdata['ProjectBudgetItemForm']['item_id']  as  $value) {
                        
                        $projectBudgetItem = new ProjectBudgetItem();
                        $projectBudgetItem->project_id = $projectbudget->project_id;
                        $projectBudgetItem->project_budget_id = $projectbudget->id;
                        $projectBudgetItem->item_id = $_POST['ProjectBudgetItemForm']['item_id'][$i];
                        $projectBudgetItem->cost = $_POST['ProjectBudgetItemForm']['cost'][$i];
                        $projectBudgetItem->comment = $_POST['ProjectBudgetItemForm']['comment'][$i];
                        $projectBudgetItem->sub_contractor_id = $_POST['ProjectBudgetItemForm']['sub_contractor_id'][$i];
                        $projectBudgetItem->sub_contractor_estimate_cost = $_POST['ProjectBudgetItemForm']['sub_contractor_estimate_cost'][$i];
                        $projectBudgetItem->created_by = Yii::$app->user->identity->id;
                        $projectBudgetItem->updated_by = Yii::$app->user->identity->id;
                        $projectBudgetItem->created_date = date("Y-m-d H:i:s");
                        $projectBudgetItem->updated_date = date("Y-m-d H:i:s");
                        $projectBudgetItem->is_active = ACTIVE;
                        $projectBudgetItem->is_delete = NOT_DELETED;
                        $projectBudgetItem->save();
                        $i++;
                    }

                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Project Budget ' . UPDATED,
                        'title' => 'Project Budget Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['project-budget/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Project Budget not updated',
                        'title' => 'Academic Year Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-budget/index']);
                }
            }
        }
        return $this->render('edit_projectbudget', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for Project Budget.
     * $id is Project Budget id
     * @return mixed
     */
    public function actionStatus($id) {
		
        $model = ProjectBudget::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Project Budget ' . DEACTIVATED,
                'title' => 'Project Budget Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Project Budget ' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['project-budget/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete ProjectBudget data.
     * $id is ProjectBudget id
     * @return
     */
    public function actionDelete($id) {
		
        if ($id) {
            $model = ProjectBudget::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Project Budget ' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['project-budget/index']));
            }
        }
    }

    /**
     *  View Action
     *  In this action User View of data.
     */
    public function actionView($id) {

        $model = ProjectBudget::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['project-budget/index']);
        }
        $model1 = ProjectBudgetItem::find()->where(['is_delete' => INACTIVE])->andWhere('project_budget_id = ' . $id)->all();
        return $this->render('view', ['model' => $model,'model1' => $model1]);
    }

    /**
     *  View Action
     *  In this action Project Budget Export Data to Excel  of data.
     */
    public function actionExportData11()
    {
        $id = 1;
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Project Budget".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');
        $data_key1 = ['Project Name', 'Sub Contractor Total Cost','Project Budget Total Cost'];
        $data_key2 = ['Item Work Name', 'Item Work Cost','Comment', 'Sub Contractor','Sub Contractor Total Cost'];

        fputcsv($output, $data_key1);
        fputcsv($output, $data_key2);
        $i = 0;
        $J = 0;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];
        
        $query = ProjectBudget::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->all();

        $query1 = ProjectBudgetItem::find()->where(['is_delete' => INACTIVE])->andWhere('project_budget_id = ' . $id)->all();

        foreach ($query as $val) {
            $data_val[$i][] = $val->project->project_name;
            $data_val[$i][] = $val->sub_contractor_total_cost;
            $data_val[$i][] = $val->pb_total_cost;
            $i++;
        } 

        foreach ($query1 as $val) { 
            $data_val_new[$i][] = $val->item->name;
            $data_val_new[$i][] = $val->cost;
            $data_val_new[$i][] = $val->comment;
            $data_val_new[$i][] = $val->subcontractor->first_name . ' '.$val->subcontractor->last_name;
            $data_val_new[$i][] = $val->sub_contractor_estimate_cost;
            $J++;
        }

        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }

        foreach ($data_val_new as $val) {
            fputcsv($output, $val);
        }
    }

    public function actionExportData($id)
    {
        // Get Data Of Project Budget 
        $query = new Query;
        $query->select([
            'project_management.project_name','sub_contractor_total_cost','pb_total_cost'
        ])  
        ->from('project_budget_management')->where(['project_budget_management.is_delete' => NOT_DELETED])
         ->orderBy([
                      'project_budget_management.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'project_management',
            'project_budget_management.project_id = project_management.id');
        $command = $query->createCommand();
        $data = $command->queryAll();
        $data = ArrayHelper::toArray($data, [
                                'app\models\Post' => [
                                    'project_management.project_name',
                                    'sub_contractor_total_cost',
                                    'pb_total_cost',
                                ],
                            ]);           
        $array = [];
        foreach ($data as  $value) {
            $array = [$value['project_name'],$value['sub_contractor_total_cost'],$value['pb_total_cost']];
        }

        $query1 = new Query;
        $query1->select([
            'item_work.name','project_budget_item.cost','users.first_name','users.last_name',
            'project_budget_item.sub_contractor_estimate_cost','project_budget_item.comment'
        ])  
        ->from('project_budget_item')->where(['project_budget_item.is_delete' => NOT_DELETED])
         ->orderBy([
                      'project_budget_item.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'item_work',
            'project_budget_item.item_id = item_work.id')
        ->join('LEFT OUTER JOIN', 'users',
            'project_budget_item.sub_contractor_id = users.id');
        $command = $query1->createCommand();
        $data = $command->queryAll();
                 
        $array1 = [];
        $array2 = [];
        $i = 0;
        foreach ($data as $value) {           
            $array2 = [$value['name'],$value['cost'],$value['first_name'],$value['last_name'],$value['sub_contractor_estimate_cost'],$value['comment']];
            //array_push($array1,$array2);
            $array1[$i] = $array2;
            $i++;
        }
        //echo "<pre>"; print_r($array1); exit();
        
        $file = \Yii::createObject([
            'class' => 'codemix\excelexport\ExcelFile',
            'sheets' => [

                'Project Budget Data' => [   // Name of the excel sheet
                    'data' => [
                        $array, 
                    ],

                    // Set to `false` to suppress the title row
                    'titles' => [
                        'Project Name',
                        'Sub Contractor Total Cost',
                        'Project Total Budget Total Cost',
                       
                    ],
                ],

                'Item Work Detail' => [
                    // Data for another sheet goes here ...
                    'data' => [
                        ['fr', 'France', 1.234, '2014-02-03 12:13:14'],
                        ['de', 'Germany', 2.345, '2014-02-05 19:18:39'],
                        ['uk', 'United Kingdom', 3.456, '2014-03-03 16:09:04'],
                        //$array1
                        
                    ],

                    // Set to `false` to suppress the title row
                    'titles' => [
                        'Item Work Name',
                        'Item Work Cost',
                        'Sub Contractor',
                        'Sub Contractor Cost',
                        'Comment'
                    ],
                ],
            ]
        ]);
        // Save on disk
        $file->send();
    }

    public function actionExportOnePdf($id)  
    {
        $porojectbudget = new ProjectBudget();
        $data = $porojectbudget->getProjectBudgetData($id);
        if(empty($data))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-budget/index']);
        }
        $data1 = $porojectbudget->getProjectBudgetItemData($id);
        $content = $this->renderPartial('_pdf', [
                     'model' => $data,
                     'model1' => $data1
                     ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }

    public function actionExportPdf() 
    {
        $porojectbudget = new ProjectBudget();
        $data = $porojectbudget->getProjectAllBudgetData();
        $data = ProjectBudget::find()->where(['is_delete' => INACTIVE])->all();
        //echo "<pre>"; print_r($query); exit();
        if(empty($data))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-budget/index']);
        }
        
        $content = $this->renderPartial('_all_pdf', [
                     'data' => $data,
                     ]);
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
}