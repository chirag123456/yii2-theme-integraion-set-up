<?php

namespace backend\controllers;

use Yii;
use common\models\order\Order;
use yii\helpers\Url;
use common\models\changeorder\ChangeOrder;
use common\models\changeorder\ChangeOrderForm;
use common\models\changeorder\ChangeOrderSearch;
use common\models\changeorder\ChangeOrderItem;
use common\models\changeorder\ChangeOrderItemForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException; 
use yii\filters\VerbFilter; 
use yii\web\Response;
use yii\bootstrap\ActiveForm; 

/**
 * ChangeOrderLogController implements the CRUD actions for ChangeOrder model.
 */
class ChangeOrderLogController extends Controller
{

    /**
     * Lists all ChangeOrder models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ChangeOrderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single ChangeOrder model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    { 
        $model = ChangeOrder::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['change-order-log/index']);
        }

        $model1 = ChangeOrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('change_order_id = ' . $id)->all();
        
        return $this->render('view', [
            'model' => $model,
            'model1' => $model1
        ]);
    }  

    public function actionExportOnePdf($id) 
    {
        $model = ChangeOrder::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['change-order-log/index']);
        }

        $model1 = ChangeOrderItem::find()->where(['is_delete' => INACTIVE])->andWhere('change_order_id = ' . $id)->all();

        $content = $this->renderPartial('_pdf', [
                     'model' => $model,
                     'model1' => $model1
                     ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Action Item',
                'subject' => 'Action Item'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
} 