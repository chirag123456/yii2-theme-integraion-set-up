<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\controllers;

use Yii;
use backend\components\CustController;
use common\models\PassengersOrders;
use common\models\user\UserSearch;
use common\models\project\ProjectSearch;

use yii\data\ActiveDataProvider;

class DashboardController extends CustController {

    public function actionIndex() {
        //return $this->render('index');

        $searchModel = new UserSearch();
        $searchModel1 = new ProjectSearch();
       
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
        $dataProvider1 = $searchModel1->search1(Yii::$app->request->queryParams); 
        
        return $this->render('index', 
            [
                'dataProvider' => $dataProvider,
                'dataProvider1' => $dataProvider1,
                'searchModel' => $searchModel1 
            ]);

    }
    
    public function getConfigureValueByKey($key) {

        $model = \common\models\SiteConfiguration::findOne(['config_key' => $key]);
        if ($model != null) {
            return $model->config_value;
        } else {
            return 'Undefine Key';
        }
    }

}
