<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use common\models\LoginForm;
use backend\models\PasswordResetRequestForm;
use backend\models\ResetPasswordForm;
use common\models\Passengers;
use yii\helpers\Url;

/**
 * Site controller
 */
class SiteController extends Controller {

    /**
     * @inheritdoc
     */
    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    public function actionIndex() {
        return $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
    }

    
    public function actionError() {
        $this->layout = "error/main";
        $exception = Yii::$app->errorHandler->exception;
        return $this->render('error', ['error' => $exception]);
    } 

    public function actionLogin() {

        $this->layout = "login/main";

        $model = new LoginForm();
        // if (!Yii::$app->user->isGuest) {
        //     return $this->redirect(\Yii::$app->urlManager->createUrl("dashboard/index"));
        // }
        if ($model->load(Yii::$app->request->post()) && $model->login()) {

            $user = \common\models\user\User::find()->where(['email' => $model->email])->andWhere(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->one();
            if(!isset($user->role) && empty($user->role) && $user->role == '')
            {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => 'Sorry, You are not authorize to login, Because your role is not assign.',
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
            }
            if ($user) {
                $user->last_login = date("Y-m-d H:i:s");
                //$user->ip_address = $_SERVER['REMOTE_ADDR'];
                if (isset($user->role) && !empty($user->role) && $user->validate()) {
                    $user->save();
                    return $this->redirect(\Yii::$app->urlManager->createUrl("dashboard/index"));
                }
                else
                {
                    return $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));   
                }
            }
        } else {
            return $this->render('login', [
                        'model' => $model,
            ]);
        }
    }

    public function actionRequestPasswordReset() {
        $this->layout = "login/main";

        $model = new PasswordResetRequestForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            //echo "<pre>"; print_r($model->sendEmail()); exit();
            if ($model->sendEmail()) {

                return $this->render('requestPasswordSend', [
                            'model' => $model,
                ]);
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => 'Sorry, we are unable to reset password for email provided.',
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
        }
        return $this->render('requestPasswordResetToken', [
                    'model' => $model,
        ]);
    }

    public function actionResetPassword($token, $email) {
        $this->layout = "login/main";

        try {
            $model = new ResetPasswordForm($token);
        } catch (InvalidParamException $e) {
            throw new BadRequestHttpException($e->getMessage());
        }
        if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {

            if ($model->successMail($email)) {
                return $this->render('passwordChangeSuccess', [
                            'model' => $model,
                ]);
            }
        }

        return $this->render('resetPassword', [
                    'model' => $model,
        ]);
    }

    public function actionTokenException() {
        $this->layout = "login/main";

        return $this->render('requestPasswordResetTokenException', [
        ]);
    }

    public function actionLogout() {

        Yii::$app->user->logout();
        return $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
    }

}
