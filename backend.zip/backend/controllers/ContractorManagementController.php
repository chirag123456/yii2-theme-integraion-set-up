<?php

namespace backend\controllers;

use Yii;
use common\models\user\User;
use common\models\userrole\UserAccess;
use common\models\userrole\AuthAssignment;
use backend\components\CustController;
use common\models\user\UserSearch;
use common\models\user\UserForm;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use common\models\ChangePasswordForm;
use backend\components\CommonFunctions;

/**
* ContractorManagementController implements the CRUD actions for User model.
*/
class ContractorManagementController extends CustController
{
    /**
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex()
    {
       $searchModel = new UserSearch();
        $dataProvider = $searchModel->searchvendor(Yii::$app->request->queryParams);
        
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider, 
        ]);
    }

    public function actionAdd() {
        $model = new UserForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $role = CommonFunctions::getConfigureValueByKey('VENDOR_USER_ID');
            $user = new User();
            $user->attributes = $model->attributes;
            $user->username = $model->first_name;
            $user->role = $role;
            $user->created_by = Yii::$app->user->id;
            $user->updated_by = Yii::$app->user->id;
            $user->updated_date = date("Y-m-d H:i:s");
            $user->created_date = date("Y-m-d H:i:s");
            $user->setPassword($model->password);
            $user->generateAuthKey();
            $user->generatePasswordResetToken();

             if (!empty($_POST['UserForm']['user_image'])) {
                $user->user_image = $this->base64_to_image($_POST['UserForm']['user_image'], 'users/image');
            }
            $post = Yii::$app->request->post();
            
            $role_id = $role;
            $user_acc = UserAccess::findOne(['id'=>$role_id]);
            $role_name = $user_acc->name;

            $auth_assign = new AuthAssignment();
            $auth_assign->item_name = $role_name;
            $auth_assign->created_at = date("Y-m-d H:i:s");
            if ($user->validate()) {
                $user->save();
                $auth_assign->user_id = $user->id;
                $auth_assign->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            } else {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    //'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => DATA_NOT_SAVED,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['contractor-management/index']);
        }
        return $this->render('create', [
                    'model' => $model,
                    'subcontractor' => 2,  
        ]);
    }

    public function actionUpdate($id) {

        $details = User::findOne(['id' => $id, 'is_delete' => NOT_DELETED]);
        $role = CommonFunctions::getConfigureValueByKey('VENDOR_USER_ID');
        if (empty($details) && $details->role != $role) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Invalid data!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['architect/index']);
        }
        $model = new UserForm();

        $model->attributes = $details->attributes;

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {
      
            $user = User::findOne(['id' => $id]);
            //$user->username = $model->username;
            $user->attributes = $model->attributes;
            $user->username = $model->first_name;
            $user->first_name=$model->first_name;
            $user->last_name=$model->last_name;
            $user->contact_number = $model->contact_number;
            $user->role = $model->role;
            $user->updated_by = Yii::$app->user->id;
            $user->updated_date = date("Y-m-d H:i:s");

            if (empty($_POST['UserForm']['user_image'])) {
                $user->user_image = $details->user_image;
            } else {
                $user->user_image = $this->base64_to_image($_POST['UserForm']['user_image'], 'user_profile/image');
            }

            if ($user->validate()) {
                if ($user->save()) {
                    
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
            }

            if (isset($_GET['page'])) {
                return $this->redirect(['contractor-management/index?page=' . $_GET['page']]);
            } else {
                return $this->redirect(['contractor-management/index']);
            }
        }

        return $this->render('edit-user', [
                    'model' => $model,
                    'subcontractor' => 2,
        ]);
    }

    /**
     *  View Action
     *  In this action User View of data.
     */
    public function actionView($id) {

        $model = User::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['contractor-management/index']);
        }

        return $this->render('view-user', ['model' => $model]);
    }

    /**
     * Delete Action
     *  In this action Delete of data.
     */
    public function actionDelete($id) {
        if ($id) {
            $model = User::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = User::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    }

    /**
     * base_64_image function
     *  In this image function.
     */
   public function base64_to_image($imageData) {

        $basePath = dirname(\Yii::$app->basePath); 
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile/' . DIRECTORY_SEPARATOR . $imagename;
        file_put_contents($file, $image_base64);

        return $imagename;
        //return '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile' . DIRECTORY_SEPARATOR . $imagename;    
    }
}