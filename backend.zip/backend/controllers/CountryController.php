<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\country\Country;
use common\models\country\CountrySearch;
use backend\components\CustController;
/**
 * CountryController
 *  This controller used for Country list , add , update , delete.
 * @author Xceltec01
 * @since Jun,2017
 */
class CountryController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {		
        $searchModel = new CountrySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
		return $this->render('index', [
				'searchModel' => $searchModel,
				'dataProvider' => $dataProvider,
		]);
        
    }
	
    /**
     * Add Action
     *  In this action use for Add new data in Country.
     * @return
     */
    public function actionAdd() {		
        $model = new \common\models\country\CountryForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $country = new Country();
                $country->attributes = $model->attributes;
        
                $country->country_name = trim($model->country_name);
                $country->created_by = Yii::$app->user->identity->id;
                $country->updated_by = Yii::$app->user->identity->id;
                $country->created_date = date("Y-m-d H:i:s");
                $country->updated_date = date("Y-m-d H:i:s");
                $country->is_active = ACTIVE;
                $country->is_delete = NOT_DELETED;
	
                if ($country->validate()) {
                    $country->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Country' . ADDED,
                        'title' => 'Country Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['country/index']);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Country not added',
                        'title' => 'Academic Year Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['country/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Update Action
     *  In this action use for update Country.
     * $id is Country id
     * @return mixed
     */
    public function actionUpdate($id) {

        $details = Country::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();        
       
       if($details == NULL){
					Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['country/index']);
        }
        $CountryForm = new \common\models\country\CountryForm();
        $model = $CountryForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $country = Country::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $country->attributes = $model->attributes;
                
                $country->country_name = trim($model->country_name);
				
                $country->created_by = Yii::$app->user->identity->id;
                $country->updated_by = Yii::$app->user->identity->id;
                $country->created_date = date("Y-m-d H:i:s");
                $country->updated_date = date("Y-m-d H:i:s");

                if ($country->validate()) {
                    $country->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Country' . UPDATED,
                        'title' => 'Country Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['country/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Country not updated',
                        'title' => 'Academic Year Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['country/index']);
                }
            }
        }
        return $this->render('edit_country', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for Country.
     * $id is Country id
     * @return mixed
     */
    public function actionStatus($id) {
		
        $model = Country::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Country' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Country' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['country/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete Country data.
     * $id is Country id
     * @return
     */
    public function actionDelete($id) {
		
        if ($id) {
            $model = Country::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Country' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['country/index']));
            }
        }
    }

    /**
     * SetAction Action
     * @dependent drop down for area _form
     * @return
     */
    public function actionSetAction($id) {
        if (Yii::$app->request->isAjax) {
            $model = \common\models\State::find()->where(['country_id' => $id])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => ACTIVE])->all();

            $modelcount = count((array) $model);
            if ($modelcount > 0) {
                echo "<option>Please select state</option>";
                foreach ($model as $action) {

                    echo "<option value='" . $action->id . "'>" . $action->state_name . "</option>";
                }
            } else {
                echo "<option>Please insert state</option>";
            }
        }
        return false;
    }
}