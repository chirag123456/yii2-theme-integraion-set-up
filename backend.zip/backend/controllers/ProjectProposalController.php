<?php
namespace backend\controllers;
ini_set('memory_limit', '512M');

use Yii;
use yii\helpers\Url;
use yii\web\Response;
use yii\web\Controller;
use yii\helpers\ArrayHelper;
use yii\bootstrap\ActiveForm; 
use common\models\project\ProjectProposal;
use common\models\project\ProjectProposalForm;
use common\models\projectbudget\ProjectBudget;
use common\models\projectbudget\ProjectBudgetSearch;
use common\models\project\ProjectProposalSearch;
use common\models\projectbudget\ProjectBudgetForm;
use common\models\projectbudget\ProjectBudgetItemForm;
use common\models\project\ProjectProposalItem;
use common\models\project\ProjectProposalItemForm;
use common\models\projectbudget\ProjectBudgetItem;
use backend\components\CustController;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;
use XLSXWriter;
use yii\db\Query;
/** 
 * ProjectProposal
 *  This controller used for ProjectProposal list , add , update , delete.
 */ 
class ProjectProposalController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {		
        $searchModel = new ProjectProposalSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
		return $this->render('index', [
				'searchModel' => $searchModel,
				'dataProvider' => $dataProvider,
		]);        
    }
	
    /**
     * Add Action
     *  In this action use for Add new data in ProjectProposal.
     * @return
     */
    public function actionAdd() {		

        $model = new ProjectProposalForm();
        $model1 = new ProjectProposalItemForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                 
                $projectProposal = new ProjectProposal();
                
                $projectProposal->project_id = $model->project_id;
                $projectProposal->p_name = $model->p_name;
                $projectProposal->sub_contractor_total_cost = $model->sub_contractor_total_cost;
                $projectProposal->p_total_cost = $model->p_total_cost;
                $projectProposal->project_size = $model->project_size;
                $projectProposal->cost_per_sf = $model->cost_per_sf;
                $projectProposal->estimated_design_duration_days = $model->estimated_design_duration_days;
                $projectProposal->overhead = $model->overall_overhead_per;
                $projectProposal->item_sub_total = $model->item_sub_total;
                $projectProposal->fee = $model->overall_fee_per;
                $projectProposal->contractor_overhead = $model->contractor_overhead;
                $projectProposal->contractor_fee = $model->contractor_fee;
                $projectProposal->item_total_cost = $model->item_total_cost;
                $projectProposal->p_desc = $model->p_desc;
                $projectProposal->created_by = Yii::$app->user->identity->id;
                $projectProposal->updated_by = Yii::$app->user->identity->id;
                $projectProposal->created_date = date("Y-m-d H:i:s");
                $projectProposal->updated_date = date("Y-m-d H:i:s");
                $projectProposal->is_active = ACTIVE;
                $projectProposal->is_delete = NOT_DELETED;
	
                if ($projectProposal->validate()) {
                    $projectProposal->save();
                    $postdata = $_POST;
                    $i = 0;
                    foreach ($postdata['ProjectProposalItemForm']['item_id']  as  $value) {
                        
                        $projectProposalItem = new ProjectProposalItem();
                        $projectProposalItem->project_id = $projectProposal->project_id;
                        $projectProposalItem->project_proposal_id = $projectProposal->id;
                        $projectProposalItem->item_id = $_POST['ProjectProposalItemForm']['item_id'][$i];
                        $projectProposalItem->cost_sf = $_POST['ProjectProposalItemForm']['cost_sf'][$i];
                        $projectProposalItem->per_total = $_POST['ProjectProposalItemForm']['per_total'][$i];
                        $projectProposalItem->proposed_spread_per = $_POST['ProjectProposalItemForm']['proposed_spread_per'][$i];
                        $projectProposalItem->sub_contractor_id = $_POST['ProjectProposalItemForm']['sub_contractor_id'][$i];
                        $projectProposalItem->cost = $_POST['ProjectProposalItemForm']['cost'][$i];
                        $projectProposalItem->comment = $_POST['ProjectProposalItemForm']['comment'][$i];
                        $projectProposalItem->sub_contractor_estimate_cost = $_POST['ProjectProposalItemForm']['sub_contractor_estimate_cost'][$i];
                        $projectProposalItem->created_by = Yii::$app->user->identity->id;
                        $projectProposalItem->updated_by = Yii::$app->user->identity->id;
                        $projectProposalItem->created_date = date("Y-m-d H:i:s");
                        $projectProposalItem->updated_date = date("Y-m-d H:i:s");
                        $projectProposalItem->is_active = ACTIVE;
                        $projectProposalItem->is_delete = NOT_DELETED;
                        $projectProposalItem->save();
                        $i++;
                    }
                    
                    $transaction->commit();
                    $projectProposal->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Project Proposal ' . ADDED,
                        'title' => 'Project Budget Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-proposal/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Project Proposal not added',
                        'title' => 'Project Budget Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-proposal/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model,
                    'model1' => $model1
        ]);
    }

    /**
     * Update Action
     *  In this action use for update ProjectProposal.
     * $id is ProjectProposal id
     * @return mixed
     */
    public function actionUpdate($id) {

        $details = ProjectProposal::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       if($details == NULL){
					Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-proposal/index']);
        }
        $projectBudgetForm = new ProjectProposalForm();
        $model = $projectBudgetForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $projectProposal = ProjectProposal::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $projectProposal->project_id = $model->project_id;
                $projectProposal->p_name = $model->p_name;
                $projectProposal->sub_contractor_total_cost = $model->sub_contractor_total_cost;
                $projectProposal->p_total_cost = $model->p_total_cost;
                $projectProposal->project_size = $model->project_size;
                $projectProposal->cost_per_sf = $model->cost_per_sf;
                $projectProposal->estimated_design_duration_days = $model->estimated_design_duration_days;
                $projectProposal->overhead = $model->overall_overhead_per;
                $projectProposal->item_sub_total = $model->item_sub_total;
                $projectProposal->fee = $model->overall_fee_per;
                $projectProposal->contractor_overhead = $model->contractor_overhead;
                $projectProposal->contractor_fee = $model->contractor_fee;
                $projectProposal->item_total_cost = $model->item_total_cost;
                $projectProposal->p_desc = $model->p_desc;
                $projectProposal->created_by = Yii::$app->user->identity->id;
                $projectProposal->updated_by = Yii::$app->user->identity->id;
                $projectProposal->created_date = date("Y-m-d H:i:s");
                $projectProposal->updated_date = date("Y-m-d H:i:s");
                $projectProposal->is_active = ACTIVE;
                $projectProposal->is_delete = NOT_DELETED;                
                if ($projectProposal->validate()) {
                    $projectProposal->save();
                    
                    \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('project_proposal_item', ['project_proposal_id' => $id])
                    ->execute();

                    $postdata = $_POST;
                    $i = 0;
                    foreach ($postdata['ProjectProposalItemForm']['item_id']  as  $value) {
                        
                        $projectProposalItem = new ProjectProposalItem();
                        $projectProposalItem->project_id = $projectProposal->project_id;
                        $projectProposalItem->project_proposal_id = $projectProposal->id;
                        $projectProposalItem->item_id = $_POST['ProjectProposalItemForm']['item_id'][$i];
                        $projectProposalItem->cost_sf = $_POST['ProjectProposalItemForm']['cost_sf'][$i];
                        $projectProposalItem->per_total = $_POST['ProjectProposalItemForm']['per_total'][$i];
                        $projectProposalItem->proposed_spread_per = $_POST['ProjectProposalItemForm']['proposed_spread_per'][$i];
                        $projectProposalItem->sub_contractor_id = $_POST['ProjectProposalItemForm']['sub_contractor_id'][$i];
                        $projectProposalItem->cost = $_POST['ProjectProposalItemForm']['cost'][$i];
                        $projectProposalItem->comment = $_POST['ProjectProposalItemForm']['comment'][$i];
                        $projectProposalItem->sub_contractor_estimate_cost = $_POST['ProjectProposalItemForm']['sub_contractor_estimate_cost'][$i];
                        $projectProposalItem->created_by = Yii::$app->user->identity->id;
                        $projectProposalItem->updated_by = Yii::$app->user->identity->id;
                        $projectProposalItem->created_date = date("Y-m-d H:i:s");
                        $projectProposalItem->updated_date = date("Y-m-d H:i:s");
                        $projectProposalItem->is_active = ACTIVE;
                        $projectProposalItem->is_delete = NOT_DELETED;
                        $projectProposalItem->save();
                        $i++;
                    }

                    $transaction->commit();
                    $projectProposal->save();

                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Project Proposal ' . UPDATED,
                        'title' => 'Project Budget Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['project-proposal/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Project Proposal not updated',
                        'title' => 'Academic Year Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['project-proposal/index']);
                }
            }
        }
        return $this->render('edit_projectproposal', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for Project Proposal.
     * $id is Project Proposal id
     * @return mixed
     */
    public function actionStatus($id) {
		
        $model = ProjectProposal::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Project Proposal ' . DEACTIVATED,
                'title' => 'Project Proposal Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Project Proposal ' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['project-proposal/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete ProjectProposal data.
     * $id is ProjectProposal id
     * @return
     */
    public function actionDelete($id) {
		
        if ($id) {
            $model = ProjectProposal::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Project Proposal ' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['project-proposal/index']));
            }
        }
    }

    /**
     *  View Action
     *  In this action ProjectProposal View of data.
     */
    public function actionView($id) {

        $model = ProjectProposal::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['project-proposal/index']);
        }
        $model1 = ProjectProposalItem::find()->where(['is_delete' => INACTIVE])->andWhere('project_proposal_id = ' . $id)->all();
        return $this->render('view', ['model' => $model,'model1' => $model1]);
    }

    public function actionExportOnePdf($id) 
    {
        $model = ProjectProposal::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        
        if(empty($model))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-proposal/index']);
        }
        $model1 = ProjectProposalItem::find()->where(['is_delete' => INACTIVE])->andWhere('project_proposal_id = ' . $id)->all();
        $content = $this->renderPartial('_pdf', [
                     'model' => $model,
                     'model1' => $model1
                     ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }

    public function actionExportPdf() 
    {
        $data = ProjectProposal::find()->where(['is_delete' => INACTIVE])->all();
        //echo "<pre>"; print_r($query); exit();
        if(empty($data))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['project-proposal/index']);
        }
        
        $content = $this->renderPartial('_all_pdf', [
                     'data' => $data,
                     ]);
        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
}