<?php

namespace backend\controllers;

use Yii;
use common\models\constructioncontractmanagement\ConstructionContractManagement;
use common\models\constructioncontractmanagement\ConstructionContractManagementForm;
use common\models\constructioncontractmanagement\ConstructionContractManagementSearch;
use common\models\contractor\ContractorManagement;
use yii\web\Controller;
use backend\components\CustController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ConstructionContractController implements the CRUD actions for ContractorManagement model.
 */
class ConstructionContractManagementController extends CustController
{

    /**
     * Lists all ConstructionContractManagement models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ConstructionContractManagementSearch();
        $dataProvider = $searchModel->searchContractor(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single ConstructionContractManagement model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $details = ConstructionContractManagement::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
        return $this->render('view', [
            'model' => $details,
        ]);
    }

    /**
     * Creates a new ConstructionContractManagement model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new ConstructionContractManagementForm();
        
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        
        if ($model->load(Yii::$app->request->post())) {

            $ccm = new ConstructionContractManagement();
            $ccm->attributes = $model->attributes;
            $ccm->created_by = Yii::$app->user->identity->id;
            $ccm->updated_by = Yii::$app->user->identity->id;
            $ccm->updated_date = date("Y-m-d H:i:s");
            $ccm->created_date = date("Y-m-d H:i:s");
            $ccm->is_active = ACTIVE;
            $ccm->is_delete = INACTIVE;
            if($ccm->validate()){
                $ccm->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }else{
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['construction-contract-management/index']);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing ConstructionContractManagement model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = ConstructionContractManagement::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
       
        if($details == NULL){
             Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['construction-contract-management/index']);
        }

        $model = new ConstructionContractManagementForm();

        $model->attributes = $details->attributes;
        $model->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
    
        if ($model->load(Yii::$app->request->post())) {
            $ccm = ConstructionContractManagement::find()->where(['id' => $_GET['id']])->one();
            $ccm->attributes = $model->attributes;
            $ccm->updated_by = Yii::$app->user->identity->id;
            $ccm->updated_date = date("Y-m-d H:i:s");
            
            if($ccm->validate() && $ccm->save()){
                Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Automotive Product Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['construction-contract-management/index']);
            }else{
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['construction-contract-management/index']);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing ConstructionContractManagement model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        //if ($id) {
            $model = ConstructionContractManagement::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        //}
    }

    public function actionStatus($id) {
        $model = ConstructionContractManagement::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    } 

    public function actionSetContractor($id) {
        //print_r($id);die;
        if (Yii::$app->request->isAjax) {
            $model = ContractorManagement::find()->where(['parent_id' => $id])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => ACTIVE])->all();

            $modelcount = count((array) $model);
            if ($modelcount > 0) {
                //echo "<option>Please select city</option>";
                foreach ($model as $action) {

                    echo "<option value='" . $action->id . "'>" . $action->contractor_name . "</option>";
                }
            } else {
                echo "<option>Please insert sub contractor</option>";
            }
        }
        return false;
    }
}
