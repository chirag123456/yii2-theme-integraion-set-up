<?php

namespace backend\controllers;

use Yii;
use common\models\siteconfiguration\SiteConfigurationForm;
use common\models\siteconfiguration\SiteConfigurationSearch;
use common\models\siteconfiguration\SiteConfiguration;
use backend\components\CustController;
use yii\web\Response;
use yii\widgets\ActiveForm;

/**
 * SettingController implements the CRUD actions.
 */
class SettingController extends CustController {

    /**
     * Lists all  models.
     * @return mixed
     */
    public function actionIndex() {

        $searchModel = new SiteConfigurationSearch();
        $model = new SiteConfigurationForm();

        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $siteConfig = SiteConfiguration::findOne($_GET['id']);

            if ($siteConfig != null) {
                $model = new SiteConfigurationForm();
                $model->attributes = $siteConfig->attributes;
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['setting/index']);
            }
        }
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model,
        ]);
    }

   /**
     * Add Action
     *  In this action Add of data.
     * @return mixed
     */
    public function actionAdd() {
        $model = new SiteConfigurationForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $siteConfig = new SiteConfiguration();
            $siteConfig->attributes = $model->attributes;
            $siteConfig->config_key = str_replace(" ", "_", strtoupper(trim($model->config_key)));
            $siteConfig->config_value = $model->config_value;

            $siteConfig->is_active = ACTIVE;
            if ($siteConfig->validate()) {
                $checkDataexist = SiteConfiguration::find()->where(['config_key' => $siteConfig->config_key])->one();
                if ($checkDataexist != null) {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Somethings Error: Key already exists!',
                        'title' => 'Somethings Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    if ($siteConfig->save()) {
                        Yii::$app->getSession()->setFlash('success', [
                            'type' => 'success',
                            'duration' => 12000,
                            'icon' => 'glyphicon glyphicon-ok-sign',
                            'message' => ADDED,
                            'title' => 'Site Configure Key Added',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]);
                    } else {
                        Yii::$app->getSession()->setFlash('danger', [
                            'type' => 'danger',
                            'duration' => 12000,
                            'icon' => 'glyphicon glyphicon-ok-sign',
                            'message' => DATA_NOT_SAVED,
                            'title' => 'Error',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]);
                    }
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

        }
        return $this->redirect(['setting/index']);
    }

   /**
     * Update Action
     *  In this action Update of data.
     * @return mixed
     */
    public function actionUpdate($id) {

        $details = SiteConfiguration::findOne($id);
        $settingForm = new \common\models\siteconfiguration\SiteConfigurationForm();
        $model = $settingForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $site = SiteConfiguration::find()->where(['id' => $details->id])->one();
            $site->attributes = $model->attributes;
            $site->config_value = $model->config_value;

            $site->created_date = date("Y-m-d H:i:s");
            $site->updated_date = date("Y-m-d H:i:s");

            if ($site->validate()) {
                if ($site->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => UPDATED,
                        'title' => 'Site Configure Key Update',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
        }
        return $this->redirect(['setting/index']);
    }

}
