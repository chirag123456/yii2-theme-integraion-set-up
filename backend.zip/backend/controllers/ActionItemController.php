<?php

namespace backend\controllers;

use Yii;
use yii\helpers\Url;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use backend\components\CommonFunctions;
use backend\components\CustController;
use common\models\actionitem\ActionItem;
use common\models\actionitem\ActionItemForm;
use common\models\actionitem\ActionItemSearch;
use common\models\actionitem\ActionItemListForm;
use common\models\actionitem\ActionItemList;

/**
 * ActionItemController implements the CRUD actions for ActionItem model.
 */
class ActionItemController extends CustController
{
    /**
     * Lists all ActionItem models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ActionItemSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single ActionItem model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    { 
        $model = ActionItem::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['action-item/index']);
        }

        $model1 = ActionItemList::find()->where(['is_delete' => INACTIVE])->andWhere('action_item_id = ' . $id)->all();
        
        return $this->render('view', [
            'model' => $model,
            'model1' => $model1
        ]);
    }

    /**
     * Creates a new ActionItem model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new ActionItemForm();
        $model1 = new ActionItemListForm();
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $actionItem = new ActionItem();
                $actionItem->attributes = $model->attributes;
                $actionItem->created_by = Yii::$app->user->identity->id;
                $actionItem->updated_by = Yii::$app->user->identity->id;
                $actionItem->created_date = date("Y-m-d H:i:s");
                $actionItem->updated_date = date("Y-m-d H:i:s");
                $actionItem->is_active = ACTIVE;
                $actionItem->is_delete = NOT_DELETED;
    
                if ($actionItem->validate()) {
                    $actionItem->save();
                    $postdata = $_POST;                
                    $i = 0;
                    foreach ($postdata['ActionItemListForm']['item_no']  as  $value) {
                         
                        $actionItemList = new ActionItemList();
                        $actionItemList->action_item_id = $actionItem->id;
                        $actionItemList->item_no = $_POST['ActionItemListForm']['item_no'][$i];
                        $actionItemList->date_of_origin = date("Y-m-d",strtotime( $_POST['ActionItemListForm']['date_of_origin'][$i]));
                        $actionItemList->priority = $_POST['ActionItemListForm']['priority'][$i];
                        $actionItemList->item_desc = $_POST['ActionItemListForm']['item_desc'][$i];
                        $actionItemList->current_status = $_POST['ActionItemListForm']['current_status'][$i];
                        $actionItemList->action_item_owner = $_POST['ActionItemListForm']['action_item_owner'][$i];
                        $actionItemList->item_origin = $_POST['ActionItemListForm']['item_origin'][$i];
                        $actionItemList->due_date = date("Y-m-d",strtotime($_POST['ActionItemListForm']['completed_or_received'][$i])); 
                        $actionItemList->completed_or_received = $_POST['ActionItemListForm']['completed_or_received'][$i];
                        $actionItemList->created_by = Yii::$app->user->identity->id;
                        $actionItemList->updated_by = Yii::$app->user->identity->id;
                        $actionItemList->created_date = date("Y-m-d H:i:s");
                        $actionItemList->updated_date = date("Y-m-d H:i:s");
                        $actionItemList->is_active = ACTIVE;
                        $actionItemList->is_delete = NOT_DELETED;
                        if($actionItemList->validate())
                        { 
                            $actionItemList->save();
                        }
                        else
                        {
                            $transaction->rollback();
                            echo "<pre>"; print_r($actionItemList->getErrors()); exit;
                        }
                        $i++;
                    }
                    
                    $transaction->commit();

                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Action Item ' . ADDED,
                        'title' => 'Action Item Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['action-item/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => 'Action Item not added',
                        'title' => 'Action Item Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['action-item/index']);
                }
            }
        }
        return $this->render('create', [
                    'model' => $model,
                    'model1' => $model1
        ]);
    } 

    /**
     * Updates an existing ActionItem model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $details = ActionItem::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();
        if($details == NULL){
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['action-item/index']);
        }
        $projectBudgetForm = new ActionItemForm();
        $model = $projectBudgetForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $actionItem = ActionItem::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();
                $actionItem->attributes = $model->attributes;
                $actionItem->updated_by = Yii::$app->user->identity->id;                
                $actionItem->updated_date = date("Y-m-d H:i:s");                
                if ($actionItem->validate()) {
                    $actionItem->save();
                    
                    \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('action_item_list', ['action_item_id' => $id])
                    ->execute();
                    $postdata = $_POST;                
                    $i = 0;

                    foreach ($postdata['ActionItemListForm']['item_no']  as  $value) {
                        
                        $actionItemList = new ActionItemList();
                        $actionItemList->action_item_id = $actionItem->id;
                        $actionItemList->item_no = $_POST['ActionItemListForm']['item_no'][$i];
                        $actionItemList->date_of_origin = $_POST['ActionItemListForm']['date_of_origin'][$i];
                        $actionItemList->priority = $_POST['ActionItemListForm']['priority'][$i];
                        $actionItemList->item_desc = $_POST['ActionItemListForm']['item_desc'][$i];
                        $actionItemList->current_status = $_POST['ActionItemListForm']['current_status'][$i];
                        $actionItemList->action_item_owner = $_POST['ActionItemListForm']['action_item_owner'][$i];
                        $actionItemList->item_origin = $_POST['ActionItemListForm']['item_origin'][$i];
                        $actionItemList->due_date = $_POST['ActionItemListForm']['due_date'][$i];
                        $actionItemList->completed_or_received = $_POST['ActionItemListForm']['completed_or_received'][$i];
                        $actionItemList->created_by = Yii::$app->user->identity->id;
                        $actionItemList->updated_by = Yii::$app->user->identity->id;
                        $actionItemList->created_date = date("Y-m-d H:i:s");
                        $actionItemList->updated_date = date("Y-m-d H:i:s");
                        $actionItemList->is_active = ACTIVE;
                        $actionItemList->is_delete = NOT_DELETED;
                        $actionItemList->save();
                        $i++;
                    }

                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Action Item ' . UPDATED,
                        'title' => 'Action Item Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['action-item/index']);
                } else {
                    $transaction->rollBack();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        //'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Action Item not updated',
                        'title' => 'Action Item Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['action-item/index']);
                }
            }
        }
        return $this->render('update', [
                    'model' => $model
        ]);
    }

    /**
     * Deletes an existing ActionItem model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        if ($id) {
            $model = ActionItem::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['action-item/index']);
            }
        }
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = ActionItem::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect(['action-item/index']);
    }

    public function actionExportOnePdf($id) 
    {
        $actionitem = new ActionItem();
        $data = $actionitem->getActionItemData($id);
    
        if(empty($data))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
              return $this->redirect(['action-item/index']);
        }
        $content = $this->renderPartial('_pdf', [
                     'model' => $data
                     ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Action Item',
                'subject' => 'Action Item'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }

    //Export pdf for all action Item data
    public function actionExportPdf() 
    {
        $data = ActionItem::find()->where(['is_delete' => INACTIVE])->all();
        if(isset($_GET) && !empty($_GET) && $_GET['status'] == 1 )
        {
            $status = OPEN;
        }
        else
        {
            $status = '';  
        }
        if(empty($data))
        {
            Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                      // 'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => DATA_NOT_VALID,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]); 
            return $this->redirect(['action-item/index']);
        }
        
        $content = $this->renderPartial('_all_pdf', [
                     'data' => $data,
                     'status' => $status
        ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_UTF8, // leaner size using standard fonts
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => [
                'title' => 'Project Budget Data',
                'subject' => 'Project Budget Data'
            ],
            'methods' => [
                'SetHeader' => ['<img height="25" width="30" style = "display: block;  margin-left: auto;
                    margin-right: auto;
                    width: 25%;" src = "'.Url::base(true).'/web/images/logo/cc-logo-new.png">'],
                'SetFooter' => ['|Page {PAGENO}|'],
            ]
        ]);
        return $pdf->render();
    }
}