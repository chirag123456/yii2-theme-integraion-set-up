<?php

namespace backend\controllers;

use Yii;
use common\models\user\User;
use common\models\userrole\UserAccess;
use common\models\userrole\AuthAssignment;
use backend\components\CustController;
use common\models\user\UserSearch;
use common\models\user\UserForm;
use common\models\user\SubcontractorItemForm;
use common\models\user\SubcontractorItem;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use common\models\ChangePasswordForm;
use backend\components\CommonFunctions;

/**
 * ContractorManagementController implements the CRUD actions for ContractorManagement model.
 */
class SubContractorManagementController extends CustController
{ 
    /**
     * Lists all ContractorManagement models.
     * @return mixed
     */
    public function actionIndex()
    {
       $searchModel = new UserSearch();
        $dataProvider = $searchModel->searchsubcontractor(Yii::$app->request->queryParams);
        
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider, 
        ]);
    }

    /**
     *  View Action
     *  In this action User View of data.
     */
    public function actionView($id) {

        $model = User::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['user/index']);
        }

        return $this->render('view-user', ['model' => $model]);
    }

    /**
     * Creates a new ContractorManagement model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionAdd() {
        $model = new UserForm();
        $model1 = new SubcontractorItemForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if ($model->load(Yii::$app->request->post())) {
            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();
            $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
            $user = new User();
            $user->attributes = $model->attributes;
            $user->role = $role;
            $user->created_by = Yii::$app->user->id;
            $user->updated_by = Yii::$app->user->id;
            $user->updated_date = date("Y-m-d H:i:s");
            $user->created_date = date("Y-m-d H:i:s");
            $user->setPassword($model->password);
            $user->generateAuthKey();
            $user->generatePasswordResetToken();

             if (!empty($_POST['UserForm']['user_image'])) {
                $user->user_image = $this->base64_to_image($_POST['UserForm']['user_image'], 'users/image');
            }
            $post = Yii::$app->request->post();
            
            $role_id = $role;
            $user_acc = UserAccess::findOne(['id'=>$role_id]);
            $role_name = $user_acc->name;

            $auth_assign = new AuthAssignment();
            $auth_assign->item_name = $role_name;
            $auth_assign->created_at = date("Y-m-d H:i:s");
            if ($user->validate()) {
                $user->save();
                $auth_assign->user_id = $user->id;
                $auth_assign->save();
                
                $i = 0;
                if(isset($_POST['SubcontractorItemForm']['item_id']) && !empty($_POST['SubcontractorItemForm']['item_id']))
                {
                    foreach ($_POST['SubcontractorItemForm']['item_id'] as  $value) {
                        $sub_contractor_item = new SubcontractorItem();
                        $sub_contractor_item->item_id = $value;
                        $sub_contractor_item->user_id = $user->id;
                        $sub_contractor_item->created_by = Yii::$app->user->id;
                        $sub_contractor_item->updated_by = Yii::$app->user->id;
                        $sub_contractor_item->updated_date = date("Y-m-d H:i:s");
                        $sub_contractor_item->created_date = date("Y-m-d H:i:s");
                        if($sub_contractor_item->validate())
                        {
                            $sub_contractor_item->save();
                        }
                        else
                        {
                            $transaction->rollBack();
                        }
                        $i++;
                    }
                } 
                $transaction->commit();
                $user->save();
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => ADDED,
                    'title' => 'User Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            } else {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    //'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => DATA_NOT_SAVED,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['sub-contractor-management/index']);
        }
        return $this->render('create', [
                    'model' => $model,
                    'subcontractor' => 1,  
                    'model1' => $model1
        ]);
    }

    

    /**
     * Updates an existing ContractorManagement model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id) {

        $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
        $details = User::findOne(['id' => $id, 'is_delete' => NOT_DELETED]);
        $details1 = SubcontractorItem::findAll(['user_id' => $id, 'is_delete' => NOT_DELETED]);
        
        if (empty($details)) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Invalid data!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['sub-contractor-management/index']);
        }
        if (!empty($details) && $details->role != $role) {
            Yii::$app->getSession()->setFlash('error', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => 'Somethings Error: Invalid data!',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['sub-contractor-management/index']);
        }
        $model = new UserForm();
        $model1 = new SubcontractorItemForm();

        $model->attributes = $details->attributes;
        //$model1->attributes = $details1->attributes;

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if ($model->load(Yii::$app->request->post())) {
      
            $user = User::findOne(['id' => $id]);
            $connection = Yii::$app->db;
            $transaction = $connection->beginTransaction();
            //$user->username = $model->username;
            $user->attributes = $model->attributes;
            $user->first_name=$model->first_name;
            $user->last_name=$model->last_name;
            $user->contact_number = $model->contact_number;
            $user->role = $model->role;
            $user->updated_by = Yii::$app->user->id;
            $user->updated_date = date("Y-m-d H:i:s");

            if (empty($_POST['UserForm']['user_image'])) {
                $user->user_image = $details->user_image;
            } else {
                $user->user_image = $this->base64_to_image($_POST['UserForm']['user_image'], 'user_profile/image');
            }

            if ($user->validate()) {
                if ($user->save()) {
                    \Yii::$app
                    ->db
                    ->createCommand()
                    ->delete('subcontractor_item', ['user_id' => $id])
                    ->execute();
                    $i = 0;
                if(isset($_POST['SubcontractorItemForm']['item_id']) && !empty($_POST['SubcontractorItemForm']['item_id']))
                {
                    foreach ($_POST['SubcontractorItemForm']['item_id'] as  $value) {
                        $sub_contractor_item = new SubcontractorItem();
                        $sub_contractor_item->item_id = $value;
                        $sub_contractor_item->user_id = $user->id;
                        $sub_contractor_item->created_by = Yii::$app->user->id;
                        $sub_contractor_item->updated_by = Yii::$app->user->id;
                        $sub_contractor_item->updated_date = date("Y-m-d H:i:s");
                        $sub_contractor_item->created_date = date("Y-m-d H:i:s");
                        if($sub_contractor_item->validate())
                        {
                            $sub_contractor_item->save();
                        }
                        else
                        {
                            $transaction->rollBack();
                        }
                        $i++;
                    }
                } 
                $transaction->commit();
                $user->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'image' => 'glyphimage glyphimage-ok-sign',
                        'message' => UPDATED,
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

            if (isset($_GET['page'])) {
                return $this->redirect(['sub-contractor-management/index?page=' . $_GET['page']]);
            } else {
                return $this->redirect(['sub-contractor-management/index']);
            }
        }

        return $this->render('edit-user', [
                    'model' => $model,
                    'model1' => $model1,
                    'details1' => $details1,
                    'subcontractor' => 0, 
        ]);
    }

   /**
     * Delete Action
     *  In this action Delete of data.
     */
    public function actionDelete($id) {
        if ($id) {
            $model = User::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'image' => 'glyphimage glyphimage-ok-sign',
                    'message' => DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

    /**
     * Status Action
     *  In this action Status of data.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = User::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    }

    public function actionSetAction($id) {
        //print_r($id);die;
        if (Yii::$app->request->isAjax) {
            $model = City::find()->where(['state_id' => $id])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => ACTIVE])->all();

            $modelcount = count((array) $model);
            if ($modelcount > 0) {
                //echo "<option>Please select city</option>";
                foreach ($model as $action) {

                    echo "<option value='" . $action->id . "'>" . $action->name . "</option>";
                }
            } else {
                echo "<option>Please insert city</option>";
            }
        }
        return false;
    }

    /**
     * base_64_image function
     *  In this image function.
     */
   public function base64_to_image($imageData) {

        $basePath = dirname(\Yii::$app->basePath); 
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile/' . DIRECTORY_SEPARATOR . $imagename;
        file_put_contents($file, $image_base64);

        return $imagename;
        //return '/media' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'user_profile' . DIRECTORY_SEPARATOR . $imagename;    
    }
}
