<?php

return [
    'adminEmail' => 'admin@example.com',
    'googleMapsUrlOptions' => [
        'key' => 'AIzaSyDV0hzpMzB9qDYi0xpyuy9AEXfiIbUvdFU',
        'language' => 'id',
        'version' => '3.1.18',
    ],
    'googleMapsOptions' => [
        'mapTypeId' => 'roadmap',
        'tilt' => 45,
        'zoom' => 5,
    ],
];
