<?php
/**
 * Created by PhpStorm.
 * User: rohan
 * Date: 16/2/16
 * Time: 4:30 PM
 */

namespace backend\components;

use Yii;
use yii\base\Component;
use common\models\siteconfiguration\SiteConfiguration;

class CommonFunctions extends Component
{
    public function welcome()
    {
        echo "Hello..Welcome to MyComponent";
    }

    public static function base64ToImage($data,$output_file_without_extentnion ,$path) {
        $full_path = Yii::getAlias('@backend') . "/web/uploads/".$path;
        $splited = explode(',', substr($data , 5 ) , 2);
        $data = str_replace('data:image/png;base64,', '', $data);
        $mime=$splited[0];
        $data=$splited[1];
        
        $mime_split_without_base64=explode(';', $mime,2);
        $mime_split=explode('/', $mime_split_without_base64[0],2);
        $extension=$mime_split[1];
        
        $output_file=str_replace(' ', '_', $output_file_without_extentnion).'.'.$extension;        
        $final_file = $full_path.$output_file;       
        $success = file_put_contents($final_file,base64_decode($data));
        if($success){
            $media = [$final_file,$path];
            return $media;
        }else{
            return false;
        }
    }   
    
    public static function returnExtension($icon) {
            $splited = explode(',', substr($icon , 5 ) , 2);
            $icon = str_replace('data:image/png;base64,', '', $icon);
            $mime=$splited[0];
            $icon=$splited[1];

            $mime_split_without_base64=explode(';', $mime,2);
            $mime_split=explode('/', $mime_split_without_base64[0],2);
            $extension=$mime_split[1];
            
            return '.'.$extension;
    }

    public function getConfigureValueByKey( $key ){
		
            $model = SiteConfiguration::findOne(['config_key'=> $key]);
            if( $model != null ){
                return $model->config_value;
            }else{
                return 'Undefine Key';
            }
    }
    
}