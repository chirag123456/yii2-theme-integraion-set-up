<?php
/**
 * Created by PhpStorm.
 * User: akshay
 * Date: 25/1/17
 * Time: 2:51 PM
 */

namespace backend\components;
use Yii;
use common\models\Media;
use yii\web\UploadedFile;
use yii\helpers\StringHelper;

class Helper
{
    public static function uploadFile($model,$name,$image_attribute,$path){

       if(isset($_FILES)){

            $model_name = StringHelper::basename(get_class($model));

            $extension = pathinfo($_FILES[$model_name]['name'][$image_attribute], PATHINFO_EXTENSION);
            $new_name = str_replace(' ', '_', $name). '_' . time() . '.' . $extension;
            $new_path = Yii::getAlias('@backend') . "/web/uploads/" . $path;
            $file_name = $_FILES[$model_name]['name'][$image_attribute];
            $tmp_name = $_FILES[$model_name]['tmp_name'][$image_attribute];
            if(move_uploaded_file($tmp_name,$new_path.$new_name)) {
                $media = new Media();
                $media->file_name = $new_name;
                $media->file_path = $new_path . $media->file_name;
                $media->original_name = $file_name;
                $media->file_url = Yii::$app->urlManager->createAbsoluteUrl($path . $media->file_name);
                $media->staus = ACTIVE;
                $media->is_deleted = 0;
                $media->created_by = 1;
                $media->created_date = time();
                $media->updated_by = 1;
                $media->updated_date = time();
                $media->save();
                return $media->id;
            }else{
                print_r("Picture not uploaded");
                return false;
            }
        }else{
            print_r("files not exist");
            return false;
        }
    }

    public static function saveFile($url,$path){

        $file_name = basename($url); // to get file name

        $media = new Media();
        $media->file_name = $file_name;
        $media->file_path = $url;
        $media->original_name = $file_name;
        $media->file_url = Yii::$app->urlManager->createAbsoluteUrl("/web/uploads/".$path.$file_name);
        $media->staus = ACTIVE;
        $media->is_deleted = 0;
        $media->created_by = 1;
        $media->created_date = time();
        $media->updated_by = 1;
        $media->updated_date = time();
        if($media->validate()){
            $media->save();
            return $media->id;
        }else{
            return false;
        }
    }

        public static function base64ToImage($data,$output_file_without_extentnion ,$path) {

        $full_path = Yii::getAlias('@backend') . "/web/uploads/".$path;

        $splited = explode(',', substr($data , 5 ) , 2);
        $data = str_replace('data:image/png;base64,', '', $data);

        $mime=$splited[0];
        $data=$splited[1];

        $mime_split_without_base64=explode(';', $mime,2);
        $mime_split=explode('/', $mime_split_without_base64[0],2);
        $extension=$mime_split[1];

        $output_file=$output_file_without_extentnion."_".time().'.'.$extension;

        $final_file = $full_path.$output_file;

        $success = file_put_contents($final_file,base64_decode($data));

        if($success){
            $media = Helper::saveFile($final_file,$path);
            return $media;
        }else{
            return false;
        }
    }

    public static function compress($source, $destination, $quality) {

        $info = getimagesize($source);

        if ($info['mime'] == 'image/jpeg') {
            $image = imagecreatefromjpeg($source);
        }
        elseif ($info['mime'] == 'image/gif') {
            $image = imagecreatefromgif($source);
        }
        elseif ($info['mime'] == 'image/png') {
            $image = imagecreatefrompng($source);
        }

        imagejpeg($image, $destination, $quality);

        return $destination;
    }

    


}