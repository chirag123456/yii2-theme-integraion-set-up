<?php
namespace backend\components;
use Yii;
use yii\helpers\Url;
use yii\web\Controller;

class CustController extends Controller {


     public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }
        
        if(Yii::$app->user->isGuest){
            $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
            return false; //not run the action
        }else{
            return true;
        }
        return true; // continue to run action
    }
}