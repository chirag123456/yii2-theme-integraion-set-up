<?php
/*namespace backend\components;
use Yii;
use yii\helpers\Url;
use yii\web\Controller;

class CustController extends Controller {


     public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }
        
        if(Yii::$app->user->isGuest){
            $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
            return false; //not run the action
        }else{
            return true;
        }
        return true; // continue to run action
    }
}*/

namespace backend\components;
use Yii;
use yii\helpers\Url;
use yii\web\Controller;
//use common\models\RolePermission;
use backend\behaviors\AccessBehavior;

use common\models\userrole\AuthAssignment;
use common\models\userrole\UserAccess;

class CustController extends Controller {

    use AccessBehavior;
    /**
     * beforeAction
     */
    public function beforeAction($action) {
        if (!parent::beforeAction($action)) {
            return false;
        }
        
        if(Yii::$app->user->isGuest){
            $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
            return false; //not run the action
        }else{
            return true;
        }
        
        return true; // continue to run action
    }
    /**
     * unauthorizedAccessRedirect
     */
    public function unauthorizedAccessRedirect() {
        Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-remove-sign',
                'message' => 'Unauthorized Access!',
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            //return $this->redirect(['/dashboard']);
            return $this->redirect(Yii::$app->request->referrer ?: Yii::$app->homeUrl);
            //return $this->refresh();
    }
    
    /**
     * accessbyroles
     
    public function accessbyroles()
    {
        $access_auth = AuthAssignments::findOne([ 'user_id' => Yii::$app->user->id ]);
        
        if( $access_auth != null ){
            $module = Yii::$app->controller->module->id;
            $user_access = UserAccess::findOne(['name' => $access_auth->item_name , 'is_admin' => '0']);
            if( $user_access != null ){
                //echo '<pre>';print_r($user_access);die;
                if( strstr( $user_access->access , $module) ){
                    return ['admin' , $user_access->name ];
                }
            }else{
                return ['admin'];
            }
        }
        return ['admin'];
    }*/
    
    /**
     * checkViewPermissions
     */
    public function checkViewPermissions($type) {           
        if( Yii::$app->user->identity->role == 1 ){
            $permissions = RolePermission::find()->select(['view_permission'])
                                ->where(['user_id' => Yii::$app->user->identity->id ])
                                ->andWhere(['is_active'=>ACTIVE,'is_delete' => NOT_DELETED])->one();
            if( $permissions != null ){
                $arr = explode(',' , $permissions->view_permission );
                if( is_array( $arr ) ){
                    if( in_array( $type , $arr ) ){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }else{
            return true;
        }
    }
    
    /**
     * checkEditPermissions
     */
    public function checkEditPermissions($type) {
        if( Yii::$app->user->identity->role == 1 ){
            $permissions = RolePermission::find()->select(['edit_permission'])
                                ->where(['user_id' => Yii::$app->user->identity->id ])
                                ->andWhere(['is_active'=>ACTIVE,'is_delete' => NOT_DELETED])->one();
            
            if( $permissions != null ){
                $arr = explode(',' , $permissions->edit_permission );
                if( is_array( $arr ) ){
                    if( in_array( $type , $arr ) ){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }else{
            return true;
        }
    }
    
    /**
     * setSuccessFlashMessage
     */
    public function setSuccessFlashMessage($msg){
        return Yii::$app->getSession()->setFlash('success', [
            'type' => 'success',
            'duration' => 12000,
            'icon' => 'glyphicon glyphicon-ok-sign',
            'message' => $msg,
            'title' => 'Success!',
            'positonY' => 'top',
            'positonX' => 'right'
        ]);
    }
    
    /**
     * setErrorFlashMessage
     */
    public function setErrorFlashMessage($msg){
        return Yii::$app->getSession()->setFlash('success', [
            'type' => 'danger',
            'duration' => 12000,
            'icon' => 'glyphicon glyphicon-remove-sign',
            'message' => $msg,
            'title' => 'Error!',
            'positonY' => 'top',
            'positonX' => 'right'
        ]); 
    }
}