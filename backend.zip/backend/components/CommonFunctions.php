<?php

/**
 * Created by PhpStorm.
 * User: rohan
 * Date: 16/2/16
 * Time: 4:30 PM
 */

namespace backend\components;

use Yii;
use yii\base\Component;
use common\models\siteconfiguration\SiteConfiguration;
use common\models\user\User; 
use common\models\project\Project;


class CommonFunctions extends Component {

    public function welcome() {
        echo "Hello..Welcome to MyComponent";
    }

    public static function base64ToImage($data, $output_file_without_extentnion, $path) {
        $full_path = Yii::getAlias('@backend') . "/web/uploads/" . $path;
        $splited = explode(',', substr($data, 5), 2);
        $data = str_replace('data:image/png;base64,', '', $data);
        $mime = $splited[0];
        $data = $splited[1];

        $mime_split_without_base64 = explode(';', $mime, 2);
        $mime_split = explode('/', $mime_split_without_base64[0], 2);
        $extension = $mime_split[1];

        $output_file = str_replace(' ', '_', $output_file_without_extentnion) . '.' . $extension;
        $final_file = $full_path . $output_file;
        $success = file_put_contents($final_file, base64_decode($data));
        if ($success) {
            $media = [$final_file, $path];
            return $media;
        } else {
            return false;
        }
    }

    public static function returnExtension($icon) {
        $splited = explode(',', substr($icon, 5), 2);
        $icon = str_replace('data:image/png;base64,', '', $icon);
        $mime = $splited[0];
        $icon = $splited[1];

        $mime_split_without_base64 = explode(';', $mime, 2);
        $mime_split = explode('/', $mime_split_without_base64[0], 2);
        $extension = $mime_split[1];

        return '.' . $extension;
    }

    public function getConfigureValueByKey($key) {

        $model = SiteConfiguration::findOne(['config_key' => $key]);
        if ($model != null) {
            return $model->config_value;
        } else {
            return 'Undefine Key';
        }
    }

    public function getDashboardDetails() {

        $daily_user = User::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['is_admin' => NOT_DELETED])
        ->andWhere(['>=','created_date',date("Y-m-d")])
        ->count('id');

        $daily_project = Project::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','created_date',date("Y-m-d")])
        ->count('id');
        
        $weekly_user = User::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['is_admin' => NOT_DELETED])
        ->andWhere(['>=','DAY(created_date)',date('d') -7])
        ->andWhere(['>=','MONTH(created_date)',date('m')])
        ->count('id');

        $weekly_project = Project::find()->where(['>=','DAY(created_date)',date('d') -7])
        ->andWhere(['>=','MONTH(created_date)',date('m')])
        ->count('id');

        $monthly_user = User::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['is_admin' => NOT_DELETED])
        ->andWhere(['>=','MONTH(created_date)',date('m')])
        ->count('id');

        $monthly_project = Project::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','MONTH(created_date)',date('m')])
        ->count('id');

        $yearly_user = User::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['is_admin' => NOT_DELETED])
        ->andWhere(['>=','YEAR(created_date)',date('Y')])
        ->count('id');

        $yearly_project = Project::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','YEAR(created_date)',date('Y')])
        ->count('id');
        
        $total_User = User::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere(['is_admin' => NOT_DELETED])
        ->count('id'); 

        $total_project = Project::find()->where(['is_delete' => NOT_DELETED])->count('id');
                
        return [
            'details' => [
                'daily_user' => isset($daily_user) ? $daily_user : '0',
                'daily_project' => isset($daily_project) ? $daily_project : '0',
                'weekly_user' => isset($weekly_user) ? $weekly_user : '0',
                'weekly_project' => isset($weekly_project) ? $weekly_project : '0',
                'monthly_user' => isset($monthly_user) ? $monthly_user : '0',
                'monthly_project' => isset($monthly_project) ? $monthly_project : '0',
                'yearly_user' => isset($yearly_user) ? $yearly_user : '0',
                'yearly_project' => isset($yearly_project) ? $yearly_project : '0',
                'total_User' => isset($total_User) ? $total_User : '0',
                'total_project' => isset($total_project) ? $total_project : '0',
            ]
        ];
    }

  
}
