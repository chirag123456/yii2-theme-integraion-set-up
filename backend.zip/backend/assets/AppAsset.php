<?php                                                                                                    
namespace backend\assets;
use yii\web\AssetBundle;

/**
 * Main backend application asset bundle.
 */
class AppAsset extends AssetBundle {

    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/site.css',
        //'bootstrap/css/bootstrap.min.css',
        // 'http://www.jqueryscript.net/css/jquerysctipttop.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css',
        'plugins/datatables/dataTables.bootstrap.css',
        'dist/css/AdminLTE.min.css',
        'dist/css/skins/_all-skins.min.css',
        'plugins/iCheck/flat/blue.css',
        // 'plugins/morris/morris.css',
        // 'plugins/jvectormap/jquery-jvectormap-1.2.2.css',
        'plugins/datepicker/datepicker3.css',
        //'plugins/daterangepicker/daterangepicker.css',
        // 'plugins/iCheck/square/blue.css',
        // 'plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css',
        'css/cropping/style-example.css',
        'css/cropping/jquery.Jcrop.css',
        'css/custom.css',
        'plugins/viewbox-master/viewbox.css',
        'plugins/select2/select2.min.css',
        "https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css",

        //'dropzone/dropzone.css',
        //'dropzone/style.css'
        "css/responsive.css",
        'css/fullcalendar.min.css',
        //'css/fullcalendar.print.min.css',

    ];
    public $js = [
        // 'http://pagead2.googlesyndication.com/pagead/show_ads.js',
        'plugins/datatables/jquery.dataTables.min.js',
        'plugins/datatables/dataTables.bootstrap.min.js',
        'plugins/datepicker/bootstrap-datepicker.js',
        'dist/js/app.min.js',
        'dist/js/demo.js',
        'js/custom.js',
        'js/cropping/jquery.Jcrop.js',
        'js/cropping/jquery.SimpleCropper.js',
        'plugins/chartjs/Chart.js',
        'plugins/viewbox-master/jquery.viewbox.min.js',
        'plugins/select2/select2.full.min.js'
            // 'plugins/Yearly-Calendar/calendar_by_year.js',
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\bootstrap\BootstrapPluginAsset',
    ];

}
