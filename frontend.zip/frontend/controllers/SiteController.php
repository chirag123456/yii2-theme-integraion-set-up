<?php
namespace frontend\controllers;

use yii\web\Controller;
use yii\helpers\Html;

/**
 * Site controller
 */
class SiteController extends Controller {
    
    public function actionIndex() {
        $this->redirect(['backend/']);
    }

}
