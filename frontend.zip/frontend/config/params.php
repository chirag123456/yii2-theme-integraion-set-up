<?php
return [
    'adminEmail' => 'admin@example.com',
    'languages' => [
        'en' => 'English',
        'fr' => 'Franch',
        'pk' => 'Pakisthan',
        'hi' => 'Hindi',
        'ru' => 'Russian',
    ],
];
