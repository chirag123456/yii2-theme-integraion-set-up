<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace frontend\components;

class CommonFunctions extends \yii\base\Behavior {

    public function events() {
        return [
            \yii\web\Application::EVENT_BEFORE_REQUEST => 'changeLanguage',
        ];
    }

    public function changeLanguage() {

        if (\Yii::$app->getRequest()->getCookies()->has('lang')) {
            \Yii::$app->language = \Yii::$app->getRequest()->getCookies()->getValue('lang');
        }
    }


}
