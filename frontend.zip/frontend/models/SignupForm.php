<?php

namespace frontend\models;

use yii\base\Model;
use common\models\User;

/**
 * Signup form
 */
class SignupForm extends Model {

    public $fname;
    public $email;
    public $password;
    public $confirm_password;
    public $terms_condition;
    

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            ['fname', 'trim'],
            ['fname', 'required', 'message' => 'Name can not be blank'],
            ['terms_condition', 'required', 'message' => 'Terms & Condition can be required'],
            //['fname', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This username has already been taken.'],
            ['fname', 'string', 'min' => 2, 'max' => 255],
            ['email', 'trim'],
            [['confirm_password'], 'required', 'message' => 'Repeat password can not be blank'],
            [['email',], 'required'],
            ['email', 'email'],
            ['email', 'string', 'max' => 255],
            ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This email address has already been taken.'],
            ['password', 'required'],
            ['password', 'string', 'min' => 6],
            ['confirm_password', 'compare', 'compareAttribute' => 'password', 'message' => "Repeat password and password must be same."],
                // ['confirm_password', 'compare', 'compareAttribute' => 'password']
        ];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function signup() {
        if (!$this->validate()) {
            return null;
        }

        $user = new User();
        $user->username = $this->username;
        $user->email = $this->email;
        $user->setPassword($this->password);
        $user->generateAuthKey();

        return $user->save() ? $user : null;
    }

}
