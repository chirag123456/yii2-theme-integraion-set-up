<?php

namespace frontend\assets;

use yii\web\AssetBundle;

/**
 * Main frontend application asset bundle.
 */
class AppAsset extends AssetBundle {

    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        //'css/site.css',
        // 'css/style/bootstrap.min.css',
        'css/style/bootstrap-theme.min.css',
        'css/style/style.css',
        'css/style/responsive.css',
        'https://fonts.googleapis.com/css?family=Montserrat|Noto+Sans:400,400i,700,700i|Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i',
    ];
    public $js = [
        'js/custom.js',
//        'js/js/bootstrap.min.js',
    ];
    public $depends = [
    //    'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\bootstrap\BootstrapPluginAsset',
    ];

}
