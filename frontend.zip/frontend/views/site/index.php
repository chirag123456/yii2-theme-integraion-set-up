<div class="home-background">
    <div class="container">
        <div class="row">
            <div class="welcome">
                <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['site/signup']) ?> " class="reg-red-btn menu-top">
                    <img src="<?= Yii::$app->request->baseUrl ?>/images/user.png">	Registration
                </a>
                <div id="overlay"></div> 
                <div class="menu">
                    <div class="menu_btn">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>	
                    </div>
                    <div class="cart">
                        <img src="<?= Yii::$app->request->baseUrl ?>/images/cart.png">
                    </div>
                </div>

                <div class="menu-detail">
                    <div class="user-detail">
                        <img src="<?= Yii::$app->request->baseUrl ?>/images/profile-pic.png">
                        <p>Name Familyname</p>
                        <a href="#">Edit profile</a>
                    </div>

                    <ul>
                        <li><a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['product/index']) ?> ">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/search2.png">
                                Search Products
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/cart2.png">
                                Shopping List<span class="green-badge">63</span>
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/user2.png">
                                Registration
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/star.png">
                                Terms & Conditions
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/setting.png">
                                Settings
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/feedback.png">
                                Feed Back
                            </a>
                        </li>
                        <?php if (!Yii::$app->user->isGuest) { ?> 
                            <li><a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['site/logout']) ?> ">
                                    <img src="<?= Yii::$app->request->baseUrl ?>/images/logout.png">Exit
                                </a>
                            </li>
                        <?php } else { ?> 
                            <li><a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['site/login']) ?> ">
                                    <img src="<?= Yii::$app->request->baseUrl ?>/images/logout.png">Login
                                </a>
                            </li>
                        <?php } ?>

                    </ul>
                </div>

                <a href="#" class="skip">skip</a>
                <div class="row">
                    <div class="col-xs-10 col-xs-offset-1">
                        <div class="input-group">
                            <span class="input-group-addon"><img src="<?= Yii::$app->request->baseUrl ?>/images/search.png"></span>
                            <input type="text" class="form-control search-box" placeholder="Search Products....">
                        </div>
                    </div>
                </div>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Carousel indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>   
                    <!-- Wrapper for carousel items -->
                    <div class="wc_logo">
                        <img src="<?= Yii::$app->request->baseUrl ?>/images/wc_logo.png" >  
                    </div>

                    <div class="wc_title">SRAVNI PAZARA</div>
                    <div class="carousel-inner">

                        <div class="item active">
                            <div class="wc_subtitle">Shop wisely!</div>
                            <p class="wc_data">Add your list with grocery products you wish to buy and COMPARE the prices at the local supermarkets!</p>
                        </div>
                        <div class="item">

                            <!-- <div class="wc_logo">
                                    <img src="images/wc_logo.png" >  
                            </div>

                            <div class="wc_title">SRAVNI PAZARA</div> -->
                            <div class="wc_subtitle">Shop wisely!</div>
                            <p class="wc_data">Add your list with grocery products you wish to buy and COMPARE the prices at the local supermarkets!</p>    
                        </div>
                        <div class="item">

                            <!-- <div class="wc_logo">
                                    <img src="images/wc_logo.png" >  
                            </div>

                            <div class="wc_title">SRAVNI PAZARA</div> -->
                            <div class="wc_subtitle">Shop wisely!</div>
                            <p class="wc_data">Add your list with grocery products you wish to buy and COMPARE the prices at the local supermarkets!</p>
                        </div>
                    </div>
                    <!-- Carousel controls -->
                    <!-- <a class="carousel-control left" href="#myCarousel" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a class="carousel-control right" href="#myCarousel" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a> -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$this->registerJs("
        
$(document).ready(function(){
		$('.menu_btn').click(function(){
			$('.menu-detail').addClass('open');
			$('#overlay').css('display','block');
			$('body').addClass('overflow');
		});

		$('#overlay').click(function() {
	      $('.menu-detail').removeClass('open');
		  $('#overlay').css('display','none');
	      $('body').removeClass('overflow');
		  

	 	});
	});
");
?>