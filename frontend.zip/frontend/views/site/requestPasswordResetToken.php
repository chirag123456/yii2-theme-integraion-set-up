<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\Url;
?>
<div class="home-background">
    <div class="container">
        <div class="row">
            <div class="col-xs-10 col-xs-offset-1 text-center login col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                <h1 class="title">Forgot Password</h1>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'request-password-reset-form',
//                            'enableAjaxValidation' => true,
//                            'enableClientValidation' => true,
                ]);
                ?>
                <div class="form-group">
                    <!-- <label for="inputEmail">Email</label> -->
                    <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => "form-control", 'id' => "inputEmail", 'placeholder' => 'Email'])->label(false) ?>
                </div>

                
                <button type="submit" class="btn btn-green">Enter</button>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>
</div>