<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\Url;
use kartik\social\GooglePlugin;
use Facebook\Facebook;

include_once(__DIR__ . "/../..//components/Facebook/autoload.php");
include_once(__DIR__ . "/../..//components/Google/autoload.php");


if (!session_id()) {
    session_start();
}

//facebook with login 
$fb = new Facebook([
    'app_id' => '228032454374464',
    'app_secret' => '8256696e07d8e85459840e752581b07b',
    'default_graph_version' => 'v2.9',
    'persistent_data_handler' => 'session',
        ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email']; // Optional permissions
$loginUrl = $helper->getLoginUrl(yii\helpers\Url::base().'/facebook/index', $permissions);

//google with login  

$client_id = '162691646946-b9g6dq2ifjrcng5lslg1kmocaovde2cs.apps.googleusercontent.com';
$client_secret = 'qrGmYZhjBKSjKebmSA2zrnEg';
$redirect_uri = yii\helpers\Url::base().'/google/data';

$client = new Google_Client();
$client->setClientId($client_id);
$client->setClientSecret($client_secret);
$client->setRedirectUri($redirect_uri);
$client->addScope("email");
$client->addScope("profile");

$service = new \Google_Service_Oauth2($client);

$authUrl = $client->createAuthUrl();
?>

<div class="home-background">
    <div class="container">
        <div class="row">
            <div class="col-xs-10 col-xs-offset-1 text-center login col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                <h1 class="title">Login</h1>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'login-form',
//                            'enableAjaxValidation' => true,
//                            'enableClientValidation' => true,
                ]);
                ?>
                <div class="form-group">
                    <!-- <label for="inputEmail">Email</label> -->
                    <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => "form-control", 'id' => "inputEmail", 'placeholder' => 'Email'])->label(false) ?>

                </div>

                <div class="form-group">
                    <!-- <label for="inputPassword">Password</label> -->
                    <?= $form->field($model, 'password')->passwordInput(['maxlength' => true, 'class' => "form-control", 'id' => "inputPassword", 'placeholder' => 'Password'])->label(false) ?>

                </div>

                <a href="<?= Url::to(['site/request-password-reset']) ?>" class="forget_link">Recover forgotten password</a>
                <div class="checkbox">
                    <!-- <label><input type="checkbox"> Remember me</label> -->
                    <input class="styled-checkbox" id="styled-checkbox-1" type="checkbox" value="value1">
                    <label for="styled-checkbox-1">Remember me</label>
                </div>

                <button type="submit" class="btn btn-green">Enter</button>
                <div class="login_with">
                    <p>Login With Email</p>

                    <a href="<?= $authUrl ?>" type="submit" class="btn btn-red">Google</a>
                    <a href="<?= $loginUrl ?> "type="submit" class="btn btn-blue">Facebook</a>

                </div>
                <?php ActiveForm::end(); ?>
            </div>
        </div>
    </div>
</div>