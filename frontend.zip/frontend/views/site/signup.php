<?php

use yii\bootstrap\ActiveForm;
?>
<div class="home-background">
    <div class="container">
        <div class="row">
            <div class="col-xs-10 col-xs-offset-1 text-center registration col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                <h1 class="title">Registration</h1>
                <?php
                $form = ActiveForm::begin([
                            'id' => 'signup-form',
                            'enableAjaxValidation' => true,
                            'enableClientValidation' => true,
                ]);
                ?>
                <div class="form-group">
                    <?= $form->field($model, 'fname')->textInput(['maxlength' => true, 'class' => "form-control", 'id' => "inputName", 'placeholder' => 'Name'])->label(false) ?>

                </div>
                <div class="form-group">
                    <!-- <label for="inputEmail">Email</label> -->
                    <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => "form-control", 'id' => "inputEmail", 'placeholder' => 'Email'])->label(false) ?>
                </div>

                <div class="form-group">
                    <!-- <label for="inputPassword">Password</label> -->
                    <?= $form->field($model, 'password')->passwordInput(['maxlength' => true, 'class' => "form-control", 'id' => "inputPassword", 'placeholder' => 'Password'])->label(false) ?>

                </div>

                <div class="form-group">
                    <!-- <label for="inputPassword">Password</label> -->
                    <?= $form->field($model, 'confirm_password')->passwordInput(['maxlength' => true, 'class' => "form-control", 'id' => "", 'placeholder' => 'Repeat password'])->label(false) ?>

                </div>
                <div class="checkbox">
                    <!-- <label><input type="checkbox"> Remember me</label> -->
                    <input class="styled-checkbox" id="styled-checkbox-2" name="SignupForm[terms_condition]" uncheck = null, checked = true type="checkbox" value="value2">
                    <label for="styled-checkbox-2">Terms & Conditions</label>
                    <?php echo $form->field($model, 'terms_condition')->checkbox(['class' => 'styled-checkbox', 'id' => 'styled-checkbox-2', 'uncheck' => null, 'checked' => true]); ?> 

                </div>
                <button type="submit" class="btn btn-green">Register</button>
                <?php ActiveForm::end(); ?>
                <div class="login_with">
                    <p>Login With Email</p>

                    <button type="submit" class="btn btn-red">Google</button>
                    <button type="submit" class="btn btn-blue">Facebook</button>

                </div>
            </div>
        </div>
    </div>
</div>