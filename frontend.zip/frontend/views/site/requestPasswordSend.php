
<div class="home-background">
    <div class="container">
        <div class="row">
            <div class="col-xs-10 col-xs-offset-1 text-center login col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3">
                <h1 class="title">Thank You</h1>

                <p class="text-success">Please check your email for further instructions.</p>
                <a href="<?= yii\helpers\Url::to(['site/login']) ?>"> Click here to GoBack to Login page</a>
            </div>
        </div>
    </div>
</div>
