
<div class="home-background">
    <div class="container">
        <div class="row">
            <div class="welcome">
                <div id="overlay"></div> 
                <div class="menu">
                    <div class="menu_btn">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>	
                    </div>
                    <div class="cart">
                        <img src="<?= Yii::$app->request->baseUrl ?>/images/cart.png">
                    </div>
                </div>

                <div class="menu-detail">
                    <div class="user-detail">
                        <img src="<?= Yii::$app->request->baseUrl ?>/images/profile-pic.png">
                        <p>Name Familyname</p>
                        <a href="#">Edit profile</a>
                    </div>

                    <ul>
                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/search2.png">
                                Search Products
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/cart2.png">
                                Shopping List<span class="green-badge">63</span>
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/user2.png">
                                Registration
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/star.png">
                                Terms & Conditions
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/setting.png">
                                Settings
                            </a>
                        </li>

                        <li><a href="#">
                                <img src="<?= Yii::$app->request->baseUrl ?>/images/feedback.png">
                                Feed Back
                            </a>
                        </li>

                      
                    </ul>
                </div>


                <div id="myCarousel" class="carousel " data-ride="carousel">
                    <!-- Carousel indicators -->

                    <!-- Wrapper for carousel items -->
                    <div class="carousel-inner">
                        <div class="item active">

                            <div class="wc_logo">
                                <a href="<?= yii\helpers\Url::to(['site/login']) ?>"><img src="<?= Yii::$app->request->baseUrl ?>/images/wc_logo.png"></a>  
                            </div>

                            <div class="wc_title">SRAVNI PAZARA</div>
                            <div class="wc_subtitle">Thank you!</div>
                            <p class="text-center"><a  href="<?= yii\helpers\Url::to(['site/login']) ?>"> Click here to GoBack to Login page</a></p>

                        </div>

                    </div>
                    <!-- Carousel controls -->
                    <!-- <a class="carousel-control left" href="#myCarousel" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a class="carousel-control right" href="#myCarousel" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a> -->
                </div>
            </div>
        </div>
    </div>
</div>


