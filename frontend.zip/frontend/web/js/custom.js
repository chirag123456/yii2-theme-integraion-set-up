/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
    $(".menu_btn").click(function () {
        $(".menu-detail").addClass("open");
        $("#overlay").css("display", "block");
        $('body').addClass("overflow");
    });

    $("#overlay").click(function () {
        $(".menu-detail").removeClass('open');
        $("#overlay").css("display", "none");
        $('body').removeClass("overflow");


    });
});