<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */

/*$resetLink = Yii::$app->urlManager->createAbsoluteUrl(['site/reset-password', 'token' => $user->password_reset_token]);*/
//$resetLink =Yii::$app->request->hostInfo.'/site/reset-password?token='.$user->password_reset_token;
?>

Hello <?php echo $data['userfirstname'] . ' '.  $data['userlastname'] ?>,

<?php echo $data['msg'] ;?>

Task Name: <?php echo $data['task_name'];?>
Project Name: <?php echo $data['project_name'];?>
Task Priority: <?php echo $data['priority'];?>
Task Status: <?php echo $data['task_status'];?>
Start Date: <?php echo $data['start_date'];?>
Due Date: <?php echo $data['due_date'];?>
Task Description: <?php echo $data['description'];?>
