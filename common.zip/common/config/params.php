<?php
return [
    'adminEmail' => 'demo.xceltec1@gmail.com',
    'supportEmail' => 'demo.xceltec1@gmail.com',
    'user.passwordResetTokenExpire' => 3600,
//    'page' =>$page_size = common\models\Settings::findAll(),
];
