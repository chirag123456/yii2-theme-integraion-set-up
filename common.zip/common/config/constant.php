<?php
$local = true;

define("APP_NAME", "CCS");
define("VERSION", "1.0.0");
define("COMPANY_NAME", "CCS");
define('ADMIN_EMAIL', 'demo.xceltec4@gmail.com');
define('TITLE', 'CCS');


define("FROM_EMAIL", "demo.xceltec4@gmail.com");

//Status
define("ACTIVE", 'Y');
define("INACTIVE", 'N');
//define("FINISHED",2);
//set password
define("DEFAULT_PASSWORD", '123456');

//Deleted
define("DELETED", 'Y');
define("NOT_DELETED", 'N');

//platforms
define("WEB", 0);
define("IOS", 1);
define("ANDROID", 2);
//send mail types constants
define('WELCOME_MAIL', 1);
define('FORGOT_PASSWORD_MAIL', 2);

// Roles
define("ADMIN", 1);
define("SUPER_ADMIN", 2);
define("APP_USER", 3);

//User's Verification Status
define("USER_VERIFIED", 1);
define("USER_PENDING", 0);

//some Default values
define("DEFAULT_COUNTRY_CODE", 91);
define("DEFAULT_USER_ID", 1);

//Login Status
define("NOT_LOGGED_IN", 'N');
define("LOGGED_IN", 'Y');

//DEFUALT VALUES


define('PAGESIZE', 10);
define('DONATION_PAGESIZE', 30);

//messages in flash
define('ADDED', 'Record has been added successfully.');
define('UPDATED', 'Record has been updated successfully.');
define('DEACTIVATED', 'Record has been deactivated successfully.');
define('ACTIVATED', 'Record has been activated successfully.');
define('DELETEDMESSAGE', 'Record has been deleted successfully.');
define('EMAIL', 'This email is already exist.');
define('ALREADY', ' is already exist.');
define('ACTIVESTATUS', ' Are you sure want to active this Record?');
define('INACTIVESTATUS', ' Are you sure want to inactive this Record?');
define('DELETESTATUS', ' Are you sure want to delete this Record?');
define('PHONE', 'This phone number is already exist.');
define('DATA_NOT_SAVED', 'Something Error: In data save!');
define('DATA_NOT_VALID', 'Something Error: Invalid data!');

define('USER_PROFILE_PATH','/media/uploads/user_profile/');
define('OPEN','OPEN');