<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\projectbudget; 

use yii\base\Model;
use common\models\projectbudget\ProjectBudget;

class ProjectBudgetForm extends Model {

    public $project_id;
    public $pb_name;
    public $contractor_id;
    public $sub_contractor_id;
    public $sub_contractor_total_cost;
    public $pb_total_cost;
    public $pb_desc;
    public $id;

    public function rules() {

        return [
            [['project_id','sub_contractor_total_cost','pb_total_cost','pb_desc'], 'required'],
            
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id= $model->project_id; 
        $this->pb_name= $model->pb_name;
        $this->contractor_id= $model->contractor_id;
        $this->sub_contractor_id= $model->sub_contractor_id;
        $this->sub_contractor_total_cost= $model->sub_contractor_total_cost;
        $this->pb_total_cost= $model->pb_total_cost;
        $this->pb_desc= $model->pb_desc;
        return $this;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'pb_name' => 'Project Budget Name',
            'contractor_id' => 'Contractor Name',
            'sub_contractor_id' => 'Sub Contractor Name',
            'sub_contractor_total_cost' => 'Sub Contractor Total Cost',
            'pb_total_cost' => 'Project Budget Total Cost',
            'pb_desc' => 'Description'
        ];
    }
}