<?php

namespace common\models\projectbudget;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\projectbudget\ProjectBudget;

/**
 * ProjectBudgetSearch represents the model behind the search form about 
 */
class ProjectBudgetSearch extends ProjectBudget {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id', 'created_by', 'updated_by'], 'integer'],
            [['project_id','pb_name','contractor_id','sub_contractor_id','sub_contractor_total_cost','pb_total_cost','pb_desc','created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = ProjectBudget::find()->where(['project_budget_management.is_delete' => NOT_DELETED]);

        // add conditions that should always apply here
        //  $settings = \common\models\Settings::find()->one();
        
         $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $dataProvider->sort->attributes['project_id'] = [
            'asc' => ['project_management.project_name' => SORT_ASC],
            'desc' => ['project_management.project_name' => SORT_DESC],
        ];

        $dataProvider->sort->attributes['sub_contractor_id'] = [
            'asc' => ['contractor_management.contractor_name' => SORT_ASC],
            'desc' => ['contractor_management.contractor_name' => SORT_DESC],
        ];
         
        $this->load($params); 


        if (!$this->validate()) {
           
            return $dataProvider;
        }
        
        $query->joinWith(['project']);

        // grid filtering conditions
        $query->andFilterWhere([
            //'id' => $this->id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
                ->andFilterWhere(['like', 'pb_name', $this->pb_name])
                ->andFilterWhere(['like', 'sub_contractor_total_cost', $this->sub_contractor_total_cost])
                ->andFilterWhere(['like', 'pb_total_cost', $this->pb_total_cost])
                ->andFilterWhere(['like', 'project_budget_management.is_active', $this->is_active])
                ->andFilterWhere(['like', 'project_budget_management.id', $this->id])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

}
