<?php

namespace common\models\projectbudget;

use Yii;
use common\models\project\Project;
use common\models\contractor\ContractorManagement;
use common\models\user\User;
use common\models\itemwork\ItemWork;

/**
 * This is the model class for table "city".
 *
 * @property integer $id
 * @property string $name
 * @property integer $created_by
 * @property string $created_date
 * @property integer $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 
 */
class ProjectBudgetItem extends \yii\db\ActiveRecord
{
    /**
    * @inheritdoc
    */

    public static function tableName()
    {
        return 'project_budget_item';
    }

    /**
    * @inheritdoc
    */

    public function rules()
    {
        return [
            [['project_id','project_budget_id','item_id','cost','comment','sub_contractor_estimate_cost','is_active', 'is_delete','sub_contractor_id'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
        ];
    }
 
    /**
    * @inheritdoc
    */
    
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'project_budget_id' => 'Project Budget Name',
            'item_id' => 'Item Work Name',
            'cost' => 'Item Work Cost',
            'comment' => 'Comment',
            'sub_contractor_estimate_cost' => 'Sub Contactor Estimate Cost',
            'sub_contractor_id' => 'Sub Contactor Name',
            'pb_total_cost' => 'Project Budget Total Cost',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getContractor()
    {
        return $this->hasOne(User::className(), ['id' => 'contractor_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getSubcontractor()
    {
        return $this->hasOne(User::className(), ['id' => 'sub_contractor_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getItem()
    {
        return $this->hasOne(ItemWork::className(), ['id' => 'item_id']);
    }
}