<?php

namespace common\models\projectbudget;

use Yii;
use common\models\project\Project;
use common\models\contractor\ContractorManagement;
use yii\db\Query;

/**
 * This is the model class for table "city".
 *
 * @property integer $id
 * @property string $name
 * @property integer $project_id
 * @property integer $created_by
 * @property string $created_date
 * @property integer $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 
 */
class ProjectBudget extends \yii\db\ActiveRecord
{
    /**
    * @inheritdoc
    */

    public static function tableName()
    {
        return 'project_budget_management';
    }

    /**
    * @inheritdoc
    */

    public function rules()
    {
        return [
            [['project_id','sub_contractor_total_cost','pb_total_cost','pb_desc','is_active', 'is_delete'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date','contractor_id','sub_contractor_id','pb_name','project_id'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
        ];
    }
 
    /**
    * @inheritdoc
    */
    
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'pb_name' => 'Project Budget Name',
            'contractor_id' => 'Contractor Name',
            'sub_contractor_id' => 'Sub Contractor Name',
            'sub_contractor_total_cost' => 'Sub Contractor Total Cost',
            'pb_desc' => 'Description',
            'pb_total_cost' => 'Project Budget Total Cost',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getContractor()
    {
        return $this->hasOne(ContractorManagement::className(), ['id' => 'contractor_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getSubcontractor()
    {
        return $this->hasOne(ContractorManagement::className(), ['id' => 'sub_contractor_id']);
    }

    // Get Project Budget Data
    public function getProjectBudgetData($id) 
    {
        $query = new Query;
        $query->select([
            'project_management.id as pb_id',
            'project_management.project_name','sub_contractor_total_cost','pb_total_cost'
        ])  
        ->from('project_budget_management')->where(['project_budget_management.is_delete' => NOT_DELETED])->andWhere('project_budget_management.id = ' . $id)
         ->orderBy([
                      'project_budget_management.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'project_management',
            'project_budget_management.project_id = project_management.id');
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

     // Get All Project Budget Data
    public function getProjectAllBudgetData() 
    {
        $query = new Query;
        $query->select([
            'project_management.id as pb_id','project_management.project_name','sub_contractor_total_cost','pb_total_cost'
        ])  
        ->from('project_budget_management')->where(['project_budget_management.is_delete' => NOT_DELETED])
         ->orderBy([
                      'project_budget_management.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'project_management',
            'project_budget_management.project_id = project_management.id');
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

    // Get Project Budget Item Data 
    public function getProjectBudgetItemData($id)
    {
        $query1 = new Query;
        $query1->select([
            'item_work.name','project_budget_item.cost','users.first_name','users.last_name',
            'project_budget_item.sub_contractor_estimate_cost','project_budget_item.comment'
        ])  
        ->from('project_budget_item')->where(['project_budget_item.is_delete' => NOT_DELETED])->andWhere('project_budget_id = ' . $id)
         ->orderBy([
                      'project_budget_item.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'item_work',
            'project_budget_item.item_id = item_work.id')
        ->join('LEFT OUTER JOIN', 'users',
            'project_budget_item.sub_contractor_id = users.id');
        $command = $query1->createCommand();
        $data = $command->queryAll();
        return $data;
    }
}