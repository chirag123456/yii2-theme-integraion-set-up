<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\projectbudget;

use yii\base\Model;
use common\models\projectbudget\ProjectBudgetItem;

class ProjectBudgetItemForm extends Model {

    public $project_id;
    public $project_budget_id;
    public $item_id;
    public $cost;
    public $comment;
    public $sub_contractor_estimate_cost;
    public $id;
    public $sub_contractor_id;

    public function rules() {

        return [
            //[['project_id','project_budget_id','item_id','cost','comment','sub_contractor_estimate_cost'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id= $model->project_id; 
        $this->project_budget_id= $model->project_budget_id;
        $this->cost= $model->cost;
        $this->comment= $model->comment;
        $this->sub_contractor_estimate_cost= $model->sub_contractor_estimate_cost;
        $this->item_id= $model->item_id;
        $this->sub_contractor_id= $model->sub_contractor_id;
        return $this;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'project_budget_id' => 'Project Budget Name',
            'item_id' => 'Item Work Name',
            'cost' => 'Item Work Cost',
            'comment' => 'Comment',
            'sub_contractor_estimate_cost' => 'Sub Contactor Cost',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }
}