<?php

namespace common\models\userdevice;

use Yii;

/**
 * This is the model class for table "user_device".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $user_device_id
 * @property string $user_access_token
 * @property integer $created_by
 * @property string $created_date
 * @property integer $updated_by
 * @property string $updated_date
 * @property string $ip_address
 * @property string $is_active
 * @property string $is_delete
 */
class UserDevice extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_devices';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_device_id'], 'required'],
            [['user_id', 'created_by', 'updated_by'], 'integer'],
            [['device_plateform', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date','user_id', 'user_access_token', 'ip_address'], 'safe'],
            [['user_device_id'], 'string', 'max' => 255],
            [['user_access_token', 'ip_address'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'user_device_id' => 'User Device ID',
            'user_access_token' => 'User Access Token',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }
}
