<?php

namespace common\models\rfi;

use Yii;
use common\models\user\User;
use common\models\client\Client;
use common\models\project\Project;
use yii\base\Model;
use codeonyii\yii2validators\AtLeastValidator;

class RfiReportForm extends Model
{
    public $id;
    public $architect_id;
    public $project_id; 
    public $rfi_date;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            
            [['architect_id', 'project_id','rfi_date'], AtLeastValidator::className(), 'in' => ['architect_id', 'project_id','rfi_date'], 'min' => 1]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'architect_id' => 'Architect',
            'project_id' => 'Project',
            'rfi_date' => 'Rfi Date',
        ];
    }
}