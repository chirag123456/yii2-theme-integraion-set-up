<?php

namespace common\models\rfi;

use Yii;
use common\models\user\User;
use common\models\client\Client;
use common\models\project\Project;
use yii\base\Model;
use codeonyii\yii2validators\AtLeastValidator;

class RfiForm extends Model
{
    public $id;
    public $client_id;
    public $architect_id;
    public $sub_contractor_id;
    public $project_id;
    public $project_number;
    public $project_location;
    public $rfi_code;
    public $response;
    public $responded_by;
    public $rfi_date;
    public $request_for_information;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'architect_id', 'sub_contractor_id', 'project_id'], 'integer'],
            [['project_number', 'project_location', 'rfi_code','project_id',  'responded_by', 'rfi_date'], 'required'],
            [['architect_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['architect_id' => 'id']],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'id']],
            [['project_id'], 'exist', 'skipOnError' => true, 'targetClass' => Project::className(), 'targetAttribute' => ['project_id' => 'id']],
            [['sub_contractor_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['sub_contractor_id' => 'id']],
            [['sub_contractor_id', 'project_id', 'request_for_information'], 'safe'],
            [['request_for_information', 'response'], AtLeastValidator::className(), 'in' => ['request_for_information', 'response'], 'min' => 1]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_id' => 'Client',
            'architect_id' => 'Architect',
            'sub_contractor_id' => 'Sub Contractor',
            'project_id' => 'Project',
            'project_number' => 'Project Number',
            'project_location' => 'Project Location',
            'rfi_code' => 'Rfi Code',
            'response' => 'Response',
            'responded_by' => 'Responded By',
            'rfi_date' => 'Rfi Date',
            'request_for_information' => 'Request For Information',
        ];
    }

    public function getUpdateModel($model) {

        $this->client_id = $model->client_id;
        $this->architect_id = $model->architect_id;
        $this->sub_contractor_id = $model->sub_contractor_id;
        $this->project_id = $model->project_id;
        $this->project_number = $model->project_number;
        $this->project_location = $model->project_location;
        $this->rfi_code = $model->rfi_code;
        $this->response = $model->response;
        $this->rfi_date = $model->rfi_date;
        $this->request_for_information = $model->request_for_information;
        return $this;
    }
}