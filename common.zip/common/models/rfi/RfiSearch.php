<?php

namespace common\models\rfi;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\rfi\Rfi;

/**
 * RfiSearch represents the model behind the search form of `common\models\Rfi`.
 */
class RfiSearch extends Rfi 
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'client_id', 'architect_id', 'sub_contractor_id', 'created_by', 'updated_by'], 'integer'],
            [['project_number', 'project_id','project_location', 'rfi_code', 'response', 'responded_by', 'rfi_date', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Rfi::find()->where(['rfi.is_delete' => NOT_DELETED]);;

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['project']);
        // grid filtering conditions
        $query->andFilterWhere([
            //'id' => $this->id,
            'client_id' => $this->client_id,
            'architect_id' => $this->architect_id,
            'sub_contractor_id' => $this->sub_contractor_id,
            //'project_id' => $this->project_id,
            'rfi_date' => $this->rfi_date,
            'created_date' => $this->created_date,
            'created_by' => $this->created_by,
            'updated_date' => $this->updated_date,
            'updated_by' => $this->updated_by,
        ]);

        $query->andFilterWhere(['like', 'rfi.project_number', $this->project_number])
            ->andFilterWhere(['like', 'rfi.id', $this->id])
            ->andFilterWhere(['like', 'project_location', $this->project_location])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'rfi_code', $this->rfi_code])
            ->andFilterWhere(['like', 'response', $this->response])
            ->andFilterWhere(['like', 'responded_by', $this->responded_by])
            ->andFilterWhere(['like', 'rfi.is_active', $this->is_active])
            ;

        return $dataProvider;
    }

    public function search1($params)
    {
        $query = Rfi::find()->where(['rfi.is_delete' => NOT_DELETED]);

        if(isset($params['RfiReportForm']['project_id']) && !empty(isset($params['RfiReportForm']['project_id'])) && $params['RfiReportForm']['project_id'] != '')
        {
            $query->andWhere(['rfi.project_id' => $params['RfiReportForm']['project_id']]);
        }
        if(isset($params['RfiReportForm']['architect_id']) && !empty(isset($params['RfiReportForm']['architect_id'])) &&  $params['RfiReportForm']['architect_id'] != '')
        {
            $query->andWhere(['rfi.architect_id' => $params['RfiReportForm']['architect_id']]);
        }

        if(isset($params['RfiReportForm']['rfi_date']) && !empty(isset($params['RfiReportForm']['rfi_date'])) &&  $params['RfiReportForm']['rfi_date'] != '')
        {
            $query->andWhere(['rfi.rfi_date' => $params['RfiReportForm']['rfi_date']]);
        }

        if(isset($params['project_id']) && !empty(isset($params['project_id'])) && $params['project_id'] != '')
        {
            $query->andWhere(['rfi.project_id' => $params['project_id']]);
        }
        if(isset($params['architect_id']) && !empty(isset($params['architect_id'])) &&  $params['architect_id'] != '')
        {
            $query->andWhere(['rfi.architect_id' => $params['architect_id']]);
        }

        if(isset($params['rfi_date']) && !empty(isset($params['rfi_date'])) &&  $params['rfi_date'] != '')
        {
            $query->andWhere(['rfi.rfi_date' => $params['rfi_date']]);
        }

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['project']);
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'client_id' => $this->client_id,
            'architect_id' => $this->architect_id,
            'sub_contractor_id' => $this->sub_contractor_id,
            'rfi_date' => $this->rfi_date,
            'created_date' => $this->created_date,
            'created_by' => $this->created_by,
            'updated_date' => $this->updated_date,
            'updated_by' => $this->updated_by,
        ]);

        $query->andFilterWhere(['like', 'rfi.project_number', $this->project_number])
            ->andFilterWhere(['like', 'project_location', $this->project_location])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'rfi_code', $this->rfi_code])
            ->andFilterWhere(['like', 'response', $this->response])
            ->andFilterWhere(['like', 'responded_by', $this->responded_by])
            ->andFilterWhere(['like', 'rfi.is_active', $this->is_active])
            ;

        return $dataProvider;
    }

    public function search2($params)
    {
        $query = Rfi::find()->where(['rfi.is_delete' => NOT_DELETED])->orderBy(['rfi.id' => SORT_DESC]);

        if(isset($params['project_id']) && !empty(isset($params['project_id'])) && $params['project_id'] != '')
        {
            $query->andWhere(['rfi.project_id' => $params['project_id']]);
        }
        if(isset($params['architect_id']) && !empty(isset($params['architect_id'])) &&  $params['architect_id'] != '')
        {
            $query->andWhere(['rfi.architect_id' => $params['architect_id']]);
        }

        if(isset($params['rfi_date']) && !empty(isset($params['rfi_date'])) &&  $params['rfi_date'] != '')
        {
            $query->andWhere(['rfi.rfi_date' => $params['rfi_date']]);
        }

        
        $query->joinWith(['project']);
        // grid filtering conditions
        

        return $query->all();
    }
}
