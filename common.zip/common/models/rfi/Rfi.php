<?php

namespace common\models\rfi;

use Yii;
use common\models\user\User;
use common\models\client\Client;
use common\models\project\Project;

/**
 * This is the model class for table "rfi".
 *
 * @property int $id
 * @property int $client_id
 * @property int $architect_id
 * @property int $sub_contractor_id
 * @property int $project_id
 * @property string $project_number
 * @property string $project_location
 * @property string $rfi_code
 * @property string $response
 * @property string $responded_by
 * @property string $rfi_date
 * @property string $created_date
 * @property int $created_by
 * @property string $updated_date
 * @property int $updated_by
 * @property string $is_active
 * @property string $is_delete
 * @property string $request_for_information
 *
 * @property User $architect
 * @property Client $client
 * @property User $createdBy
 * @property Project $project
 * @property User $subContractor
 * @property User $updatedBy
 */
class Rfi extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'rfi';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'architect_id', 'sub_contractor_id', 'project_id', 'created_by', 'updated_by'], 'integer'],
            [['sub_contractor_id', 'project_id', 'project_number', 'project_location', 'rfi_code' , 'responded_by', 'rfi_date', 'created_date', 'created_by', 'updated_date', 'updated_by'], 'required'],
            [['project_location', 'response', 'is_active', 'is_delete'], 'string'],
            [['rfi_date', 'created_date', 'updated_date','request_for_information','response'], 'safe'],
            [['project_number', 'rfi_code', 'responded_by'], 'string', 'max' => 255],
            [['architect_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['architect_id' => 'id']],
            [['client_id'], 'exist', 'skipOnError' => true, 'targetClass' => Client::className(), 'targetAttribute' => ['client_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['project_id'], 'exist', 'skipOnError' => true, 'targetClass' => Project::className(), 'targetAttribute' => ['project_id' => 'id']],
            [['sub_contractor_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['sub_contractor_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_id' => 'Client',
            'architect_id' => 'Architect',
            'sub_contractor_id' => 'Sub Contractor',
            'project_id' => 'Project',
            'project_number' => 'Project Number',
            'project_location' => 'Project Location',
            'rfi_code' => 'RFI Code',
            'response' => 'Response',
            'responded_by' => 'Responded By',
            'rfi_date' => 'RFI Date',
            'created_date' => 'Created Date',
            'created_by' => 'Created By',
            'updated_date' => 'Updated Date',
            'updated_by' => 'Updated By',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
            'request_for_information' => 'Request For Information',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getArchitect()
    {
        return $this->hasOne(User::className(), ['id' => 'architect_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubContractor()
    {
        return $this->hasOne(User::className(), ['id' => 'sub_contractor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRfiData()
    {
        $query = new Query;
        $query->select([
            'project_management.id as pid',
            'project_management.project_name',
            'project_management.project_cost',
            'project_management.project_size',
            'project_management.project_estimated_days',
            'project_management.project_number',
            'project_management.date_of_commencement',
            'project_management.date_of_substantial_completion',
            'project_management.date_of_completion',
            'project_management.project_physical_address',
            'project_management.project_zipcode',            
            'state.state_name as p_state_name',
            'city.name as p_city_name',
            'users.email as architect_email',
            'project_management.construction_plan_dated',
            
            'landlord.landlord_email',
            'lender.lender_email',
        ])  
        ->from('rfi')->where(['rfi.is_delete' => NOT_DELETED])
         ->orderBy([
                      'rfi.id' => SORT_DESC,                              
                    ]);
        if(isset($params['project']) && $params['project'] != '')
        {
            $query->andWhere(['rfi.project_id' => $params['project'] ]);
        }

        if(isset($params['architect']) && $params['architect'] != '')
        {
            $query->andWhere(['rfi.rachitect_id' => $params['architect'] ]);   
        }

        
        $query
        ->join('LEFT OUTER JOIN', 'project_management',
            'project_management.id = rfi.project_id')
        ->join('LEFT OUTER JOIN', 'users',
            'rfi.rachitect_id = users.id');
        
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

    // public function getRfi()
    // {
    //     $rfi = Rfi::find()->joinWith(['project','architect'])->where('is_delete' => NOT_DELETED)->all();
    //     if(isset($params['project']) && $params['project'] != '')
    //     {
    //         $rfi->andWhere(['rfi.project_id' => $params['project'] ]);
    //     }

    //     if(isset($params['architect']) && $params['architect'] != '')
    //     {
    //         $rfi->andWhere(['rfi.rachitect_id' => $params['architect'] ]);   
    //     }
    //     return $rfi;
    // }

}
