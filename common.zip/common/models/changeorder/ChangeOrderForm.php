<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\changeorder; 

use yii\base\Model;
use common\models\changeorder\ChangeOrder;
use common\models\itemwork\ItemWork;

class ChangeOrderForm extends Model {

    public $id;
    public $project_id;
    public $project_no;
    public $change_order_no;
    public $contract_date;
    public $contract_for;
    public $to_contractor;
    public $old_contract_sum;
    public $change_order_total_sum;
    public $new_order_contract_sum;
    public $architect_id;
    public $contractor_id;
    public $client_id;
    public $date_submited_approval;
    public $date_approval_recived_back;
    public $date_recived_response;
    public $current_status;

    public function rules() {

        return [
            [['project_id', 'project_no', 'change_order_no', 'contract_date', 'contract_for', 'to_contractor', 'old_contract_sum', 'change_order_total_sum', 'new_order_contract_sum', 'architect_id', 'contractor_id', 'client_id', 'date_submited_approval', 'date_approval_recived_back', 'date_recived_response', 'current_status'], 'required'],
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id = $model->project_id;
        $this->project_no = $model->project_no;
        $this->change_order_no = $model->change_order_no;
        $this->contract_date = $model->contract_date;
        $this->contract_for = $model->contract_for;
        $this->to_contractor = $model->to_contractor;
        $this->old_contract_sum = isset($model->old_contract_sum) ? $model->old_contract_sum : 'N\A';
        $this->change_order_total_sum = isset($model->change_order_total_sum) ? $model->change_order_total_sum : 'N\A';
        $this->new_order_contract_sum = isset($model->new_order_contract_sum) ? $model->new_order_contract_sum : 'N\A';
        $this->architect_id = isset($model->architect_id) ? $model->architect_id : 'N\A';
        $this->contractor_id = isset($model->contractor_id) ? $model->contractor_id : 'N\A';
        $this->client_id = isset($model->client_id) ? $model->client_id : 'N\A';
        $this->current_status = isset($model->current_status) ? $model->current_status : 'N\A';
        $this->date_submited_approval = isset($model->date_submited_approval) ? $model->date_submited_approval : 'N\A';
        $this->date_approval_recived_back = isset($model->date_approval_recived_back) ? $model->date_approval_recived_back : 'N\A';
        $this->date_recived_response = isset($model->date_recived_response) ? $model->date_recived_response : 'N\A';
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'project_no' => 'Project No',
            'change_order_no' => 'Change Order No',
            'contract_date' => 'Contract Date',
            'contract_for' => 'Contract For',
            'to_contractor' => 'To Contractor',
            'old_contract_sum' => 'Old Contract Sum',
            'change_order_total_sum' => 'Change Order Total Sum',
            'new_order_contract_sum' => 'New Order Contract Sum',
            'architect_id' => 'Architect',
            'contractor_id' => 'Contractor',
            'client_id' => 'Client',
            'date_submited_approval' => 'Date Submited Approval',
            'date_approval_recived_back' => 'Date Approval Recived Back',
            'date_recived_response' => 'Date Recived Response',
            'current_status' => 'Current Status',
        ];
    }

    //This Function Use Unique Change Order No
    public function custom_change_order_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = ChangeOrder::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->change_order_no), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = User::find()->where(['change_order_no' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Change Order Number is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = ChangeOrder::find()->where(['change_order_no' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Change Order Number is already exist!');
            }
        }
    }
}