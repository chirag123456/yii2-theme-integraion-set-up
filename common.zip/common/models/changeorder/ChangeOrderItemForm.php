<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\changeorder; 

use yii\base\Model;
use common\models\changeorder\ChangeOrder; 
use common\models\changeorder\ChangeOrderItem; 
use common\models\itemwork\ItemWork;

class ChangeOrderItemForm extends Model {

    public $change_order_id;
    public $item_id;
    public $qty;
    public $id;
    public $unit;
    public $description;
    public $unit_price;
    public $extended_amt;
    public $change_class;
    public $time_ext;
    public $co_amt;
    public $updated_contract_amt;
    public $notes;

    public function rules() {
        return [
            [['change_order_id', 'item_id', 'qty', 'unit', 'description', 'unit_price', 'extended_amt', 'change_class', 'time_ext', 'co_amt', 'updated_contract_amt', 'notes'], 'safe'],
        ];
    }

    public function getUpdateModel($model) {

        $this->change_order_id = $model->change_order_id;
        $this->item_id = $model->item_id;
        $this->qty = $model->qty;
        $this->unit = $model->unit;
        $this->description = $model->description;
        $this->unit_price = $model->unit_price;
        $this->extended_amt = isset($model->extended_amt) ? $model->extended_amt : 'N\A';
        $this->change_class = isset($model->change_class) ? $model->change_class : 'N\A';
        $this->time_ext = isset($model->time_ext) ? $model->time_ext : 'N\A';
        $this->co_amt = isset($model->co_amt) ? $model->co_amt : 'N\A';
        $this->notes = isset($model->notes) ? $model->notes : 'N\A';
        $this->updated_contract_amt = isset($model->updated_contract_amt) ? $model->updated_contract_amt : 'N\A';
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'change_order_id' => 'Change Order',
            'item_id' => 'Item',
            'qty' => 'Qty',
            'unit' => 'Unit',
            'description' => 'Description',
            'unit_price' => 'Unit Price',
            'extended_amt' => 'Extended Amt',
            'change_class' => 'Change Class',
            'time_ext' => 'Time Ext',
            'co_amt' => 'Co Amt',
            'updated_contract_amt' => 'Updated Contract Amt',
            'notes' => 'Notes',
        ];
    }
}