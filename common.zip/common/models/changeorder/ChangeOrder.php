<?php

namespace common\models\changeorder; 

use Yii;
use common\models\project\Project;
use common\models\client\Client;
use common\models\user\User;

/**
 * This is the model class for table "change_order".
 *
 * @property int $id
 * @property int $project_id
 * @property string $project_no
 * @property string $change_order_no
 * @property string $contract_date
 * @property string $contract_for
 * @property int $to_contractor
 * @property string $old_contract_sum
 * @property string $change_order_total_sum
 * @property string $new_order_contract_sum
 * @property int $architect_id
 * @property int $contractor_id
 * @property int $client_id
 * @property string $date_submited_approval
 * @property string $date_approval_recived_back
 * @property string $date_recived_response
 * @property string $current_status
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class ChangeOrder extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'change_order';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'project_no', 'change_order_no', 'contract_date', 'contract_for', 'to_contractor', 'old_contract_sum', 'change_order_total_sum', 'new_order_contract_sum', 'contractor_id', 'date_submited_approval', 'date_approval_recived_back', 'date_recived_response', 'current_status', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['project_id', 'to_contractor', 'architect_id', 'contractor_id', 'client_id', 'created_by', 'updated_by'], 'integer'],
            [['contract_date', 'date_submited_approval', 'date_approval_recived_back', 'date_recived_response', 'created_date', 'updated_date','client_id'], 'safe'],
            [['current_status', 'is_active', 'is_delete'], 'string'],
            //[['architect_id','project_no', 'change_order_no', 'contract_for', 'old_contract_sum', 'change_order_total_sum', 'new_order_contract_sum'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'project_no' => 'Project No',
            'change_order_no' => 'Change Order No',
            'contract_date' => 'Contract Date',
            'contract_for' => 'Contract For',
            'to_contractor' => 'To Contractor',
            'old_contract_sum' => 'Old Contract Sum',
            'change_order_total_sum' => 'Change Order Total Sum',
            'new_order_contract_sum' => 'New Order Contract Sum',
            'architect_id' => 'Architect ID',
            'contractor_id' => 'Contractor ID',
            'client_id' => 'Client ID',
            'date_submited_approval' => 'Date Submited Approval',
            'date_approval_recived_back' => 'Date Approval Recived Back',
            'date_recived_response' => 'Date Recived Response',
            'current_status' => 'Current Status',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getContractor()
    {
        return $this->hasOne(User::className(), ['id' => 'contractor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getArchitect()
    {
        return $this->hasOne(User::className(), ['id' => 'architect_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }
}
