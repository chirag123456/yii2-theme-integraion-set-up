<?php 

namespace common\models\changeorder;

use Yii;
use common\models\changeorder\ChangeOrder; 
use common\models\itemwork\ItemWork;

/**
 * This is the model class for table "change_order_item".
 *
 * @property int $id
 * @property int $change_order_id
 * @property int $item_id
 * @property string $qty
 * @property string $unit
 * @property string $description
 * @property string $unit_price
 * @property string $extended_amt
 * @property string $change_class
 * @property string $time_ext
 * @property string $co_amt
 * @property string $updated_contract_amt
 * @property string $notes
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class ChangeOrderItem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'change_order_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['change_order_id', 'item_id', 'qty', 'unit', 'description', 'unit_price', 'extended_amt', 'change_class', 'time_ext', 'co_amt', 'updated_contract_amt', 'notes', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['change_order_id', 'item_id', 'created_by', 'updated_by'], 'integer'],
            [['description', 'change_class', 'notes', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date'], 'safe'],
            //[['qty', 'unit', 'unit_price', 'extended_amt', 'time_ext', 'co_amt', 'updated_contract_amt'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'change_order_id' => 'Change Order ID',
            'item_id' => 'Item ID',
            'qty' => 'Qty',
            'unit' => 'Unit',
            'description' => 'Description',
            'unit_price' => 'Unit Price',
            'extended_amt' => 'Extended Amt',
            'change_class' => 'Change Class',
            'time_ext' => 'Time Ext',
            'co_amt' => 'Co Amt',
            'updated_contract_amt' => 'Updated Contract Amt',
            'notes' => 'Notes',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    } 

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getChangeorder()
    {
        return $this->hasOne(ChangeOrder::className(), ['id' => 'change_order_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getItem()
    {
        return $this->hasOne(ItemWork::className(), ['id' => 'item_id']);
    }
}
