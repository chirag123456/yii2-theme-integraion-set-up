<?php

namespace common\models\changeorder;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\changeorder\ChangeOrder; 

/**
 * ChangeOrderSearch represents the model behind the search form of `common\models\ChangeOrder`.
 */
class ChangeOrderSearch extends ChangeOrder
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'project_id', 'to_contractor', 'architect_id', 'contractor_id', 'client_id','project_no', 'change_order_no', 'contract_date', 'contract_for', 'old_contract_sum', 'change_order_total_sum', 'new_order_contract_sum', 'date_submited_approval', 'date_approval_recived_back', 'date_recived_response', 'current_status', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = ChangeOrder::find()->where(['change_order.is_delete' => NOT_DELETED]); 

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'project_id' => $this->project_id,
            'contract_date' => $this->contract_date,
            'to_contractor' => $this->to_contractor,
            'architect_id' => $this->architect_id,
            'contractor_id' => $this->contractor_id,
            'client_id' => $this->client_id,
            'date_submited_approval' => $this->date_submited_approval,
            'date_approval_recived_back' => $this->date_approval_recived_back,
            'date_recived_response' => $this->date_recived_response,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'project_no', $this->project_no])
            ->andFilterWhere(['like', 'change_order_no', $this->change_order_no])
            ->andFilterWhere(['like', 'contract_for', $this->contract_for])
            ->andFilterWhere(['like', 'old_contract_sum', $this->old_contract_sum])
            ->andFilterWhere(['like', 'change_order_total_sum', $this->change_order_total_sum])
            ->andFilterWhere(['like', 'new_order_contract_sum', $this->new_order_contract_sum])
            ->andFilterWhere(['like', 'current_status', $this->current_status])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }
}
