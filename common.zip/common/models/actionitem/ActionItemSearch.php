<?php

namespace common\models\actionitem;
use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\actionitem\ActionItem; 

/**
 * ActionItemSearch represents the model behind the search form of `common\models\ActionItem`.
 */
class ActionItemSearch extends ActionItem
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            //[['id', 'project_id', 'created_by', 'updated_by'], 'integer'],
            [['id', 'project_id','meeting_date', 'meeting_location', 'next_meeting_details', 'facilitators', 'invitees', 'participants', 'objective', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) 
    {
        $query = ActionItem::find()->where(['action_item.is_delete' => NOT_DELETED]); 

        // add pspell_config_dict_dir(conf, directory)ions that should always apply here
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['project']);
        // grid filtering conditions
        $query->andFilterWhere([
            //'id' => $this->id,
            //'project_id' => $this->project_id,
            'meeting_date' => $this->meeting_date,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'meeting_location', $this->meeting_location])
            ->andFilterWhere(['like', 'action_item.id', $this->id])
            ->andFilterWhere(['like', 'next_meeting_details', $this->next_meeting_details])
            ->andFilterWhere(['like', 'facilitators', $this->facilitators])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'invitees', $this->invitees])
            ->andFilterWhere(['like', 'participants', $this->participants])
            ->andFilterWhere(['like', 'objective', $this->objective])
            ->andFilterWhere(['like', 'action_item.is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }
}
