<?php

namespace common\models\actionitem;
use Yii;

/**
 * This is the model class for table "action_item_list".
 *
 * @property int $id
 * @property int $action_item_id
 * @property int $item_no
 * @property string $date_of_origin
 * @property string $priority
 * @property string $item_desc
 * @property string $current_status
 * @property string $action_item_owner
 * @property string $item_origin
 * @property string $due_date
 * @property string $completed_or_received
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updates_date
 * @property string $is_active
 * @property string $is_delete
 *
 * @property ActionItem $actionItem
 */
class ActionItemList extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'action_item_list';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['action_item_id', 'item_no', 'date_of_origin', 'priority', 'item_desc', 'current_status', 'action_item_owner', 'item_origin', 'due_date', 'completed_or_received', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            //[['action_item_id', 'item_no', 'created_by', 'updated_by'], 'integer'],
            [['date_of_origin', 'due_date', 'created_date', 'updates_date'], 'safe'],
            //[['priority', 'item_desc', 'current_status', 'completed_or_received', 'is_active', 'is_delete'], 'string'],
            [['action_item_owner', 'item_origin'], 'string', 'max' => 255],
            [['action_item_id'], 'exist', 'skipOnError' => true, 'targetClass' => ActionItem::className(), 'targetAttribute' => ['action_item_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'action_item_id' => 'Action Item',
            'item_no' => 'Item No',
            'date_of_origin' => 'Date Of Origin',
            'priority' => 'Priority',
            'item_desc' => 'Item Desc',
            'current_status' => 'Current Status',
            'action_item_owner' => 'Action Item Owner',
            'item_origin' => 'Item Origin',
            'due_date' => 'Due Date',
            'completed_or_received' => 'Completed Or Received',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updates_date' => 'Updates Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getActionItem()
    {
        return $this->hasOne(ActionItem::className(), ['id' => 'action_item_id']);
    }
}
