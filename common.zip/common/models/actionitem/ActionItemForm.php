<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\actionitem;

use yii\base\Model;
use common\models\actionitem\ActionItem;
use common\models\project\Project;
class ActionItemForm extends Model {

    public $project_id;
    public $meeting_date;
    public $meeting_location;
    public $id;
    public $next_meeting_details;
    public $facilitators;
    public $invitees;
    public $participants;
    public $objective;

    public function rules() {

        return [
            [['project_id', 'meeting_date', 'meeting_location', 'next_meeting_details', 'facilitators', 'invitees', 'participants','objective'], 'required'],
            [['project_id'], 'exist', 'skipOnError' => true, 'targetClass' => Project::className(), 'targetAttribute' => ['project_id' => 'id']],
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id = $model->project_id;
        $this->next_meeting_details = $model->next_meeting_details;
        $this->facilitators = $model->facilitators;
        $this->invitees = $model->invitees;
        $this->participants = $model->participants;
        $this->objective = $model->objective;
        $this->meeting_date = isset($model->meeting_date) ? $model->meeting_date : 'N\A';
        $this->meeting_location = isset($model->meeting_location) ? $model->meeting_location : 'N\A';
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'meeting_date' => 'Meeting Date',
            'meeting_location' => 'Meeting Location',
            'next_meeting_details' => 'Next Meeting Details',
            'facilitators' => 'Facilitators',
            'invitees' => 'Invitees',
            'participants' => 'Participants',
            'objective' => 'Objective'
        ];
    }
}