<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\actionitem;

use yii\base\Model;
use common\models\actionitem\ActionItem;

class ActionItemListForm extends Model {

    public $item_no;
    public $date_of_origin; 
    public $priority;
    public $id;
    public $item_desc;
    public $current_status;
    public $action_item_owner;
    public $item_origin;
    public $due_date;
    public $completed_or_received;

    public function rules() {

        return [
            [['item_no', 'date_of_origin', 'priority', 'item_desc', 'current_status', 'action_item_owner', 'item_origin', 'due_date', 'completed_or_received'], 'safe'],
            [['action_item_id'], 'exist', 'skipOnError' => true, 'targetClass' => ActionItem::className(), 'targetAttribute' => ['action_item_id' => 'id']],
        ];
    }

    public function getUpdateModel($model) {

        $this->item_no = $model->item_no;
        $this->date_of_origin = $model->date_of_origin;
        $this->priority = $model->priority;
        $this->item_desc = $model->item_desc;
        $this->current_status = $model->current_status;
        $this->action_item_owner = $model->action_item_owner;
        $this->completed_or_received = $model->completed_or_received;

        $this->item_origin = isset($model->item_origin) ? $model->item_origin : 'N\A';
        $this->due_date = isset($model->due_date) ? $model->due_date : 'N\A';
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'action_item_id' => 'Action Item',
            'item_no' => 'Item No',
            'date_of_origin' => 'Date Of Origin',
            'priority' => 'Priority',
            'item_desc' => 'Item Desc',
            'current_status' => 'Current Status',
            'action_item_owner' => 'Action Item Owner',
            'item_origin' => 'Item Origin',
            'due_date' => 'Due Date',
            'completed_or_received' => 'Completed Or Received',
        ];
    }
}