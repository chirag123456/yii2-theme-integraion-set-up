<?php

namespace common\models\actionitem;

use Yii;
use common\models\project\Project;
use yii\db\Query;

/**
 * This is the model class for table "action_item".
 *
 * @property int $id
 * @property int $project_id
 * @property string $meeting_date
 * @property string $meeting_location
 * @property string $next_meeting_details
 * @property string $facilitators
 * @property string $invitees
 * @property string $participants
 * @property string $objective
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 * @property Project $project
 * @property ActionItemList[] $actionItemLists
 */
class ActionItem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'action_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'meeting_date', 'meeting_location', 'next_meeting_details', 'facilitators', 'invitees', 'participants', 'objective', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['project_id', 'created_by', 'updated_by'], 'integer'],
            [['meeting_date', 'created_date', 'updated_date'], 'safe'],
            [['meeting_location', 'next_meeting_details', 'objective', 'is_active', 'is_delete'], 'string'],
            [['facilitators', 'invitees', 'participants'], 'string', 'max' => 255],
            [['project_id'], 'exist', 'skipOnError' => true, 'targetClass' => Project::className(), 'targetAttribute' => ['project_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'meeting_date' => 'Meeting Date',
            'meeting_location' => 'Meeting Location',
            'next_meeting_details' => 'Next Meeting Details',
            'facilitators' => 'Facilitators',
            'invitees' => 'Invitees',
            'participants' => 'Participants',
            'objective' => 'Objective',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    // Get Action item & action item list Data
    public function getActionItemData($id) 
    {
        $query = new Query;
        $query->select([
            'ac.id as ac_id',
            'project_management.project_name','ac.meeting_location','ac.facilitators', 'ac.invitees', 'ac.participants', 'acl.*'
        ])  
        ->from('action_item as ac')->where(['ac.is_delete' => NOT_DELETED])->andWhere('ac.id = ' . $id)
         ->orderBy([
                      'ac.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'project_management',
            'ac.project_id = project_management.id')
        ->join('LEFT OUTER JOIN', 'action_item_list as acl',
            'acl.action_item_id = ac.id');
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

    // Get Action item & action item list Data
    public function getActionItemListData($id) 
    {
        $query = new Query;
        $query->select([
            'ac.id as ac_id',
            'project_management.project_name','ac.meeting_location','ac.facilitators', 'ac.invitees', 'ac.participants', 'acl.*'
        ])  
        ->from('action_item_list as acl')->where(['ac.is_delete' => NOT_DELETED])->andWhere('acl.id = ' . $id)
         ->orderBy([
                      'ac.id' => SORT_DESC,                              
                    ])
        ->join('LEFT OUTER JOIN', 'action_item as ac',
            'acl.action_item_id = ac.id')
        ->join('LEFT OUTER JOIN', 'project_management',
            'ac.project_id = project_management.id');
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }
    
}