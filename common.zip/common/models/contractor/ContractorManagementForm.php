<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
namespace common\models\contractor;

use yii\base\Model;
use common\models\contractor\ContractorManagement;

class ContractorManagementForm extends Model {

    public $parent_id;
    public $user_id;
    public $contractor_name;
    public $contractor_phone;
    public $contractor_address;
    public $contractor_state_id;
    public $contractor_city_id;
    public $created_date;
    public $created_by;
    public $updated_by;
    public $updated_date;
    public $is_delete;
    public $is_active;

    public function rules() {

       return [
            [['parent_id', 'contractor_name', 'contractor_phone', 'contractor_address', 'contractor_state_id', 'contractor_city_id', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete','user_id'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            ['contractor_phone', 'number', 'message' => 'Phone Number is Invalid.'],
            [['contractor_name', 'contractor_address'], 'string', 'max' => 255],
        ]; 
    }


    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'parent_id' => 'Parent Contractor',
            'contractor_name' => 'Contractor Name',
            'contractor_phone' => 'Contractor Phone',
            'contractor_address' => 'Contractor Address',
            'contractor_state_id' => 'Contractor State',
            'contractor_city_id' => 'Contractor City',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
            'user_id' => 'User',
        ];
    }

    public function getUpdateModel($model) {
        $this->contractor_name = $model->contractor_name;
        $this->contractor_phone = $model->contractor_phone;
        $this->contractor_address = $model->contractor_address;
        $this->contractor_state_id = $model->contractor_state_id;
        $this->contractor_city_id = $model->contractor_city_id;
        $this->user_id = $model->user_id;
        return $this;
    }

}
