<?php

namespace common\models\contractor;

use Yii;
use common\models\user\User; 

/**
 * This is the model class for table "contractor_management".
 *
 * @property int $id
 * @property int $parent_id
 * @property int $user_id
 * @property string $contractor_name
 * @property string $contractor_phone
 * @property string $contractor_address
 * @property int $contractor_state_id
 * @property int $contractor_city_id
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class ContractorManagement extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'contractor_management';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['parent_id', 'contractor_name', 'contractor_phone', 'contractor_address', 'contractor_state_id', 'contractor_city_id', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete','user_id'], 'required'],
            [['parent_id', 'contractor_state_id', 'contractor_city_id', 'created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            [['contractor_name', 'contractor_phone', 'contractor_address'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'parent_id' => 'Parent ID',
            'user_id' => 'User',
            'contractor_name' => 'Contractor Name',
            'contractor_phone' => 'Contractor Phone',
            'contractor_address' => 'Contractor Address',
            'contractor_state_id' => 'Contractor State',
            'contractor_city_id' => 'Contractor City',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getParent()
    {
        return $this->hasOne(ContractorManagement::className(), ['id' => 'parent_id']);
    }
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }
}
