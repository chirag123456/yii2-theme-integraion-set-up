<?php

namespace common\models\contractor;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\contractor\ContractorManagement;
 
/**
 * ContractorManagementSearch represents the model behind the search form of `common\models\ContractorManagement`.
 */
class ContractorManagementSearch extends ContractorManagement
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id',  'created_by', 'updated_by'], 'integer'],
            [['user_id','parent_id', 'contractor_state_id', 'contractor_city_id','contractor_name', 'contractor_phone', 'contractor_address', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function searchcontractor($params)
    {
        $query = ContractorManagement::find()->where(['contractor_management.is_delete' => INACTIVE,'parent_id'=>'0']);

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider; 
        }
        $query->joinWith('user');
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'parent_id' => $this->parent_id,
            'contractor_state_id' => $this->contractor_state_id,
            'contractor_city_id' => $this->contractor_city_id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'contractor_name', $this->contractor_name])
            ->andFilterWhere(['like', 'contractor_phone', $this->contractor_phone])
            ->andFilterWhere(['like', 'users.first_name', $this->user_id])
            ->andFilterWhere(['like', 'contractor_address', $this->contractor_address])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

    public function searchsubcontractor($params)
    {
        $query = ContractorManagement::find()->where(['contractor_management.is_delete' => INACTIVE])->andWhere('parent_id !='.'0');

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith('user');
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'parent_id' => $this->parent_id,
            'contractor_state_id' => $this->contractor_state_id,
            'contractor_city_id' => $this->contractor_city_id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'contractor_name', $this->contractor_name])
            ->andFilterWhere(['like', 'contractor_phone', $this->contractor_phone])
            ->andFilterWhere(['like', 'user.first_name'.'user.last_name'.'-'.'user.email', $this->user_id])
            ->andFilterWhere(['like', 'contractor_address', $this->contractor_address])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider; 
    }

}
