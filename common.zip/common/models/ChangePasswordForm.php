<?php

/**
 * Created by PhpStorm.
 * User: mohit
 * Date: 3/7/17
 * Time: 3:48 PM
 */

namespace common\models;

use Yii;
use yii\base\Model;
use common\models\user\User;

/**
 * Login form
 */
class ChangePasswordForm extends Model {

    public $old_password;
    public $new_password;
    public $confirm_password;
    public $user_id = 0;
    private $_user;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            // username and password are both required
            [['old_password', 'new_password', 'confirm_password'], 'required'],
            [['old_password', 'new_password', 'confirm_password'],'string', 'min' => 6],
            // password is validated by validatePassword()
            ['old_password', 'validatePassword'],
//            ['confirm_password', 'compare', 'compareAttribute' => 'new_password'],
            ['confirm_password', 'compare', 'compareAttribute' => 'new_password', 'message' => "New Password confirm new password must be same"],
        ];
    }

public function attributeLabels()
    {
      return ['old_password'=>'Current password',
               'new_password'=>'New password',
               'confirm_password'=>'Confirm new password' 
             ];
    }


    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validatePassword($attribute, $params) {
        $user = $this->getUser($this->user_id);
        if (!$user || !$user->validatePassword($this->old_password)) {
            $this->addError($attribute, 'Incorrect current password.');
        }
    }

    /**
     * Finds user by [[username]]
     *
     * @return User|null
     */
    protected function getUser($user_id) {
        if (!$user_id) {
            if ($this->_user === null) {
                $this->_user = User::findIdentity(\Yii::$app->user->identity->id);
            }
        } else {
            if ($this->_user === null) {
                $this->_user = User::findIdentity($user_id);
            }
        }
        return $this->_user;
    }

    /**
     * Resets password.
     *
     * @return boolean if password was reset.
     */
    public function resetPassword() {
        $user = $this->_user;
        //$user->setPassword($this->new_password);
        $user->password = md5($this->new_password);
        $user->removePasswordResetToken();
        $user->generatePasswordResetToken();

        return $user->save(false);
    }

}
