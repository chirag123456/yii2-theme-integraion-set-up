<?php

namespace common\models\module;

use Yii;

/**
 * This is the model class for table "client".
 *
 * @property int $id
 * @property string $client_name
 * @property string $client_email
 * @property string $client_address
 * @property string $client_phone
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class Action extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'action';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['action_name'], 'required'],
            [['is_active', 'is_delete'], 'string'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'safe'],
            [['action_name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'action_name' => 'Action Name',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getModule()
    {
        return $this->hasOne(Module::className(), ['module_id' => 'id']);
    }
}
