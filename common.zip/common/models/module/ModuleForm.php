<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\module; 

use yii\base\Model;
use common\models\module\Module; 
use yii;

class ModuleForm extends Model {

    public $id;
    public $module_name;
    public $action_name;
    public $created_by;
    public $created_date;
    public $updated_by;
    public $updated_date;
    public $is_delete;
    public $is_active, $icon;

    public function rules() {

       return [
            [['module_name', 'action_name', 'icon'], 'required'],
            ['module_name','custom_module_unique'],
            ['module_name','check_module_exists'],
            //['action_name','check_action_exists'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            
            [['is_active', 'is_delete'], 'string'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'module_name' => 'Module Name',
            'icon' => 'Icon',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getUpdateModel($model) {
        $this->id = $model->id;
        $this->module_name = $model->module_name;
        $this->icon = $model->icon;
        return $this;
    }

    public function custom_module_unique($attribute, $params) {
        $check = false;

        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Module::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = strcasecmp(trim($check->module_name), trim($this->$attribute));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Module::find()->where(['module_name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Module'.ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Module::find()->where(['module_name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Module'.ALREADY);
            }
        }
    }
    
    public function check_module_exists($attribute, $params){
        $check = false;
        $controller = $attribute;
        $controllerPath=Yii::$app->controllerPath;
        $exists = $controllerPath.DIRECTORY_SEPARATOR.ucfirst($this->$attribute).'Controller.php';

        if(file_exists($exists)){
            $check = true;
        }else{
            if (isset($_GET['id']) && !empty($_GET['id'])) {  //die('dd');
                $check = Module::find()->where(['id' => $_GET['id']])->one();
                if ($check) {
                    $cmp = strcasecmp(trim($check->module_name), trim($this->$attribute));
                    if ($cmp == 0) {
                        $check = true;
                    } else {
                        $this->addError($attribute, "This Module doesn't exists");
                    }
                }
            }else{
                if(file_exists($exists)){
                    return true;    
                }else{
                    $this->addError($attribute, "This Module doesn't exists");
                }
            }
            
        }
    }

}