<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\constructioncontractmanagement;

use yii\base\Model;
use common\models\constructioncontractmanagement\ConstructionContractManagement;

class ConstructionContractManagementForm extends Model {

    public $project_id;
    public $contractor_id;
    public $sub_contractor_id;
    public $construction_contract_cost;
    public $construction_estimated_days;
    public $sub_contractor_price;
    public $client_id;
    public $construction_address;
    public $created_by;
    public $created_date;
    public $updated_by;
    public $updated_date;
    public $is_delete;
    public $is_active;

    public function rules() {

       return [
            [['project_id', 'contractor_id', 'sub_contractor_id', 'construction_contract_cost', 'construction_estimated_days', 'sub_contractor_price', 'client_id', 'construction_address'], 'required'],
            [['project_id', 'contractor_id', 'sub_contractor_id', 'client_id'], 'integer'],
            [['created_date', 'updated_date','created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            /*
            ['construction_contract_cost', 'number', 'message' => 'Construction Contract Cost should be number.'],
            ['construction_estimated_days', 'number', 'message' => 'Construction Estimated days should be number.'],
            ['sub_contractor_price', 'number', 'message' => 'Sub Contactor Price should be number.'],*/
            //[['construction_contract_cost', 'construction_estimated_days', 'sub_contractor_price', 'construction_address'], 'string', 'max' => 255],
        ];
    }


    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'contractor_id' => 'Contractor Name',
            'sub_contractor_id' => 'Sub Contractor Name',
            'construction_contract_cost' => 'Construction Contract Cost',
            'construction_estimated_days' => 'Construction Estimated Days',
            'sub_contractor_price' => 'Sub Contractor Price',
            'client_id' => 'Client Name',
            'construction_address' => 'Construction Address',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getUpdateModel($model) {
        $this->project_id = $model->project_id;
        $this->contractor_id = $model->contractor_id;
        $this->sub_contractor_id = $model->sub_contractor_id;
        $this->construction_contract_cost = $model->construction_contract_cost;
        $this->construction_estimated_days = $model->construction_estimated_days;
        $this->sub_contractor_price = $model->sub_contractor_price;
        $this->client_id = $model->client_id;
        $this->construction_address = $model->construction_address;
        return $this;
    }

}
