<?php

namespace common\models\constructioncontractmanagement;

use Yii;
use common\models\client\Client;
use common\models\user\User;
use common\models\contractor\ContractorManagement;
use common\models\project\Project;

/**
 * This is the model class for table "construction_contract_management".
 *
 * @property int $id
 * @property int $project_id
 * @property int $contractor_id
 * @property int $sub_contractor_id
 * @property string $construction_contract_cost
 * @property string $construction_estimated_days
 * @property string $sub_contractor_price
 * @property int $client_id
 * @property string $construction_address
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class ConstructionContractManagement extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'construction_contract_management';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'contractor_id', 'sub_contractor_id', 'construction_contract_cost', 'construction_estimated_days', 'sub_contractor_price', 'client_id', 'construction_address', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['project_id', 'contractor_id', 'sub_contractor_id', 'client_id', 'created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            //[['construction_contract_cost', 'construction_estimated_days', 'sub_contractor_price', 'construction_address'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'contractor_id' => 'Contractor Name',
            'sub_contractor_id' => 'Sub Contractor Name',
            'construction_contract_cost' => 'Construction Contract Cost',
            'construction_estimated_days' => 'Construction Estimated Days',
            'sub_contractor_price' => 'Sub Contractor Price',
            'client_id' => 'Client Name',
            'construction_address' => 'Construction Address',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getContractor()
    {
        return $this->hasOne(User::className(), ['id' => 'contractor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubcontractor()
    {
        return $this->hasOne(User::className(), ['id' => 'sub_contractor_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClient()
    {
        return $this->hasOne(Client::className(), ['id' => 'client_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }
}
