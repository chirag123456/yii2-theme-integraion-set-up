<?php

namespace common\models\constructioncontractmanagement;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\constructioncontractmanagement\ConstructionContractManagement;

/**
 * ContractorManagementSearch represents the model behind the search form of `common\models\ConstructionContractManagement`.
 */
class ConstructionContractManagementSearch extends ConstructionContractManagement
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'contractor_id', 'sub_contractor_id'], 'integer'],
            [['project_id', 'contractor_id', 'sub_contractor_id', 'construction_contract_cost', 'construction_estimated_days', 'sub_contractor_price', 'client_id', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function searchContractor($params)
    {
        $query = ConstructionContractManagement::find()->where(['construction_contract_management.is_delete' => INACTIVE]);

        // add conditions that should always apply here
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        // $dataProvider->sort->attributes['country_id'] = [
        //     'asc' => ['client.client_name' => SORT_ASC],
        //     'desc' => ['client.client_name' => SORT_DESC],
        // ];

        // $dataProvider->sort->attributes['state_id'] = [
        //     'asc' => ['contractor.contractor_name' => SORT_ASC],
        //     'desc' => ['contractor.contractor_name' => SORT_DESC],
        // ];

        /*$dataProvider->sort->attributes['state_id'] = [
            'asc' => ['subcontractor.contractor_name' => SORT_ASC],
            'desc' => ['subcontractor.contractor_name' => SORT_DESC],
        ];
*/
        $dataProvider->sort->attributes['state_id'] = [
            'asc' => ['project_management.project_name' => SORT_ASC],
            'desc' => ['project_management.project_name' => SORT_DESC],
        ];

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        $query->joinWith(['client','project']);

        // grid filtering conditions
        $query->andFilterWhere([
            //'id' => $this->id,           
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'construction_contract_cost', $this->construction_contract_cost])
            ->andFilterWhere(['like', 'construction_estimated_days', $this->construction_estimated_days])
            ->andFilterWhere(['like', 'construction_contract_management.id', $this->id])
            ->andFilterWhere(['like', 'sub_contractor_price', $this->sub_contractor_price])
            ->andFilterWhere(['like', 'client.client_name', $this->client_id])
            
            //->andFilterWhere(['like', 'subcontractor.contractor_name', $this->sub_contractor_id])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'construction_contract_management.is_active', $this->is_active])
            ->andFilterWhere(['like', 'client.client_name', $this->client_id]);

        return $dataProvider;

        
    }
}