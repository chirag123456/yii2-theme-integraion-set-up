<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\team;

use yii\base\Model;
use common\models\team\team;

class TeamForm extends Model {

   public $id;
   public $role_id; 
   public $user_id;
   public $item_id;
   public $business_name;
   public $contact_name;
   public $email;
   public $phone;
   public $fax;
   public $address;
   public $project_id;
 
    public function rules() {

        return [
            [['role_id', 'user_id', 'business_name', 'contact_name', 'email', 'address','project_id','phone'], 'required'], 
            [['fax','item_id'], 'safe'], 
        ];
    }

    public function getUpdateModel($model) {

      $this->role_id = $model->role_id;
      $this->user_id = isset($model->user_id) ? $model->user_id : 'N\A';
      $this->item_id = isset($model->item_id) ? $model->item_id : 'N\A';
      $this->business_name = $model->business_name;
      $this->contact_name = $model->contact_name;
      $this->email = $model->email;
      $this->phone = $model->phone;
      $this->address = $model->address;
      $this->fax = $model->fax;
      $this->project_id = $model->project_id;
        return $this;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'role_id' => 'Role',
            'user_id' => 'User',
            'item_id' => 'Item',
            'business_name' => 'Business Name',
            'contact_name' => 'Contact Name',
            'email' => 'Email',
            'phone' => 'Phone Number',
            'fax' => 'Fax',
            'address' => 'Address',
            'project_id' => 'Project',
        ];
    }
}