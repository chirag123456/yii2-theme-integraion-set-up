<?php

namespace common\models\team;

use Yii;
use common\models\userrole\UserAccess;
use common\models\project\Project;
use common\models\user\User;
use common\models\itemwork\ItemWork;

/**
 * This is the model class for table "Team".
 *
 * @property int $id
 * @property int $role_id
 * @property int $user_id
 * @property int $item_id
 * @property int $project_id
 * @property string $business_name
 * @property string $contact_name
 * @property string $email
 * @property string $phone
 * @property string $fax
 * @property string $address
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class Team extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'team';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['role_id', 'user_id', 'business_name', 'contact_name', 'email', 'address', 'created_by', 'created_date', 'updated_by', 'updated_date','project_id'], 'required'],
            [['role_id', 'user_id', 'created_by', 'updated_by'], 'integer'],
            [['address', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date'], 'safe'],
            [['business_name', 'contact_name', 'email'], 'string', 'max' => 255],
            [['phone', 'fax'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'role_id' => 'Role',
            'project_id' => 'Project',
            'user_id' => 'User',
            'item_id' => 'Item',
            'business_name' => 'Business Name',
            'contact_name' => 'Contact Name',
            'email' => 'Email',
            'phone' => 'Phone Number',
            'fax' => 'Fax',
            'address' => 'Address',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    } 

    /**
    * Get Role
    */
    public function getRole()
    {
        return $this->hasOne(UserAccess::className(), ['id' => 'role_id']);
    }

    /**
    * Get Project
    */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
    * Get User
    */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
    * Get Item
    */
    public function getItem()
    {
        return $this->hasOne(ItemWork::className(), ['id' => 'item_id']);
    }
}
