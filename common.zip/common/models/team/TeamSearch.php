<?php

namespace common\models\team;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\team\Team;
use common\models\project\Project;

/**
 * TeamSearch represents the model behind the search form of `common\models\Team`.
 */
class TeamSearch extends Team
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'role_id', 'item_id', 'created_by', 'updated_by'], 'integer'],
            [['business_name', 'contact_name', 'email', 'phone', 'fax', 'address', 'created_date', 'updated_date', 'is_active', 'is_delete','project_id','user_id'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Team::find()->where(['team.is_delete' => NOT_DELETED]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        $query->joinWith(['role', 'project','user']);

        // grid filtering conditions
        $query->andFilterWhere([
            //'id' => $this->id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'business_name', $this->business_name])
            ->andFilterWhere(['like', 'team.id', $this->id])
            ->andFilterWhere(['like', 'contact_name', $this->contact_name])
            ->andFilterWhere(['like', 'email', $this->email])
            ->andFilterWhere(['like', 'user_access.id', $this->role_id])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'users.email', $this->user_id])
            ->andFilterWhere(['like', 'phone', $this->phone])
            ->andFilterWhere(['like', 'fax', $this->fax])
            ->andFilterWhere(['like', 'address', $this->address])
            ->andFilterWhere(['like', 'team.is_active', $this->is_active])
            ->andFilterWhere(['like', 'team.is_delete', $this->is_delete]);

        return $dataProvider;
    } 
}
