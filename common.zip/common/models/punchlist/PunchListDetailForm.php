<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\punchlist;

use yii\base\Model;
use common\models\punchlist\PunchListDetail;

class PunchListDetailForm extends Model {

    public $location;
    public $description;
    public $subcontractor_id;
    public $gc_initial;
    public $owner_pm_initial;
    public $completed_date;

    public function rules() {

        return [
            //[['location', 'description', 'subcontractor_id', 'gc_initial', 'owner_pm_initial', 'completed_date', 'created_date', 'created_by', 'updated_date', 'updated_by', 'is_active', 'is_delete'], 'required'],
            [['subcontractor_id', 'created_by', 'updated_by'], 'integer'],
            [['description', 'is_active', 'is_delete'], 'string'],
            [['completed_date', 'created_date', 'updated_date'], 'safe'],
            [['gc_initial', 'owner_pm_initial'], 'string', 'max' => 255],
        ];
    }

    public function getUpdateModel($model) {

        $this->location= $model->location; 
        return $this;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'location' => 'Location',
            'description' => 'Description',
            'subcontractor_id' => 'Subcontractor',
            'gc_initial' => 'Gc Initial',
            'owner_pm_initial' => 'Owner Pm Initial',
        ];
    }
}