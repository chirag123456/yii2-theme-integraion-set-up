<?php

namespace common\models\punchlist;

use Yii;
use common\models\contractor\ContractorManagement;
use common\models\user\User;

/**
 * This is the model class for table "punch_list_detail".
 *
 * @property int $id
 * @property int $location
 * @property string $description
 * @property int $subcontractor_id
 * @property string $gc_initial
 * @property string $owner_pm_initial
 * @property string $completed_date
 * @property string $created_date
 * @property int $created_by
 * @property string $updated_date
 * @property int $updated_by
 * @property string $is_active
 * @property string $is_delete
 */
class PunchListDetail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'punch_list_detail';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['location', 'description', 'subcontractor_id', 'gc_initial', 'owner_pm_initial', 'completed_date', 'created_date', 'created_by', 'updated_date', 'updated_by', 'is_active', 'is_delete'], 'required'],
            [[ 'subcontractor_id', 'created_by', 'updated_by'], 'integer'],
            [['description', 'is_active', 'is_delete'], 'string'],
            [['completed_date', 'created_date', 'updated_date'], 'safe'],
            [['gc_initial', 'owner_pm_initial'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'location' => 'Location',
            'description' => 'Description',
            'subcontractor_id' => 'Subcontractor ID',
            'gc_initial' => 'Gc Initial',
            'owner_pm_initial' => 'Owner Pm Initial',
            'completed_date' => 'Completed Date',
            'created_date' => 'Created Date',
            'created_by' => 'Created By',
            'updated_date' => 'Updated Date',
            'updated_by' => 'Updated By',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getSubcontractor()
    {
        return $this->hasOne(User::className(), ['id' => 'subcontractor_id']);
    }
}
