<?php

namespace common\models\punchlist;

use Yii;
use common\models\project\Project; 
use common\models\user\User;

/**
 * This is the model class for table "punch_list".
 *
 * @property int $id
 * @property int $project_id
 * @property int $project_manager_user_id
 * @property string $present
 * @property string $walkthrough_date
 * @property int $superintendent_user_id
 * @property string $cell_phone
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class PunchList extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'punch_list';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'project_manager_user_id', 'present', 'walkthrough_date', 'superintendent_user_id', 'cell_phone', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['project_id', 'project_manager_user_id', 'superintendent_user_id', 'created_by', 'updated_by'], 'integer'],
            [['present', 'is_active', 'is_delete'], 'string'],
            [['walkthrough_date', 'created_date', 'updated_date'], 'safe'],
            [['cell_phone'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'project_manager_user_id' => 'Project Manager Name',
            'present' => 'Present',
            'walkthrough_date' => 'Walkthrough Date',
            'superintendent_user_id' => 'Superintendent Name',
            'cell_phone' => 'Cell Phone',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'project_manager_user_id']);
    }

    public function getSuperintendent()
    {
        return $this->hasOne(User::className(), ['id' => 'superintendent_user_id']);
    }
}
