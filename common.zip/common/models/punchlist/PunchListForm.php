<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\punchlist;

use yii\base\Model;
use common\models\punchlist\PunchList;

class PunchListForm extends Model {

    public $project_id;
    public $project_manager_user_id;
    public $present;
    public $walkthrough_date;
    public $superintendent_user_id;
    public $cell_phone;

    public function rules() {

        return [
            [['project_id', 'project_manager_user_id', 'present', 'walkthrough_date', 'superintendent_user_id', 'cell_phone'], 'required'],
            [['project_id', 'project_manager_user_id', 'superintendent_user_id'], 'integer'],
            [['present'], 'string'],
            [['cell_phone'], 'number'],
            [['walkthrough_date'], 'safe'],
            
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id= $model->project_id; 
        return $this;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'project_manager_user_id' => 'Project Manager',
            'present' => 'Present',
            'walkthrough_date' => 'Walkthrough Date',
            'superintendent_user_id' => 'Superintendent',
            'cell_phone' => 'Cell Phone',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }
}