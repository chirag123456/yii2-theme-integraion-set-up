<?php

namespace common\models\punchlist;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\punchlist\PunchList;

/**
 * ProjectBudgetSearch represents the model behind the search form about 
 */
class PunchListSearch extends PunchList {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id','project_id', 'project_manager_user_id', 'present', 'walkthrough_date', 'superintendent_user_id', 'cell_phone', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'safe'],
            // [['project_id', 'project_manager_user_id', 'superintendent_user_id', 'created_by', 'updated_by'], 'integer'],
            [['present', 'is_active', 'is_delete'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = PunchList::find()->where(['punch_list.is_delete' => NOT_DELETED]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        $query->joinWith(['project', 'user']);
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'users.first_name', $this->project_manager_user_id])
            ->andFilterWhere(['like', 'users.first_name', $this->superintendent_user_id])
            ->andFilterWhere(['like', 'cell_phone', $this->cell_phone]);

        return $dataProvider;
    }

}
