<?php

namespace common\models\city;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\city\City;

/**
 * CitySearch represents the model behind the search form about `common\models\City`.
 */
class CitySearch extends City {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id', 'created_by', 'updated_by'], 'integer'],
            [['name', 'country_id', 'is_active', 'created_date', 'updated_date', 'state_id'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = City::find()->where(['city.is_delete' => NOT_DELETED]);
       // $query1 = State::find()->where(['state.is_delete' => NOT_DELETED]);
        //$query2 = Country::find()->where(['country.is_delete' => NOT_DELETED]);
        // add conditions that should always apply here

        //$settings = \common\models\Settings::find()->one();
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);
        $dataProvider->sort->attributes['country_id'] = [
            'asc' => ['country.country_name' => SORT_ASC],
            'desc' => ['country.country_name' => SORT_DESC],
        ];

         $dataProvider->sort->attributes['state_id'] = [
            'asc' => ['state.state_name' => SORT_ASC],
            'desc' => ['state.state_name' => SORT_DESC],
        ];

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['state', 'country']);


        $query->andFilterWhere([
            //'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
                ->andFilterWhere(['like', 'city.id', $this->id])
                ->andFilterWhere(['like', 'state.state_name', $this->state_id])
                ->andFilterWhere(['like', 'country.country_name', $this->country_id])
                ->andFilterWhere(['like', 'city.is_active', $this->is_active]);

        return $dataProvider;
    }

}
