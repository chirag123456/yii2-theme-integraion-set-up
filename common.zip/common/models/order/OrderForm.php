<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\order;

use yii\base\Model;
use common\models\order\Order;


class OrderForm extends Model {

    public $id;
    public $purchase_order_no;
    public $project_id;
    public $owner_id;
    public $architect_id;
    public $contractor_id;
	public $contract_for;
	public $job_no;
	public $job_name;
    public $order_date;
    public $delivery_date;
    public $to_be_shipped_via;
    public $sub_total;
    public $tax;
    public $shipping_handling;
    public $other_cost;
    public $total_amt;
    public $issued_by;
    public $issued_date;
    public $accepted_by;
    public $accepted_date;
    public $fob; 
	

    public function rules() {
        return [
            [['purchase_order_no', 'project_id', 'architect_id', 'contractor_id', 'job_no', 'job_name', 'order_date', 'delivery_date', 'to_be_shipped_via', 'sub_total', 'tax', 'shipping_handling', 'other_cost', 'total_amt', 'issued_by', 'issued_date', 'accepted_by', 'accepted_date', 'fob'], 'required'],
            [['sub_total', 'tax','other_cost', 'total_amt'], 'number'],
            ['purchase_order_no', 'custom_purchase_order_no_unique'],
            ['job_no', 'custom_job_no_unique'],
        ];
    }

    public function getUpdateModel($model) {

        $this->purchase_order_no = $model->purchase_order_no;
        $this->project_id = $model->project_id;
        $this->owner_id = $model->owner_id;
		$this->architect_id = $model->architect_id;
		$this->contractor_id = $model->contractor_id;
		$this->contract_for = $model->contract_for;
        $this->job_no = $model->job_no;
        $this->job_name = $model->job_name;
        $this->order_date = $model->order_date;
        $this->delivery_date = $model->delivery_date;
        $this->to_be_shipped_via = $model->to_be_shipped_via;
        $this->sub_total = $model->sub_total;
        $this->tax = $model->tax;
        $this->shipping_handling = $model->shipping_handling;
        $this->other_cost = $model->other_cost;
        $this->total_amt = $model->total_amt;
        $this->issued_by = $model->issued_by;
        $this->issued_date = $model->issued_date;
        $this->accepted_by = $model->accepted_by;
        $this->accepted_date = $model->accepted_date;
        $this->fob = $model->fob;

        return $this;
    }
 
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'purchase_order_no' => 'Purchase Order No',
            'project_id' => 'Project',
            'owner_id' => 'Owner',
            'architect_id' => 'Architect',
            'contractor_id' => 'Contractor',
            'contract_for' => 'Contract For',
            'job_no' => 'Job No',
            'job_name' => 'Job Name',
            'order_date' => 'Order Date',
            'delivery_date' => 'Delivery Date',
            'to_be_shipped_via' => 'To Be Shipped Via',
            'sub_total' => 'Sub Total',
            'tax' => 'Tax',
            'shipping_handling' => 'Shipping Handling',
            'other_cost' => 'Other Cost',
            'total_amt' => 'Total Amount',
            'issued_by' => 'Issued By',
            'issued_date' => 'Issued Date',
            'accepted_by' => 'Accepted By',
            'accepted_date' => 'Accepted Date',
            'fob' => 'Fob'
        ];
    }

    //This Function Use Unique Purchase Order Number Id
    public function custom_purchase_order_no_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Order::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->purchase_order_no), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Order::find()->where(['purchase_order_no' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This purchase order number is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Order::find()->where(['purchase_order_no' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This purchase order number is already exist!');
            }
        }
    }

    //This Function Use Unique Job Number Id
    public function custom_job_no_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Order::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->job_no), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Order::find()->where(['job_no' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This job number is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Order::find()->where(['job_no' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This job number is already exist!');
            }
        }
    }
}