<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\order;

use yii\base\Model;


class OrderItemForm extends Model {

    public $id;
    public $item_id;
    public $qty;
    public $unit;
    public $description;
	public $cost_code;
	public $unit_price;
	public $extended_amt;
	

    public function rules() {
        return [
            [['order_id', 'item_id', 'qty', 'unit', 'description', 'cost_code', 'unit_price', 'extended_amt'], 'safe'],
        ];
    }

    public function getUpdateModel($model) {

        $this->item_name = $model->item_id;
        $this->qty = $model->qty;
		$this->unit = $model->unit;
		$this->description = $model->description;
		$this->cost_code = $model->cost_code;
        $this->unit_price = $model->unit_price;
        $this->extended_amt = $model->extended_amt;

        return $this;
    }
 
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'item_id' => 'Item Name',
            'qty' => 'Quantity',
            'unit' => 'Unit',
            'description' => 'Description',
            'cost_code' => 'Cost Code',
            'unit_price' => 'Unit Price',
            'extended_amt' => 'Extended Amount',
        ];
    }
}