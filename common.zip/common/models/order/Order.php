<?php

namespace common\models\order;

use Yii;
use common\models\user\User;
use common\models\project\Project;

/**
 * This is the model class for table "order".
 *
 * @property int $id
 * @property int $purchase_order_no
 * @property int $project_id
 * @property int $owner_id
 * @property int $architect_id
 * @property int $contractor_id
 * @property string $contract_for
 * @property string $job_no
 * @property string $job_name
 * @property string $order_date
 * @property string $delivery_date
 * @property string $to_be_shipped_via
 * @property string $sub_total
 * @property string $tax
 * @property string $shipping_handling
 * @property string $other_cost
 * @property string $total_amt
 * @property int $issued_by
 * @property string $issued_date
 * @property int $accepted_by
 * @property string $accepted_date
 * @property string $fob
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class Order extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'order';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['purchase_order_no', 'project_id' , 'architect_id', 'contractor_id', 'job_no', 'job_name', 'order_date', 'delivery_date', 'to_be_shipped_via', 'sub_total', 'tax', 'shipping_handling', 'other_cost', 'total_amt', 'issued_by', 'issued_date', 'accepted_by', 'accepted_date', 'fob', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            //[['purchase_order_no', 'project_id', 'owner_id', 'architect_id', 'contractor_id', 'issued_by', 'accepted_by', 'created_by', 'updated_by'], 'integer'],
            [['contract_for', 'is_active', 'is_delete'], 'string'],
            [['order_date', 'delivery_date', 'issued_date', 'accepted_date', 'created_date', 'updated_date','owner_id'], 'safe'],
            [['job_no', 'job_name', 'to_be_shipped_via', 'sub_total', 'tax', 'shipping_handling', 'other_cost', 'total_amt', 'fob'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'purchase_order_no' => 'Purchase Order No',
            'project_id' => 'Project',
            'owner_id' => 'Owner',
            'architect_id' => 'Architect',
            'contractor_id' => 'Contractor',
            'contract_for' => 'Contract For',
            'job_no' => 'Job No',
            'job_name' => 'Job Name',
            'order_date' => 'Order Date',
            'delivery_date' => 'Delivery Date',
            'to_be_shipped_via' => 'To Be Shipped Via',
            'sub_total' => 'Sub Total',
            'tax' => 'Tax',
            'shipping_handling' => 'Shipping Handling',
            'other_cost' => 'Other Cost',
            'total_amt' => 'Total Amount',
            'issued_by' => 'Issued By',
            'issued_date' => 'Issued Date',
            'accepted_by' => 'Accepted By',
            'accepted_date' => 'Accepted Date',
            'fob' => 'Fob',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    } 

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getArchitect()
    {
        return $this->hasOne(User::className(), ['id' => 'architect_id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getContractor()
    {
        return $this->hasOne(User::className(), ['id' => 'contractor_id']);
    }
}
