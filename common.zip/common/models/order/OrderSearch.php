<?php

namespace common\models\order;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\order\Order;

/**
 * OrderSearch represents the model behind the search form of `common\models\Order`.
 */
class OrderSearch extends Order
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            
            [['id', 'purchase_order_no', 'project_id', 'contract_for', 'job_no', 'job_name', 'order_date', 'delivery_date', 'to_be_shipped_via', 'sub_total', 'tax', 'shipping_handling', 'other_cost', 'total_amt', 'issued_date', 'accepted_date', 'fob', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Order::find()->where(['order.is_delete' => NOT_DELETED]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $query->joinWith(['project']); 

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'purchase_order_no' => $this->purchase_order_no,
            //'project_id' => $this->project_id,
            'owner_id' => $this->owner_id,
            'architect_id' => $this->architect_id,
            'contractor_id' => $this->contractor_id,
            'order_date' => $this->order_date,
            'delivery_date' => $this->delivery_date,
            'issued_by' => $this->issued_by,
            'issued_date' => $this->issued_date,
            'accepted_by' => $this->accepted_by,
            'accepted_date' => $this->accepted_date,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'contract_for', $this->contract_for])
            ->andFilterWhere(['like', 'job_no', $this->job_no])
            ->andFilterWhere(['like', 'job_name', $this->job_name])
            ->andFilterWhere(['like', 'to_be_shipped_via', $this->to_be_shipped_via])
            ->andFilterWhere(['like', 'sub_total', $this->sub_total])
            ->andFilterWhere(['like', 'tax', $this->tax])
            ->andFilterWhere(['like', 'shipping_handling', $this->shipping_handling])
            ->andFilterWhere(['like', 'other_cost', $this->other_cost])
            ->andFilterWhere(['like', 'total_amt', $this->total_amt])
            ->andFilterWhere(['like', 'fob', $this->fob])
            ->andFilterWhere(['like', 'order.is_active', $this->is_active])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id]);

        return $dataProvider;
    }
}
