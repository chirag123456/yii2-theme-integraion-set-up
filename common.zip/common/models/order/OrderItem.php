<?php

namespace common\models\order;

use Yii;
use common\models\itemwork\ItemWork;

/**
 * This is the model class for table "order_item".
 *
 * @property int $id
 * @property int $order_id
 * @property string $item_id
 * @property int $qty
 * @property string $unit
 * @property string $description
 * @property string $cost_code
 * @property string $unit_price
 * @property string $extended_amt
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class OrderItem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'order_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['order_id', 'item_id', 'qty', 'unit', 'description', 'unit_price', 'extended_amt', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['order_id', 'qty', 'created_by', 'updated_by'], 'integer'],
            [['description', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date','cost_code'], 'safe'],
           // [['item_name', 'unit', 'cost_code', 'unit_price', 'extended_amt'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'order_id' => 'Order',
            'item_id' => 'Item Name',
            'qty' => 'Qty',
            'unit' => 'Unit',
            'description' => 'Description',
            'cost_code' => 'Cost Code',
            'unit_price' => 'Unit Price',
            'extended_amt' => 'Extended Amt',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getItem()
    {
        return $this->hasOne(ItemWork::className(), ['id' => 'item_id']);
    }
}
