<?php

namespace common\models\client;

use Yii;

/**
 * This is the model class for table "client".
 *
 * @property int $id
 * @property string $client_name
 * @property string $client_email
 * @property string $client_address
 * @property string $client_phone
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class Client extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'client';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_name', 'client_address', 'client_phone','client_email','created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['client_address', 'is_active', 'is_delete'], 'string'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['client_name', 'client_phone'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_name' => 'Client Name',
            'client_address' => 'Client Address',
            'client_phone' => 'Client Phone',
            'client_email' =>'Client Email',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }
}
