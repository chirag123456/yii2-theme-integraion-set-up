<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\client; 

use yii\base\Model;
use common\models\client\Client;

class ClientForm extends Model {

    public $id;
    public $client_name;
    public $client_address;
    public $client_phone;
    public $client_email;
    public $created_date;
    public $created_by;
    public $updated_by;
    public $updated_date;
    public $is_delete;
    public $is_active;

    public function rules() {

       return [
            [['client_name', 'client_address', 'client_phone', 'client_email'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            ['client_email', 'email', 'message' => 'Please enter valid email address '],
            ['client_email','custom_client_email_unique'],
            ['client_phone', 'required', 'message' => 'Phone Number cannot be blank.'],
            ['client_phone', 'number', 'message' => 'Phone Number is Invalid.'],
            [['is_active', 'is_delete'], 'string'],
            ['client_email', 'email', 'message' => 'Please enter valid client email address '], 
        ];
    }


    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_name' => 'Client Name',
            'client_address' => 'Client Address',
            'client_phone' => 'Client Phone',
            'client_email' => 'Client Email',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getUpdateModel($model) {
        $this->client_name = $model->client_name;
        $this->client_address = $model->client_address;
        $this->client_phone = $model->client_phone;
        $this->client_email = $model->client_email;
        return $this;
    }

    public function custom_client_email_unique($attribute, $params) {
        $check = false;

        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Client::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = strcasecmp(trim($check->client_email), trim($this->$attribute));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Client::find()->where(['client_email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Client Email'.ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Client::find()->where(['client_email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Client Email'.ALREADY);
            }
        }
    }

}
