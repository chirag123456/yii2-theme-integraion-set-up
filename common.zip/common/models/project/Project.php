<?php

namespace common\models\project;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use common\models\city\City;
use common\models\state\State;
use yii\web\IdentityInterface;
use yii\db\Query;

/**
 * User model
 *
 * @property integer $id
 */
class Project  extends ActiveRecord  {

   
    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%project_management}}';
    }

   

    /**
     * @inheritdoc
     */
    public function rules() {
      return [
           [['project_name','project_cost', 'project_size', 'project_estimated_days', 'project_number', 'project_desc', 'date_of_commencement', 'date_of_substantial_completion', 'date_of_completion', 'project_physical_address', 'project_state_id', 'project_city_id', 'project_zipcode','architect_id','lender_id','landlord_id','construction_plan_dated','is_architect_ca'], 'required'],
            [['id', 'created_by', 'updated_by'], 'integer'],
            [[ 'is_active', 'created_by', 'updated_by'], 'safe'],
        ];
    }
    
    public function attributeLabels()
    {
         return [
            'id' => 'ID',
            'architect_id' => 'Architect',
            'owner_id' => 'Owner',
            'landlord_id' => 'Landlord',
            'lender_id' => 'Lender',
            'project_name' => 'Project Name',
            'project_cost' => 'Project Cost',
            'project_size' => 'Project Size',
            'project_estimated_days' => 'Project Estimated Days',
            'project_number' => 'Project Number',
            'project_desc' => 'Project Description',
            'date_of_commencement' => 'Date of Commencement',
            'date_of_substantial_completion' => 'Date of Substantial Completion',
            'date_of_completion' => 'Date of Completion',
            'project_physical_address' => 'Project Physical Address',
            'project_state_id' => 'State Name',
            'project_city_id' => 'City Name',
            'project_zipcode' => 'Zipcode',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'construction_plan_dated' => 'Construction Plans Dated',
            'is_architect_ca' => 'CA'
        ];
    }

     /**
     * @return \yii\db\ActiveQuery
     */
    public function getState()
    {
        return $this->hasOne(State::className(), ['id' => 'project_state_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['id' => 'project_city_id']);
    }

    public function getProjectData()
    {
        $data = [];
        /*$query = new Query;
        $query->select([
            'project_management.project_name',
            'project_management.project_cost',
            'project_management.project_size',
            'project_management.project_estimated_days',
            'project_management.project_number',
            'project_management.date_of_commencement',
            'project_management.date_of_substantial_completion',
            'project_management.date_of_completion',
            'project_management.project_physical_address',
            'project_management.project_zipcode',            
            'state.state_name as p_state_name',
            'city.name as p_city_name',

            'users.first_name as architect_first_name',
            'users.last_name as architect_last_name',
            'users.email as architect_email',
            'users.contact_number as architect_contact_number',
            'users.architect_firm as architect_firm',
            'users.address as architect_address',
            'users.zipcode as architect_zipcode',
            'project_management.construction_plan_dated',
            'project_management.is_architect_ca',
            'architect_state.state_name as architect_state',
            'architect_city.name as architect_city',

            'landlord.landlord_email',
            'landlord.landlord_phone',
            'landlord.landlord_contact_person',
            'landlord.landlord_address',
            'landlord.landlord_zipcode',
            'landlord_state.state_name as landlord_state',
            'landlord_city.name as landlord_city', 
            'landlord.will_landlord_require_special_documentation_for_billing',
            'landlord.if_special_documentation_required_if_yes_list',

            'lender.lender_or_bank_contact_person',
            'lender.lender_email',
            'lender.lender_phone',
            'lender.bank_require_special_documentation_for_billing_project_closeout',
            'lender.lender_special_documentation_list_requirements',
            'lender.lender_address',
            'lender.lender_zipcode as lender_zipcode',
            'lender_state.state_name as lender_state_name',
            'lender_city.name as lender_city_name',

        ])  
        ->from('project_management')->where(['project_management.is_delete' => NOT_DELETED])
         ->orderBy([
                      'project_management.id' => SORT_DESC,                              
                    ])
        
        ->join('LEFT OUTER JOIN', 'users',
            'project_management.architect_id = users.id')
        ->join('LEFT OUTER JOIN', 'landlord',
            'project_management.landlord_id = landlord.id')
        ->join('LEFT OUTER JOIN', 'lender',
            'project_management.lender_id = lender.id')


        ->join('LEFT OUTER JOIN', 'state',
            'project_management.project_state_id = state.id')
        ->join('LEFT OUTER JOIN', 'city',
            'project_management.project_city_id = city.id')

        ->join('LEFT OUTER JOIN', 'state lender_state',
            'lender.lender_state_id = lender_state.id')
        ->join('LEFT OUTER JOIN', 'city lender_city',
            'lender.lender_city_id = lender_city.id')

        ->join('LEFT OUTER JOIN', 'state landlord_state',
            'landlord.landlord_state_id = landlord_state.id')
        ->join('LEFT OUTER JOIN', 'city landlord_city',
            'landlord.landlord_city_id = landlord_city.id')


        ->join('LEFT OUTER JOIN', 'state architect_state',
            'users.state_id = architect_state.id')
        ->join('LEFT OUTER JOIN', 'city architect_city',
            'users.city_id = architect_state.id');

        $command = $query->createCommand();
        $data = $command->queryAll();*/

        $connection = Yii::$app->getDb();
        $command3 = $connection->createCommand(
                "SELECT pm.project_name,
                    pm.project_cost,
                    pm.project_size,
                    pm.project_estimated_days,
                    pm.project_number,
                    pm.date_of_commencement,
                    pm.date_of_substantial_completion,
                    pm.date_of_completion,
                    pm.project_physical_address,
                    pm.project_zipcode,

                    state.state_name as p_state_name,
                    city.name as p_city_name,
                    users.first_name as architect_first_name,
                    users.last_name as architect_last_name,
                    users.email as architect_email,
                    users.contact_number as architect_contact_number,
                    users.architect_firm as architect_firm,
                    users.address as architect_address,
                    users.zipcode as architect_zipcode,

                    pm.construction_plan_dated,
                    pm.is_architect_ca,
                    
                    la.landlord_email,
                    la.landlord_phone,
                    la.landlord_contact_person,
                    la.landlord_address,
                    la.landlord_zipcode,
                    landlord_st.state_name as landlord_state,
                    landlord_ci.name as landlord_city, 
                    la.will_landlord_require_special_documentation_for_billing,
                    la.if_special_documentation_required_if_yes_list,

                    le.lender_or_bank_contact_person,
                    le.lender_email,
                    le.lender_phone,
                    le.bank_require_special_documentation_for_billing_project_closeout,
                    le.lender_special_documentation_list_requirements,
                    le.lender_address,
                    le.lender_zipcode as lender_zipcode,
                    lender_state.state_name as lender_state_name,
                    lender_city.name as lender_city_name,
                    architect_state.state_name as architect_state,
                    architect_city.name as architect_city

                    FROM project_management as pm 
                    LEFT JOIN state ON state.id = pm.project_state_id
                    LEFT JOIN city ON city.id = pm.project_city_id
                    LEFT JOIN users ON users.id = pm.architect_id
                    LEFT JOIN landlord as la ON pm.landlord_id = la.id
                    LEFT JOIN lender as le ON pm.lender_id = le.id
                    LEFT JOIN state as lender_state ON le.lender_state_id = lender_state.id
                    LEFT JOIN city as lender_city ON le.lender_city_id = lender_city.id
                    LEFT JOIN state as landlord_st ON la.landlord_state_id = landlord_st.id
                    LEFT JOIN city as landlord_ci ON la.landlord_city_id = landlord_ci.id
                    LEFT JOIN state as architect_state ON users.state_id = architect_state.id
                    LEFT JOIN city as architect_city ON users.city_id = architect_city.id
                    WHERE pm.is_delete = 'N'
                    ");
        
        $data = $command3->queryAll();
        return $data;
    }

    public function getProjectFilterData($params)
    {
        $query = new Query;
        $query->select([
            'project_management.id as pid',
            'project_management.project_name',
            'project_management.project_cost',
            'project_management.project_size',
            'project_management.project_estimated_days',
            'project_management.project_number',
            'project_management.date_of_commencement',
            'project_management.date_of_substantial_completion',
            'project_management.date_of_completion',
            'project_management.project_physical_address',
            'project_management.project_zipcode',            
            'state.state_name as p_state_name',
            'city.name as p_city_name',
            'users.email as architect_email',
            'project_management.construction_plan_dated',
            
            'landlord.landlord_email',
            'lender.lender_email',
        ])  
        ->from('project_management')->where(['project_management.is_delete' => NOT_DELETED])
         ->orderBy([
                      'project_management.id' => SORT_DESC,                              
                    ]);
        if(isset($params['date_of_commencement']) && $params['date_of_commencement'] != '')
        {
            $query->andWhere(['project_management.date_of_commencement' => $params['date_of_commencement'] ]);
        }

        if(isset($params['date_of_completion']) && $params['date_of_completion'] != '')
        {
            $query->andWhere(['project_management.date_of_completion' => $params['date_of_completion'] ]);   
        }

        
        $query->join('LEFT OUTER JOIN', 'users',
            'project_management.architect_id = users.id')
        ->join('LEFT OUTER JOIN', 'landlord',
            'project_management.landlord_id = landlord.id')
        ->join('LEFT OUTER JOIN', 'lender',
            'project_management.lender_id = lender.id')


        ->join('LEFT OUTER JOIN', 'state',
            'project_management.project_state_id = state.id')
        ->join('LEFT OUTER JOIN', 'city',
            'project_management.project_city_id = city.id')

        ;

        
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }
    
}