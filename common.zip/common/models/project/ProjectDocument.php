<?php
namespace common\models\project;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use common\models\project\FolderCreate;

/**
 * ProjectDucument model
 *
 * @property integer $id
 * @property string $project_id
 * @property string $file_name
 * @property string $file_path
 */

class ProjectDocument  extends ActiveRecord  {


    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%project_document}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
      return [
           //[[], 'required'],
            [['id', 'created_by', 'updated_by'], 'integer'],
            [['project_id','project_folder_id','file_name', 'file_path', 'is_active', 'created_by', 'updated_by','is_delete','is_downloaded'], 'safe'],
        ];
    }
    
    public function attributeLabels()
    {
         return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'project_folder_id' => 'Folder Name',
            'file_name' => 'File',
            'file_path' => 'File Path',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'is_downloaded' => 'Is Downloaded ?',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProjectfolder()
    {
        return $this->hasOne(FolderCreate::className(), ['id' => 'project_folder_id']);
    }
}