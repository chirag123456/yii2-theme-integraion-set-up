<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\project;

use yii\base\Model;
use common\models\project\Project;
use codeonyii\yii2validators\AtLeastValidator;


class ProjectReportForm extends Model {

    public $id;
    public $date_of_commencement;
    public $date_of_completion;

    public function rules() {

        return [
            [['date_of_completion', 'date_of_commencement'], AtLeastValidator::className(), 'in' => ['date_of_completion', 'date_of_commencement'], 'min' => 1]

        ];
    }

    

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'date_of_commencement' => 'Date of Commencement',
            'date_of_completion' => 'Date of Completion',
        ];
    }

    
}