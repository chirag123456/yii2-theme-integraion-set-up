<?php

namespace common\models\project;

use Yii;
use yii\base\Model;


/**
 * This is the model class for table "project_proposal".
 *
 * @property int $id
 * @property int $project_id
 * @property string $p_name
 * @property string $sub_contractor_total_cost
 * @property string $p_total_cost
 * @property string $project_size
 * @property string $cost_per_sf
 * @property int $estimated_design_duration_days
 * @property string $item_sub_total
 * @property string $overall_overhead_per
 * @property string $overall_fee_per
 * @property string $contractor_overhead
 * @property string $contractor_fee
 * @property string $item_total_cost
 * @property string $p_desc
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class ProjectProposal extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'project_proposal';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'p_name', 'sub_contractor_total_cost', 'p_total_cost', 'project_size', 'cost_per_sf', 'estimated_design_duration_days', 'item_sub_total', 'overhead', 'fee', 'contractor_overhead', 'contractor_fee', 'item_total_cost', 'p_desc'], 'required'],
            
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'p_name' => 'Proposal Name',
            'sub_contractor_total_cost' => 'Sub Contractor Total Cost',
            'p_total_cost' => 'Proposal Total Cost',
            'project_size' => 'Project Size',
            'cost_per_sf' => 'Cost Per Sf',
            'estimated_design_duration_days' => 'Estimated Design Duration Days',
            'item_sub_total' => 'Item Sub Total',
            'overhead' => 'Overall Overhead Per',
            'fee' => 'Overall Fee Per',
            'contractor_overhead' => 'Contractor Overhead',
            'contractor_fee' => 'Contractor Fee',
            'item_total_cost' => 'Item Total Cost',
            'p_desc' => 'Proposal Description',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }
}
