<?php

namespace common\models\project;

use Yii;
use yii\base\Model;

class ProjectProposalForm extends Model
{
    public $id;
    public $project_id;
    public $p_name;
    public $sub_contractor_total_cost;
    public $p_total_cost;
    public $project_size;
    public $cost_per_sf;
    public $estimated_design_duration_days;
    public $item_sub_total;
    public $overall_overhead_per;
    public $overall_fee_per;
    public $contractor_overhead;
    public $contractor_fee;
    public $item_total_cost;
    public $p_desc;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'p_name', 'sub_contractor_total_cost', 'p_total_cost', 'project_size', 'cost_per_sf', 'estimated_design_duration_days', 'item_sub_total', 'overall_overhead_per', 'overall_fee_per', 'contractor_overhead', 'contractor_fee', 'item_total_cost', 'p_desc'], 'required'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'p_name' => 'Proposal Name',
            'sub_contractor_total_cost' => 'Sub Contractor Total Cost',
            'p_total_cost' => 'Proposal Total Cost',
            'project_size' => 'Project Size',
            'cost_per_sf' => 'Cost Per Sf',
            'estimated_design_duration_days' => 'Estimated Design Duration Days',
            'item_sub_total' => 'Item Sub Total',
            'overall_overhead_per' => 'Overall Overhead Per',
            'overall_fee_per' => 'Overall Fee Per',
            'contractor_overhead' => 'Contractor Overhead',
            'contractor_fee' => 'Contractor Fee',
            'item_total_cost' => 'Item Total Cost',
            'p_desc' => 'Proposal Desc',
            
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id= $model->project_id; 
        $this->p_name= $model->p_name;
        $this->sub_contractor_total_cost= $model->sub_contractor_total_cost;
        $this->p_total_cost= $model->p_total_cost;
        $this->project_size= $model->project_size;
        //$this->cost_sf= $model->cost_sf;
        $this->cost_per_sf= $model->cost_per_sf;
        $this->estimated_design_duration_days= $model->estimated_design_duration_days;
        $this->item_sub_total= $model->item_sub_total;
        $this->overall_overhead_per= $model->overhead;
        $this->overall_fee_per= $model->fee;
        $this->contractor_overhead= $model->contractor_overhead;
        $this->contractor_fee= $model->contractor_fee;
        $this->item_total_cost= $model->item_total_cost;
        $this->p_desc= $model->p_desc;
        return $this;
    }
}
