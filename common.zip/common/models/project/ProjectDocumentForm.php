<?php

/*
 * To change this license header, choose License Headers in ProjectDocument.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\project;

use yii\base\Model;
use common\models\project\ProjectDocument;

class ProjectDocumentForm extends Model { 

    public $id;
    public $project_id;
    public $file_name;
    public $file_path;
    public $created_by;
    public $updated_by;
    public $is_active;

    public function rules() {

        return [
        
        [['id', 'created_by', 'updated_by'], 'integer'],
        [['is_active', 'created_by', 'updated_by','project_id','file_name','file_path'], 'safe'],
        
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'file_name' => 'File',
            'file_path' => 'File Path',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
        ];
    }

    public function getUpdateModel($model) {
        $this->file_name = $model->file_name;
        return $this;
    }
}