<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\project;

use yii\base\Model;
use common\models\project\Project;
use common\models\itemwork\ItemWork;
class ProjectScheduleManagementForm extends Model {

    public $project_id;
    public $schedule_title;
    public $schedule_start_date;
    public $schedule_end_date;
    public $item_name;
    public $id;

    public function rules() {

        return [
            [['project_id', 'schedule_title', 'schedule_start_date', 'schedule_end_date', 'item_name'], 'required'],
            [['project_id'], 'exist', 'skipOnError' => true, 'targetClass' => Project::className(), 'targetAttribute' => ['project_id' => 'id']],
            [['item_name'], 'exist', 'skipOnError' => true, 'targetClass' => ItemWork::className(), 'targetAttribute' => ['item_name' => 'id']],
        ];
        
    }


    public function attributeLabels()
    {
        return [
            
            'project_id' => 'Project',
            'schedule_title' => 'Schedule Title',
            'schedule_start_date' => 'Schedule Start Date',
            'schedule_end_date' => 'Schedule End Date',
            'item_name' => 'Item Name',
            
        ];
    }

    public function getUpdateModel($model) {
        $this->project_id = $model->project_id;
        $this->schedule_title = $model->schedule_title;
        $this->schedule_start_date = $model->schedule_start_date;
        $this->schedule_end_date = $model->schedule_end_date;
        $this->item_name = $model->item_name;
        $this->id = $model->id;
        return $this;
    }

}
