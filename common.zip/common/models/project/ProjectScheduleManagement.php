<?php

namespace common\models\project;

use Yii;
use common\models\user\User;
use common\models\project\Project;
use common\models\itemwork\ItemWork;

/**
 * This is the model class for table "project_schedule_management".
 *
 * @property int $id
 * @property int $project_id
 * @property string $schedule_title
 * @property string $schedule_start_date
 * @property string $schedule_end_date
 * @property string $item_name
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 * @property User $createdBy
 * @property Project $project
 * @property User $updatedBy 
 */
class ProjectScheduleManagement extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'project_schedule_management';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'schedule_title', 'schedule_start_date', 'schedule_end_date', 'item_name', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['project_id', 'created_by', 'updated_by'], 'integer'],
            [['schedule_start_date', 'schedule_end_date', 'created_date', 'updated_date'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            //[['schedule_title', 'item_name'], 'string', 'max' => 255],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['project_id'], 'exist', 'skipOnError' => true, 'targetClass' => Project::className(), 'targetAttribute' => ['project_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
            [['item_name'], 'exist', 'skipOnError' => true, 'targetClass' => ItemWork::className(), 'targetAttribute' => ['item_name' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'schedule_title' => 'Schedule Title',
            'schedule_start_date' => 'Schedule Start Date',
            'schedule_end_date' => 'Schedule End Date',
            'item_name' => 'Item Name',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getItem()
    {
        return $this->hasOne(ItemWork::className(), ['id' => 'item_name']);
    }
}
