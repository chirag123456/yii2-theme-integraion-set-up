<?php

namespace common\models\project;

use Yii;
use yii\base\Model;


class ProjectProposalItemForm extends Model
{
    
 public $id;
 public $project_id;
 public $project_proposal_id;
 public $item_id;
 public $cost;
 public $cost_sf;
 public $per_total;
 public $comment;
 public $sub_contractor_id;
 public $sub_contractor_estimate_cost;
 public $proposed_spread_per;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'project_proposal_id', 'sub_contractor_id', 'item_id', 'cost', 'cost_sf', 'per_total', 'comment', 'sub_contractor_estimate_cost', 'proposed_spread_per'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'project_proposal_id' => 'Project Proposal',
            'sub_contractor_id' => 'Sub Contractor',
            'item_id' => 'Item Work',
            'cost' => 'Cost',
            'cost_sf' => 'Cost Sf',
            'per_total' => 'Per Total',
            'comment' => 'Comment',
            'sub_contractor_estimate_cost' => 'Sub Contractor Estimate Cost',
            'proposed_spread_per' => 'Proposed Spread Per'
        ];
    }

    public function getUpdateModel($model) {

        $this->project_id= $model->project_id; 
        $this->project_proposal_id= $model->project_proposal_id;
        $this->item_id= $model->item_id;
        $this->sub_contractor_id= $model->sub_contractor_id;
        $this->cost= $model->cost;
        $this->cost_sf= $model->cost_sf;
        $this->per_total= $model->per_total;
        $this->comment= $model->comment;
        $this->sub_contractor_estimate_cost= $model->sub_contractor_estimate_cost;
        $this->proposed_spread_per= $model->proposed_spread_per;
        return $this;
    }
}
