<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\project;

use yii\base\Model;
use common\models\project\Project;

class ProjectForm extends Model {

    public $id;
    public $project_name;
    public $architect_name;
    public $architect_address;
    public $project_cost;
    public $project_size;
    public $project_estimated_days;  
    public $project_number;
    public $project_desc;
    public $date_of_commencement;
    public $date_of_substantial_completion;
    public $date_of_completion;
    public $project_physical_address;
    public $project_state_id;
    public $project_city_id;
    public $project_zipcode;
    public $created_by;
    public $updated_by;
    public $is_active;
    public $landlord_id;
    public $lender_id;
    public $owner_id;
    public $architect_id;
    public $construction_plan_dated;
    public $is_architect_ca;

    public function rules() {

        return [
            [['project_name','project_cost','project_estimated_days', 'project_number','project_size', 'project_desc', 'date_of_commencement', 'date_of_substantial_completion', 'date_of_completion', 'project_physical_address', 'project_state_id', 'project_city_id', 'project_zipcode','architect_id','owner_id','lender_id','landlord_id','construction_plan_dated','is_architect_ca'], 'required'],
            [['id', 'created_by', 'updated_by','project_state_id', 'project_city_id'], 'integer'],
            [['is_active', 'created_by', 'updated_by'], 'safe'],
            ['project_number', 'custom_projectnumber_unique'],
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'owner_id' => 'Owner',
            'landlord_id' => 'Landlord',
            'lender_id' => 'Lender',
            'project_name' => 'Project Name',
            'project_cost' => 'Project Cost',
            'project_size' => 'Project Size',
            'project_estimated_days' => 'Project Estimated Days',
            'project_number' => 'Project Number',
            'project_desc' => 'Project Description',
            'date_of_commencement' => 'Date of Commencement',
            'date_of_substantial_completion' => 'Date of Substantial Completion',
            'date_of_completion' => 'Date of Completion',
            'project_physical_address' => 'Project Physical Address',
            'project_state_id' => 'State Name',
            'project_city_id' => 'City Name',
            'project_zipcode' => 'Zipcode',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'construction_plan_dated' => 'Construction Plans Dated',
            'architect_id' => 'Architect',
            'is_architect_ca' => 'CA ?' 
        ];
    }

    public function getUpdateModel($model) {
        $this->project_name = $model->project_name;
        $this->project_cost=$model->project_cost;
        $this->project_size=$model->project_size;
        $this->project_estimated_days = $model->project_estimated_days;
        $this->project_number = $model->project_number;
        $this->project_desc = $model->project_desc;
        $this->date_of_commencement = $model->date_of_commencement;
        $this->date_of_substantial_completion=$model->date_of_substantial_completion;
        $this->date_of_completion=$model->date_of_completion;
        $this->project_physical_address = $model->project_physical_address;
        $this->project_state_id = $model->project_state_id;
        $this->project_city_id = $model->project_city_id;
        $this->project_zipcode = $model->project_zipcode;
        $this->landlord_id = $model->landlord_id;
        $this->lender_id = $model->lender_id;
        $this->owner_id = $model->owner_id;
        $this->architect_id = $model->architect_id;
        return $this;
    }

    public function custom_projectnumber_unique($attribute, $params) {        
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Project::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->project_number), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Project::find()->where(['project_number' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This project number is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Project::find()->where(['project_number' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This project number is already exist!');
            }
        }
    } 
}