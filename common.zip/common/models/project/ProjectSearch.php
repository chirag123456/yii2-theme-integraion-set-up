<?php

namespace common\models\project;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\project\Project; 

/**
 * ProjectSearch represents the model behind the search form about `common\models\Project`.
 */
class ProjectSearch extends Project {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id', 'created_by', 'updated_by'], 'integer'],
            //[['username', 'contact_number', 'email'], 'string', 'max' => 50],
            [['project_name', 'project_cost', 'project_size', 'project_estimated_days', 'project_number', 'project_desc', 'date_of_commencement', 'date_of_substantial_completion', 'date_of_completion', 'project_physical_address', 'project_state_id', 'project_city_id', 'project_zipcode', 'is_active', 'created_by', 'updated_by'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */

    public function search($params) {
        $query = Project::find()->where(['is_delete' => NOT_DELETED]); //->orderBy(['id' => SORT_DESC]);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), 
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'project_name', $this->project_name])
                ->andFilterWhere(['like', 'project_cost', $this->project_cost])
                ->andFilterWhere(['like', 'project_size', $this->project_size])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'project_estimated_days', $this->project_estimated_days])
                ->andFilterWhere(['like', 'project_number', $this->project_number]);

        return $dataProvider;
    }

    public function search1($params) {
        $query = Project::find()->where(['is_delete' => NOT_DELETED,'is_active' => ACTIVE])->limit(5);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 5, 
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'project_name', $this->project_name])
                ->andFilterWhere(['like', 'project_cost', $this->project_cost])
                ->andFilterWhere(['like', 'project_size', $this->project_size])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'project_estimated_days', $this->project_estimated_days])
                ->andFilterWhere(['like', 'project_number', $this->project_number]);

        return $dataProvider;
        
        return $dataProvider;
    }

    public function searchReport($params) {
        $query = Project::find()->where(['project_management.is_delete' => NOT_DELETED]);  

        if(isset($params['ProjectReportForm']['date_of_commencement']) && !empty(isset($params['ProjectReportForm']['date_of_commencement'])) && $params['ProjectReportForm']['date_of_commencement'] != '')
        {
            $query->andWhere(['project_management.date_of_commencement' => $params['ProjectReportForm']['date_of_commencement']]);
        }

        if(isset($params['ProjectReportForm']['date_of_completion']) && !empty(isset($params['ProjectReportForm']['date_of_completion'])) &&  $params['ProjectReportForm']['date_of_completion'] != '')
        {
            $query->andWhere(['project_management.date_of_completion' => $params['ProjectReportForm']['date_of_completion']]);
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), 
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'project_name', $this->project_name])
                ->andFilterWhere(['like', 'project_cost', $this->project_cost])
                ->andFilterWhere(['like', 'project_size', $this->project_size])
                ->andFilterWhere(['like', 'project_estimated_days', $this->project_estimated_days])
                ->andFilterWhere(['like', 'project_number', $this->project_number]);

        return $dataProvider;
    }

}