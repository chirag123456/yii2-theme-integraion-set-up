<?php
namespace common\models\project;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;

/**
 * ProjectDucument model
 *
 * @property integer $id
 * @property string $project_id
 * @property string $file_name
 * @property string $file_path
 */

class FolderCreate  extends ActiveRecord  {


    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%project_folder}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
      return [
           [['project_id','folder_name','folder_path'], 'required'],
            [['id', 'created_by', 'updated_by'], 'integer'],
            [[ 'is_active', 'created_by', 'updated_by','is_delete'], 'safe'],
        ];
    }
    
    public function attributeLabels()
    {
         return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'file_path' => 'File Path',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
        ];
    }
}