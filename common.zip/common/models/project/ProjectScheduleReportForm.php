<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\project;

use yii\base\Model;
use common\models\project\Project;
use codeonyii\yii2validators\AtLeastValidator;


class ProjectScheduleReportForm extends Model {

    public $id;
    public $project_id;
    public $start_date;
    public $end_date;

    public function rules() {

        return [
            [['project_id', 'start_date','end_date'], AtLeastValidator::className(), 'in' => ['project_id', 'start_date','end_date'], 'min' => 1]

        ];
    }

    

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'start_date' => 'Start Date',
            'end_date' => 'End Date',
        ];
    }

    
}