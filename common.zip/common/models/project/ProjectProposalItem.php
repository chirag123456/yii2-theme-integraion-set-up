<?php

namespace common\models\project;

use Yii;
use yii\base\Model;
use common\models\itemwork\ItemWork;
use common\models\user\User;

/**
 * This is the model class for table "project_proposal_item".
 *
 * @property int $id
 * @property int $project_id
 * @property int $project_proposal_id
 * @property int $sub_contractor_id
 * @property int $item_id
 * @property string $cost
 * @property string $cost_sf
 * @property string $per_total
 * @property string $comment
 * @property string $sub_contractor_estimate_cost
 * @property string $proposed_spread_per
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class ProjectProposalItem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'project_proposal_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'project_proposal_id', 'sub_contractor_id', 'item_id', 'cost', 'cost_sf', 'per_total', 'comment', 'sub_contractor_estimate_cost', 'proposed_spread_per', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['project_id', 'project_proposal_id', 'sub_contractor_id', 'item_id', 'created_by', 'updated_by'], 'integer'],
            [['comment', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date'], 'safe'],
            [['cost', 'cost_sf', 'per_total', 'proposed_spread_per'], 'string', 'max' => 100],
            [['sub_contractor_estimate_cost'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'project_proposal_id' => 'Project Proposal',
            'sub_contractor_id' => 'Sub Contractor',
            'item_id' => 'Item Work Name',
            'cost' => 'Cost',
            'cost_sf' => 'Cost Sf',
            'per_total' => 'Per Total',
            'comment' => 'Comment',
            'sub_contractor_estimate_cost' => 'Sub Contractor Estimate Cost',
            'proposed_spread_per' => 'Proposed Spread Per',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    } 

    /**
    * @return \yii\db\ActiveQuery
    */

    public function getItem()
    {
        return $this->hasOne(ItemWork::className(), ['id' => 'item_id']);
    }

     /**
    * @return \yii\db\ActiveQuery
    */

    public function getSubcontractor()
    {
        return $this->hasOne(User::className(), ['id' => 'sub_contractor_id']);
    }
}
