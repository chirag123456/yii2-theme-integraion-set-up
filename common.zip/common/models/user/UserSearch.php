<?php

namespace common\models\user;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\user\User;
use backend\components\CommonFunctions;

/**
 * UserSearch represents the model behind the search form about `common\models\User`.
 */
class UserSearch extends User {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id', 'created_by', 'updated_by'], 'integer'],
            [['username', 'contact_number', 'email'], 'string', 'max' => 50],
            [['first_name','last_name','email','user_image', 'password', 'confirm_password', 'auth_key', 'password_reset_token', 'username', 'last_login', 'is_active', 'created_date', 'updated_date'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */

    public function search($params) {
        $query = User::find()->where(['is_delete' => NOT_DELETED])->andWhere('id !=' . Yii::$app->user->id)->andWhere(['is_admin' => 'N']);//->orderBy(['id' => SORT_DESC]); 

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            //'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), //$params['per-page'],
     //       'pageSizeLimit' => [1, \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE')],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'email', $this->email])
                ->andFilterWhere(['like', 'contact_number', $this->contact_number])
                ->andFilterWhere(['like', 'password', $this->password])
                ->andFilterWhere(['like', 'auth_key', $this->auth_key])
                ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
                ->andFilterWhere(['like', 'first_name', $this->first_name])
                ->andFilterWhere(['like', 'last_name', $this->last_name])
                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }

    public function searchsubcontractor($params) {
        $role = CommonFunctions::getConfigureValueByKey('SUB_CONTRACTOR_USER_ID');
        $query = User::find()->where(['is_delete' => NOT_DELETED])->andWhere('role =' . $role)->andWhere(['is_admin' => 'N']);//->orderBy(['id' => SORT_DESC]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            //'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), //$params['per-page'],
     //       'pageSizeLimit' => [1, \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE')],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'email', $this->email])
                ->andFilterWhere(['like', 'contact_number', $this->contact_number])
                ->andFilterWhere(['like', 'password', $this->password])
                ->andFilterWhere(['like', 'auth_key', $this->auth_key])
                ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
                ->andFilterWhere(['like', 'first_name', $this->first_name])
                ->andFilterWhere(['like', 'last_name', $this->last_name])
                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }

    public function searcharchitect($params) {
        $role = CommonFunctions::getConfigureValueByKey('ARCHITECTURE_USER_ID');
        $query = User::find()->where(['is_delete' => NOT_DELETED])->andWhere('role =' . $role)->andWhere(['is_admin' => 'N']);//->orderBy(['id' => SORT_DESC]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            //'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), //$params['per-page'],
     //       'pageSizeLimit' => [1, \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE')],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'email', $this->email])
                ->andFilterWhere(['like', 'contact_number', $this->contact_number])
                ->andFilterWhere(['like', 'password', $this->password])
                ->andFilterWhere(['like', 'auth_key', $this->auth_key])
                ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
                ->andFilterWhere(['like', 'first_name', $this->first_name])
                ->andFilterWhere(['like', 'last_name', $this->last_name])
                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }

    public function searchvendor($params) {
        $role = CommonFunctions::getConfigureValueByKey('VENDOR_USER_ID');
        $query = User::find()->where(['is_delete' => NOT_DELETED])->andWhere('role =' . $role)->andWhere(['is_admin' => 'N']);//->orderBy(['id' => SORT_DESC]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            //'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), //$params['per-page'],
     //       'pageSizeLimit' => [1, \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE')],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'email', $this->email])
                ->andFilterWhere(['like', 'contact_number', $this->contact_number])
                ->andFilterWhere(['like', 'password', $this->password])
                ->andFilterWhere(['like', 'auth_key', $this->auth_key])
                ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
                ->andFilterWhere(['like', 'first_name', $this->first_name])
                ->andFilterWhere(['like', 'last_name', $this->last_name])
                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }

    public function search1($params) {
        $query = User::find()->where(['is_delete' => NOT_DELETED])
        ->andWhere('id !=' . Yii::$app->user->id)
        ->andWhere(['is_admin' => 'N'])
        ->limit(5);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => false

        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        return $dataProvider;
    }

    public function searchpwa($params) {
        $query = User::find()->where(['is_delete' => NOT_DELETED])->andWhere('id !=' . Yii::$app->user->id)->andWhere(['is_admin' => 'N','is_pwa' => 'Y']);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), 
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'email', $this->email])
                ->andFilterWhere(['like', 'contact_number', $this->contact_number])
                ->andFilterWhere(['like', 'password', $this->password])
                ->andFilterWhere(['like', 'auth_key', $this->auth_key])
                ->andFilterWhere(['like', 'password_reset_token', $this->password_reset_token])
                ->andFilterWhere(['like', 'first_name', $this->first_name])
                ->andFilterWhere(['like', 'last_name', $this->last_name])
                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }

}