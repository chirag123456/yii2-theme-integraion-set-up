<?php

namespace common\models\user;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface; 
use common\models\userrole\AuthAssignment;
use common\models\state\State;
use common\models\city\City;

/**
 * User model
 *
 * @property integer $id
 * @property string $username
 * @property integer $city_id
 * @property integer $state_id
 * @property string $zipcode
 * @property string $address
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property string $auth_key
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property string $password write-only password
 */
class User  extends ActiveRecord implements IdentityInterface {

    const USER_DELETED = 'N';
    const STATUS_ACTIVE = 'Y';
    const NOT_DELETED = 'N';

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%users}}';
    }

    /**
     * @inheritdoc
     */
//    public function behaviors() {
//        return [
//            TimestampBehavior::className(),
//        ];
//    }

    /**
     * @inheritdoc
     */
    public function rules() {
      return [
            [['email','password', 'auth_key'], 'required'],
            [['id', 'created_by', 'updated_by'], 'integer'],
            [['is_active'], 'string'],
            [['last_login','user_image', 'contact_number','is_active', 'created_by', 'updated_by','username','architect_firm'], 'safe'],            

            //[['created_at', 'is_deleted','updated_at'], 'safe'],
            //[['full_name'], 'string', 'max' => 50],
            [['email'], 'string', 'max' => 100],
            [['password', 'password_reset_token'], 'string', 'max' => 255],
            [['auth_key'], 'string', 'max' => 32],
            [['first_name','last_name','role','state_id','city_id','address','zipcode'],'safe'],            
        ];
    }
    
    public function attributeLabels()
    {
         return [
            'id' => 'ID',
            'username' => 'Username',
            'first_name'=>'First Name',
            'last_name'=>'Last Name',
            'state_id' => 'State',
            'city_id' => 'City',
            'zipcode' => 'Zipcode',
            'address' => 'Address',
            'email' => 'Email',
            'user_image' => 'User Image',
            'password' => 'Password',
            'auth_key' => 'Auth Key',
            'password_reset_token' => 'Password Reset Token',            
            'last_login' => 'Last Login',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'role' => 'Role'
        ];
    }
    /**
     * @inheritdoc
     */
    public static function findIdentity($id) {
        return static::findOne(['id' => $id, 'is_active' => self::STATUS_ACTIVE]);
    }

    /**
     * @inheritdoc
     */
    public static function findIdentityByAccessToken($token, $type = null) {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username) {     
        return static::findOne(['email' => $username, 'is_active' => self::STATUS_ACTIVE,'is_delete' => self::NOT_DELETED]);
    }

    /**
     * Finds user by password reset token
     *
     * @param string $token password reset token
     * @return static|null
     */
    public static function findByPasswordResetToken($token) {
        if (!static::isPasswordResetTokenValid($token)) {
            return null;
        }

        return static::findOne([
            'password_reset_token' => $token,
            'is_active' => self::STATUS_ACTIVE,
        ]);
    }

    /**
     * Finds out if password reset token is valid
     *
     * @param string $token password reset token
     * @return bool
     */
    public static function isPasswordResetTokenValid($token) {
        if (empty($token)) {
            return false;
        }
        $timestamp = (int) substr($token, strrpos($token, '_') + 1);
         
        $expire = Yii::$app->params['user.passwordResetTokenExpire'];
        
        return $timestamp + $expire >= time();
    }

    /**
     * @inheritdoc
     */
    public function getId() {
        return $this->getPrimaryKey();
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey() {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey) {
        return $this->getAuthKey() === $authKey;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password) {
        //return Yii::$app->security->validatePassword($password, $this->password);
        
        if ($this->password != md5($password)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password) {
        $this->password = md5($password);
    }

    /**
     * Generates "remember me" authentication key
     */
    public function generateAuthKey() {
        $this->auth_key = Yii::$app->security->generateRandomString();
    }

    /**
     * Generates new password reset token
     */
    public function generatePasswordResetToken() {
        $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
    }

    /**
     * Removes password reset token
     */
    public function removePasswordResetToken() {
        $this->password_reset_token = null;
    }

    public function getRolename()
    {
        return $this->hasOne(AuthAssignment::className(), ['user_id' => 'id']);
    }

    public function upload($filename)
    {
        $user_imagepath=\backend\components\CommonFunctions::getConfigureValueByKey('USER_IMAGE_PATH');       
        
        if ($this->validate()) {
            if($this->user_image->saveAs('../'.$user_imagepath.'/'.$filename . '.' . $this->user_image->extension,false)){
                $this->user_image=$filename.'.' . $this->user_image->extension;
                return true;
            }else{
                return false;
            }
        } else {            
            return false;
        }
        
        // echo $SoundPath.date('YmdHis').'.'.$this->sound_file_name->extension;
        // exit;
    }

    public function getState()
    {
        return $this->hasOne(State::className(), ['id' => 'state_id']);
    }

    public function getCity()
    {
        return $this->hasOne(City::className(), ['id' => 'city_id']);
    }
    
}