<?php
 
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\user;

use yii\base\Model;
use common\models\user\User;

class UserForm extends Model {

    public $id;
    public $username;
    public $first_name;
    public $last_name;
    public $city_id;
    public $state_id;
    public $zipcode;
    public $address;
    public $user_image;
    public $email;   
    public $password;
    public $confirm_password;
    public $contact_number;
    public $image_path;
    public $user_id;
    public $updated_by;
    public $updated_date;
    public $role;
    public $architect_firm;

    public function rules() {

        return [
        [['email', 'contact_number','user_image','first_name','last_name','role','state_id','city_id','zipcode','address'], 'required'],
        [['contact_number'], 'number', 'message' => "Number should be integer."],
        ['email', 'email', 'message' => 'Please enter valid email address '],
        [['id'], 'integer'],
        [['id','username','architect_firm'], 'safe'],
        [['username'],'string','max'=>30],
        ['contact_number', 'number', 'message' => 'Contact Number is Invalid.'],
        [['password', 'confirm_password'], 'string', 'min' => 6,'max'=>25],
        [['password', 'confirm_password'], 'required'],
        ['confirm_password', 'compare', 'compareAttribute' => 'password', 'message' => "Password and Confirm Password must be same"],
        ['email', 'custom_email_unique'],
        ['contact_number', 'custom_contactnumber_unique'],
        
        
        ];
    }

//This Function Use Unique Email Id
    public function custom_email_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = User::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->email), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = User::find()->where(['email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This email is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = User::find()->where(['email' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This email is already exist!');
            }
        }
    }

// This Function use for Unique Username

public function custom_username_unique($attribute, $params) {        
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = User::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->username), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = User::find()->where(['username' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This username is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = User::find()->where(['username' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This username is already exist!');
            }
        }
    } 

public function custom_contactnumber_unique($attribute, $params) {        
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = User::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->contact_number), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = User::find()->where(['contact_number' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This contact number is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = User::find()->where(['contact_number' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This contact number is already exist!');
            }
        }
    } 



   //This Function Use Validate Password
    public function validatePassword($attribute, $params) {
        $user = $this->getUser($this->user_id);
        if (!$user || !$user->validatePassword($this->password)) {
            $this->addError($attribute, 'Incorrect password.');
        }
    }


    public function attributeLabels() {
        return [
            'id' => 'ID',
            'username' => 'User Name',
            'first_name'=>'First Name',
            'last_name'=>'Last Name',
            'email' => 'Email',
            'user_image' => 'User Image',
            'password' => 'Password',
            'auth_key' => 'Auth Key',
            'password_reset_token' => 'Password Reset Token',
            'contact_number' => 'Contact Number',
            'last_login' => 'Last Login',
            'is_active' => 'Is Active',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'role' => 'Role',
            'state_id'=>'State',
            'city_id' => 'City',
            'address' => 'Address',
            'zipcode' => 'Zipcode',
            'architect_firm' => 'Architect Firm'
        ];
    }

    public function getUpdateModel($model) {
        $this->email = $model->email;
        $this->user_image = $model->user_image;
        $this->username = $model->username;
        $this->first_name=$model->first_name;
        $this->last_name=$model->last_name;
        $this->latlong=$model->latlong;
        $this->contact_number = $model->contact_number;
        $this->password = $model->password;
        $this->confirm_password = $model->password;
        $this->role = $model->role;
        $this->state_id = $model->state_id;
        $this->city_id = $model->city_id;
        $this->address = $model->address;
        $this->zipcode = $model->zipcode;
        $this->architect_firm = $model->architect_firm;
        return $this;
    }

   //This Function User Send Email
    public function sendEmail() { /* @var $user User */
        $user = User::findOne([
                'is_active' => User::STATUS_ACTIVE,
                'email' => $this->email,
        ]);

        if (!$user) {
            return false;
        }
        if (!User::isPasswordResetTokenValid($user->password_reset_token)) {

            $user->generatePasswordResetToken();
            if (!$user->save()) {
                return false;
            }
        }
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'passwordResetToken-html', 'text' => 'passwordResetToken-text'], ['user' => $user]
                        )
                        ->setFrom('developer.livewitness@gmail.com')
                        ->setTo($this->email)
                        ->setSubject('Password reset for ' . Yii::$app->username)
                        ->send();
    }

}
