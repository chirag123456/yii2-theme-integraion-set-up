<?php

namespace common\models\lender;

use Yii;
use common\models\city\City;
use common\models\state\State;
use common\models\user\User;
 
/**
 * This is the model class for table "lender".
 *
 * @property int $id
 * @property string $lender_or_bank_contact_person
 * @property string $lender_email
 * @property string $lender_phone
 * @property string $bank_require_special_documentation_for_billing_project_closeout
 * @property string $lender_special_documentation_list_requirements
 * @property string $lender_address
 * @property int $lender_state_id
 * @property int $lender_city_id
 * @property string $lender_zipcode
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 * @property City $lenderCity
 * @property User $createdBy
 * @property State $lenderState
 * @property Users $updatedBy
 */
class Lender extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'lender';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['lender_or_bank_contact_person', 'lender_email', 'lender_phone', 'bank_require_special_documentation_for_billing_project_closeout', 'lender_special_documentation_list_requirements', 'lender_address', 'lender_state_id', 'lender_city_id', 'lender_zipcode', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['bank_require_special_documentation_for_billing_project_closeout', 'lender_special_documentation_list_requirements', 'lender_address', 'is_active', 'is_delete'], 'string'],
            [['lender_state_id', 'lender_city_id', 'created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['lender_or_bank_contact_person', 'lender_email', 'lender_phone', 'lender_zipcode'], 'string', 'max' => 255],
            [['lender_city_id'], 'exist', 'skipOnError' => true, 'targetClass' => City::className(), 'targetAttribute' => ['lender_city_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['lender_state_id'], 'exist', 'skipOnError' => true, 'targetClass' => State::className(), 'targetAttribute' => ['lender_state_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'lender_or_bank_contact_person' => 'Lender Or Bank Contact Person',
            'lender_email' => 'Lender Email',
            'lender_phone' => 'Lender Phone',
            'bank_require_special_documentation_for_billing_project_closeout' => 'Bank Require Special Documentation For Billing Project Closeout',
            'lender_special_documentation_list_requirements' => 'Lender Special Documentation List Requirements',
            'lender_address' => 'Lender Address',
            'lender_state_id' => 'Lender State',
            'lender_city_id' => 'Lender City',
            'lender_zipcode' => 'Lender Zipcode',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['id' => 'lender_city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getState()
    {
        return $this->hasOne(State::className(), ['id' => 'lender_state_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }
}
