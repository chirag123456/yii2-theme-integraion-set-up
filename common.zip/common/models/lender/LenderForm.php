<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\lender; 

use yii\base\Model;
use common\models\lender\Lender;
use common\models\city\City;
use common\models\state\State;

class LenderForm extends Model {

    public $id;
    public $lender_or_bank_contact_person;
    public $lender_email;
    public $lender_phone;
    public $bank_require_special_documentation_for_billing_project_closeout;
    public $lender_special_documentation_list_requirements;
    public $lender_address;
    public $lender_state_id;
    public $lender_city_id;
    public $lender_zipcode; 

    public function rules() {

        return [
            [['lender_or_bank_contact_person', 'lender_email', 'lender_phone', 'bank_require_special_documentation_for_billing_project_closeout', 'lender_special_documentation_list_requirements', 'lender_address', 'lender_state_id','lender_city_id', 'lender_zipcode'], 'required'],            
            [['lender_state_id', 'lender_city_id'], 'integer'],            
            [['lender_or_bank_contact_person', 'lender_email'], 'string', 'max' => 255],
            [['lender_city_id'], 'exist', 'skipOnError' => true, 'targetClass' => City::className(), 'targetAttribute' => ['lender_city_id' => 'id']],            
            [['lender_state_id'], 'exist', 'skipOnError' => true, 'targetClass' => State::className(), 'targetAttribute' => ['lender_state_id' => 'id']],  
            ['lender_email', 'custom_lender_email_unique'], 
            ['lender_email', 'email', 'message' => 'Please enter valid lender email address '] ,        
            ['lender_phone', 'number', 'message' => 'Lender Phone Number is Invalid.'],
        ];
    }

    public function getUpdateModel($model) { 

        $this->lender_or_bank_contact_person = $model->lender_or_bank_contact_person;
        $this->lender_email = $model->lender_email;
        $this->lender_phone = $model->lender_phone;
        $this->lender_special_documentation_list_requirements = $model->lender_special_documentation_list_requirements;
        $this->lender_address = $model->lender_address;
        $this->lender_zipcode = $model->lender_zipcode;
        $this->bank_require_special_documentation_for_billing_project_closeout = $model->bank_require_special_documentation_for_billing_project_closeout;
        $this->lender_city_id = isset($model->lender_city_id) ? $model->lender_city_id : 'N\A';
        $this->lender_state_id = isset($model->lender_state_id) ? $model->lender_state_id : 'N\A';

        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'lender_or_bank_contact_person' => 'Lender Or Bank Contact Person',
            'lender_email' => 'Lender Email',
            'lender_phone' => 'Lender Phone',
            'bank_require_special_documentation_for_billing_project_closeout' => 'Bank Require Special Documentation For Billing Project Closeout',
            'lender_special_documentation_list_requirements' => 'Lender Special Documentation List Requirements',
            'lender_address' => 'Lender Address',
            'lender_state_id' => 'Lender State',
            'lender_city_id' => 'Lender City',
            'lender_zipcode' => 'Lender Zipcode'
        ];
    }

    public function custom_lender_email_unique($attribute, $params) {

        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Lender::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->lender_email), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Lender::find()->where(['lender_email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Lender Email is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Lender::find()->where(['lender_email' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Lender Email is already exist!');
            }
        }
    }

}
