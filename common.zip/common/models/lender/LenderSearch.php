<?php

namespace common\models\lender;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\lender\Lender;

/**
 * LenderSearch represents the model behind the search form of `common\models\Lender`.
 */
class LenderSearch extends Lender
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'lender_state_id', 'lender_city_id', 'created_by', 'updated_by'], 'integer'],
            [['lender_or_bank_contact_person', 'lender_email', 'lender_phone', 'bank_require_special_documentation_for_billing_project_closeout', 'lender_special_documentation_list_requirements', 'lender_address', 'lender_zipcode', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Lender::find()->where(['is_delete' => NOT_DELETED]);

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            //'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'), //$params['per-page'],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'lender_state_id' => $this->lender_state_id,
            'lender_city_id' => $this->lender_city_id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'lender_or_bank_contact_person', $this->lender_or_bank_contact_person])
            ->andFilterWhere(['like', 'lender_email', $this->lender_email])
            ->andFilterWhere(['like', 'lender_phone', $this->lender_phone])
            ->andFilterWhere(['like', 'bank_require_special_documentation_for_billing_project_closeout', $this->bank_require_special_documentation_for_billing_project_closeout])
            ->andFilterWhere(['like', 'lender_special_documentation_list_requirements', $this->lender_special_documentation_list_requirements])
            ->andFilterWhere(['like', 'lender_address', $this->lender_address])
            ->andFilterWhere(['like', 'lender_zipcode', $this->lender_zipcode])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }
}
