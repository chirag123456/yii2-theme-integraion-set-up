<?php

namespace common\models\taskallocation;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\taskallocation\TaskAllocation;

/**
 * TaskAllocationSearch represents the model behind the search form of `common\models\TaskAllocation`.
 */
class TaskAllocationSearch extends TaskAllocation
{ 
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'role_id', 'created_by', 'updated_by'], 'integer'],
            [['project_id','task_name','user_id', 'priority', 'description', 'task_status' ,'start_date', 'due_date', 'is_active', 'is_delete', 'created_date', 'updated_date'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = TaskAllocation::find()->where(['task_allocation.is_delete' => NOT_DELETED]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);
        $dataProvider->sort->attributes['user_id'] = [
            'asc' => ['users.email' => SORT_ASC],
            'desc' => ['users.email' => SORT_DESC],
        ];

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['user','project']);
        // grid filtering conditions
        $query->andFilterWhere([
            //'id' => $this->id,
            //'project_id' => $this->project_id,
            //'user_id' => $this->user_id,
            'role_id' => $this->role_id,
            'start_date' => $this->start_date,
            'due_date' => $this->due_date,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'task_name', $this->task_name])
            ->andFilterWhere(['like', 'task_allocation.id', $this->id])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'priority', $this->priority])
            ->andFilterWhere(['like', 'users.email', $this->user_id])
            ->andFilterWhere(['like', 'task_status', $this->task_status])
            ->andFilterWhere(['like', 'description', $this->description])
            ->andFilterWhere(['like', 'task_allocation.is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

    public function search1($params)
    {
        $query = TaskAllocation::find()->where(['task_allocation.is_delete' => NOT_DELETED]);

        if(isset($params['TaskAllocationReportForm']['project_id']) && !empty(isset($params['TaskAllocationReportForm']['project_id'])) && $params['TaskAllocationReportForm']['project_id'] != '')
        {
            $query->andWhere(['task_allocation.project_id' => $params['TaskAllocationReportForm']['project_id']]);
        }
        if(isset($params['TaskAllocationReportForm']['priority']) && !empty(isset($params['TaskAllocationReportForm']['priority'])) &&  $params['TaskAllocationReportForm']['priority'] != '')
        {
            $query->andWhere(['task_allocation.priority' => $params['TaskAllocationReportForm']['priority']]);
        }
        if(isset($params['TaskAllocationReportForm']['task_status']) && !empty(isset($params['TaskAllocationReportForm']['task_status'])) && $params['TaskAllocationReportForm']['task_status'] != '')
        {
            $query->andWhere(['task_allocation.task_status' => $params['TaskAllocationReportForm']['task_status']]);
        }
        if(isset($params['TaskAllocationReportForm']['role_id']) && !empty(isset($params['TaskAllocationReportForm']['role_id'])) && $params['TaskAllocationReportForm']['role_id'] != '')
        {
            $query->andWhere(['task_allocation.role_id' => $params['TaskAllocationReportForm']['role_id']]);
        }
        if(isset($params['TaskAllocationReportForm']['user_id']) && !empty(isset($params['TaskAllocationReportForm']['user_id'])) && $params['TaskAllocationReportForm']['user_id'] != '')
        {
            $query->andWhere(['task_allocation.user_id' => $params['TaskAllocationReportForm']['user_id']]);
        }
        if(isset($params['TaskAllocationReportForm']['start_date']) && !empty(isset($params['TaskAllocationReportForm']['start_date'])) && $params['TaskAllocationReportForm']['start_date'] = '')
        {
            $query->andWhere(['task_allocation.start_date' => $params['TaskAllocationReportForm']['start_date']]);
        }
        if(isset($params['TaskAllocationReportForm']['due_date']) && !empty(isset($params['TaskAllocationReportForm']['due_date'])) && $params['TaskAllocationReportForm']['due_date'] != '')
        {
            $query->andWhere(['task_allocation.due_date' => $params['TaskAllocationReportForm']['due_date']]);
        }

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);
        $dataProvider->sort->attributes['user_id'] = [
            'asc' => ['users.email' => SORT_ASC],
            'desc' => ['users.email' => SORT_DESC],
        ];
        
        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['user']);
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'project_id' => $this->project_id,
            'user_id' => $this->user_id,
            'role_id' => $this->role_id,
            'start_date' => $this->start_date,
            'due_date' => $this->due_date,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'task_name', $this->task_name])
            ->andFilterWhere(['like', 'priority', $this->priority])
            ->andFilterWhere(['like', 'users.email', $this->user_id])
            ->andFilterWhere(['like', 'task_status', $this->task_status])
            ->andFilterWhere(['like', 'description', $this->description])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }
    public function search2($params)
    {
        $query = TaskAllocation::find()->where(['task_allocation.is_delete' => NOT_DELETED]);

        if(isset($params['project_id']) && !empty(($params['project_id'])) && $params['project_id'] != '')
        {
            $query->andWhere(['task_allocation.project_id' => $params['project_id']]);
        }
        if(isset($params['priority']) && !empty(($params['priority'])) &&  $params['priority'] != '')
        {
            $query->andWhere(['task_allocation.priority' => $params['priority']]);
        }
        if(isset($params['task_status']) && !empty(($params['task_status'])) && $params['task_status'] != '')
        {
            $query->andWhere(['task_allocation.task_status' => $params['task_status']]);
        }
        if(isset($params['role_id']) && !empty(($params['role_id'])) && $params['role_id'] != '')
        {
            $query->andWhere(['task_allocation.role_id' => $params['role_id']]);
        }
        if(isset($params['user_id']) && !empty(($params['user_id'])) && $params['user_id'] != '')
        {
            $query->andWhere(['task_allocation.user_id' => $params['user_id']]);
        }
        if(isset($params['start_date']) && !empty(($params['start_date'])) && $params['start_date'] = '')
        {
            $query->andWhere(['task_allocation.start_date' => $params['start_date']]);
        }
        if(isset($params['due_date']) && !empty(isset($params['due_date'])) && $params['due_date'] != '')
        {
            $query->andWhere(['task_allocation.due_date' => $params['due_date']]);
        }
        return $query->joinWith(['user'])->all();    
    }
}
