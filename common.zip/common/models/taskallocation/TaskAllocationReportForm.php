<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\taskallocation;  

use yii\base\Model;
use common\models\taskallocation\TaskAllocation;
use codeonyii\yii2validators\AtLeastValidator;

class TaskAllocationReportForm extends Model {

   public $id;
   public $project_id; 
   public $priority;
   public $user_id;
   public $role_id;
   public $task_status;
   public $start_date;
   public $due_date;
 
    public function rules() {
        return [
            
            [['project_id', 'priority', 'user_id', 'role_id','task_status','start_date','due_date'], AtLeastValidator::className(), 'in' => ['project_id', 'priority', 'user_id', 'role_id','task_status','start_date','due_date'], 'min' => 1]
        ];
    } 

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',            
            'priority' => 'Priority',
            'user_id' => 'User',
            'role_id' => 'User Type',
            'task_status' => 'Task Status',
            'start_date' => 'Start Date',
            'due_date' => 'Due Date',
        ];
    }
}