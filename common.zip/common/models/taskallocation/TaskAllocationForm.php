<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\taskallocation;

use yii\base\Model;
use common\models\taskallocation\TaskAllocation;

class TaskAllocationForm extends Model {

   public $id;
   public $project_id; 
   public $task_name;
   public $priority;
   public $user_id;
   public $role_id;
   public $task_status;
   public $description;
   public $start_date;
   public $due_date;
   public $is_active;
   public $is_delete;
 
    public function rules() {

        return [
            [['project_id', 'task_name', 'priority', 'user_id', 'role_id','task_status', 'description', 'start_date', 'due_date'], 'required'],
            [['project_id', 'created_by', 'updated_by'], 'integer'],
            [['task_name', 'description', 'is_active', 'is_delete'], 'string'],
            [['start_date', 'due_date', 'created_date', 'updated_date'], 'safe'],
            [['priority'], 'string', 'max' => 255],            
        ];
    }

    public function getUpdateModel($model) {

      $this->project_id = $model->project_id;
      $this->task_name = isset($model->task_name) ? $model->task_name : 'N\A';
      $this->priority = isset($model->priority) ? $model->priority : 'N\A';
      $this->user_id = $model->user_id;
      $this->role_id = $model->role_id;
      $this->task_status = $model->task_status;
      $this->start_date = $model->start_date;
      $this->due_date = $model->due_date;
      $this->description = $model->description;
        return $this;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'task_name' => 'Task Name',
            'priority' => 'Priority',
            'user_id' => 'User',
            'role_id' => 'User Type',
            'task_status' => 'Task Status',
            'description' => 'Description',
            'start_date' => 'Start Date',
            'due_date' => 'Due Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Created Date',
            'updated_date' => 'Updated Date',
        ];
    }
}