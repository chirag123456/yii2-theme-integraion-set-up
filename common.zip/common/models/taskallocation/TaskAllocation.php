<?php

namespace common\models\taskallocation;

use Yii;
use common\models\project\Project;
use common\models\user\User;
use common\models\userrole\UserAccess;

/**
 * This is the model class for table "task_allocation".
 *
 * @property integer $id
 * @property integer $project_id
 * @property string $task_name
 * @property string $priority
 * @property integer $user_id
 * @property integer $role_id
 * @property string $description
 * @property string $start_date
 * @property string $due_date
 * @property string $is_active
 * @property string $is_delete
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $created_date
 * @property string $updated_date
 */
class TaskAllocation extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'task_allocation';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id', 'task_name', 'priority', 'role_id', 'user_id', 'task_status', 'description', 'start_date', 'due_date'], 'required'],
            [['project_id', 'created_by', 'updated_by'], 'integer'],
            [['task_name', 'description', 'is_active', 'is_delete'], 'string'],
            [['start_date', 'due_date', 'created_date', 'updated_date'], 'safe'],
            [['priority'], 'string', 'max' => 255],
            
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project Name',
            'task_name' => 'Task Name',
            'priority' => 'Priority',
            'role_id' => 'User Type',
            'user_id' => 'User',
            'description' => 'Description',
            'start_date' => 'Start Date',
            'due_date' => 'Due Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Created Date',
            'updated_date' => 'Updated Date',
        ];
    }

    /**
    * @return \yii\db\ActiveQuery
    */
    public function getProject() 
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
    * @return \yii\db\ActiveQuery
    */
    public function getRole()
    {
        return $this->hasOne(UserAccess::className(), ['id' => 'role_id']);
    }

    /**
     * Sends an email with a link, for resetting the password.
     *
     * @return bool whether the email was send
     */
    public function sendTaskEmail($data) { /* @var $user User */ 
        $from = $this->getConfigureValueByKey('EMAIL_FROM');   
        return Yii::$app 
                        ->mailer
                        ->compose(
                                ['html' => 'task-html', 'text' => 'task-text'], ['data' => $data]
                        )
                        ->setFrom($from)                       
                        ->setTo($data['user'])
                        ->setSubject('Couch Construction Services | Task Detail')
                        ->send();
    }

    public function getConfigureValueByKey($key) {

        $model = \common\models\siteconfiguration\SiteConfiguration::findOne(['config_key' => $key]);        
        if ($model != null) {
            return $model->config_value;
        } else {
            return 'Undefine Key';
        }
    }
}