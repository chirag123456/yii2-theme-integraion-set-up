<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\siteconfiguration;

use yii\base\Model;
use common\models\siteconfiguration\SiteConfiguration;

class SiteConfigurationForm extends Model {

    public $config_key;
    public $config_value;

    public function rules() {

        return [
            [['config_key', 'config_value'], 'required'],
            [['config_key'], 'custom_config_key_unique'],
            [['config_key', 'config_value'], 'string', 'min' => 1, 'max' => 255],
        ];
    }

    public function getUpdateModel($model) {

        $this->config_key = $model->config_key;
        $this->config_value = $model->config_value;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'config_key' => 'Key',
            'config_value' => 'Value',
        ];
    }

   //This Function Use Unique Config Key
    public function custom_config_key_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = SiteConfiguration::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->config_key), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {

                    $check = SiteConfiguration::find()->where(['config_key' => trim($this->$attribute)])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Key' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = SiteConfiguration::find()->where(['config_key' => trim($this->$attribute)])->one();
            if ($check) {
                $this->addError($attribute, 'This Key' . ALREADY);
            }
        }
    }

}
