<?php

namespace common\models\siteconfiguration;

use Yii;

/**
 * This is the model class for table "site_configuration".
 *
 * @property integer $id
 * @property string $config_key
 * @property string $config_value
 * @property integer $created_by
 * @property string $created_date
 * @property integer $updated_by
 * @property string $updated_date
 * @property string $is_active
 *
 * @property AdminUser $createdBy
 * @property AdminUser $updatedBy
 */
class SiteConfiguration extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'site_configuration';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['config_key', 'config_value'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['is_active'], 'string'],
            [['config_key', 'config_value'], 'string', 'max' => 255],
          
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'config_key' => 'Config Key',
            'config_value' => 'Config Value',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy() {
        return $this->hasOne(AdminUser::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy() {
        return $this->hasOne(AdminUser::className(), ['id' => 'updated_by']);
    }

}
