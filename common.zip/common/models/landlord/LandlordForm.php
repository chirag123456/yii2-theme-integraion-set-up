<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\landlord;

use yii\base\Model;
use common\models\city\City;
use common\models\state\State;
use common\models\user\User;
use common\models\landlord\Landlord;


class LandlordForm extends Model {

    public $landlord_address;
    public $landlord_state_id;
    public $landlord_city_id;
    public $id;
    public $landlord_contact_person;
    public $landlord_email;
	public $landlord_phone;
	public $will_landlord_require_special_documentation_for_billing;
	public $if_special_documentation_required_if_yes_list;
    public $landlord_zipcode;
	

    public function rules() {
        return [
        [['landlord_address', 'landlord_state_id', 'landlord_city_id', 'landlord_zipcode', 'landlord_contact_person', 'landlord_email', 'landlord_phone', 'will_landlord_require_special_documentation_for_billing',], 'required'], 
            
        [['landlord_state_id', 'landlord_city_id'], 'integer'],
		[['if_special_documentation_required_if_yes_list'], 'safe'],
        [['landlord_city_id'], 'exist', 'skipOnError' => true, 'targetClass' => City::className(), 'targetAttribute' => ['landlord_city_id' => 'id']],
        
        [['landlord_state_id'], 'exist', 'skipOnError' => true, 'targetClass' => State::className(), 'targetAttribute' => ['landlord_state_id' => 'id']],
        ['landlord_email', 'custom_landlord_email_unique'],
        ['landlord_email', 'email', 'message' => 'Please enter valid landlord email address '], 
        ['landlord_phone', 'number', 'message' => 'Landlord Phone Number is Invalid.'],
        ];
    }

    public function getUpdateModel($model) {

        $this->landlord_address = $model->landlord_address;
        $this->landlord_state_id = isset($model->landlord_state_id) ? $model->landlord_state_id : 'N\A';
        $this->landlord_city_id = isset($model->landlord_city_id) ? $model->landlord_city_id : 'N\A';
        $this->if_special_documentation_required_if_yes_list = isset($model->if_special_documentation_required_if_yes_list) ? $model->if_special_documentation_required_if_yes_list : 'N\A';
		$this->landlord_contact_person = $model->landlord_contact_person;
		$this->landlord_email = $model->landlord_email;
		$this->landlord_phone = $model->landlord_phone;
        $this->landlord_zipcode = $model->landlord_zipcode;
		$this->will_landlord_require_special_documentation_for_billing = $model->will_landlord_require_special_documentation_for_billing;

        return $this;
    }
 
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'landlord_address' => 'Landlord Address',
            'landlord_state_id' => 'Landlord State',
            'landlord_city_id' => 'Landlord City',
            'landlord_zipcode' => 'Landlord Zipcode',
            'landlord_contact_person' => 'Landlord Contact Person',
            'landlord_email' => 'Landlord Email',
            'landlord_phone' => 'Landlord Phone',
            'will_landlord_require_special_documentation_for_billing' => 'Will Landlord Require Special Documentation For Billing',
            'if_special_documentation_required_if_yes_list' => 'If Special Documentation Required If Yes List',
        ];
    }

    public function custom_landlord_email_unique($attribute, $params) {        
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = Landlord::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->landlord_email), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Landlord::find()->where(['landlord_email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Landlord email is already exist!');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Landlord::find()->where(['landlord_email' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Landlord email is already exist!');
            }
        }
    }
}
