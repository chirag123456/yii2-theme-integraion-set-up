<?php

namespace common\models\landlord;

use Yii;
use common\models\city\City;
use common\models\state\State;
use common\models\user\User;

/**
 * This is the model class for table "landlord".
 *
 * @property int $id
 * @property string $landlord_address
 * @property int $landlord_state_id
 * @property int $landlord_city_id
 * @property string $landlord_zipcode
 * @property string $landlord_contact_person
 * @property string $landlord_email
 * @property string $landlord_phone
 * @property string $will_landlord_require_special_documentation_for_billing
 * @property string $if_special_documentation_required_if_yes_list
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 * @property City $landlordCity
 * @property User $createdBy
 * @property State $landlordState
 * @property User $updatedBy
 */
class Landlord extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'landlord';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['landlord_address', 'landlord_state_id', 'landlord_city_id', 'landlord_zipcode', 'landlord_contact_person', 'landlord_email', 'landlord_phone', 'will_landlord_require_special_documentation_for_billing', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['landlord_address', 'will_landlord_require_special_documentation_for_billing', 'if_special_documentation_required_if_yes_list', 'is_active', 'is_delete'], 'string'],
            [['landlord_state_id', 'landlord_city_id', 'created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date'], 'safe'],
            [['landlord_zipcode'], 'string', 'max' => 100],
            [['landlord_contact_person', 'landlord_email'], 'string', 'max' => 255],
            [['landlord_phone'], 'string', 'max' => 50],
            [['landlord_city_id'], 'exist', 'skipOnError' => true, 'targetClass' => City::className(), 'targetAttribute' => ['landlord_city_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['landlord_state_id'], 'exist', 'skipOnError' => true, 'targetClass' => State::className(), 'targetAttribute' => ['landlord_state_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'landlord_address' => 'Landlord Address',
            'landlord_state_id' => 'Landlord State',
            'landlord_city_id' => 'Landlord City',
            'landlord_zipcode' => 'Landlord Zipcode',
            'landlord_contact_person' => 'Landlord Contact Person',
            'landlord_email' => 'Landlord Email',
            'landlord_phone' => 'Landlord Phone',
            'will_landlord_require_special_documentation_for_billing' => 'Will Landlord Require Special Documentation For Billing',
            'if_special_documentation_required_if_yes_list' => 'If Special Documentation Required If Yes List',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCity()
    {
        return $this->hasOne(City::className(), ['id' => 'landlord_city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getState()
    {
        return $this->hasOne(State::className(), ['id' => 'landlord_state_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }
}
