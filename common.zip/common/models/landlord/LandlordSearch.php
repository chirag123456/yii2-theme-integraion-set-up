<?php

namespace common\models\landlord;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\landlord\Landlord;

/**
 * LandlordSearch represents the model behind the search form of `common\models\Landlord`.
 */
class LandlordSearch extends Landlord
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'landlord_state_id', 'landlord_city_id', 'created_by', 'updated_by'], 'integer'],
            [['landlord_address', 'landlord_zipcode', 'landlord_contact_person', 'landlord_email', 'landlord_phone', 'will_landlord_require_special_documentation_for_billing', 'if_special_documentation_required_if_yes_list', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Landlord::find()->where(['is_delete' => NOT_DELETED]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'landlord_state_id' => $this->landlord_state_id,
            'landlord_city_id' => $this->landlord_city_id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'landlord_address', $this->landlord_address])
            ->andFilterWhere(['like', 'landlord_zipcode', $this->landlord_zipcode])
            ->andFilterWhere(['like', 'landlord_contact_person', $this->landlord_contact_person])
            ->andFilterWhere(['like', 'landlord_email', $this->landlord_email])
            ->andFilterWhere(['like', 'landlord_phone', $this->landlord_phone])
            ->andFilterWhere(['like', 'will_landlord_require_special_documentation_for_billing', $this->will_landlord_require_special_documentation_for_billing])
            ->andFilterWhere(['like', 'if_special_documentation_required_if_yes_list', $this->if_special_documentation_required_if_yes_list])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }
}
