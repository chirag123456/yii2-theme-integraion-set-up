<?php

namespace common\models\submittal;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\submittal\Submittal;

/**
 * SubmittalSearch represents the model behind the search form of `common\models\Submittal`.
 */
class SubmittalSearch extends Submittal
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id','project_id','date', 'to_user_id', 're', 'email', 'phone', 'from_user_id', 'attention', 'review_date_of_resubmittal', 'under_separate_cover', 'under_separate_cover_via', 'shop_drawings', 'prints', 'plans', 'samples', 'specifications', 'copy_of_letter', 'change_order', 'other', 'for_approval', 'approved_as_submitted', 'resubmit', 'copies_for_approval', 'for_your_use', 'approved_as_noted', 'submit', 'copies_for_distribution', 'as_requested', 'returned_for_corrections', 'return', 'corrected_prints', 'review_comment', 'for_bids_due', 'remarks', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_delete','is_active'], 'safe'],            
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Submittal::find()->where(['submittal.is_delete' => NOT_DELETED]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);
        $query->joinWith(['project']);
        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->joinWith(['project']);

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'date' => $this->date,
            'to_user_id' => $this->to_user_id,
            'from_user_id' => $this->from_user_id,
            'review_date_of_resubmittal' => $this->review_date_of_resubmittal,
            'for_approval' => $this->for_approval,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);
 
        $query->andFilterWhere(['like', 're', $this->re])
            ->andFilterWhere(['like', 'email', $this->email])
            ->andFilterWhere(['like', 'project_management.project_name', $this->project_id])
            ->andFilterWhere(['like', 'phone', $this->phone])
            ->andFilterWhere(['like', 'attention', $this->attention])
            ->andFilterWhere(['like', 'attached_img', $this->attached_img])
            ->andFilterWhere(['like', 'under_separate_cover', $this->under_separate_cover])
            ->andFilterWhere(['like', 'under_separate_cover_via', $this->under_separate_cover_via])
            ->andFilterWhere(['like', 'shop_drawings', $this->shop_drawings])
            ->andFilterWhere(['like', 'prints', $this->prints])
            ->andFilterWhere(['like', 'plans', $this->plans])
            ->andFilterWhere(['like', 'samples', $this->samples])
            ->andFilterWhere(['like', 'specifications', $this->specifications])
            ->andFilterWhere(['like', 'copy_of_letter', $this->copy_of_letter])
            ->andFilterWhere(['like', 'change_order', $this->change_order])
            ->andFilterWhere(['like', 'other', $this->other])
            ->andFilterWhere(['like', 'approved_as_submitted', $this->approved_as_submitted])
            ->andFilterWhere(['like', 'resubmit', $this->resubmit])
            ->andFilterWhere(['like', 'copies_for_approval', $this->copies_for_approval])
            ->andFilterWhere(['like', 'for_your_use', $this->for_your_use])
            ->andFilterWhere(['like', 'approved_as_noted', $this->approved_as_noted])
            ->andFilterWhere(['like', 'submit', $this->submit])
            ->andFilterWhere(['like', 'copies_for_distribution', $this->copies_for_distribution])
            ->andFilterWhere(['like', 'as_requested', $this->as_requested])
            ->andFilterWhere(['like', 'returned_for_corrections', $this->returned_for_corrections])
            ->andFilterWhere(['like', 'return', $this->return])
            ->andFilterWhere(['like', 'corrected_prints', $this->corrected_prints])
            ->andFilterWhere(['like', 'review_comment', $this->review_comment])
            ->andFilterWhere(['like', 'for_bids_due', $this->for_bids_due])
            ->andFilterWhere(['like', 'remarks', $this->remarks])
            ->andFilterWhere(['like', 'submittal.is_active', $this->is_active])
            ->andFilterWhere(['like', 'submittal.is_delete', $this->is_delete]);

        return $dataProvider;
    }
}
