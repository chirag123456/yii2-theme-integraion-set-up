<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\submittal; 

use yii\base\Model;
use common\models\submittal\Submittal;
use codeonyii\yii2validators\AtLeastValidator;


class SubmittalForm extends Model {

    public $id;
    public $project_id;
    public $date;
    public $to_user_id;
    public $re;
    public $email;
    public $phone;
	public $from_user_id;
	public $attention;
	public $review_date_of_resubmittal;
    public $attached_img;
    public $under_separate_cover;
    public $under_separate_cover_via;
    public $shop_drawings;
    public $prints;
    public $plans;
    public $samples;
    public $specifications;
    public $copy_of_letter;
    public $change_order;
    public $other;
    public $for_approval;
    public $approved_as_submitted;
    public $resubmit;
    public $copies_for_approval;
    public $for_your_use;
    public $approved_as_noted;
    public $submit; 
    public $copies_for_distribution;
    public $as_requested;
    public $returned_for_corrections;
    public $return;
    public $corrected_prints;
    public $review_comment;
    public $for_bids_due;
    public $remarks; 

    public function rules() {
        return [
            [['project_id','date', 'to_user_id', 're', 'email', 'phone', 'from_user_id', 'attention', 'review_date_of_resubmittal', 'attached_img', 'under_separate_cover', 'under_separate_cover_via',  'for_bids_due', 'remarks'], 'required'],
            [['shop_drawings', 'prints', 'plans', 'samples','specifications','copy_of_letter','change_order','other'], AtLeastValidator::className(), 'in' => ['shop_drawings', 'prints', 'plans', 'samples','specifications','copy_of_letter','change_order','other'], 'min' => 1],
            [['for_approval', 'approved_as_submitted', 'resubmit', 'copies_for_approval', 'for_your_use', 'approved_as_noted', 'submit', 'copies_for_distribution', 'as_requested', 'returned_for_corrections', 'return', 'corrected_prints', 'review_comment'], AtLeastValidator::className(), 'in' => ['for_approval', 'approved_as_submitted', 'resubmit', 'copies_for_approval', 'for_your_use', 'approved_as_noted', 'submit', 'copies_for_distribution', 'as_requested', 'returned_for_corrections', 'return', 'corrected_prints', 'review_comment'], 'min' => 1],
            [['phone'], 'number', 'message' => "Phone Number should be integer."],
            ['email', 'email', 'message' => 'Please enter valid email address '],

        ];
    }

    public function getUpdateModel($model) {

        $this->date = $model->date;
        $this->to_user_id = $model->to_user_id;
        $this->re = $model->re;
		$this->email = $model->email;
		$this->phone = $model->phone;
		$this->from_user_id = $model->from_user_id;
        $this->attention = $model->attention;
        $this->review_date_of_resubmittal = $model->review_date_of_resubmittal;
        $this->attached_img = $model->attached_img;
        $this->under_separate_cover = $model->under_separate_cover;
        $this->under_separate_cover_via = $model->under_separate_cover_via;
        $this->shop_drawings = $model->shop_drawings;
        $this->prints = $model->prints;
        $this->plans = $model->plans;
        $this->samples = $model->samples;
        $this->specifications = $model->specifications;
        $this->copy_of_letter = $model->copy_of_letter;
        $this->change_order = $model->change_order;
        $this->other = $model->other;
        $this->for_approval = $model->for_approval;
        $this->approved_as_submitted = $model->approved_as_submitted;
        $this->resubmit = $model->resubmit;
        $this->copies_for_approval = $model->copies_for_approval;
        $this->for_your_use = $model->for_your_use;
        $this->approved_as_noted = $model->approved_as_noted;
        $this->submit = $model->submit;
        $this->copies_for_distribution = $model->copies_for_distribution;
        $this->as_requested = $model->as_requested;
        $this->returned_for_corrections = $model->returned_for_corrections;
        $this->return = $model->return;
        $this->corrected_prints = $model->corrected_prints;
        $this->review_comment = $model->review_comment;
        $this->for_bids_due = $model->for_bids_due;
        $this->remarks = $model->remarks;
        $this->project_id = $model->project_id;

        return $this;
    }
 
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'date' => 'Date',
            'to_user_id' => 'To User',
            'project_id' => 'Project',
            're' => 'Regarding',
            'email' => 'Email',
            'phone' => 'Phone',
            'from_user_id' => 'From User',
            'attention' => 'Attention',
            'review_date_of_resubmittal' => 'Review Date Of Resubmittal',
            'attached_img' => 'Attached Img',
            'under_separate_cover' => 'Under Separate Cover',
            'under_separate_cover_via' => 'Under Separate Cover Via',
            'shop_drawings' => 'Shop Drawings',
            'prints' => 'Prints',
            'plans' => 'Plans',
            'samples' => 'Samples',
            'specifications' => 'Specifications',
            'copy_of_letter' => 'Copy Of Letter',
            'change_order' => 'Change Order',
            'other' => 'Other',
            'for_approval' => 'For Approval',
            'approved_as_submitted' => 'Approved As Submitted',
            'resubmit' => 'Resubmit',
            'copies_for_approval' => 'Copies For Approval',
            'for_your_use' => 'For Your Use',
            'approved_as_noted' => 'Approved As Noted',
            'submit' => 'Submit',
            'copies_for_distribution' => 'Copies For Distribution',
            'as_requested' => 'As Requested',
            'returned_for_corrections' => 'Returned For Corrections',
            'return' => 'Return',
            'corrected_prints' => 'Corrected Prints',
            'review_comment' => 'Review Comment',
            'for_bids_due' => 'For Bids Due',
            'remarks' => 'Remarks'
        ];
    }
}