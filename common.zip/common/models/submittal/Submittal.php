<?php

namespace common\models\submittal;

use Yii;
use common\models\project\Project; 
use common\models\user\User; 

/** 
 * This is the model class for table "submittal".
 *
 * @property int $id
 * @property string $date
 * @property int $to_user_id
 * @property string $re
 * @property string $email
 * @property string $phone
 * @property int $from_user_id
 * @property string $attention
 * @property string $review_date_of_resubmittal
 * @property string $attached_img
 * @property string $under_separate_cover
 * @property string $under_separate_cover_via
 * @property string $shop_drawings
 * @property string $prints
 * @property string $plans
 * @property string $samples
 * @property string $specifications
 * @property string $copy_of_letter
 * @property string $change_order
 * @property string $other
 * @property int $for_approval
 * @property string $approved_as_submitted
 * @property string $resubmit
 * @property string $copies_for_approval
 * @property string $for_your_use
 * @property string $approved_as_noted
 * @property string $submit
 * @property string $copies_for_distribution
 * @property string $as_requested
 * @property string $returned_for_corrections
 * @property string $return
 * @property string $corrected_prints
 * @property string $review_comment
 * @property string $for_bids_due
 * @property string $remarks
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 * @property int $project_id
 */
class Submittal extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'submittal';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['project_id','date', 'to_user_id', 're', 'email', 'phone', 'from_user_id', 'attention', 'review_date_of_resubmittal', 'under_separate_cover', 'under_separate_cover_via', 'shop_drawings', 'prints', 'plans', 'samples', 'specifications', 'copy_of_letter', 'change_order', 'other', 'for_approval', 'approved_as_submitted', 'resubmit', 'copies_for_approval', 'for_your_use', 'approved_as_noted', 'submit', 'copies_for_distribution', 'as_requested', 'returned_for_corrections', 'return', 'corrected_prints', 'review_comment', 'for_bids_due', 'remarks', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_delete'], 'required'],            
            [['attached_img'], 'safe'],            
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'project_id' => 'Project',
            'date' => 'Date',
            'to_user_id' => 'To User',
            're' => 'Regarding',
            'email' => 'Email',
            'phone' => 'Phone',
            'from_user_id' => 'From User',
            'attention' => 'Attention',
            'review_date_of_resubmittal' => 'Review Date Of Resubmittal',
            'attached_img' => 'Attached Img',
            'under_separate_cover' => 'Under Separate Cover',
            'under_separate_cover_via' => 'Under Separate Cover Via',
            'shop_drawings' => 'Shop Drawings',
            'prints' => 'Prints',
            'plans' => 'Plans',
            'samples' => 'Samples',
            'specifications' => 'Specifications',
            'copy_of_letter' => 'Copy Of Letter',
            'change_order' => 'Change Order',
            'other' => 'Other',
            'for_approval' => 'For Approval',
            'approved_as_submitted' => 'Approved As Submitted',
            'resubmit' => 'Resubmit',
            'copies_for_approval' => 'Copies For Approval',
            'for_your_use' => 'For Your Use',
            'approved_as_noted' => 'Approved As Noted',
            'submit' => 'Submit',
            'copies_for_distribution' => 'Copies For Distribution',
            'as_requested' => 'As Requested',
            'returned_for_corrections' => 'Returned For Corrections',
            'return' => 'Return',
            'corrected_prints' => 'Corrected Prints',
            'review_comment' => 'Review Comment',
            'for_bids_due' => 'For Bids Due',
            'remarks' => 'Remarks',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }
 

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProject()
    {
        return $this->hasOne(Project::className(), ['id' => 'project_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }
}
