<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\submittal;

use yii\base\Model;
use common\models\submittal\SubmittalItem;


class SubmittalItemForm extends Model {

    public $id;
    public $submittal_id;
    public $copies;
    public $item_date;
    public $number;
    public $description;

    public function rules() {
        return [
            [['copies', 'item_date', 'number', 'description'], 'safe']
        ];
    }

    public function getUpdateModel($model) {

        $this->id = $model->id;
        $this->copies = $model->copies;
        $this->item_date = $model->item_date;
        $this->number = $model->number;
		$this->description = $model->description;

        return $this;
    }
 
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'copies' => 'Copies',
            'item_date' => 'Date',
            'number' => 'Number',
            'description' => 'Description',
        ];
    }
}