<?php

namespace common\models\submittal; 

use Yii;

/**
 * This is the model class for table "submittal_item".
 *
 * @property int $id
 * @property int $submittal_id
 * @property string $copies
 * @property string $item_date
 * @property string $number
 * @property string $description
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class SubmittalItem extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'submittal_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['submittal_id', 'copies', 'item_date', 'number', 'description', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['submittal_id', 'created_by', 'updated_by'], 'integer'],
            [['item_date', 'created_date', 'updated_date'], 'safe'],
            [['description', 'is_active', 'is_delete'], 'string'],
            [['copies', 'number'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'submittal_id' => 'Transmittal ID',
            'copies' => 'Copies',
            'item_date' => 'Date',
            'number' => 'Number',
            'description' => 'Description',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }
}
