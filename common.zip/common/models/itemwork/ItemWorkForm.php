<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\itemwork;

use yii\base\Model;
use common\models\itemwork\ItemWork;

class ItemWorkForm extends Model {

    public $name;
    public $id;
    public $cost_code;

    public function rules() {

        return [
            [['name', 'cost_code'], 'required'],
            [['name'], 'string', 'max' => 255],
            [['name'], 'custom_item_unique'],
            [['cost_code'], 'custom_cost_code_unique'],
            [['cost_code'], 'integer'],
            [['cost_code'], 'string', 'min' => 3],
            [['cost_code'], 'string', 'max' => 4],
  
        ];
    }

    public function getUpdateModel($model) {

        $this->name= $model->name;
        $this->cost_code = $model->cost_code; 
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'Item Work Name',
            'cost_code' => 'Cost Code',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'date_created' => 'Date Created',
            'date_updated' => 'Date Updated',
        ];
    }

    public function custom_item_unique($attribute, $params) {
  
 
        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $check = ItemWork::find()->where(['id' => $_GET['id']])->one();
            
            if ($check) {
                $cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))));

                if ($cmp == 0) {


                    $check = true;
                } else {

                    $check = ItemWork::find()->where(['name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Item Work' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = ItemWork::find()->where(['name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Item Work' . ALREADY);
            }
        }
    }

    public function custom_cost_code_unique($attribute, $params) {
  
        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $check = ItemWork::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->cost_code), trim($this->$attribute))));

                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = ItemWork::find()->where(['cost_code' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($check) {
                        $this->addError($attribute, 'This Cost Code' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = ItemWork::find()->where(['cost_code' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Cost Code' . ALREADY);
            }
        }
    }

}
