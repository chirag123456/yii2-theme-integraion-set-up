<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\ownerinformation;

use yii\base\Model;
use common\models\city\City;
use common\models\state\State;
use common\models\user\User;


class OwnerInformationForm extends Model {

    public $owners_legal_name;
    public $permissible_working_hours;
    public $latest_owner_signed_construction_proposal_date;
    public $id;
    public $owners_mailing_address;
    public $owner_city_id;
	public $owner_state_id;
	public $owner_zipcode;
	public $owners_primary_contact_person;
	public $owner_email;
	public $owner_phone;
	
	 

    public function rules() {
        return [
        [['owners_legal_name', 'permissible_working_hours',  
        'latest_owner_signed_construction_proposal_date', 'owners_mailing_address', 'owner_city_id', 'owner_state_id', 'owner_zipcode', 'owners_primary_contact_person', 'owner_email', 
        'owner_phone',], 'required'],
        [['owner_city_id', 'owner_state_id'], 'integer'],
        [['owner_city_id'], 'exist', 'skipOnError' => true, 'targetClass' => City::className(), 'targetAttribute' => ['owner_city_id' => 'id']],
        [['owner_state_id'], 'exist', 'skipOnError' => true, 'targetClass' => State::className(), 'targetAttribute' => ['owner_state_id' => 'id']],
        ['owner_email', 'email', 'message' => 'Please enter valid owner email address '] , 
        ['owner_phone', 'number', 'message' => 'Owner Phone Number is Invalid.'],
        ];
    }

    public function getUpdateModel($model) {

        $this->owners_legal_name = $model->owners_legal_name;
        $this->owner_state_id = isset($model->owner_state_id) ? $model->owner_state_id : 'N\A';
        $this->owner_city_id = isset($model->owner_city_id) ? $model->owner_city_id : 'N\A';
		$this->permissible_working_hours = $model->permissible_working_hours;
		$this->owners_mailing_address = $model->owners_mailing_address;
		$this->latest_owner_signed_construction_proposal_date = $model->latest_owner_signed_construction_proposal_date;
		
		$this->owner_zipcode = $model->owner_zipcode;
		$this->owners_primary_contact_person = $model->owners_primary_contact_person;
		$this->owner_email = $model->owner_email;
		$this->owner_phone = $model->owner_phone;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'owners_legal_name' => 'Owners Legal Name',
            'permissible_working_hours' => 'Permissible Working Hours',
            'latest_owner_signed_construction_proposal_date' => 'Latest Owner Signed Construction Proposal Date',
            'owners_mailing_address' => 'Owners Mailing Address',
            'owner_city_id' => 'Owner City',
            'owner_state_id' => 'Owner State',
            'owner_zipcode' => 'Owner Zipcode',
            'owners_primary_contact_person' => 'Owners Primary Contact Person',
            'owner_email' => 'Owner Email',
            'owner_phone' => 'Owner Phone',
        ];
    }
}
