<?php

namespace common\models\ownerinformation;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\ownerinformation\OwnerInformation;

/**
 * OwnerInformationSearch represents the model behind the search form of `common\models\OwnerInformation`.
 */
class OwnerInformationSearch extends OwnerInformation
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'owner_city_id', 'owner_state_id', 'created_by', 'updated_by'], 'integer'],
            [['owners_legal_name', 'permissible_working_hours', 'latest_owner_signed_construction_proposal_date', 'owners_mailing_address', 'owner_zipcode', 'owners_primary_contact_person', 'owner_email', 'owner_phone', 'created_date', 'updated_date', 'is_active', 'is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) 
    {
        $query = OwnerInformation::find()->where(['is_delete' => INACTIVE]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
           
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'latest_owner_signed_construction_proposal_date' => $this->latest_owner_signed_construction_proposal_date,
            'owner_city_id' => $this->owner_city_id,
            'owner_state_id' => $this->owner_state_id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'owners_legal_name', $this->owners_legal_name])
            ->andFilterWhere(['like', 'permissible_working_hours', $this->permissible_working_hours])
            ->andFilterWhere(['like', 'owners_mailing_address', $this->owners_mailing_address])
            ->andFilterWhere(['like', 'owner_zipcode', $this->owner_zipcode])
            ->andFilterWhere(['like', 'owners_primary_contact_person', $this->owners_primary_contact_person])
            ->andFilterWhere(['like', 'owner_email', $this->owner_email])
            ->andFilterWhere(['like', 'owner_phone', $this->owner_phone])
            ->andFilterWhere(['like', 'is_active', $this->is_active])
            ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }
}
