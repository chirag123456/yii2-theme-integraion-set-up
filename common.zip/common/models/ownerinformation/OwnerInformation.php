<?php

namespace common\models\ownerinformation;

use Yii;
use common\models\city\City;
use common\models\state\State;
use common\models\user\User;

/**
 * This is the model class for table "owner_information".
 *
 * @property int $id
 * @property string $owners_legal_name
 * @property string $permissible_working_hours
 * @property string $latest_owner_signed_construction_proposal_date
 * @property string $owners_mailing_address
 * @property int $owner_city_id
 * @property int $owner_state_id
 * @property string $owner_zipcode
 * @property string $owners_primary_contact_person
 * @property string $owner_email
 * @property string $owner_phone
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 *
 * @property City $ownerCity
 * @property User $createdBy
 * @property State $ownerState
 * @property User $updatedBy
 */
class OwnerInformation extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'owner_information';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['owners_legal_name', 'permissible_working_hours', 'latest_owner_signed_construction_proposal_date', 'owners_mailing_address', 'owner_city_id', 'owner_state_id', 'owner_zipcode', 'owners_primary_contact_person', 'owner_email', 'owner_phone', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'required'],
            [['latest_owner_signed_construction_proposal_date', 'created_date', 'updated_date'], 'safe'],
            [['owner_city_id', 'owner_state_id', 'created_by', 'updated_by'], 'integer'],
            [['is_active', 'is_delete'], 'string'],
            [['owners_legal_name', 'permissible_working_hours', 'owners_mailing_address', 'owners_primary_contact_person'], 'string', 'max' => 255],
            [['owner_zipcode', 'owner_email', 'owner_phone'], 'string', 'max' => 100],
            [['owner_city_id'], 'exist', 'skipOnError' => true, 'targetClass' => City::className(), 'targetAttribute' => ['owner_city_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['owner_state_id'], 'exist', 'skipOnError' => true, 'targetClass' => State::className(), 'targetAttribute' => ['owner_state_id' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'owners_legal_name' => 'Owners Legal Name',
            'permissible_working_hours' => 'Permissible Working Hours',
            'latest_owner_signed_construction_proposal_date' => 'Latest Owner Signed Construction Proposal Date',
            'owners_mailing_address' => 'Owners Mailing Address',
            'owner_city_id' => 'Owner City',
            'owner_state_id' => 'Owner State',
            'owner_zipcode' => 'Owner Zipcode',
            'owners_primary_contact_person' => 'Owners Primary Contact Person',
            'owner_email' => 'Owner Email',
            'owner_phone' => 'Owner Phone',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOwnerCity()
    {
        return $this->hasOne(City::className(), ['id' => 'owner_city_id']);
    }

    public function getCity()
    {
        return $this->hasOne(City::className(), ['id' => 'owner_city_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOwnerState()
    {
        return $this->hasOne(State::className(), ['id' => 'owner_state_id']);
    }

    public function getState()
    {
        return $this->hasOne(State::className(), ['id' => 'owner_state_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }
}
