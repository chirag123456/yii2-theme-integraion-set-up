<?php

namespace common\models\userrole;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\userrole\UserRole;

/**
 * AreaSearch represents the model behind the search form about `common\models\Area`.
 */
class UserRoleSearch extends UserRole {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            //[['id'], 'integer'],
            [['name', 'type', 'description', 'rule_name', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        //$query = UserRole::find()->where(['auth_item.is_delete' => NOT_DELETED]);
       //$query = UserRole::find()->where(['is_delete'=>NOT_DELETED , 'role'=> $role]);
        $query = UserRole::find()->where('auth_item.name!='." 'superadmin' ");
        // add conditions that should always apply here
        
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
        
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            // 'sort' => ['defaultOrder' => ['user_access.id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize, 
                'pageSizeLimit' => [1, 100],
            ],
        ]);

       

        $query->joinWith(['useraccess']);
        //$query->orderby(['user_access.id'=>SORT_DESC]);
        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        $query->andFilterWhere([
            //'id' => $this->id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);
    
        $query->andFilterWhere(['like', 'user_access.name', $this->name]); //auth_item.name
        return $dataProvider;
    }

}