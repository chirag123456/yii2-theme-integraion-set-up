<?php

namespace common\models\userrole;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
//use common\models\school\School;

/**
 * User model 
 *
 * @property integer $id
 * @property string $username
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property string $auth_key
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property string $password write-only password
 */
class UserAccess extends ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%user_access}}';
    }

    /**
     * @inheritdoc
     */
//    public function behaviors() {
//        return [
//            TimestampBehavior::className(),
//        ];
//    }

    /**
     * @inheritdoc
     */
    
    public function rules() {
        return [
            [['name', 'access'], 'required'],
            //[['created_by', 'updated_by'], 'integer'],
            //[['is_active'], 'string'],
            [['is_admin'], 'safe'],
            [['name'], 'string', 'max' => 100],
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'User Access Name',
            'access' => 'Access',
            'status' => 'Status',
        ];
    }
    
    /*public function getSchool()
    {
        return $this->hasOne(School::className(), ['id' => 'school_id']);
    }*/
    
}