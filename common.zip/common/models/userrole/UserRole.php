<?php

namespace common\models\userrole;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use common\models\userrole\UserAccess;

/**
 * User model
 *
 * @property integer $id
 * @property string $username
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property string $auth_key
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property string $password write-only password
 */
class UserRole extends ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%auth_item}}';
    }

    /**
     * @inheritdoc
     */
//    public function behaviors() {
//        return [
//            TimestampBehavior::className(),
//        ];
//    }

    /**
     * @inheritdoc
     */
    //public $min_order;
    public function rules() {
        return [
            [['name'], 'required'],
            //[['created_by', 'updated_by'], 'integer'],
            //[['is_active'], 'string'],
            [['type', 'description', 'rule_name', 'created_at', 'updated_at'], 'safe'],
            //[['name'], 'string', 'max' => 10],
        ];
    }

    public function attributeLabels() {
        return [
            //'id' => 'ID',
            'name' => 'User Role Name',
            //'type' => 'Type',
            //'description' => 'Description',
            //'access' => 'Access',
            'created_at' => 'Created Date',
            'updated_at' => 'Updated Date',
        ];
    }
    
    public function getUseraccess()
    {
        return $this->hasOne(UserAccess::className(), ['name' => 'name']);
    }
    
}