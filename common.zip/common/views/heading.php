<section class="content-header">
    <h1>
        <?= $head_arr[0] ?>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?= $head_arr[1] ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active"><?= $head_arr[2] ?></li>
    </ol>
</section>