<?php
    use yii\helpers\Html;
    use yii\widgets\ActiveForm;
?>
<div class="user-index">
        <?php
        $form = ActiveForm::begin([
                    'method' => 'get',
                    'action' => $page_arr[4],
                    'id' => $page_arr[0]
        ]);
        ?>
        <input type="hidden" value="<?= $page_arr[1] ?>" id="per_page" name="per-page">

        <?php ActiveForm::end();
        ?>
        <?php
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
        ?>

        <div id="sample_1_length" class="pull-right">
            <label>
                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                    <?php
                    $sel10 = '';
                    $sel20 = '';
                    $sel50 = '';
                    $sel100 = '';
                    if ($pagesize == '10') {
                        $sel10 = 'selected="selected"';
                    } else if ($pagesize == '20') {
                        $sel20 = 'selected="selected"';
                    } else if ($pagesize == '50') {
                        $sel50 = 'selected="selected"';
                    } else if ($pagesize == '100') {
                        $sel100 = 'selected="selected"';
                    }
                    ?>
                    <option value="10" <?php echo $sel10; ?>>10</option>
                    <option value="20" <?php echo $sel20; ?>>20</option>
                    <option value="50" <?php echo $sel50; ?>>50</option>
                    <option value="100" <?php echo $sel100; ?>>100</option>
                </select>
                records per page</label>
        </div>
        <p>
            <?php
                if(isset($page_arr[2]) && !empty($page_arr[2]))
                {
                    echo Html::a($page_arr[2], ['add'], ['class' => 'btn btn-primary']) ;
                } 
            ?>
            
            <?php 
                if(isset($page_arr[5]) && !empty($page_arr[5]))
                {
            ?>
                    <a class="btn btn-primary" href="<?= $page_arr[6] ?>" ><?= $page_arr[5]?></a>
            <?php        
                }
            ?>

             <?php 
                if(isset($page_arr[7]) && !empty($page_arr[7]))
                {
            ?>
                    <a target="_blank" class="btn btn-primary" href="<?= $page_arr[8] ?>" ><?= $page_arr[7]?></a>
            <?php        
                }
            ?>
            <a class="btn btn-primary" href="<?= $page_arr[4] ?>" >Reset</a>
        </p>