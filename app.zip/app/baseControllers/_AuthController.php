<?php

namespace app\baseControllers;

use Yii;
use yii\web\Controller;
use yii\filters\ContentNegotiator;
use yii\web\Response;
use common\models\SiteConfiguration;

/**
 * Site controller
 */
class AuthController extends \yii\rest\Controller {

    public $cData;

    /**
     * @inheritdoc
     */
    public function behaviors() {
        $behaviors = parent::behaviors();

        $behaviors[] = [
            'class' => ContentNegotiator::className(),
            'formats' => [
                'application/json' => Response::FORMAT_JSON,
            ],
        ];

        return $behaviors;
    }

    public function loadRequestData($rVar, $cVar = '') {
        if (\Yii::$app->request->post($rVar) != null) {
            if ($cVar == '') {
                $this->cData[$rVar] = \Yii::$app->request->post($rVar);
            } else {
                $this->cData[$cVar] = \Yii::$app->request->post($rVar);
            }
        } else {
            if (\Yii::$app->request->get($rVar) != null) {
                if ($cVar == '') {
                    $this->cData[$rVar] = \Yii::$app->request->get($rVar);
                } else {
                    $this->cData[$cVar] = \Yii::$app->request->get($rVar);
                }
            }
        }
    }

    public function __print($arr, $exit = true) {

        if ($exit) {
            \Yii::$app->end();
        }
    }

    public function getConfigureValueByKey($key) {

        $model = SiteConfiguration::findOne(['config_key' => $key]);
        if ($model != null) {
            return $model->config_value;
        } else {
            return 'Undefine Key';
        }
    }

    public function getDecryptData($array) {
        $newArr = [];
        if (is_array($array) && !empty($array)) {
            foreach ($array as $key => $val) {
                $newArr[$key] = base64_decode($val);
            }
        }
        return $newArr;
    }

    public function getEncryptData($array) {
        $newArr = [];
        if (is_array($array) && !empty($array)) {
            foreach ($array as $key => $val) {
                $newArr[$key] = base64_encode($val);
            }
            return $newArr;
        } else {
            return $array;
        }
    }

    public function getDistanceBetweenPointsNew($lat1, $lon1, $lat2, $lon2, $unit) {

        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        $unit = strtoupper($unit);

        if ($unit == "K") {
            return ($miles * 1.609344);
        } else if ($unit == "N") {
            return ($miles * 0.8684);
        } else {
            return $miles;
        }
    }

    public function getDistanceBetweenPointsWithTime($lat1, $lat2, $lon1, $lon2) {

        //$lat1 = 23.1411102; $lon1 = 72.5303491;$lat2 = 23.1714583; $lon2 = 72.5699831;
        $departure_time = new \DateTime();
        $departure_time = strtotime($departure_time->format('2017-m-d h:i:s'));

        $traffic_model = 'best_guess'; //pessimistic,optimistic

        $url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=" . $lat1 . "," . $lon1 . "&destinations=" . $lat2 . "," . $lon2 . "&mode=driving&language=en-GB&departure_time=" . $departure_time . "&traffic_model=best_guess";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        curl_close($ch);
        //echo $url;die;
        $response_a = json_decode($response, true);
        $status = $response_a['rows'][0]['elements'][0]['status'];
        if ($status != 'ZERO_RESULTS') {
            $dist = $response_a['rows'][0]['elements'][0]['distance']['text'];
            $distance = explode(' ', $dist);

            if ($distance[1] == 'km') {
                $dist = str_replace('km', '', $dist);
            } else if ($distance[1] == 'm') {
                $dist = str_replace('m', '', $dist);
            } else if ($distance[1] == 'mi') {
                $dist = str_replace('mi', '', $dist);
            }
            $time = $response_a['rows'][0]['elements'][0]['duration']['text'];


            $dist = str_replace(',', '.', $dist);
            $time = str_replace('min', '', $time);


            return ['distance' => trim($dist), 'time' => trim($time)];
        } else {
            return ['distance' => 0, 'time' => 0];
        }
    }

}
