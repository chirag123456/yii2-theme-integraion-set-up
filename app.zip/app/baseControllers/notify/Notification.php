<?php

/**
 * Created by PhpStorm.
 * User: rohan
 * Date: 22/9/16
 * Time: 5:20 PM
 */

namespace app\baseControllers\notify;

use yii\base\Component;
use app\baseControllers\notify\Firebase;
use app\baseControllers\notify\Apns;

class Notification extends Component {

    private $android;
    private $ios;

    public function SendPushDriver($user, $title, $message, $data, $isDriver = true) {
        return $this->SendPush($user, $title, $message, $data, $isDriver);
    }

    public function SendPushUser($user, $title, $message, $data, $isDriver = false) {
        return $this->SendPush($user, $title, $message, $data, $isDriver);
    }

    /**
     * Send Push
     * @param object user, String title,String message,data whcih is need to send
     * @example Yii::
     * */
    public function SendPush($user, $title, $message, $data, $isDriver, $background = false, $image = '') {

        $android_ids = [];
        $ios_ids = [];

        foreach ($user->devices as $device) {
//            if ($device->is_login) {
            if (strtolower($device->device_platform) == 'android') {
                if (($device->fcm_token != "android") || ($device->fcm_token != "test token")) {
                    array_push($android_ids, $device->fcm_token);
                } else {
                    array_push($android_ids, $device->fcm_token);
                }
            } elseif (strtolower($device->device_platform) == 'ios') {
                if ($device->fcm_token == 'ios' || $device->fcm_token == 'token') {
                    
                } else {
                    array_push($ios_ids, $device->fcm_token);
                }
            }
//            }
        }

        if (($key = array_search('test token', $android_ids)) !== false) {
            unset($android_ids[$key]);
        }
        if (($keyi = array_search('token', $ios_ids)) !== false) {
            unset($ios_ids[$keyi]);
        }


        // print_r($android_ids);die;
        $fcm = new Firebase();
        if (!empty($android_ids)) {
            foreach ($android_ids as $ai) {
                return $fcm->send([$ai], $fcm->getPush($title, $message, $background, $image, $data), $isDriver);
            }
        }

        $apns = new Apns();
        if (!empty($ios_ids)) {
            return $apns->sendMultiple($ios_ids, $message, $data, $isDriver);
        }
    }

}
