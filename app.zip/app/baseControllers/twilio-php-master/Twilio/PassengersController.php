<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace app\controllers;

use Yii;
use Stripe\Stripe;
use common\models\PassengersLoginForm;
use common\models\PassengersOrders;
use common\models\Passengers;
use common\models\PassengersDevices;
use common\models\PassengersCardsDetails;
use app\baseControllers\AuthController;

require Yii::getAlias('@app') . '/baseControllers/twilio-php-master/Twilio/autoload.php';

require_once(__DIR__ . '/../../vendor/stripe-php/init.php');
require_once(__DIR__ . '/../../vendor/autoload.php');

class PassengersController extends AuthController {

    private $secret_key = "sk_test_wqb10YxyZTRBCnla56RiWLIy";

    public function actions() {
        return [
            'error' => ['class' => 'yii\web\ErrorAction'],
        ];
    }

    /*
     * Login Action for login passenger
     */

    public function actionLogin() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengersLoginForm'])) {
//                $postdata = $_POST['PassengersLoginForm']; /* call for data decrypt *///
                $postdata = $this->getDecryptData($_POST['PassengersLoginForm']);
//echo '<pre>';print_r($postdata);die;
                if (!empty($postdata['phone']) && !empty($postdata['password'])) {
                    $userData = Passengers::findOne([
                                'password' => $postdata['password'], 'phone' => $postdata['phone'],
                                'is_active' => ACTIVE, 'is_verified' => ACTIVE, 'is_delete' => NOT_DELETED,
                                    /* 'is_logged_in' => INACTIVE */
                    ]);
                    $userData1 = PassengersDevices::find()->joinWith(['passenger'])->where([
                                'password' => $postdata['password'], 'phone' => $postdata['phone'],
                                'passenger_device_id' => $postdata['passenger_device_id'],
                                'passengers.is_active' => ACTIVE, 'is_verified' => ACTIVE, 'passengers.is_delete' => NOT_DELETED,
                            ])->one();
                    if ($userData != null) {
                        $passengers = new PassengersLoginForm();
                        $passengers->attributes = $postdata;
                        if (isset($postdata['passenger_device_id'])) {

                            if ($userData->is_logged_in == INACTIVE) {
                                return $this->checkLogin($userData, $postdata);
                            } else {
                                if (!empty($userData1->passenger_device_token)) {
                                    return $this->checkLogin($userData, $postdata);
                                } else {
                                    return [
                                        'code' => 999, // invalide access
                                        'message' => $this->getConfigureValueByKey('ALREADY_LOGIN')
                                    ];
                                }
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        }
                    } else {
                        $userData = Passengers::findOne(['phone' => $postdata['phone'], 'is_delete' => NOT_DELETED]);

                        if ($userData != null) {

                            if ($userData->password != $postdata['password']) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('INVALID_PASSWORD')
                                ];
                            }

                            if ($userData->is_active != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_INACTIVE')
                                ];
                            }

                            if ($userData->is_verified != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_NOT_VERIFIED')
                                ];
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('USER_NOT_EXIST')
                            ];
                        }
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    public function checkLogin($userData, $postdata) {
        $device = $this->passenger_device($userData, $postdata);

        $userData->is_logged_in = ACTIVE;
        if ($userData->save(false)) {
            $passengerData = [
                'id' => base64_encode($userData->id),
                'name' => base64_encode($userData->name),
                'image_path' => base64_encode(dirname(\yii\helpers\Url::base(true)) . '/backend/web/uploads/passengers/' . $userData->image_path),
                'email' => base64_encode($userData->email),
                'phone' => base64_encode($userData->phone),
            ];

            return [
                'code' => 200, //success
                'message' => $this->getConfigureValueByKey('LOGIN_SUCCESS'),
                'data' => [
                    'access_token' => base64_encode($device->passenger_device_token),
                    'passenger' => $passengerData,
                ]
            ];
        } else {
            return [
                'code' => 202, // driver device data not save
                'message' => $this->getConfigureValueByKey('SERVER_ERROR')
            ];
        }
    }

    /*
     * Signup Action for new passenger signup or register
     */

    public function actionMobileVerify() {

        try {
            if (Yii::$app->request->isPost && isset($_POST['MobileVerify'])) {
                $postdata = $_POST['MobileVerify'];
                if (!empty($postdata['mobile_no'])) {
                    $sid = "ACb9584326c0bd0fa3675e88dda6c95e72"; // Your Account SID from www.twilio.com/console
                    $token = "9add870d8da3582e96e147e04c24201d"; // Your Auth Token from www.twilio.com/console

                    $client = new \Twilio\Rest\Client($sid, $token);
//                    print_r(\yii\helpers\Url::base());
//                    die;
                    $message = $client->messages->create(
                            $postdata['mobile_no'], // Text this number
                            array(
                        'from' => '+19197525338', // From a valid Twilio number
                        'body' => 'Swiftdragin testing OTP number  ' . rand(10000, 99999)
                            )
                    );
                    if ($message->sid) {
                        return [
                            'code' => 200, // invalide access
                            'message' => ''//$this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    } else {
                        return [
                            'code' => 201, // invalide access
                            'message' => 'Otp is not sent'//$this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 999, // invalide access
                        'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    public function actionSignupOLD() {

        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengersForm'])) {
                $postdata = $_POST['PassengersForm'];
                if (!empty($postdata['name']) && !empty($postdata['phone']) && !empty($postdata['email']) && !empty($postdata['password'])) {

                    $passenger = Passengers::find()->where(['phone' => $postdata['phone']])->orWhere(['email' => $postdata['email']])->one();

                    if ($passenger != null) {

                        if ($passenger->phone == $postdata['phone']) {
                            return [
                                'code' => 203, //phone already exist
                                'message' => $this->getConfigureValueByKey('PHONE_EXIST')
                            ];
                        }
                        if ($passenger->email == $postdata['email']) {
                            return [
                                'code' => 204, //email already exist
                                'message' => $this->getConfigureValueByKey('EMAIL_EXIST')
                            ];
                        }
                    } else {
                        $passenger = new Passengers();

                        $passenger->name = $postdata['name'];
                        $passenger->phone = $postdata['phone'];
                        $passenger->email = $postdata['email'];
                        $passenger->password = $postdata['password'];
                        $passenger->image = $postdata['image'];
//$passenger->balance = 0; //$passenger->created_by = 1;
//$passenger->updated_by = 1; 
                        $passenger->is_active = ACTIVE;
                        $passenger->is_verified = ACTIVE;
                        $passenger->is_delete = NOT_DELETED;
                        $passenger->ip_address = $_SERVER['REMOTE_ADDR'];
                        $passenger->created_date = date("Y-m-d H:i:s");
                        $passenger->updated_date = date("Y-m-d H:i:s");
                        $passenger->last_login = date("Y-m-d H:i:s");
                        if ($passenger->validate()) {
                            if ($passenger->save()) {

                                $device = $this->passenger_device($passenger, $postdata);
                                if ($device) {
                                    return [
                                        'code' => 200, // sign completed redirect login
                                        'message' => $this->getConfigureValueByKey('SIGNUP_SUCCESS')
                                    ];
                                } else {
                                    return [
                                        'code' => 202, // passenger device data not save
                                        'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                    ];
                                }
                            } else {
                                return [
                                    'code' => 202, // passenger device data not save
                                    'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                ];
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        }
                    }
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * GetDetail Action for get passenger details
     */

    public function actionGetDetail() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengerDetail'])) {
//                $postdata = $_POST['PassengerDetail']; /* call for data decrypt *///
                $postdata = $this->getDecryptData($_POST['PassengerDetail']);
                if (!empty($postdata['access_token']) && !empty($postdata['passenger_device_id'])) {

                    $passengersDevices = PassengersDevices::find()->where(['passenger_device_token' => $postdata['access_token'], 'passenger_device_id' => $postdata['passenger_device_id']])->one();

                    if ($passengersDevices != null) {

                        $passengers = Passengers::find()->select('id , name , image_path, phone , email , balance')->where(['id' => $passengersDevices->passenger_id, 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();

                        if ($passengers != null) {

                            $passengers->image_path = dirname(\yii\helpers\Url::base(true)) . '/backend/web/uploads/passengers/' . $passengers->image_path;

                            $passengerCards = PassengersCardsDetails::find()->select('id,passenger_id,card_type,card_number,card_name')->
                                            where(['passenger_id' => $passengers->id, 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->
                                            groupBy('stripe_fingerprint')->all();

                            if ($passengerCards != null) {
                                $cardArr = $this->getCardDetailsFromStrip($passengers, $passengerCards);
                            } else {
                                $cardArr = [];
                            }

                            return [
                                'code' => 200, //success //'message' => $this->getConfigureValueByKey('INVALID_INPUT'),
                                'data' => [
                                    'passenger' => [
                                        "id" => base64_encode($passengers->id),
                                        "name" => base64_encode($passengers->name),
                                        "image_path" => base64_encode($passengers->image_path),
                                        "phone" => base64_encode($passengers->phone),
                                        "email" => base64_encode($passengers->email),
                                        "balance" => base64_encode($passengers->balance),
                                    ], //$passengers,
                                    /* call for data encrypt *///$this->getEncryptData( $passengers ),
                                    'passenger_card' => ($cardArr), /* call for data encrypt *///$this->getEncryptData( $cardArr ),
                                    'passenger_id' => base64_encode($passengers->id),
                                    'passenger_device_id' => base64_encode($postdata['passenger_device_id']),
                                    'passenger_device_token' => base64_encode($postdata['access_token']),
                                ]
                            ];
                        } else {
                            return [
                                'code' => 999, // invalide access
                                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                            ];
                        }
                    } else {
                        return [
                            'code' => 999, // invalide access
                            'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    public function getCardDetailsFromStrip($passenger, $passengerCards) {
        Stripe::setApiKey($this->secret_key);

        $passengerCards = PassengersCardsDetails::find()->where(['passenger_id' => $passenger->id, 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();
        $exist_customers = \Stripe\Customer::retrieve($passengerCards->stripe_customer_id);
        $cards = [];
        $arr = [];
        $card_uniqe = PassengersCardsDetails::find()->where(['passenger_id' => $passenger->id])->groupBy('stripe_fingerprint')->all();


        if ($exist_customers->deleted != 1) {
            foreach ($exist_customers->sources->data as $card) {
                $cards[] = [
                    'card_id' => $passengerCards->id,
                    'passenger_id' => $passengerCards->passenger_id,
                    'card_type' => $passengerCards->card_type,
                    'card_number' => $passengerCards->card_number,
                    'card_name' => $passengerCards->card_name,
                    'stripe_card_id' => $card->id,
                    'stripe_card_type' => $card->brand,
                    'stripe_customer_id' => $card->customer,
                    'stripe_expiry_date' => $card->exp_month . '/' . $card->exp_year,
                    'stripe_card_number' => $card->last4
                ];
            }
        }
//        print_r($cards);
//        die;

        return $cards;
    }

    /*
     * UpdateDetail Action for update passenger details
     */

    public function actionUpdateDetail() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengersForm'])) {
//                $postdata = $_POST['PassengersForm']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['PassengersForm']);

                if (!empty($postdata['access_token']) && !empty($postdata['passenger_device_id']) && !empty($postdata['passenger_id']) && !empty($postdata['email']) && !empty($postdata['name'])) {

                    $passengersDevices = PassengersDevices::find()->select('passenger_id')->where(['passenger_device_token' => $postdata['access_token'], 'passenger_device_id' => $postdata['passenger_device_id']])->one();

                    if ($passengersDevices != null) {

                        $passengers = Passengers::find()->where(['id' => $postdata['passenger_id'], 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();

                        if ($passengers != null) {


                            if (!empty($postdata['image'])) {
                                $passengers->image = NULL; //$postdata['image'];
                                $passengers->image_path = $this->base64_to_image($postdata['image']);
                            }

                            $passengers->name = $postdata['name'];
                            $passengers->is_guest = ACTIVE;
//$passengers->image = $postdata['image'];
//$passengers->image_path = $this->base64_to_image( $postdata['image'] );
//$passengers->phone = $postdata['phone'];
                            $passengerEmailCheck = Passengers::find()->where(['email' => $postdata['email']])->andWhere('id != ' . $postdata['passenger_id'])->one();
                            if ($passengerEmailCheck != null) {
                                return [
                                    'code' => 204, //email already exist
                                    'message' => $this->getConfigureValueByKey('EMAIL_EXIST')
                                ];
                            } else {
                                $passengers->email = $postdata['email'];

                                if ($passengers->validate()) {
                                    if ($passengers->save()) {

                                        $passengerData = [
//'id' => $passengers->id,
                                            'passenger_id' => $postdata['passenger_id'],
                                            'name' => $passengers->name,
                                            'image_path' => dirname(\yii\helpers\Url::base(true)) . '/backend/web/uploads/passengers/' . $passengers->image_path,
                                            'phone' => $passengers->phone,
                                            'email' => $passengers->email,
                                            'balance' => $passengers->balance,
                                            'passenger_device_id' => $postdata['passenger_device_id'],
                                            'passenger_device_token' => $postdata['access_token']
                                        ];

                                        return [
                                            'code' => 200, //success
                                            'message' => $this->getConfigureValueByKey('PROFILE_UPDATE_SUCCESS'),
                                            'data' => [
                                                'passenger' => $this->getEncryptData($passengerData), /* call for data encrypt *///$this->getEncryptData( $passengerData ),
                                            ],
                                        ];
                                    } else {
                                        return [
                                            'code' => 202, //data save error
                                            'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                        ];
                                    }
                                } else {
                                    return [
                                        'code' => 201, //invalid input
                                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                                    ];
                                }
                            }
                        } else {
                            return [
                                'code' => 999, // invalide access
                                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                            ];
                        }
                    } else {
                        return [
                            'code' => 999, // invalide access
                            'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * AddCard Action for passenger add card details
     */

    public function actionAddCard() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengersCardForm'])) {
//                $postdata = $_POST['PassengersCardForm']; /* call for data decrypt *///
                $postdata = $this->getDecryptData($_POST['PassengersCardForm']);
                if (!empty($postdata['passenger_device_id']) && !empty($postdata['access_token']) && !empty($postdata['card_type']) && !empty($postdata['card_number']) && !empty($postdata['card_name'])) {

                    $passengersDevices = PassengersDevices::find()->select('id, passenger_id')->where(['passenger_device_token' => $postdata['access_token'], 'passenger_device_id' => $postdata['passenger_device_id']])->one();
                    if ($passengersDevices != null) {

                        $passengerCards = PassengersCardsDetails::find()->where(['card_number' => $postdata['card_number'], 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();
                        if ($passengerCards != null) {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        } else {

                            $passengerCardsNew = new PassengersCardsDetails();
                            $passengerCardsNew->passenger_id = $passengersDevices->passenger_id;
                            $passengerCardsNew->card_type = $postdata['card_type'];
                            $passengerCardsNew->card_number = $postdata['card_number'];
                            $passengerCardsNew->card_name = $postdata['card_name'];
                            $passengerCardsNew->passenger_device_id = $passengersDevices->id;
                            $passengerCardsNew->created_by = $passengersDevices->passenger_id;
                            $passengerCardsNew->updated_by = $passengersDevices->passenger_id;

                            if ($passengerCardsNew->validate()) {
//print_r($passengerCardsNew);die;
                                if ($passengerCardsNew->save()) {
                                    return [
                                        'code' => 200, // success
                                        'message' => $this->getConfigureValueByKey('ADD_CARD_SUCCESS')
                                    ];
                                } else {
                                    return [
                                        'code' => 202, //data save error
                                        'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                    ];
                                }
                            } else {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                                ];
                            }
                        }
                    } else {
                        return [
                            'code' => 999, // invalide access
                            'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * DeleteCard Action for passenger delete card details
     */

    public function actionDeleteCard() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['DeleteCard'])) {
                $postdata = $_POST['DeleteCard']; /* call for data decrypt *///$postdata = $this->getDecryptData($_POST['DeleteCard']);
                if (!empty($postdata['id']) && !empty($postdata['access_token']) && !empty($postdata['passenger_device_id'])) {

                    $passengersDevices = PassengersDevices::find()->select('passenger_id')->where(['passenger_device_token' => $postdata['access_token'], 'passenger_device_id' => $postdata['passenger_device_id']])->one();
                    if ($passengersDevices != null) {
                        $passengerCards = PassengersCardsDetails::findOne($postdata['id']);
                        if ($passengerCards != null) {
                            $passengerCards->is_delete = ACTIVE;
                            if ($passengerCards->save()) {
                                return [
                                    'code' => 200, // success
                                    'message' => $this->getConfigureValueByKey('DELETE_CARD_SUCCESS')
                                ];
                            } else {
                                return [
                                    'code' => 202, //data save error
                                    'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                ];
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        }
                    } else {
                        return [
                            'code' => 999, // invalide access
                            'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * PhoneExist Action for check user exist or not
     */

    public function actionPhoneExist() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PhoneExist'])) {
// $postdata = $_POST['PhoneExist']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['PhoneExist']);
                if (!empty($postdata['phone'] && !empty($postdata['email']))) {
                    $passenger = Passengers::find()->where(['phone' => $postdata['phone']])->orWhere(['email' => $postdata['email']])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($passenger != null) {
                        if ($passenger->is_verified == ACTIVE && $passenger->is_active == ACTIVE) {
                            if ($passenger->phone == $postdata['phone']) {
                                return [
                                    'code' => 203,
                                    'message' => $this->getConfigureValueByKey('PHONE_EXIST')
                                ];
                            } else if ($passenger->email == $postdata['email']) {
                                return [
                                    'code' => 204,
                                    'message' => $this->getConfigureValueByKey('EMAIL_EXIST')
                                ];
                            }
                        } else {
                            if ($passenger->is_active != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_INACTIVE')
                                ];
                            }
                            if ($passenger->is_verified != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_NOT_VERIFIED')
                                ];
                            }
                        }
                    } else {
                        return [
                            'code' => 200, // user dose not exist
                            'message' => $this->getConfigureValueByKey('USER_NOT_EXIST')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * ResetPasswordRequest Action for check user for forgot password request
     */

    public function actionResetPasswordRequest() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['ResetPasswordRequest'])) {
//$postdata = $_POST['ResetPasswordRequest']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['ResetPasswordRequest']);
                if (!empty($postdata['phone']) && !empty($postdata['passenger_device_id'])) {

                    $passenger = Passengers::find()->where(['phone' => $postdata['phone'], 'is_verified' => ACTIVE, 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();

                    if ($passenger != null) {
                        $device = $this->passenger_device($passenger, $postdata);
                        if ($device->passenger_device_id != $postdata['passenger_device_id']) {
                            return [
                                'code' => 202, // passenger device data not save
                                'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                            ];
                        } else {
                            return [
                                'code' => 200, // user exist redirect Reset password form
                                'passenger_data' => [
                                    'passenger_id' => $passenger->id,
                                    'passenger_device_id' => $postdata['passenger_device_id'],
                                //  'passenger_device_token' => $postdata['passenger_device_token']
                                ],
                                'message' => $this->getConfigureValueByKey('NUMBER_VERIFY')
                            ];
                        }
                    } else {
                        $passenger = Passengers::findOne(['phone' => $postdata['phone'], 'is_delete' => NOT_DELETED]);

                        if ($passenger != null) {

                            if ($passenger->is_active != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_INACTIVE')
                                ];
                            }
                            if ($passenger->is_verified != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_NOT_VERIFIED')
                                ];
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('USER_NOT_EXIST')
                            ];
                        }
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * ResetPassword Action for reset password
     */

    public function actionResetPassword() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['ResetPasswordForm'])) {
//$postdata = $_POST['ResetPasswordForm']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['ResetPasswordForm']);
                if (!empty($postdata['phone'])) {
                    $passenger = Passengers::find()->where(['phone' => $postdata['phone'], 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();

                    if ($passenger != null) {

                        if (!empty($postdata['new_password']) && !empty($postdata['confirm_password'])) {
                            if ($postdata['new_password'] != $postdata['confirm_password']) {
                                return [
                                    'code' => 201, // two password not match
                                    'message' => $this->getConfigureValueByKey('PASSWORD_NOT_MATCH')
                                ];
                            } else {
                                $passenger_device = PassengersDevices::find()
                                                ->where(['passenger_id' => $passenger->id,
                                                    'passenger_device_id' => $postdata['passenger_device_id'], 'passenger_device_token' => $postdata['passenger_device_token']])->one();
                                if ($passenger_device != null) {

                                    $passenger->password = $postdata['confirm_password'];
                                    if ($passenger->save()) {
                                        return [
                                            'code' => 200, // password reset successfully
                                            'passenger_data' => [
                                                'passenger_id' => base64_encode($passenger->id),
                                                'passenger_device_id' => base64_encode($postdata['passenger_device_id']),
                                                'passenger_device_token' => base64_encode($postdata['passenger_device_token'])
                                            ],
                                            'message' => $this->getConfigureValueByKey('PASSWORD_RESET_SUCCESS')
                                        ];
                                    } else {
                                        return [
                                            'code' => 202, // passenger device data not save
                                            'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                        ];
                                    }
                                } else {
                                    return [
                                        'code' => 999, // invalide access
                                        'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                                    ];
                                }
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        }
                    } else {
                        $passenger = Passengers::findOne(['phone' => $postdata['phone'], 'is_delete' => NOT_DELETED]);

                        if ($passenger != null) {

                            if ($passenger->is_active != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_INACTIVE')
                                ];
                            }
                            if ($passenger->is_verified != ACTIVE) {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('USER_NOT_VERIFIED')
                                ];
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('USER_NOT_EXIST')
                            ];
                        }
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * ChangePassword Action for change password
     */

    public function actionChangePassword() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['ChangePasswordForm'])) {
                $postdata = $_POST['ChangePasswordForm']; /* call for data decrypt *///$postdata = $this->getDecryptData($_POST['ChangePasswordForm']);

                if (!empty($postdata['passenger_device_id']) && !empty($postdata['access_token'])) {

                    $passenger_device = PassengersDevices::find()
                                    ->where(['passenger_device_id' => $postdata['passenger_device_id'], 'passenger_device_token' => $postdata['access_token']])->one();
                    if ($passenger_device != null) {
                        if (!empty($postdata['old_password']) && !empty($postdata['new_password']) && !empty($postdata['confirm_password'])) {
                            if ($postdata['new_password'] != $postdata['confirm_password']) {
                                return [
                                    'code' => 201, // two password not match
                                    'message' => $this->getConfigureValueByKey('PASSWORD_NOT_MATCH')
                                ];
                            } else {
                                $passenger = Passengers::find()->where(['phone' => $postdata['phone'], 'is_active' => ACTIVE, 'is_delete' => INACTIVE])->one();
                                if ($passenger != null) {
                                    if ($passenger->password != $postdata['old_password']) {
                                        return [
                                            'code' => 201, // old password not match
                                            'message' => $this->getConfigureValueByKey('OLD_PASSWORD_NOT_MATCH')
                                        ];
                                    } else {
                                        $passenger->password = $postdata['confirm_password'];

                                        if ($passenger->save()) {
                                            return [
                                                'code' => 200, // password change successfully
                                                'passenger_data' => [
                                                    'passenger_id' => $passenger->id,
                                                    'passenger_device_id' => $postdata['passenger_device_id'],
                                                    'passenger_device_token' => $postdata['access_token']
                                                ],
                                                'message' => $this->getConfigureValueByKey('PASSWORD_CHANGE_SUCCESS')
                                            ];
                                        } else {
                                            return [
                                                'code' => 202, // passenger device data not save
                                                'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                            ];
                                        }
                                    }
                                } else {
                                    return [
                                        'code' => 999, // invalide access
                                        'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                                    ];
                                }
                            }
                        } else {
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        }
                    } else {
                        return [
                            'code' => 999, // invalide access
                            'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    /*
     * passenger_device function for save data for passenger device 
     */

    public function passenger_device($passenger, $postdata) {

        $passenger_device = PassengersDevices::find()
                ->where(['passenger_id' => $passenger->id,
                    'passenger_device_id' => $postdata['passenger_device_id']])
                ->one();
        if ($passenger_device != null) {
            $passenger_device->passenger_id = $passenger->id;
            $passenger_device->passenger_device_id = $postdata['passenger_device_id'];
            $passenger_device->passenger_device_token = Yii::$app->security->generateRandomString();
            $passenger_device->fcm_token = isset($postdata['fcm_token']) ? $postdata['fcm_token'] : 'test token';
            $passenger_device->device_platform = isset($postdata['device_platform']) ? $postdata['device_platform'] : 'android';
            $passenger_device->created_by = $passenger->id;
            $passenger_device->updated_by = $passenger->id;
            $passenger_device->is_active = ACTIVE;
            $passenger_device->device_date = date("Y-m-d H:i:s");
            $passenger_device->is_delete = NOT_DELETED;
            $passenger_device->ip_address = $_SERVER['REMOTE_ADDR'];
//$passenger_device->created_date = date("Y-m-d H:i:s");
            $passenger_device->updated_date = date("Y-m-d H:i:s");
            if ($passenger_device->validate()) {
                if ($passenger_device->save()) {
                    return $passenger_device;
                } else {
                    return false;
                }
            } else {
                return [
                    'code' => 201, //invalid input
                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                ];
            }
        } else {
            $passenger_device = new PassengersDevices();
            $passenger_device->passenger_id = $passenger->id;
            $passenger_device->passenger_device_id = $postdata['passenger_device_id'];
            $passenger_device->passenger_device_token = Yii::$app->security->generateRandomString();
            $passenger_device->fcm_token = isset($postdata['fcm_token']) ? $postdata['fcm_token'] : 'test token';
            $passenger_device->device_platform = isset($postdata['device_platform']) ? $postdata['device_platform'] : 'android';
            $passenger_device->created_by = $passenger->id;
            $passenger_device->updated_by = $passenger->id;
            $passenger_device->is_active = ACTIVE;
            $passenger_device->device_date = date("Y-m-d H:i:s");
            $passenger_device->is_delete = NOT_DELETED;
            $passenger_device->ip_address = $_SERVER['REMOTE_ADDR'];
            $passenger_device->created_date = date("Y-m-d H:i:s");
            $passenger_device->updated_date = date("Y-m-d H:i:s");

            if ($passenger_device->validate()) {
                if ($passenger_device->save()) {
                    return $passenger_device;
                } else {
                    return [
                        'code' => 202, // passenger device data not save
                        'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                    ];
                }
            } else {
                return [
                    'code' => 201, //invalid input
                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                ];
            }
        }
    }

    public function passenger_device_guest($passenger, $postdata) {

        $passenger_device = PassengersDevices::find()
                ->where(['passenger_id' => $passenger->id,
                    'passenger_device_id' => $postdata['passenger_device_id']])
                ->one();
        if ($passenger_device != null) {
            $passenger_device->passenger_id = $passenger->id;
            $passenger_device->passenger_device_id = $postdata['passenger_device_id'];
            $passenger_device->passenger_device_token = Yii::$app->security->generateRandomString();
            $passenger_device->created_by = $passenger->id;
            $passenger_device->updated_by = $passenger->id;
            $passenger_device->is_active = ACTIVE;
            $passenger_device->device_date = date("Y-m-d H:i:s");
            $passenger_device->is_delete = NOT_DELETED;
            $passenger_device->ip_address = $_SERVER['REMOTE_ADDR'];
//$passenger_device->created_date = date("Y-m-d H:i:s");
            $passenger_device->updated_date = date("Y-m-d H:i:s");
            if ($passenger_device->validate()) {
                if ($passenger_device->save()) {
                    return [
                        'code' => 200, // passenger device data not save
                        'message' => $this->getConfigureValueByKey('GUEST_SUCCESS_LOGIN'),
                        'data' => [
                            'id' => base64_encode($passenger->id),
                            'passenger_device_id' => base64_encode($postdata['passenger_device_id']),
                            'access_token' => base64_encode($passenger_device->passenger_device_token),
                        ],
                    ];
                } else {
                    return [
                        'code' => 202, // passenger device data not save
                        'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                    ];
                }
            } else {
                return [
                    'code' => 201, //invalid input
                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                ];
            }
        } else {
            $passenger_device = new PassengersDevices();
            $passenger_device->passenger_id = $passenger->id;
            $passenger_device->passenger_device_id = $postdata['passenger_device_id'];
            $passenger_device->passenger_device_token = Yii::$app->security->generateRandomString();
            $passenger_device->created_by = $passenger->id;
            $passenger_device->updated_by = $passenger->id;
            $passenger_device->is_active = ACTIVE;
            $passenger_device->device_date = date("Y-m-d H:i:s");
            $passenger_device->is_delete = NOT_DELETED;
            $passenger_device->ip_address = $_SERVER['REMOTE_ADDR'];
            $passenger_device->created_date = date("Y-m-d H:i:s");
            $passenger_device->updated_date = date("Y-m-d H:i:s");

            if ($passenger_device->validate()) {
                if ($passenger_device->save()) {
                    return [
                        'code' => 200, // passenger device data not save
                        'message' => $this->getConfigureValueByKey('GUEST_SUCCESS_LOGIN'),
                        'data' => [
                            'id' => base64_encode($passenger->id),
                            'passenger_device_id' => base64_encode($postdata['passenger_device_id']),
                            'access_token' => base64_encode($passenger_device->passenger_device_token),
                        ],
                    ];
                } else {
                    return [
                        'code' => 202, // passenger device data not save
                        'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                    ];
                }
            } else {
                return [
                    'code' => 201, //invalid input
                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                ];
            }
        }
    }

    /*
     * Signup Action for new passenger signup or register
     */

    public function actionSignup() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengersForm'])) {
//$postdata = $_POST['PassengersForm']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['PassengersForm']);
                if (!empty($postdata['name']) && !empty($postdata['phone']) && !empty($postdata['email']) && !empty($postdata['password']) && !empty($postdata['confirm_password'])) {

                    $passenger = Passengers::find()->where(['phone' => $postdata['phone']])->orWhere(['email' => $postdata['email']])->andWhere(['is_delete' => INACTIVE])->one();

                    if ($passenger != null) {
                        if ($passenger->is_active == INACTIVE) {
                            return [
                                'code' => 201, // inactive
                                'message' => $this->getConfigureValueByKey('USER_INACTIVE')
                            ];
                        }
                        if ($passenger->phone == $postdata['phone']) {
                            return [
                                'code' => 203, //phone already exist
                                'message' => $this->getConfigureValueByKey('PHONE_EXIST')
                            ];
                        }
                        if ($passenger->email == $postdata['email']) {
                            return [
                                'code' => 204, //email already exist
                                'message' => $this->getConfigureValueByKey('EMAIL_EXIST')
                            ];
                        }
                    } else {
                        if ($postdata['password'] != $postdata['confirm_password']) {
                            return [
                                'code' => 201, // two password not match
                                'message' => $this->getConfigureValueByKey('PASSWORD_NOT_MATCH')
                            ];
                        } else {
                            $passenger = new Passengers();
                            $passenger->name = $postdata['name'];
                            $passenger->phone = $postdata['phone'];
                            $passenger->email = $postdata['email'];
                            $passenger->password = $postdata['password'];
                            $passenger->image = NULL; //$postdata['image'];
                            $passenger->image_path = 'default.png'; //$this->base64_to_image($postdata['image']);
//$passenger->image_path = dirname( \yii\helpers\Url::base(true) ).'/backend/web/uploads/passengers/'.$passenger_image;
//$passenger->balance = 0; //$passenger->created_by = 1;
//$passenger->updated_by = 1; 
                            $passenger->is_active = ACTIVE;
                            $passenger->is_verified = ACTIVE;
                            $passenger->is_delete = NOT_DELETED;
                            $passenger->ip_address = $_SERVER['REMOTE_ADDR'];
                            $passenger->created_date = date("Y-m-d H:i:s");
                            $passenger->updated_date = date("Y-m-d H:i:s");
                            $passenger->last_login = date("Y-m-d H:i:s");

                            if ($passenger->validate()) {
                                if ($passenger->save()) {
                                    $device = $this->passenger_device($passenger, $postdata);

                                    if ($device) {
                                        return [
                                            'code' => 200, // sign completed redirect login
                                            'message' => $this->getConfigureValueByKey('SIGNUP_SUCCESS'),
                                            'data' => [
                                                'id' => base64_encode($passenger->id),
                                                'passenger_device_id' => base64_encode($postdata['passenger_device_id']),
                                                'access_token' => base64_encode($device->passenger_device_token),
                                            ],
                                        ];
                                    } else {
                                        return [
                                            'code' => 202, // passenger device data not save
                                            'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                        ];
                                    }
                                } else {
                                    return [
                                        'code' => 202, // passenger device data not save
                                        'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                    ];
                                }
                            } else {
                                return [
                                    'code' => 201, //invalid input
                                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                                ];
                            }
                        }
                    }
                } else {

                    $passenger = Passengers::find()->where(['phone' => $postdata['phone']])->orWhere(['email' => $postdata['email']])->andWhere(['is_delete' => INACTIVE])->one();


                    if ($passenger == null) {
                        $guest = $this->getConfigureValueByKey('GUEST_INFO');

                        $passenger = new Passengers();
                        $passenger->name = $guest;
                        $passenger->phone = $postdata['phone'];
                        $passenger->email = $postdata['email'];
                        $passenger->password = $guest;
                        $passenger->image = NULL; //$postdata['image'];
                        $passenger->image_path = 'default.png';
//$passenger->balance = 0; //$passenger->created_by = 1;
//$passenger->updated_by = 1; 
                        $passenger->is_active = ACTIVE;
                        $passenger->is_verified = ACTIVE;
                        $passenger->is_delete = NOT_DELETED;
                        $passenger->ip_address = $_SERVER['REMOTE_ADDR'];
                        $passenger->created_date = date("Y-m-d H:i:s");
                        $passenger->updated_date = date("Y-m-d H:i:s");
                        $passenger->last_login = date("Y-m-d H:i:s");
                        $passenger->is_guest = ACTIVE;
                        $passenger->is_logged_in = ACTIVE;

                        if ($passenger->validate()) {
                            if ($passenger->save()) {
                                return $this->passenger_device_guest($passenger, $postdata);
                            } else {
                                $transaction->rollBack();
                                return [
                                    'code' => 202, // passenger device data not save
                                    'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                ];
                            }
                        } else {
                            $transaction->rollBack();
                            return [
                                'code' => 201, //invalid input
                                'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                            ];
                        }
                    } else {
                        if ($passenger->is_active == INACTIVE) {
                            return [
                                'code' => 201, // inactive
                                'message' => $this->getConfigureValueByKey('USER_INACTIVE')
                            ];
                        }
                        if ($passenger->phone == $postdata['phone']) {
                            return [
                                'code' => 203, //phone already exist
                                'message' => $this->getConfigureValueByKey('PHONE_EXIST')
                            ];
                        }
                        if ($passenger->email == $postdata['email']) {
                            return [
                                'code' => 204, //email already exist
                                'message' => $this->getConfigureValueByKey('EMAIL_EXIST')
                            ];
                        }
//if ($passenger->is_guest == 'N') {

                        /* } else {
                          $connection = \Yii::$app->db;
                          $transaction = $connection->beginTransaction();
                          $device = $this->passenger_device($passenger, $postdata, $transaction);
                          if ($device) {
                          return [
                          'code' => 200, // sign completed redirect login
                          'message' => $this->getConfigureValueByKey('SIGNUP_SUCCESS'),
                          'data' => [
                          'passenger_id' => $passenger->id,
                          'passenger_device_id' => $postdata['passenger_device_id'],
                          'passenger_device_token' => $device->passenger_device_token,
                          ],
                          ];
                          } else {
                          return [
                          'code' => 202, // passenger device data not save
                          'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                          ];
                          }
                          } */
                    }
                }
            } else {
                return [
                    'code' => 999, // invalide access
                    'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    public function base64_to_image($imageData) {

        $basePath = dirname(\Yii::$app->basePath);
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . 'backend' . DIRECTORY_SEPARATOR . 'web' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'passengers' . DIRECTORY_SEPARATOR . $imagename;
//echo $file;exit;
        file_put_contents($file, $image_base64);

        return $imagename;
    }

    public function actionLogout() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengersLogout'])) {
//                $postdata = $_POST['PassengersLogout']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['PassengersLogout']);
                if (isset($postdata) && !empty($postdata)) {
                    $passenger_device = PassengersDevices::findOne(['passenger_id' => $postdata['passenger_id'], 'passenger_device_id' => $postdata['passenger_device_id'], 'passenger_device_token' => $postdata['passenger_device_token']]);
                    if (isset($passenger_device)) {
                        $passenger_device->passenger_device_token = NULL;
                        $passenger_device->updated_date = date("Y-m-d H:i:s");
                        $passenger_device->ip_address = $_SERVER['REMOTE_ADDR'];

                        if ($passenger_device->save(false)) {
                            $passenger = Passengers::findOne(['id' => $passenger_device->passenger_id]);
                            $passenger->is_logged_in = INACTIVE;
                            if ($passenger->save(false)) {
                                return [
                                    'code' => 200, // sign completed redirect login
                                    'passenger_data' => [
                                        'passenger_id' => $postdata['passenger_id'],
                                        'passenger_device_id' => $postdata['passenger_device_id'],
                                        'passenger_device_token' => $postdata['passenger_device_token']
                                    ],
                                    'message' => $this->getConfigureValueByKey('LOGOUT_SUCCESS')
                                ];
                            } else {
                                return [
                                    'code' => 202, // passenger device data not save
                                    'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                                ];
                            }
                        } else {
                            return [
                                'code' => 202, // passenger device data not save
                                'message' => $this->getConfigureValueByKey('SERVER_ERROR')
                            ];
                        }
                    } else {
                        return [
                            'code' => 999, // invalide access
                            'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                        ];
                    }
                } else {
                    return [
                        'code' => 999, // invalide access
                        'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
                    ];
                }
            } else {
                return [
                    'code' => 201, //invalid input
                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    public function actionPassengerOrderRequestDetails() {
        try {
            if (Yii::$app->request->isPost && isset($_POST['PassengerOrderRequestDetails'])) {
//$postdata = $_POST['PassengerOrderRequestDetails']; /* call for data decrypt */ //
                $postdata = $this->getDecryptData($_POST['PassengerOrderRequestDetails']);
                $passenger_device = PassengersDevices::findOne(['passenger_id' => $postdata['passenger_id'], 'passenger_device_id' => $postdata['passenger_device_id'], 'passenger_device_token' => $postdata['passenger_device_token']]);
                if (isset($passenger_device)) {
                    $passenger_order = $this->getPassengerOrderDetails($postdata['passenger_id']);
                    if ($passenger_order) {
                        return [
                            'code' => 200,
                            'passenger_orders' => $passenger_order,
                            'driver_data' => [
                                'passenger_id' => base64_encode($postdata['passenger_id']),
                                'passenger_device_id' => base64_encode($postdata['passenger_device_id']),
                                'passenger_device_token' => base64_encode($postdata['passenger_device_token'])
                            ],
                            'message' => '', //$this->getConfigureValueByKey('USER_VERIFIED')
                        ];
                    } else {
                        return [
                            'code' => 202, // invalide access
                            'message' => $this->getConfigureValueByKey('NO_REQUEST')
                        ];
                    }
                } else {
                    return [
                        'code' => 201, //invalid input
                        'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            } else {
                return [
                    'code' => 201, //invalid input
                    'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => 999, // invalide access
                'message' => $this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

    public function getPassengerOrderDetails($passenger_id) {
        $passenger_order = PassengersOrders::find()->where(['passenger_id' => $passenger_id,
                    'order_status' => ['Completed']])->orderBy(['order_date' => SORT_DESC])->limit(10)->all();
        $data = '';
        foreach ($passenger_order as $val) {
            $datetime1 = new \DateTime($val->order_start_time);
            $datetime2 = new \DateTime($val->order_end_time);
            $interval = $datetime1->diff($datetime2);
            $hours = $interval->format('%h') . ":" . $interval->format('%i') . ":" . $interval->format('%s');

            $timesplit = explode(':', $hours);
            $minutes = ($timesplit[0] * 60) + ($timesplit[1]) + ($timesplit[2] > 30 ? 1 : 0);

            $data[] = [
                'order_id' => base64_encode($val->id),
                'passenger_id' => base64_encode($val->passenger_id),
                'passenger_name' => base64_encode($val->passenger->name),
                'passenger_image' => base64_encode(dirname(\yii\helpers\Url::base(true)) . '/backend/web/uploads/passengers/' . $val->passenger->image_path),
//                'passenger_image' => isset($val->passenger->image) ? $val->passenger->image : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAgAElEQVR4Xu1dB3hUVfY/970pyUx6AyIlBVCKDRQLgsAqRUAS2rrqurZd/4pSggF03TW66uqq7EoQhZVgd5dUUGzoWigixAJKEaSX9D6TyZT37v+7EwIpr868N+XNXL98xMy9555yf3PbOeciCBfVNTBz5swBNLBjWYDrAfBwBBAFAEaMwYgAGTCAEQAMCJG/YQwADgRgBwR28jsAsmPADoRRMyD8A2Bqi4Nhvt64ceMZ1ZkP8Q5QiMuvqPizZk0bxLLUSApRv0cAkwGAUrQDAWIYoBgD+yaAa3dJyYfHfdWv1vsJA8RLC8/KnvF3hNDdGOMEhJDOS3JKNXcA4Hpg0XNFZWX/UopoKNIJA0Sm1WfMmNFPR8FdCGAhIBQvs7mfquPTDIYXAag3S0tL6/zERFB2GwaIRLPNmTO9P3ZR3wFCSRKbBFw1sr9BCJ222Z2XbNq0qSHgGAxAhsIAETHK7JkzHsAYPY0QxAWg/TxmCWOowCx+uGTDhnc9JhICDcMA4THynBkzLsY02hMCY8CJaP0FhYWFNSEgq2wRwwDpprKsrKxMGsGHCMFg2doM4gYYYFerzX7DRx991BzEYijOehggnVQ6OyvrcaAgT3EtBxFBjNGdxaWlbwQRy6qyGgYIAIwbNy4iMT5uP0KQpqq2g4Q4BvwDRRuuLiwsdAQJy6qxGfIAmXXzzVcgHbVLNQ0HMWGHix20cePGX4NYBK9ZD2mAZGffPJlG1CZf3nh7bTHfEmAwYkcUF28MhcMKTs2GLEBmz8x6CABW+Ha8BWdvDGbnlpZuLAxO7r3jOiQBMisray6i4L/eqS50WrsdKCndwOLi4iOhI3W7pCEHkFlZ07MAUSUIoZCT3dvBjVi4orCs7Dtv6QRT+5AaJHPGjYvCCXEtwWSgQOMV0WW6wkJgAo0vtfgJGYBMmTLFaIow1iAE0WopMxToYoCK4pKy1FCQNaSWWLOyZ3yCEJoYKoZVU06M8dPFpRseU7OPQKEdEjPInOzpEzCiPw8UpWuBD0TbUwoLP9K8/1YoAISaNTOrDoG2vHH9DTKM4VhxaVm6v/lQu3/NA2RW9s1/RIhao7YiQ5F+KJxqaR4gs2dmkSQI4aKKBrC1qGQDSUCh2aJpgMzKyspCFJRq1noBIBjb5kgr+VC7SSK0DZDsrH0IwZAAGEcaZgF/XFSyYYpWBdQ0QMLLK98M26KSMhoAWN/05tteNAuQ7OzswTTCv8hRJ0IU0DQFNEUBUAgAA2DMAknlRtyRuv/Ioe3vusSzpucPAJGZDAIiG8MywDBEXnnbNlTfGF345ZcWf8uoRv+aBcjs7Kz3AcE0JZRGUQQ4NOh0urODjAysnqpjWRbcPwwLLoY5BygleOCj0THoCX8E3BT5QT3z1bWDux3wLhfj/iG/K1FYFu4qKSt7XQlagUZDuwBR+fSKDEwCHJ2OBr1eL2jXjpmHgMfpdLq/pT0pBASkL4o6Pxvw0SF9ulwu9w/Lts9+KpaKIo26n4QBouCoIaAhA9j9TU5RnLNM5+7I4HU4nO5Zh6sQOoQembmEChn8hAbDMOB0utQGAycrRSVlmhxLmhQqOzt7CI3wPgXHvkekCGDI4DYYDCDkXO9e/zMstLW1ufuJjIwQBRhpY7c73KBQeXaQJDui9UYtxrBrEiCzsm6+H1HUKkmW9WElAha9Xufez8gt7lmCYcHhXqIFnrc5C+y0kpKNJHxZU0WTAJk9c0YJAMoOZEuR5VNERIToMozI0Nra6t5HBHRB+IWi4g25Ac2jB8xpFCBZhwBgoAf68HkTsgwzGNr3GR0nY2S2IJt5sj8JmoLgg6LisulBw69ERrUKkAD/uuW2DtmrkKNXstEOvoJ/LSrZMCj4+BbmOAwQrVnUf/IwRSVlgfI+imJaCANEMVWGCWnxqFdzABk5cqQ+fUC/kE+Z6Q+4hgHiD63L7HNOdvYEjHA4vFam3pSorkWnRc3NIHNmZT2IMeQrYfAwDXkaQE4mo/D994/KaxXYtTUHkNmzZjwLGC0NbLVrlDsGjy3asGGLlqTTHkCys94CBLdryUjBIgvLuG4r2fCBpp500yJAvgAE44JlUGmJT5aFpSVlZf/QkkyaA8ismTMOIUBBcYuupYF0Vpb8opKy+VqSS3sAyc46gRD005KRgkUWDLisuGRDQPvAydWl5gAye+aMUwDoArmKCNdXQAMYvioqLdPU8laDAMk6CQB9FTB3mIR8DWwuKinTVP5jzQFk1syskygMEPlDW4kWGD4oKtWWR6/2ACJzD7J07iiINLa7mpNEJiT6lXVn+GDB7mTA2uaEY9UtcLSyCQ6faQCHM/CCleSMbVOEHjJT4yG9dyz0T4oCc4Qe9Lr2TC7uWPezGU6IDhpa7LBiw/fSyWMoKSotmyW9QeDX1BxAZs+ccRwA9Zei+sWzr4SU2EgpVXvUabY54efjtXDwZD2crrVAc6vdIzpqNUqIjoTUxCgYMiARhvZPBJNBfhQj4e2HX6vhP18dkMQmRvBecXHZrZIqB0klDQIk6xgADBDT/+B+CXDPxOFi1SR/zrDYPbt8tvsUbP3phOR2SlUkMe8Tr8iAa4f0BgNNu2cDpcrzhbugttkmSg5jeKO4tOxO0YpBVEE5LQaI0LNmZu1DIJ5u9Mk7RkOEUQ+mmBhRzjuyhmCGOZv3igHG5SJJpnjbkjb7TzbAj0eqYc+RaqGqov1zVaApBJcP7AWXZabAoNQ4QRpk+UiTiEUCHDd4KEA8WVdszc09sqzUNdvgH4WSnpJ/saik7GGPBArQRpoDyJyZMzZhQDcJ6Tsx1gRLZl8B5jjhgSXVZk67HZxtbYLZRch+Zu0nP8HJmhaP48sJKIYMSIZbxg527xv4ijtfV0QE6A0GqSKcq2ezWIAl4O9Wlq39miSaFCl4XlHJhoBLliHGtdDnmgPIrFkzViKM5gkJTTbmKYkxYDSZvNEdZ1tM8lO5XOB0ODgHGplZTtVZ4X8/noB9x2sl9X/F4D5w/SV9efdLZHbQGQxA6/WSkkAIddpmsbTPjt3K8epmWPX+j4L8MpidUlq68WNJQgVJJe0BJPvmHISoF/n0r6MpeOoPo8EcG+teZqheMIa21lbeJdmPR2vhgx2/Qktr1xivuKgImHP9hTCwd2xPFs8umQjAlX7N2t7aCi4Hd7zZ0rVfiwAEXVhaWnpQdZ36sAPNAWR29s0zAVHFfDpM6x0L90+9VLHllRxbsSTzocMBLnvXEy+ylalqbIWN3x6GqAgDTBo5ABKjI3qQ1huN7pmC7CPUKo62Nvdykas8894OaOoG5M71EpJSDGvWrAmiVCziWtQcQMSyKt4wIg0mj8qECLNZXDsq1iBgId/W5F+hQsBgNJvdG2tfFDJ7EL64yntfHoAfD1fzshEOufWFhRToQ+hdkNw5o6BvapL7VCcQijvtqNPZY1ASULhPnoRylqogAOGlzWrlpPzD4Wr4z5f8dyJhgKhgEDVICgHkuXvGuo92fbL/kCkc2Ry7b/RVXEKJsURmNFtLC2c1chdC7kT4ShggYtoNkM9FAUI26D7+Zg4Q1YiyQbLEk7sQrkJmu2UF/BG1YYCIqjcwKoQB4rkdCAham5p4CfCeZGGoKiot6+15z4HZUnObdKLm2TOzyE4ymUvlZIlFjngF3yMITFv5jCtrY6MnAPm8qLTsBp8x6aOONAmQP931u331TTbO123dAFHoBt1HNvJ5N54AJDUx6sMV/357qs+ZVblDTQHkTPlqE2XX1ZR+tc/0eflhTtWFASI+ovgAQp5geGQd9x4k+9qBcPWQPtY2a0vCsLl5mslsqSmAVG5dewYQ6vP9L2eg4INyXoCYwpt0QZTwAaTB0gbP/ncnZ9v5My6HC5KiyWd7MqfmXCoOw+CooRmAVGxd+xeE0JNE7TWNVnhiLXf20Sd+PxoSkhPCp1gC45MPIL+cqoeCT37mbPns3WPOv2/CwsyB03NKgwMCwlxqBiCV29Y2AiC34xI5iXlo+fuckt856WIYOSwtDBAPALL5+2Pw2Q/csS5k6Xq+4MrMqYv7hAESIBqo+GZdGmJxl5ywD764kZO7MRf3hbk3XBaQF4UBok7gm0He+mwv/Hy8rgebFELw97vHdPk7TaPUtMmLKgJFJk/50MQMcmbb2hwKUBcP3pyXNoHD1dPPaUCvWFh86xif+TZ5ahh/tuMDyFPv7oAWW8/996UZyXDr+K6HhhihmwbetOgjf8qhRN+aAEjl1nVHAOH0zgp5f+t++ORb8lRh10KCjp6//0YwRPT0llVCoVqgwQcQvkvC/5t6qTsJRJeCoShzWs6cYNeHNgCyraBHsJvF5oBlq7hjd578wxhISIoPdtupxj8XQBiM4VEeNxMSvmzUd3XBRwDHM6bmpKnGpI8IaxYgRH98+5DbfjMMrrks00cqDr5uuABSuOUglB+s5BTmmbuuc6cN6l4yp+YE/fgKegGIUSo5ZhAhgOh1NPxzgeYufRVDIhdA+JZXBh0Ff/vDdZx9hwGimEm8I8QHkMdWfwqNFu7ouPyc6eGjXh61dwcISZ735DvfcNbumxQFD80YEQaId0NY3dZ8AFld9i38dLiKs/OFvx0NA/smqstYkFLvDhASRUiiCbnKFYN6wZyxF3J91Jw5NYcjoD64lKKNJdb2ggrA0MPV+pNvD8L7W7kNu+i3oyEzDBDO0dodILuP1MC7X+znrHvLuIvg8swUjs/wB5lTF08PLjj05FYbANm27m0AfFt38Y6crofl/9nKaaOc310HGakJwW4/VfjvDpCfj9XCW5/v4+zrL7deDVGRPfNvYYxzB05b/IIqDPqQqCYAUrW94FqMYVt3vQm5nJDLwvQ+4aNerrHWHSD7TtTBG5v3cg7Lri4m56sw4Lp88NQlwom0fDjQPe1KEwA5U746ibLra7iUwHfUm3vbGBjQOwwQKQA5cLIe1n3K7aTIAxBsiAdzv2tzxBP6ejpyfdROEwAhuqrcVkAyDUR11xsfQJbcPhb691Im9aiPbOWzbrrPIIdON8BrH//Uo//k2Eh4ePaVXHxVZU7N0UT4rYYAsvY9AHRLd2u9tnEX/Hiop8/cst9fD31Tgv6QRXHQkNSprd2SNhyuaIQ1H+7p0deNI9Lghsu5XprAeZlTFz+hOHN+IKgZgODtyyOrcFyPjGf7jlbDqpIdPVT76B3jIDVZPLO7H2zi1y4ZhoG2bml/yONBr27a3YOvhdkjoU9CzwR8Wrgg7BBWMwBpX2at3QeAuriVNlvb4NFXP+1h3D//YRz0SQoDpLtiuDIr8iWufuzWqyG65wnWB5lTc4L+eFeTAKnbUTDUyQDZTZ4DPnF5J67v3ctjd42H3gnuENFw6aQBruTVp2paIH/jDz309Pe7SNhAl+9Y7GKh34XTc05rRamamkHObtaJT8TVHQYiR70Pr/wQ7I6usSF/vXsCpMT32NNrxa4ey8H1PsiZOgu8VNb1rUIyc5AZpHNBGN7ImJYTfmHKY+37qGHl1gILIDi3OH72rS/hVHXXbIGP3/MbSI7zbwJrH6lDVjdkg0426p1LVYMVlpd81+VvfZOj4aGbL+/0N+2E2XYBvSztBUnlhi/WxdkNuKGD3dc3fQ/lB0514T7v3t9AUmwYIN1NyuXJW9PUCi8Udc0SM2Z4X5h2Vca55hmnzAZ0332aevqACKe5JVaHxerLV8c67Hpyk5v23YHTsG5T12/AJ/94AyTEKP/CVJB8h3CyyZd2lOuNwgdvHgH9kt1L1D1t1uYrtZQLS/MzSGcBz2x5faTT5fhqcf6HXaaLv/3pRoiP9uwJ6GAGgRDvfImrufJhPXfP2FpgHSMzpy/z/ZO+PjSAZmeQ7jrkc4n3oa4DvivyGKnDJs07REt3HUKGCRmAVGwrqEcAYecrgdFA3gURe/GKNKcoypo+ZWFIHAGGDEAqtxU8BQB/DvivcT8yKJS0ujNbNEXnp01ZMN+PrPqs6xACyGvDAaieHnc+U3VgdyT2LkiXjauOuj5j0kLhJ28DW1zJ3IUMQPD69XT1BRY7BlDviVjJag+8ijL2HzhjV7MO5eV1vSwJPJEU4ShkAEK0VbGt4CgCCPpcTYpYvhuRNoul/S13sYKgOvOmnF5i1bTyeUgB5MzWgmcoBI9oxXhKyiF1/6EzGN4ZcOODtyvZdyDTCimA7N273pDYaLEHskH8wRtXDAgfH6FyvNshf0gBhAhduW2tAwDp/TEQA7VP8qotuSQUKwgQkzF1UWA8MC/GrEKfhx5AthY8AgieUUh/miAjdXmFKOqpjCkL/6IJoSUKEXIAqd3+xgUuzJzUsh+aRNu7qzFOJ7RZrZKaRBroAak3LtC0a0l3RYQcQNqXWQW8z0RLGikaqsTl3h7ef5zXQEgCpGLr2ikIoQ81NM49EkXO5aDeaLyl/w3z/utRR0HcKCQBcnYW6fGmSBDb0SPWpfpeEeKhdnoVsqdYHYJXbFv7IgKU49HI0kAjObMHRVHvpU9ZeKsGxJYtQsjOICe3v5agx1TPFyllqzA4GxC3duJeIqUYaEjsNzmnXkpdrdUJWYAQQ1ZtLSjHCEZqzaii8mAM1qYm0WqkAkXTh9MnLxgoqbIGK4U0QEJ1LyLZ7woAIk3m5NTx99VqcOxLEinkAVK1vaAYY5gpSVsaqCTHrYSiqO3pUxaO1oDYHosQ8gA5U77aRNn10m7KPFZz4DSU6lZCOG6zNhu1moxBqkVCHiDte5F1uRjhf0hVWrDWczmdYJd4a07rqOfTJi1cEqyyKsV3GCAAgAFQ1ba11QAoSSnFBhodOce6ANCSOTUnnLg47I90fhjXfvPvIS6W5n5nLNBGuwf8cOXc5SOjM5qGDbjh/zSrCznqC88gnbRVtb2gBGPIlqPAYKhLMpWQW3MphabpL9ImL5ggpW4o1AkDpJOVcV4eVTWxfzVg0NT70JLd2RFYyy3fxM6dW9g103coIIFHxjBAuinm8ObVsWaTvlErY0KOv5VFx0RdOik3ZE70pNg4DBAOLVVuK5gBAGVSFBjIdbgew+Hjl9Lr7kqfOP/1QJbHH7yFAcKj9Yrt655EGAdt9JycUytE08szJi9Y7I8BGOh9hgEiYKHKbQVrAeDuQDdid/7c4CAPcWJxj35EU8UZkxfODjYZfcVvGCAimq7cWvApILjRVwZRoh+p+w5EUeUZUxZyvuOsBB9aoBEGiAQrVm5b9wEAniqhqt+rkJtycmMuViia2p4+ObT9rMR0RD4PA0SKlog7yrZ1j2PAeRKr+6Wa1PShOh31rwGTFi7yC5NB1mkYIDIMVrF1bS5CKCB9tqT6WVE6+tn0SQvC2SUl2j0MEImK6qh26svVT9M63aMIBY7qpLqwU7Tuv+mT598iU+SQrh44Vg4CM7Q7NRawJAsh62JAZ/B/gkY5ea2Iit/a1UznhUhmdiWGVBggMrRYuW1tKQDK6mjSWNsAcUn+e7RKyrKKgJmiqHNSIgp2Z0zJuUyG2CFdNQwQieav2lKQgSn4tfvBhs1qc+e1NUf79klpZ1sbONraeLl3OhmgKAQ0fR4cHZUpg+6a9Bvn75AoekhXCwNEgvndTow39ud14CMXc5UnKiApNRl0Oh2ouT8hfZGjXL63PMjnLU2tEB1rBqFt0glTs378+DwJD4JIUJCGq4QBIsG4lVsLdgCCq8SqWpotYGlsgbjEOIgwK//EtHszTtzWOW7IWQxgbbFBRIQe9AbxBOwIoRMZNy0ijwmJX7eLCa7hz8MAETFu5daCLwDBODljoOZMNdhtdohJiIWo2KguewA5dDrX5XM8JEspS3MrGAw6MMt8952iqIr0KQtTPeUpFNqFASJg5apt6z7BgCd6MhCcDifUVtQA42JAb9C7gWKOjpJ/NUv8qlpagMweHYVhMbRabOByMu49RlRMpMcgpChqX/qUhcM8kTEU2oQBwmHlU5+tTNRHmo5hAK/fAnc5XVBXWQsEMKSQ/Ul0fAxEmiNBp+ffr5CNP8l+SI5xyb7C5WLdSyjyOyk6HeWeMTqfUHkzYFGEIS3jNw8e94aGFtuGAdLNqpVbC14FgHsBKfsaLhnwLQ3N0NLYNfQVUcg9yMkpmDk2CliGhTZLK7Q0WQCT/8jmolMxmY1gMOrVOAjANE1/kzZ5QUjnweoO8jBAAODoF+siTAZ2Hga3G0nPc1GFvxrJbEI29DZLqxsQQoXW0RBpNrmXaIzTAWQvonahEPUcQxuXD5x0P3lHJaRLSAPEfbdBw05/x6CTZZOlyQItjc2AgCzBosEcE8U5S7hz6kqI81BiVCOEGJo2ZA+YNO99JegFI42QAkjF1jXDANNzEEJzAMHQYDQYARPJrUsylfiyIAq1AEJv6A26j/pNeDBkHh/SLECOfrEuzhjpykROahmi0CytufbbCEhc/r3no3S6Y62Yvv/durj9N6Smnh4/frx/GVLhG0MTAFm/fr3BGh/xxHc1lqEIs6PvGRQf39tZpfpeQgV7yCIp11FRFnGJlQ+6zLCmot1pM0pPM3aG/WxgrKmhr9n1wAPTbmuQSCZgqwUdQJZvWD9wb6MtenhC9Jv7GqzDba6eS42cUcMhtWlPwCpdacbIK7UELP4ohxNGwCu7j/B2TQZYFOWwHKhvvO7q1CRmxR33/uwPPj3tM+AB8teidyYda3Lk1FjbLraxbG8nw6K0uGhBP6M/jRwGgy0/eaqToGxH9iZkX0JSjHa+VFRbmJ/jRsLrPx0W7OZkQ825z8mAizboW+0Mu3Nc/95fP33L7Y+rzaM39AMKIKvXr479pt51jckU9eefapuv63YFcE7OjIRowYOc2UMHwjVxALjuoDe6Ceq2xBXeZbcDQzbzKp160QnpUO6Mg3f2HeXVFY0QHKsXPy1OjaQPNbTh3EsTYc/KP+byE/SxVfwOkPXr19MfN9RuPtLKXOlkpd1cX5GaDHU2flfvCel9YdrgNGCPfe1jdQZmd2R2cd/G2+2S3yWUIgmdMQa2VjZB8S8neKsbaIDDtednECl09RQ4eht1h0tS+12M5s717XFdNwb9ApCn/7N6xIFG10OnbeydduF7Mk59Xt23F1RZW3l1nREfAw+OugTYU7sAXDYpNgm5OmQZRmYZ4jZPTsM6XFgkK4LWA505Dl7cuRdOtfDbQocAjtbLA0h3HvpG6LYkGun8tQ8sLJTMn0IVfQqQF9575enSM65HveU92qiHJFOE4LT+/MTRgFsqANcd8ra7kGpPNvsOu130CJmKTwOUPAgWfb5LUD911mZodUh7TVeKorP6RHz22J0LfJanTHWAPP/m8+adlsg1VTZ8q5JzZXp8tKA+l0+6zv15eJklZdjx12mPv3e1zzadTsrowe1jVAwgFU114OrkiewdN+dbpxipr+J1xtvfmT//lFI0ueioBpClq1fHHmZcuyps7CA1BBADSN71oyAmwgBs4zGARv41shq8aZ0mNsYBk3gROJwuWPy/ckFxTzXUqBqRFaenmwaa8eBX788VPwnwwDCqAGTWypUvVdrxfA/4kdzkkl6J0CLguNcvJgoWXXMZYJYBfGKbZLrhiuIaQBdcAUhvgk8On4CPD50AlhwAsOSna1sKARz3cv8hzk17jTgjVfJZTi7xmFC0KAqQ+eteGvRjA7Wfwcq6inNJ3MscCSaR0NJzy6zKnwDagv5SV1HDe0yM0gPV/xp386e+3gX1tq77C+Kc73BicGEMDpcTqlp8+9TKULP+qjfn5+z0WL5uDRUDyC2vvJx/spV9UCnGxOgkRBghNtIgWO3x66+E2AgjYNYJ+MQ3YiTDn0vQAEodCchgds8auZ9uE1w+EV+fA9W1wGIld5/iTMbo6cL/PfzwXPGa4jUUAcjN+fmf1znA5+/aie1Dpl+YBuPT+rq1wFb9DGCrF9dIuAa/BvRmoC4Y6f78TIsVXtj+g6C2jjacDw5zMU5gGN+5w0TpqIovc3O9jrf3GiDTVqysbnDiZH+MK7ELQ5NeB09NuNrNWngv4r2FUN+rAOmMbkKv/7gf9lTV8RIlA+tIJ4C4bUDcYTALLpdyx75CUhkp1JZaviuqsNDzNxe9Asi0FStrGpzYb2+LJ5siIMoonP7zhYmjgTqbIIptOAbQFD7R8ggqpgSgUoafa5rzyVZBMma9Hn6u5p+xfTWj6BBidyxbQnskszcxElPzV+5odGDRXFGeMialHRn4A+KE8yqM7d8HsoZkniMXvheRotmedai0sef+eKyxGVZ8K+wtXd9qhya7eHiw3UE8HdRNzWWmUc1XS5akeCK5RzPIXa++/MZBK3uHJx0q3WZwYiw4BS6iInQ0PPOb9lMX9zTf1gS4crfSbGiaHkq6CFDU+fG1atdP8Gt9E6/MOgrBobpmyTohexMyo6hZkgzUVx8vzpWV34zwIxsgf1qdf9FeC+xXUxg5tDMTYtwnKkIl99rLoU+n3LlszQEAqyr3SnJYD466xhig+pzPdU1uxZds3i7IewRNw/5aece7GLPgcPI7oCqhrAtj9JPemZfzqRxasgEy4Z/51XYW/LIp5xNM7DRraHI83Duia2409tROAJe6BpFjiICsS9GA+l0DCJ0Pzvy+ohre3iMcRlDZ0gpcgWziMmJoX3KpU3QUsu9YuoTfiY+jW1kAeWDNyw/vbmGfV4d9z6mOTE2GegH3d0L5xYmju2YJYZzAngzfjQhpneo7CkDXdTyJbc7JvvBwvfTlVc/+1QXJkBjDf9+at0jyI0KyADJmeT7xKPD4RMBzCAi3jDLoIdks/MUwObM/TBzYvwshbG8BXCF8lq8Wz4FOFyVdCCiqVxc2jze2wEvfCu/f7C4Gzgi4v0uRmxwHO5zqzSTljyyVPO4lV7z1lZX3H2/Fq6QI6I86Ypt1k04Hf5twVY9cU7jlDOA68uxHuJzTQNwAoOIG9FDIim93w7FumSG7VzrdbAWHSDI8KZpmWQacKt2XJBqov32yOPVHnfkAAAzJSURBVPevUviQDJApK/IdzU7w/5tjPFINT0kAq0jiggVXXQoD4nq6ybPNpwHqheOqpShTC3VQTD9ACek9RCHHIIu9vPuQqx+1Trd0FMI7li6RlPVGEkC++CJP99j3ieqew8nVHkd9sc26nkLw3I3cqWdZEljVUqEAF0FMwpQMVMoQTgGe+HKn6L1GRUsrtHFkmfFGI3YHf7SiN3RvzdSbcubmiK7jJAHkgddeKdvd5JrhDUO+aDuyTxLUtwm7Mcy78mLITIjlZCeUIxBRXBqguK57tA4l1bW2wdNbhOM+og162FOlvK+bWse/vSJ0BzctWnyh2LiUBJAJ/8o/bWfAa8cvMWa8/dys10FKlPDLTjFGPTx+/Sje7Oi4tQ5w9V5vWQmq9ihlGCBTIi/Pz2wph9pW4SNxMnOQGUSNQjbssmPmRRjRIWjdsWyp6MOS4gDBGI3558sMi7F4XTW0I5OmWEogQu7ey4fC0JQEXsqYGOQ0+cZU1wVCpmgqVEfQ7r5u4qV9qK4RXikXzvXG5ZioJLNqbdij7Db9l3nC7zSKDvo/rnn5yn0trGIBKEoqjouWlFmEtHvuhmtATwucWBPPUzKTaNVFPjIe3DNHp0vA7vq0Opzw+Jc7RT0VWuxO0RnGW7ursRdJMeimf7h48QdCvIkC5O7Vqwp+sTB3eSugL9tLOdHqHWWCJaNHiLLl9t2q2qNa8jVRBhSvgAD1GgYokn8GJV22uVzw2P++FQWHkabhgEy3Ek9EcrocwLLK5sbOiKJ/XP/Qw5d7BZAJ/8x32dnAuxwUEsps0EOKyMUhaR8fYYS/XH+luL0wC7jpJODG4H6hDMUNABTbD0Bg1iDKaLDZ4e9by91x5mKFhNw2tYl77YrRkfK50rMIQgjvWiZ83Cs6g4x+MV9cS1Kk83GdS3slQPPZdwGFuk6NNsPD1wp+iXRqjoGt2gdg4w8U8rGY0rozJQGVIu05lOONzfCSiCt7R6dqnVzxCaU0QEg/YrfqggB5/O1Xb/+syvmWNCsEXi2xe5EOjiXPJGcbkKNHsFQFfFI64i4C5mTBfUZnq/1S1wCry6Wd4JGcu0cbW4C8uOur4nTaFY9vHxWnX7Hq/pwFfDIIAmTKSys3NbvwTb5SgNL9pJgjwSyS+aSjzz7RJsi9VnxP0p1H7LAAJjfx1hoS16u0CPLokaVTVC9AMX0B6YWPu7sT3nToGHx+RHoONqvDBdVW0Xs2efyL1GZYF7hcyi7nDAjt2r5sySjPALJiZXWzn+LNldLsNf16QaVF2vk8iWF/cvxV50J0PeEBW2sAE7cVRllD8vJCGwAlDRbddAvJQrKTMDIywBNfK+Jz5Y+i9DIrkqacW5bk8qbHEZpB0Njl+QyD5QdV+UNxQn0OSY6T7AJBlg5LrxsBSSZ538Cc/ZOs6s5WAHsLAGMHcDkAk3/P/g4kHQ7frEPi6BENQJIk0Mb2ZAm0sf3/DVHu1DveFjLIiQOiUERm9z5IcNrxRou3XXvcXmmAEEam2W10Xl4e5/TPC5BH3liZ+HUtrvVYkgBreGmvRGiW8YTy4msugwtihOPdA0xEWex8few0lP0i7xkOcqp1ssl/4CACqrEPGRFFD1nz0MMHuBTIC5DpL73Uv95FBfe5ZieJiaAXJscBiVeQWq4fkAozLsqQWj0o6hGXEDJrSF12dghlczKy26ihEDViRSIQvmzrsmWcgS68AFlU8PILOxvYxWoI6U+aJPzWJuN12MTICPcxsFEXcHFistRIBtb2U5VQvE+eWz+JEGxuc0CNiC+WLGa8qKwGQC6J1X9V8EAOZ0IHXoD8btXLDSdsbJwXsgRs0xF9kqBBxOu3M/NkX/KHyy6C4Sn8Dn0BKywAWBxOWP7Nj9AoQ2Yij4Gm4Eh9i6w9ii/0oPQ+JEpHMV/m5upkLbGC9YJQqoEuSooDO3m/T0YZkhQPd10+BHSUpFgbGZTVqUruKL44dgo+PCR/pUy+FH71KrZcHZkIVZL9xH0XpWDhuzDknUG0DhCiW/JUG5bpsUtyPpH7kmSzAqdcChq4O6lD9U3w2nd7Pfr2d7hYON3in2NcKSohdyHkTkTJEgYIjzbJU24kRkTufTAB1x9HDAWjjnNmVtJ2smjVWG2w9vt9UN0q/xIvUqeDIw3Nko/EZTGmYGU13N/DABEwEFkyZSZEe5RsoONFXQXt7zGpV8t/hoN18hK2dXRGMlDur/GsrccMe9xQ+dRAsgDy7Ltrhr1fYReOkvFYuMBtKCVLIxf3BGB3XnYRDE0WdiFXQ3KGZd17jC+OnfaIvJ6ioMXhVC0a0COmJDRSeqM+Mdkw7Zl7F23q3jXnHuTR11++46s69g0JfGquSmZ8DLCyF1ztaiD7k6WjR0JCZAScTSivmn7IjfZXx07D+wePedxHXIQBfqgIMs/ks9IqDZBLovXPFzyYs0QSQO5bs+qvP7cwT3is+SBvSJYbAxNiwOr0bCMYF2GE2y4ezJscwhv1kHuAzUdOwmdHTkqK1+Dqi8hXabG54z6CtSh9kpVg1K39NGfxvZIActOKlS82OXFOsCpPKb6Juzx5iNJTj24SbffAlcPdLisdb5R4ypuTYeGzoydh8+GTnpJwO9VF6nWwtzr432tUOsKQBvT6t48s6RE5y7nEuuGfK960sej3HltCQw3JfcBFyXHQ6uFsQlRBgDJmQB+YMjDNo6XXG7v3w+5K75ZCCZFG+LmqHuwKZD0MBPMyjAtcCnpMm2jY/PWSpRMlzSDTV6zcUu/E1wWCIgKFB3IcHB9p8HhZ0yHH8OQEmDSwv6gj5KlmCxTu/RVONnvnHEiWU41tjqDbhIvZnWVZcCqYnT9eT53c/HBuj8RgnDNI1sqVh2vsWFteemIal/i5JzfwXKSJG8fIPskwe+jALjm6vjtTDcX7DytyF0FCPMRy6UoUO+CqKZ1QLlaHWj/PXdIjhoATIDfnr2yoc2BN+mEpYWk9TcGA2ChZQUZC/ZKQ3yHJ8bD9ZKXX7BGDkkduTjQF7k2410KefRBUyQzwRgqx25b2fMuQEyATX1rpsLpwwCaqVkLBStAg+5OhKXFgcXh22qUED51pkBDjnaerQUZwoNIs+Iye0l69FIXwTo6E1pwAuW55PjlmF8144jNtBHhHZANM8mzJcaNXUiRyQkaiA5VOHK0kj0rTUhoghD+u23ROEISCo6LSBiP0SFZHkvxBTny3N3ykmCLh29Oh+9ai0peF15gjI/Lnz+9yORQGiDcjlKdtlEEHaXHRHl80CrFEDEZiyEmiaCmJ3VQQL2BIKg2QUTFR0avmzetybMgJkDHL81k2vMRSZCBckZrsDlTydlYh/l7Eb2pfTfBf8imiWICzD37K9cPm7/1Cc2TsO/Pnd3lgkXufgQE99vaqwT+1QEqyHv+p3o6zq+zY+zQaSmkmCOkQvyfiDElSdcopxG3lSH2z6OM1cmhqpa7DYZMdz9MheySN2AGR9M7DNmbZcDPVekGN5TuuzCayN+JPv/PyZRU2uGd/C5tpoNAldhb3Drbcvf4eIEOS2k/Q23giGsnpGJlx1Hixyd+yK9m/mD+WgUJsBAVnbCyUDzLr64fGUE8su2PBCTk8yAYIF/G8t1fEnLJBDMXSQw00euKglb3C6sKBFUkkRys+qksuC5NNkRAbYXCfgBGXFAKKZrvDQ39iHzEeIN10BkiCgXYOjNJ/+n1964OZZso1qLetOm9untfZ+xQBiJC+nilYkdxM6397xMIMb3TiQXoKXWxhIMnFBseDPAEyFkKaDRoBjtZBEwtovw6hfZlmOJpshE1/vm3ej2orRnWA8Anw0IoVRqvZbDAie3I0DXmnrez0Y7bw7b3aBg90+hlmqq63ATY1MGyezYbrBkXXO/LuyhN+/01FofwGEDGZ8vLydBdcdemcQw22tN21zRG9zfopThaG1tgcplanK2D5FpMrVD9PjDSwcUZ9A4vZXa0M3nFxQowtFlu/bd53Ygtf2s9A0FXQD7R/l7w7oZnW5Z5udVx8sL7V3OxwGBCAAQPQJI4DB8nbioEwGOTyQNwzEHnIEYMLELRlxEc7082GykQD2qynmv583/T7pGUNl9uxD+sHPUDEdFW85YOMMw22C49bXfGHG6x6swEuiTXobrQ42fQam9PcZHdoXgdiOuL63KTX4eRIvSPWoDvjYpntR5rtmy+Kj2LTYiIsvUzGkyMvsO8ZNmyu15tgT3jzZZvw4ODQdnl5uf6MtXp8fZtrbL3dcVFtm7NXldURecpio+0MYzZSKA4hMLMYDC4MtIthkbcXgUoZnaYoTGLjdQAMRYEDs9DqYNlGPUVZ+saYmN4moy3RZKiJ1VOH4iP122aOHfYpQul+W+MrJbdadP4fjGrAuZWTmR8AAAAASUVORK5CYII=',
                'phone' => base64_encode($val->passenger->phone),
                'from_location' => base64_encode($val->from_location),
                'from_latitude' => base64_encode($val->from_latitude),
                'from_longitude' => base64_encode($val->from_longitude),
                'to_location' => base64_encode($val->to_location),
                'to_latitude' => base64_encode($val->to_latitude),
                'to_longitude' => base64_encode($val->to_longitude),
                'total_cost' => base64_encode('$' . $val->total_cost),
                'distance' => base64_encode($val->distance . 'Km'),
                'order_status' => base64_encode($val->order_status),
                'order_date' => base64_encode($val->order_date),
                'no_of_passengers' => base64_encode($val->no_of_passengers),
                'estimate_time' => base64_encode($minutes . ' Min'),
            ];
        }
        return $data;
    }

    public function actionUploadFile() {
        try {
            $basePath = dirname(\Yii::$app->basePath);

            $obj = new \stdClass();
//$obj->name = $_POST['name'];
//$obj->file = $_POST['UserForm']['file'];
//$obj->file = $_POST['file'];


            if (Yii::$app->request->isPost && isset($_POST['file'])) {
                $postdata = $_POST;

                if (isset($postdata) && !empty($postdata)) {
//below 2 lines are working
                    $icon = $this->base64_to_image($postdata['file']);
                    $image1 = $icon;

//return 'how are you '; //$postdata['file'];
//return $image1; //$user[
//return  dirname(\yii\helpers\Url::base(true)) . '/backend/app/uploads/users/image/' . $icon;
//];
                    return 'successfully uploaded';
                } else {
                    return [
                        'code' => 202, //invalid input
//'message' => $this->getConfigureValueByKey('INVALID_INPUT')
                    ];
                }
            }
        } catch (Exception $ex) {
            return [
                'code' => 999, // invalide access
                'message' => 'INVALID_ACCESS', //$this->getConfigureValueByKey('INVALID_ACCESS')
            ];
        }
    }

}
