<?php

namespace app\baseControllers;

use Yii;
use yii\web\Controller;
use yii\filters\ContentNegotiator;
use yii\web\Response;
use backend\components\PhpGoogleTranslate\src\GoogleTranslate;
use common\models\siteconfiguration\SiteConfiguration;
use common\models\user\Users;
use common\models\userdevice\UserDevice;

require_once('..//vendor/autoload.php');

/**
 * Auth controller
 */
class AuthController extends \yii\rest\Controller {

    public $cData;
    public $trans;

    /**
     * @inheritdoc
     */
    public function init() {
        $this->trans = new GoogleTranslate();
        session_start();
    }

    public static function allowedDomains() {
        return [
            '*',
        ];
    }
    
    public function behaviors() {
        $behaviors = array_merge(parent::behaviors());

        $behaviors['contentNegotiator'] = [

            'class' => ContentNegotiator::className(),
            'formats' => [
                'application/json' => Response::FORMAT_JSON,
            ],
            // For cross-domain AJAX request
            
        ];

        $behaviors['corsFilter'] = [

           
            // For cross-domain AJAX request
            
                'class' => \yii\filters\Cors::className(),
                'cors'  => [
                    // restrict access to domains:
                    'Origin'                           => static::allowedDomains(),
                    'Access-Control-Request-Method'    => ['POST','GET','PUT','PATCH','COPY','HEAD','OPTIONS'],
                    'Access-Control-Allow-Credentials' => true,
                    'Access-Control-Request-Headers' => ['*'],
                    'Access-Control-Expose-Headers' => [],

                    'Access-Control-Max-Age'           => 36000000,                 // Cache (seconds)
                ],
            
        ];
            $behaviors['authenticator']['except'] = ['options'];

        return $behaviors;
    }

    public function loadRequestData($rVar, $cVar = '') {
        if (\Yii::$app->request->post($rVar) != null) {
            if ($cVar == '') {
                $this->cData[$rVar] = \Yii::$app->request->post($rVar);
            } else {
                $this->cData[$cVar] = \Yii::$app->request->post($rVar);
            }
        } else {
            if (\Yii::$app->request->get($rVar) != null) {
                if ($cVar == '') {
                    $this->cData[$rVar] = \Yii::$app->request->get($rVar);
                } else {
                    $this->cData[$cVar] = \Yii::$app->request->get($rVar);
                }
            }
        }
    }

    public function checkUserAccess($data,$postdata) {
        if(isset($data['Authorization']) && !empty(['Authorization']))
        {
            $userCheck = UserDevice::find()->where(['is_active' => ACTIVE, 'is_delete' => INACTIVE])->andwhere(['user_access_token' => $data['Authorization'],'user_id' => $postdata])->one();

            if ($userCheck != null) {
                return true;
            } else {
                return true;
            }
        }
        else
        {
            return true; 
        }
    }

    public function __print($arr, $exit = true) {

        if ($exit) {
            \Yii::$app->end();
        }
    }

    public function getConfigureValueByKey($key) {

        $lang = isset(apache_request_headers()['Accept-Language']) ? apache_request_headers()['Accept-Language'] : 'en';

        $model = SiteConfiguration::findOne(['config_key' => $key]);
        if ($model != null) {
            if ($lang == 'ch') {
                return $model->config_value_ch;
            } else {
                return $model->config_value;
            }
        } else {
            return 'Undefine Key';
        }
    }
}