<?php

namespace app\baseControllers;

use Yii;
use yii\web\Controller;
use yii\filters\ContentNegotiator;
use yii\web\Response;

/**
 * Site controller
 */
class cController extends \yii\rest\Controller {

    public $cData;

    /**
     * @inheritdoc
     */
    public function behaviors() {
        $behaviors = parent::behaviors();

        $behaviors[] = [
            'class' => ContentNegotiator::className(),
            'formats' => [
                'application/json' => Response::FORMAT_JSON,
            ],
        ];

        return $behaviors;
    }

    public function loadRequestData($rVar, $cVar = '') {
        if (\Yii::$app->request->post($rVar) != null) {
            if ($cVar == '') {
                $this->cData[$rVar] = \Yii::$app->request->post($rVar);
            } else {
                $this->cData[$cVar] = \Yii::$app->request->post($rVar);
            }
        } else {
            if (\Yii::$app->request->get($rVar) != null) {
                if ($cVar == '') {
                    $this->cData[$rVar] = \Yii::$app->request->get($rVar);
                } else {
                    $this->cData[$cVar] = \Yii::$app->request->get($rVar);
                }
            }
        }
    }

    public function __print($arr, $exit = true) {

        if ($exit) {
            \Yii::$app->end();
        }
    }

}
