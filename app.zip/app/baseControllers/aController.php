<?php

namespace app\baseControllers;

use app\auth\QueryParamAuth;
use yii\filters\auth\CompositeAuth;

/**
 * Site controller
 */
class aController extends cController {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        $behaviors = parent::behaviors();

        $behaviors['authenticator'] = [
            'class' => CompositeAuth::className(),
            'authMethods' => [
                ['class' => QueryParamAuth::className()],
            ]
        ];

        return $behaviors;
    }

}
