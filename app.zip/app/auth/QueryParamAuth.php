<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace app\auth;

use yii\filters\auth\AuthMethod;

/**
 * QueryParamAuth is an action filter that supports the authentication based on the access token passed through a query parameter.
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class QueryParamAuth extends AuthMethod
{
    /**
     * @var string the parameter name for passing the access token
     */
    public $tokenParam 	= 'access-token';

    /**
     * @inheritdoc
     */
    public function authenticate($user, $request, $response)
    {
        $accessToken = \Yii::$app->custom->accessToken;
        
        if ($accessToken == null) {
        	$this->unAuthorizedAccess();
        }
        
        if (is_string($accessToken)) {
            $identity = $user->loginByAccessToken($accessToken, get_class($this));
            if ($identity !== null) {
            	return $identity;
            }else{
            	$this->unAuthorizedAccess();
            }
        }
        
        return null;
    }
    
    /**
     * @inheritdoc
     */
    public function unAuthorizedAccess(){
    	return \Yii::$app->custom->app->unAuthorizedAccess;
    }
    
}
